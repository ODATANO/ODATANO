"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTransaction = exports.getHsmSigner = exports.shutdownAppContext = exports.startWalletWorkerIfConfigured = exports.loadWalletWorkerConfigFromEnv = exports.startCrawlerIfConfigured = exports.loadCrawlerConfigFromEnv = exports.loadHsmConfigFromEnv = exports.loadConfigFromEnv = exports.getCardanoTxBuilder = exports.getCardanoClient = exports.getCardanoIndexer = exports.getAppContext = exports.CardanoTransactionBuilder = exports.CardanoIndexer = exports.CardanoClient = void 0;
exports.initialize = initialize;
exports.shutdown = shutdown;
exports.getStatus = getStatus;
const cds_1 = __importDefault(require("@sap/cds"));
const logger = cds_1.default.log('ODATANO');
// Re-export key types and classes for programmatic consumers
var cardano_client_1 = require("../srv/blockchain/cardano-client");
Object.defineProperty(exports, "CardanoClient", { enumerable: true, get: function () { return cardano_client_1.CardanoClient; } });
var cardano_indexer_1 = require("../srv/blockchain/cardano-indexer");
Object.defineProperty(exports, "CardanoIndexer", { enumerable: true, get: function () { return cardano_indexer_1.CardanoIndexer; } });
var cardano_tx_builder_1 = require("../srv/blockchain/cardano-tx-builder");
Object.defineProperty(exports, "CardanoTransactionBuilder", { enumerable: true, get: function () { return cardano_tx_builder_1.CardanoTransactionBuilder; } });
// Re-export server accessors
var server_1 = require("../srv/server");
Object.defineProperty(exports, "getAppContext", { enumerable: true, get: function () { return server_1.getAppContext; } });
Object.defineProperty(exports, "getCardanoIndexer", { enumerable: true, get: function () { return server_1.getCardanoIndexer; } });
Object.defineProperty(exports, "getCardanoClient", { enumerable: true, get: function () { return server_1.getCardanoClient; } });
Object.defineProperty(exports, "getCardanoTxBuilder", { enumerable: true, get: function () { return server_1.getCardanoTxBuilder; } });
Object.defineProperty(exports, "loadConfigFromEnv", { enumerable: true, get: function () { return server_1.loadConfigFromEnv; } });
Object.defineProperty(exports, "loadHsmConfigFromEnv", { enumerable: true, get: function () { return server_1.loadHsmConfigFromEnv; } });
Object.defineProperty(exports, "loadCrawlerConfigFromEnv", { enumerable: true, get: function () { return server_1.loadCrawlerConfigFromEnv; } });
Object.defineProperty(exports, "startCrawlerIfConfigured", { enumerable: true, get: function () { return server_1.startCrawlerIfConfigured; } });
Object.defineProperty(exports, "loadWalletWorkerConfigFromEnv", { enumerable: true, get: function () { return server_1.loadWalletWorkerConfigFromEnv; } });
Object.defineProperty(exports, "startWalletWorkerIfConfigured", { enumerable: true, get: function () { return server_1.startWalletWorkerIfConfigured; } });
Object.defineProperty(exports, "shutdownAppContext", { enumerable: true, get: function () { return server_1.shutdownAppContext; } });
// Re-export HSM signer for programmatic access
var hsm_signer_1 = require("../srv/blockchain/signing/hsm-signer");
Object.defineProperty(exports, "getHsmSigner", { enumerable: true, get: function () { return hsm_signer_1.getHsmSigner; } });
// Re-export pure CBOR utilities (no CAP round-trip needed)
var cbor_1 = require("../srv/cbor");
Object.defineProperty(exports, "parseTransaction", { enumerable: true, get: function () { return cbor_1.parseTransaction; } });
/**
 * Initialize the ODATANO plugin.
 * Loads configuration from cds.env.requires["odatano-core"] OR environment variables,
 * then initializes all blockchain components.
 */
async function initialize() {
    const { loadConfigFromEnv, loadHsmConfigFromEnv, initializeFromConfig, getAppContext } = await Promise.resolve().then(() => __importStar(require('../srv/server')));
    let alreadyInitialized = false;
    try {
        getAppContext();
        alreadyInitialized = true;
    }
    catch {
        // not initialized yet — initializeFromConfig will create the context
    }
    const config = loadConfigFromEnv();
    const hsmConfig = loadHsmConfigFromEnv();
    await initializeFromConfig(config, undefined, hsmConfig);
    if (!alreadyInitialized) {
        logger.info('ODATANO core initialized');
    }
    // Start the pre-sync crawler if configured (plugin mode). Non-fatal.
    const { startCrawlerIfConfigured, startWalletWorkerIfConfigured, redriveInterruptedSubmissionsIfConfigured } = await Promise.resolve().then(() => __importStar(require('../srv/server')));
    await startCrawlerIfConfigured();
    // Start the wallet worker if configured (plugin mode). Non-fatal.
    await startWalletWorkerIfConfigured();
    // Re-drive deferred submissions interrupted by a restart (plugin mode). Non-fatal.
    await redriveInterruptedSubmissionsIfConfigured();
}
/**
 * Shutdown the ODATANO plugin.
 * Cleans up all backend connections (especially Ogmios WebSocket).
 */
async function shutdown() {
    const { shutdownAppContext } = await Promise.resolve().then(() => __importStar(require('../srv/server')));
    await shutdownAppContext();
    logger.info('ODATANO core shutdown');
}
/**
 * Get the current status of the plugin.
 */
function getStatus() {
    try {
        const { getAppContext } = require('../srv/server');
        const ctx = getAppContext();
        return {
            initialized: true,
            network: ctx.cardanoClient.network,
            backends: ctx.cardanoClient.listBackends(),
        };
    }
    catch {
        return { initialized: false };
    }
}
//# sourceMappingURL=index.js.map