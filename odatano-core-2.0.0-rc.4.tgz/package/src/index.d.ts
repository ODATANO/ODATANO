export { CardanoClient } from '../srv/blockchain/cardano-client';
export type { CardanoClientConfig, Network, BackendName, TransactionBuilderName } from '../srv/blockchain/cardano-client';
export { CardanoIndexer } from '../srv/blockchain/cardano-indexer';
export { CardanoTransactionBuilder } from '../srv/blockchain/cardano-tx-builder';
export { getAppContext, getCardanoIndexer, getCardanoClient, getCardanoTxBuilder, loadConfigFromEnv, loadHsmConfigFromEnv, loadCrawlerConfigFromEnv, startCrawlerIfConfigured, loadWalletWorkerConfigFromEnv, startWalletWorkerIfConfigured, shutdownAppContext, } from '../srv/server';
export { getHsmSigner } from '../srv/blockchain/signing/hsm-signer';
export type { HsmConfig, HsmSignResult } from '../srv/utils/types';
export { parseTransaction } from '../srv/cbor';
export type { ParsedTransaction, ParsedInput, ParsedOutput, ParsedAsset, ParsedWitnesses, } from '../srv/cbor';
/**
 * Initialize the ODATANO plugin.
 * Loads configuration from cds.env.requires["odatano-core"] OR environment variables,
 * then initializes all blockchain components.
 */
export declare function initialize(): Promise<void>;
/**
 * Shutdown the ODATANO plugin.
 * Cleans up all backend connections (especially Ogmios WebSocket).
 */
export declare function shutdown(): Promise<void>;
/**
 * Get the current status of the plugin.
 */
export declare function getStatus(): {
    initialized: boolean;
    network?: string;
    backends?: string[];
};
//# sourceMappingURL=index.d.ts.map