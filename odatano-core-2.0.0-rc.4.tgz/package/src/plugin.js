"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cds_1 = __importDefault(require("@sap/cds"));
const path_1 = __importDefault(require("path"));
const logger = cds_1.default.log('ODATANO');
const pluginRoot = path_1.default.resolve(__dirname, '..');
let initialized = false;
/**
 * CAP Plugin registration for @odatano/core
 * This is executed when the plugin is loaded via cds-plugin.js
 */
// Register service kinds so consumer apps can configure via cds.env.requires
if (!cds_1.default.env.requires) {
    cds_1.default.env.requires = {};
}
if (!cds_1.default.env.requires.kinds) {
    cds_1.default.env.requires.kinds = {};
}
cds_1.default.env.requires.kinds['odatano-core'] = {
    impl: '@odatano/core',
    model: [
        '@odatano/core/db/schema',
        '@odatano/core/srv/cardano-service',
        '@odatano/core/srv/cardano-tx-service',
        '@odatano/core/srv/cardano-sign-service',
        '@odatano/core/srv/cardano-indexer-service',
        '@odatano/core/srv/cardano-worker-service'
    ]
};
// CRITICAL: Also set model directly on the requires entry.
// CAP's _link_required_services() merges kind→requires BEFORE cds-plugin.js runs,
// so the model array on the kind is never merged. Set it directly.
const req = cds_1.default.env.requires['odatano-core'];
if (req) {
    req.model = [
        '@odatano/core/db/schema',
        '@odatano/core/srv/cardano-service',
        '@odatano/core/srv/cardano-tx-service',
        '@odatano/core/srv/cardano-sign-service',
        '@odatano/core/srv/cardano-indexer-service',
        '@odatano/core/srv/cardano-worker-service'
    ];
}
logger.debug('Plugin registered');
/**
 * Rewrite @impl paths for plugin mode.
 * CDS files use relative @impl (e.g. 'srv/cardano-service') which resolves from cds.root.
 * In standalone mode cds.root IS the package root, so it works.
 * In plugin mode cds.root is the consumer app — rewrite to package-qualified paths
 * so CAP resolves via Node module resolution (node_modules/@odatano/core/srv/...).
 */
cds_1.default.on('loaded', (model) => {
    if (path_1.default.resolve(cds_1.default.root) === pluginRoot)
        return;
    const defs = model.definitions ?? {};
    for (const def of Object.values(defs)) {
        if (def['@impl'] === 'srv/cardano-service') {
            def['@impl'] = '@odatano/core/srv/cardano-service';
        }
        else if (def['@impl'] === 'srv/cardano-tx-service') {
            def['@impl'] = '@odatano/core/srv/cardano-tx-service';
        }
        else if (def['@impl'] === 'srv/cardano-sign-service') {
            def['@impl'] = '@odatano/core/srv/cardano-sign-service';
        }
        else if (def['@impl'] === 'srv/cardano-indexer-service') {
            def['@impl'] = '@odatano/core/srv/cardano-indexer-service';
        }
        else if (def['@impl'] === 'srv/cardano-worker-service') {
            def['@impl'] = '@odatano/core/srv/cardano-worker-service';
        }
    }
});
/**
 * Initialize blockchain components when services are served
 */
cds_1.default.on('served', async () => {
    if (initialized)
        return;
    // Honor SKIP_AUTO_INIT so consumer test suites can mount the plugin without it
    // opening real backend connections (matches srv/server.ts's standalone hook).
    if (process.env.SKIP_AUTO_INIT === 'true') {
        logger.info('Skipping plugin auto-initialization (SKIP_AUTO_INIT=true)');
        return;
    }
    logger.debug('Plugin activation triggered');
    try {
        const core = await Promise.resolve().then(() => __importStar(require('./index')));
        await core.initialize();
        logger.info('Plugin initialized successfully');
        initialized = true;
    }
    catch (err) {
        // Don't throw - plugin failure shouldn't crash the host app
        logger.error('Failed to initialize plugin:', err);
    }
});
/**
 * Graceful shutdown handler
 */
cds_1.default.on('shutdown', async () => {
    if (!initialized)
        return;
    try {
        logger.debug('Shutting down...');
        const core = await Promise.resolve().then(() => __importStar(require('./index')));
        await core.shutdown();
        initialized = false;
        logger.info('Plugin shutdown complete');
    }
    catch (err) {
        logger.error('Error during shutdown:', err);
    }
});
//# sourceMappingURL=plugin.js.map