"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cds_1 = __importDefault(require("@sap/cds"));
const backend_request_handler_1 = require("./utils/backend-request-handler");
const errors_1 = require("./utils/errors");
const mappers_1 = require("./utils/mappers");
const validators_1 = require("./utils/validators");
const cbor_1 = require("./cbor");
const server_1 = require("./server");
const external_signer_1 = require("./blockchain/signing/external-signer");
const hsm_signer_1 = require("./blockchain/signing/hsm-signer");
const cose_verifier_1 = require("./blockchain/signing/cose-verifier");
const signing_helper_1 = require("./utils/signing-helper");
const tx_utils_1 = require("./utils/tx-utils");
const submission_finalizer_1 = require("./blockchain/signing/submission-finalizer");
const { SELECT, UPDATE } = cds_1.default.ql;
const logger = cds_1.default.log('CardanoSignService');
/**
 * Verify that a build exists and, when an address is provided, that it matches
 * the build's senderAddress. Always fetches the build from DB.
 */
async function verifyBuildOwnership(req, db, buildId, address, TransactionBuilds, actionName) {
    const build = await db.run(SELECT.one.from(TransactionBuilds).where({ id: buildId }));
    if (!build)
        (0, errors_1.rejectInvalid)(req, actionName, 'Build not found', 'buildId');
    // rejectInvalid returns `never` → build is narrowed to non-null here
    if (address && build.senderAddress !== address) {
        (0, errors_1.rejectInvalid)(req, actionName, 'Address does not match build owner', 'address');
    }
    return build;
}
/**
 * Check if a signing request has expired and update its status.
 * @returns true if expired, false otherwise
 */
async function checkAndExpireSigningRequest(db, signingRequest, SigningRequests) {
    const now = new Date().toISOString();
    const result = await db.run(UPDATE.entity(SigningRequests)
        .set({ status: 'expired' })
        // status filter: only PENDING requests may expire — without it an old
        // 'submitted'/'verified' record would be flipped to 'expired' here
        .where({ id: signingRequest.id, status: 'pending', expiresAt: { '<=': now } }));
    if (result > 0) {
        signingRequest.status = 'expired';
        return true;
    }
    // NOTE: when the surrounding request is subsequently rejected, CAP rolls the
    // managed transaction back — including this update. The expiry status is
    // then re-applied on the next touch; reads always re-check expiresAt.
    return false;
}
/**
 * Resolve the key hashes that MUST witness a signing request:
 * - the `required_signers` declared in the unsigned tx body (extra_signatories)
 * - the payment KEY hash of the associated build's senderAddress (the fee
 *   payer's inputs require its witness on-chain anyway; script credentials
 *   are skipped — scripts witness via redeemers, not vkeys)
 *
 * Previously NONE of this was checked: any valid signature from ANY key
 * flipped the request to 'verified' / let SubmitVerifiedTransaction proceed.
 * Returns undefined when nothing is derivable (no over-restriction).
 */
async function resolveRequiredSigners(db, signingRequest, TransactionBuilds) {
    const signers = new Set();
    try {
        const parsed = (0, cbor_1.parseTransaction)(signingRequest.unsignedTxCbor);
        for (const s of parsed.requiredSigners ?? [])
            signers.add(s.toLowerCase());
    }
    catch (err) {
        // body-hash verification still protects integrity; just log
        logger.warn(`Could not parse unsigned tx for required_signers: ${err instanceof Error ? err.message : String(err)}`);
    }
    if (signingRequest.build_id) {
        const build = await db.run(SELECT.one.from(TransactionBuilds).where({ id: signingRequest.build_id }));
        if (build?.senderAddress) {
            const cred = (0, validators_1.extractPaymentCredential)(build.senderAddress);
            if (cred && !cred.isScript)
                signers.add(cred.hash.toLowerCase());
        }
    }
    return signers.size > 0 ? [...signers] : undefined;
}
// submitAndFinalize + FinalizeParams moved to blockchain/signing/submission-finalizer.ts
// (shared with the boot-time redrive of interrupted deferred submissions).
/**
 * Enforce HSM role check if hsm.requiresRole is configured.
 * Rejects with 403 if the user lacks the required role.
 */
function enforceHsmRole(req, actionName) {
    const hsmConfig = (0, server_1.getHsmConfig)();
    if (hsmConfig?.requiresRole && !req.user?.is(hsmConfig.requiresRole)) {
        req.reject(403, `Action '${actionName}' requires role '${hsmConfig.requiresRole}'`);
    }
}
/**
 * Cardano Sign Service Implementation
 * Handles transaction signing operations & some additional data queries.
 */
module.exports = (srv) => {
    logger.info('Module loaded - registering handlers');
    const { SigningRequests, AddressSigningRequests, TransactionBuilds, } = require('#cds-models/CardanoSignService');
    /**
     * before-READ handler for SigningRequests: bulk expiration check
     * Atomically expires all pending requests past their TTL (handles both single and collection reads)
     * Throttled to run at most once per 60 seconds to avoid write amplification on every READ.
     */
    let lastExpiryCheck = 0;
    const EXPIRY_CHECK_INTERVAL_MS = 60_000;
    srv.before('READ', SigningRequests, async (req) => {
        const now = Date.now();
        if (now - lastExpiryCheck < EXPIRY_CHECK_INTERVAL_MS)
            return;
        lastExpiryCheck = now;
        await cds_1.default.tx(req).run(UPDATE.entity(SigningRequests)
            .set({ status: 'expired' })
            .where({ status: 'pending', expiresAt: { '<=': new Date().toISOString() } }));
    });
    /**
     * Create a new signing request for external signing
     * Persists the request for audit trail and workflow tracking
     * @param req - CDS request object (with buildId)
     * @returns {SigningRequest} Signing request entity
     */
    srv.on('CreateSigningRequest', async (req) => {
        logger.debug('CreateSigningRequest Action handler called');
        const { buildId, message } = req.data;
        // Validate inputs
        const errors = (0, validators_1.validateTransactionInputs)({ buildId }, ['buildId']);
        (0, errors_1.throwIfValidationErrors)(req, 'CreateSigningRequest', errors);
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            // Fetch the build
            const build = await db.run(SELECT.one.from(TransactionBuilds).where({ id: buildId }));
            if (!build)
                (0, errors_1.rejectInvalid)(req, 'CreateSigningRequest', 'Build not found', 'buildId');
            // Check if signing request already exists for this build
            const existingRequest = await db.run(SELECT.one.from(SigningRequests).where({ build_id: buildId, status: 'pending' }));
            if (existingRequest) {
                logger.info({ buildId, signingRequestId: existingRequest.id }, 'Returning existing signing request');
                return existingRequest;
            }
            // Create signing request using external signer module
            const signerModule = (0, external_signer_1.getExternalSignerModule)();
            const signingPayload = signerModule.createSigningRequest(build.id, build.unsignedTxCbor, build.txBodyHash, build.network, message);
            // Delegate persistence to indexer
            const signingRequestRecord = await (0, server_1.getCardanoIndexer)().persistSigningRequest(db, {
                buildId,
                signingPayload,
            });
            logger.info({ buildId, signingRequestId: signingRequestRecord.id }, 'Created signing request');
            return signingRequestRecord;
        });
    });
    /**
     * Get an existing signing request by ID
     * @param req - CDS request object (with signingRequestId)
     * @returns {SigningRequest} signing request entity
     */
    srv.on('GetSigningRequest', async (req) => {
        logger.debug('GetSigningRequest Action handler called');
        const { signingRequestId } = req.data;
        // Validate inputs
        const errors = (0, validators_1.validateTransactionInputs)({ signingRequestId }, ['signingRequestId']);
        (0, errors_1.throwIfValidationErrors)(req, 'GetSigningRequest', errors);
        // Fetch the signing request within transaction context
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const signingRequest = await db.run(SELECT.one.from(SigningRequests).where({ id: signingRequestId }));
            if (!signingRequest)
                (0, errors_1.rejectInvalid)(req, 'GetSigningRequest', 'Signing request not found', 'signingRequestId');
            // Check if expired and update status if needed
            if (signingRequest.status === 'pending') {
                await checkAndExpireSigningRequest(db, signingRequest, SigningRequests);
            }
            return signingRequest;
        });
    });
    /**
     * Verify signature of a signed transaction (unbound action)
     * @param req - CDS request with signingRequestId + signedTxCbor in data
     * @returns {SignatureVerification} Persisted signature verification entity
     */
    srv.on('VerifySignature', async (req) => {
        logger.debug('VerifySignature Action handler called');
        const { signingRequestId, signedTxCbor, signerType, signerInfo, address } = req.data;
        const errors = (0, validators_1.validateTransactionInputs)({ signingRequestId, signedTxCbor }, ['signingRequestId', 'signedTxCbor']);
        (0, errors_1.throwIfValidationErrors)(req, 'VerifySignature', errors);
        if (address && !(0, validators_1.isValidBech32Address)(address))
            (0, errors_1.rejectInvalid)(req, 'VerifySignature', 'Invalid bech32 address format', 'address');
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            // Fetch the signing request (@from already validated by framework)
            const signingRequest = await db.run(SELECT.one.from(SigningRequests).where({ id: signingRequestId }));
            if (!signingRequest)
                (0, errors_1.rejectInvalid)(req, 'VerifySignature', 'Signing request not found', 'signingRequestId');
            // Ownership check: verify address matches build owner (defense-in-depth)
            if (address && signingRequest.build_id) {
                await verifyBuildOwnership(req, db, signingRequest.build_id, address, TransactionBuilds, 'VerifySignature');
            }
            // Atomically CLAIM the pending request (pending → 'signed' = verification
            // in progress). Replaces the read-then-check pattern that let two
            // concurrent verifies both pass `status === 'pending'` and double-insert
            // verification records (last-writer-wins on status). The final status is
            // overwritten to 'verified'/'failed' by persistSignatureVerification.
            const now = new Date().toISOString();
            const claimed = await db.run(UPDATE.entity(SigningRequests)
                .set({ status: 'signed' })
                .where({ id: signingRequestId, status: 'pending', expiresAt: { '>': now } }));
            if (claimed === 0) {
                // re-read the committed state for an accurate message (a concurrent
                // verify may have moved it since our SELECT above)
                const current = await db.run(SELECT.one.from(SigningRequests).where({ id: signingRequestId }));
                if (current && current.status === 'pending' && current.expiresAt <= now) {
                    await db.run(UPDATE.entity(SigningRequests).set({ status: 'expired' }).where({ id: signingRequestId, status: 'pending' }));
                    (0, errors_1.rejectInvalid)(req, 'VerifySignature', 'Signing request has expired', 'signingRequestId');
                }
                (0, errors_1.rejectInvalid)(req, 'VerifySignature', `Signing request status is '${current?.status ?? 'unknown'}', expected 'pending'`, 'signingRequestId');
            }
            // Detect if signedTxCbor is a witness set (CIP-30) or a full signed transaction (cardano-cli)
            let fullSignedTxCbor;
            if ((0, signing_helper_1.isWitnessSetCbor)(signedTxCbor)) {
                // CIP-30 wallet returns only witness set — combine with unsigned tx
                fullSignedTxCbor = (0, signing_helper_1.combineTransactionWithWitnesses)(signingRequest.unsignedTxCbor, signedTxCbor);
                logger.debug({ signingRequestId }, 'Combined witness set with unsigned transaction for verification');
            }
            else {
                // Full signed transaction provided (e.g., from cardano-cli)
                fullSignedTxCbor = signedTxCbor;
            }
            // Verify the signature — bound to the keys that must actually witness
            // this transaction (declared required_signers + the build's fee payer)
            const requiredSigners = await resolveRequiredSigners(db, signingRequest, TransactionBuilds);
            const signerModule = (0, external_signer_1.getExternalSignerModule)();
            const result = signerModule.verifySignedTransaction(fullSignedTxCbor, signingRequest.txBodyHash, { requiredSigners });
            // Delegate persistence to indexer (store full signed tx for later submission)
            const verificationRecord = await (0, server_1.getCardanoIndexer)().persistSignatureVerification(db, {
                signingRequestId,
                signedTxCbor: fullSignedTxCbor,
                verificationResult: result,
                signerType,
                signerInfo,
            });
            logger.info({
                signingRequestId,
                verificationId: verificationRecord.id,
                isValid: result.isValid,
                witnessCount: result.witnessCount,
            }, 'Signature verification completed');
            return verificationRecord;
        });
    });
    /**
     * Verify and submit a signed transaction in one step (unbound action)
     * @param req - CDS request with signingRequestId + signedTxCbor in data
     * @returns {TransactionSubmission} Transaction submission details
     */
    srv.on('SubmitVerifiedTransaction', async (req) => {
        logger.debug('SubmitVerifiedTransaction Action handler called');
        const { signingRequestId, signedTxCbor, signerType, signerInfo, address } = req.data;
        const deferSubmit = req.data.deferSubmit === true;
        const errors = (0, validators_1.validateTransactionInputs)({ signingRequestId, signedTxCbor }, ['signingRequestId', 'signedTxCbor']);
        (0, errors_1.throwIfValidationErrors)(req, 'SubmitVerifiedTransaction', errors);
        if (address && !(0, validators_1.isValidBech32Address)(address))
            (0, errors_1.rejectInvalid)(req, 'SubmitVerifiedTransaction', 'Invalid bech32 address format', 'address');
        // Three committed phases instead of one request-long transaction (see
        // submitAndFinalize): the network submit must NOT run inside an open DB
        // transaction. Errors are mapped the same way handleRequest would.
        //
        // deferSubmit (KNOWN_ISSUES #11, Layer 2): phase 1 instead JOINS the
        // caller's transaction (claim + signed CBOR commit with the caller), the
        // response returns immediately with the tx hash (= body hash), and the
        // network submit runs detached after the caller's commit.
        try {
            // PHASE 1 (committed): fully verify, then atomically claim → 'submitting'.
            // The claim is deliberately the LAST statement: on the deferred path
            // these statements run on the CALLER's transaction, and a verification
            // failure whose error the caller swallows (and then commits) must not
            // leave a stranded 'submitting' claim behind — everything before the
            // claim is read-only. The guarded UPDATE (status still pending/verified)
            // remains the atomic gate against concurrent submits on both paths.
            const phase1 = async (db) => {
                const now = new Date().toISOString();
                const signingRequest = await db.run(SELECT.one.from(SigningRequests).where({ id: signingRequestId }));
                if (!signingRequest)
                    (0, errors_1.rejectInvalid)(req, 'SubmitVerifiedTransaction', 'Signing request not found', 'signingRequestId');
                if (signingRequest.expiresAt <= now)
                    (0, errors_1.rejectInvalid)(req, 'SubmitVerifiedTransaction', 'Signing request has expired', 'signingRequestId');
                if (!['pending', 'verified'].includes(signingRequest.status)) {
                    (0, errors_1.rejectInvalid)(req, 'SubmitVerifiedTransaction', `Signing request status is '${signingRequest.status}', expected 'pending' or 'verified'`, 'signingRequestId');
                }
                // Ownership check: verify address matches build owner (defense-in-depth)
                if (address && signingRequest.build_id) {
                    await verifyBuildOwnership(req, db, signingRequest.build_id, address, TransactionBuilds, 'SubmitVerifiedTransaction');
                }
                // Check if build association exists
                if (!signingRequest.build_id) {
                    (0, errors_1.rejectInvalid)(req, 'SubmitVerifiedTransaction', 'Signing request has no associated build', 'signingRequestId');
                }
                // Detect if signedTxCbor is a witness set (CIP-30) or a full signed transaction (cardano-cli)
                const fullSignedTxCbor = (0, signing_helper_1.isWitnessSetCbor)(signedTxCbor)
                    ? (0, signing_helper_1.combineTransactionWithWitnesses)(signingRequest.unsignedTxCbor, signedTxCbor)
                    : signedTxCbor;
                // Verify signature (throws on failure) — bound to the keys that must
                // actually witness this transaction (required_signers + fee payer)
                const requiredSigners = await resolveRequiredSigners(db, signingRequest, TransactionBuilds);
                const verificationResult = (0, external_signer_1.getExternalSignerModule)().verifyOrThrow(fullSignedTxCbor, signingRequest.txBodyHash, { requiredSigners });
                // Atomic claim — last statement, see above. Deferred path: persist the
                // signed CBOR + signer metadata with the claim, so an interrupted
                // submission can be re-driven after a restart.
                const claimed = await db.run(UPDATE.entity(SigningRequests)
                    .set({
                    status: 'submitting',
                    ...(deferSubmit ? { signedTxCbor: fullSignedTxCbor, signerType, signerInfo } : {}),
                })
                    .where({
                    id: signingRequestId,
                    status: { in: ['pending', 'verified'] },
                    expiresAt: { '>': now },
                }));
                if (claimed === 0) {
                    (0, errors_1.rejectInvalid)(req, 'SubmitVerifiedTransaction', 'Signing request was claimed by a concurrent submission', 'signingRequestId');
                }
                return { buildId: signingRequest.build_id, txHash: signingRequest.txBodyHash, fullSignedTxCbor, verificationResult };
            };
            const finalizeParams = (prep) => ({
                signingRequestId,
                buildId: prep.buildId,
                fullSignedTxCbor: prep.fullSignedTxCbor,
                txHash: prep.txHash,
                verificationResult: prep.verificationResult,
                signerType,
                signerInfo,
            });
            if (deferSubmit) {
                // Phase 1 on the CALLER's transaction: joins its pooled connection (no
                // deadlock), commits together with the caller. Validation errors stay
                // synchronous; the submit is scheduled for after the commit.
                const prep = await phase1(cds_1.default.tx(req));
                (0, submission_finalizer_1.scheduleDeferredSubmit)(req, SigningRequests, finalizeParams(prep));
                logger.info({ signingRequestId, txHash: prep.txHash }, 'Verified and claimed — submit deferred until after the caller commits');
                return {
                    id: null,
                    build_id: prep.buildId,
                    txHash: prep.txHash,
                    signedTxCbor: prep.fullSignedTxCbor,
                    status: 'pending',
                    submittedAt: null,
                };
            }
            const prep = await (0, tx_utils_1.detachedTx)('claim + verify signing request', phase1);
            logger.info({ signingRequestId, witnessCount: prep.verificationResult.witnessCount }, 'Signature verified, proceeding with submission');
            // PHASES 2+3: submit outside any DB tx, then finalize in its own tx
            const submissionRecord = await (0, submission_finalizer_1.submitAndFinalize)(SigningRequests, finalizeParams(prep));
            logger.info({ signingRequestId, txHash: prep.txHash }, 'Transaction submitted and all records updated');
            return submissionRecord;
        }
        catch (e) {
            logger.error({ err: e }, 'SubmitVerifiedTransaction error');
            return (0, mappers_1.mapError)(req, e, 'SubmitVerifiedTransaction');
        }
    });
    /**
     * Verify a CIP-30 signData (COSE_Sign1) message signature (unbound action).
     * Stateless crypto check behind wallet-based login — no DB write, no state.
     * Public (@requires:'any' in CDS) because the caller is not yet authenticated.
     * @param req - CDS request with address, coseSignature, coseKey, expectedPayload
     * @returns { valid, reason, signedPayload, signerVkh }
     */
    srv.on('VerifyDataSignature', async (req) => {
        logger.debug('VerifyDataSignature Action handler called');
        const { address, coseSignature, coseKey, expectedPayload } = req.data;
        // Validate inputs before the crypto check
        if (!address)
            (0, errors_1.rejectMissing)(req, 'VerifyDataSignature', 'address');
        if (!(0, validators_1.isValidBech32Address)(address))
            (0, errors_1.rejectInvalid)(req, 'VerifyDataSignature', 'Invalid bech32 address format', 'address');
        if (!coseSignature)
            (0, errors_1.rejectMissing)(req, 'VerifyDataSignature', 'coseSignature');
        if (!coseKey)
            (0, errors_1.rejectMissing)(req, 'VerifyDataSignature', 'coseKey');
        // verifyDataSignature never throws: a bad/forged signature is a 200 with
        // valid:false + reason, not an error. Only malformed *inputs* reject above.
        return (0, cose_verifier_1.verifyDataSignature)({ address, coseSignature, coseKey, expectedPayload });
    });
    /**
     * Get all existing signing requests by address
     * @param req - CDS request object (with address)
     * @returns {AddressSigningRequests} Address signing request associations
     */
    srv.on('GetSigningRequestsByAddress', async (req) => {
        logger.debug('GetSigningRequestsByAddress Action handler called');
        const { address } = req.data;
        // Validate input before business logic
        if (!address)
            (0, errors_1.rejectMissing)(req, 'GetSigningRequestsByAddress', 'address');
        if (!(0, validators_1.isValidBech32Address)(address))
            (0, errors_1.rejectInvalid)(req, 'GetSigningRequestsByAddress', 'Invalid bech32 address format', 'address');
        // Fetch the address-signing request associations
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            return db.run(SELECT.from(AddressSigningRequests).where({ address_address: address }));
        });
    });
    // ---------------------------------------------------------------------------
    // HSM (Hardware Security Module) Signing Actions
    // ---------------------------------------------------------------------------
    /**
     * Sign a transaction using the configured HSM.
     * Creates signing request, signs with HSM, verifies the signature.
     * @param req - CDS request object (with buildId)
     * @returns {SigningRequest} Signing request with status 'verified'
     */
    srv.on('SignWithHsm', async (req) => {
        logger.debug('SignWithHsm Action handler called');
        enforceHsmRole(req, 'SignWithHsm');
        const { buildId, address } = req.data;
        // Validate input
        const errors = (0, validators_1.validateTransactionInputs)({ buildId }, ['buildId']);
        (0, errors_1.throwIfValidationErrors)(req, 'SignWithHsm', errors);
        if (address && !(0, validators_1.isValidBech32Address)(address))
            (0, errors_1.rejectInvalid)(req, 'SignWithHsm', 'Invalid bech32 address format', 'address');
        // Check HSM is available (before handleRequest — same pattern as validation)
        const hsmSigner = (0, hsm_signer_1.getHsmSigner)();
        if (!hsmSigner || !hsmSigner.isConnected()) {
            (0, errors_1.rejectInvalid)(req, 'SignWithHsm', 'HSM is not configured or not connected', 'hsm');
        }
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            // 1. Fetch the build (with ownership check)
            const build = await verifyBuildOwnership(req, db, buildId, address, TransactionBuilds, 'SignWithHsm');
            // HSM can only sign builds for its own address
            const hsmAddress = hsmSigner.getAddress();
            if (build.senderAddress !== hsmAddress) {
                (0, errors_1.rejectInvalid)(req, 'SignWithHsm', `Build sender '${build.senderAddress}' does not match HSM address '${hsmAddress}'`, 'buildId');
            }
            // 2. Create signing request internally (reuse external signer module)
            const signerModule = (0, external_signer_1.getExternalSignerModule)();
            const signingPayload = signerModule.createSigningRequest(build.id, build.unsignedTxCbor, build.txBodyHash, build.network, 'HSM signing');
            const signingRequestRecord = await (0, server_1.getCardanoIndexer)().persistSigningRequest(db, {
                buildId,
                signingPayload,
            });
            // 3. Sign with HSM
            const signedTxCbor = hsmSigner.signTransaction(build.unsignedTxCbor, build.txBodyHash);
            // 4. Verify the HSM signature (same verification path as external signing)
            const verificationResult = signerModule.verifySignedTransaction(signedTxCbor, build.txBodyHash);
            const hsmStatus = hsmSigner.getStatus();
            const hsmKeyIdentifier = hsmStatus.keyLabel || hsmStatus.keyId || 'unknown';
            // A failed HSM verification is an HSM/server fault, not a successful sign —
            // reject (rolls back) instead of returning 200 with status 'failed', matching
            // SignAndSubmitWithHsm.
            if (!verificationResult.isValid) {
                logger.error({ signingRequestId: signingRequestRecord.id, hsmKey: hsmKeyIdentifier }, 'HSM signature verification failed');
                (0, errors_1.rejectInvalid)(req, 'SignWithHsm', 'HSM signature verification failed', 'signedTxCbor');
            }
            // 5. Persist verification
            await (0, server_1.getCardanoIndexer)().persistSignatureVerification(db, {
                signingRequestId: signingRequestRecord.id,
                signedTxCbor,
                verificationResult,
                signerType: 'hsm',
                signerInfo: `HSM key: ${hsmKeyIdentifier}`,
            });
            // 6. Update HSM audit field
            await db.run(UPDATE.entity(SigningRequests)
                .set({ hsmKeyId: hsmKeyIdentifier })
                .where({ id: signingRequestRecord.id }));
            logger.info({
                buildId,
                signingRequestId: signingRequestRecord.id,
                isValid: verificationResult.isValid,
                hsmKey: hsmKeyIdentifier,
            }, 'Transaction signed with HSM');
            // Return updated signing request
            return db.run(SELECT.one.from(SigningRequests).where({ id: signingRequestRecord.id }));
        });
    });
    /**
     * Sign a transaction with HSM and submit to blockchain atomically.
     * Creates signing request, signs, verifies, and submits in one operation.
     * @param req - CDS request object (with buildId)
     * @returns {TransactionSubmission} Transaction submission details
     */
    srv.on('SignAndSubmitWithHsm', async (req) => {
        logger.debug('SignAndSubmitWithHsm Action handler called');
        enforceHsmRole(req, 'SignAndSubmitWithHsm');
        const { buildId, address } = req.data;
        const deferSubmit = req.data.deferSubmit === true;
        // Validate input
        const errors = (0, validators_1.validateTransactionInputs)({ buildId }, ['buildId']);
        (0, errors_1.throwIfValidationErrors)(req, 'SignAndSubmitWithHsm', errors);
        if (address && !(0, validators_1.isValidBech32Address)(address))
            (0, errors_1.rejectInvalid)(req, 'SignAndSubmitWithHsm', 'Invalid bech32 address format', 'address');
        // Check HSM is available
        const hsmSigner = (0, hsm_signer_1.getHsmSigner)();
        if (!hsmSigner || !hsmSigner.isConnected()) {
            (0, errors_1.rejectInvalid)(req, 'SignAndSubmitWithHsm', 'HSM is not configured or not connected', 'hsm');
        }
        try {
            // PHASE 1 (committed): fetch build, sign with HSM, verify. A failure
            // here rolls back the freshly-created signing request. (Deferred path:
            // the INSERT runs on the caller's tx; a swallowed failure leaves a
            // 'pending' row that expires via its TTL — harmless.)
            const phase1 = async (db) => {
                // 1. Fetch the build (with ownership check)
                const build = await verifyBuildOwnership(req, db, buildId, address, TransactionBuilds, 'SignAndSubmitWithHsm');
                // HSM can only sign builds for its own address
                const hsmAddress = hsmSigner.getAddress();
                if (build.senderAddress !== hsmAddress) {
                    (0, errors_1.rejectInvalid)(req, 'SignAndSubmitWithHsm', `Build sender '${build.senderAddress}' does not match HSM address '${hsmAddress}'`, 'buildId');
                }
                // 2. Create signing request
                const signerModule = (0, external_signer_1.getExternalSignerModule)();
                const signingPayload = signerModule.createSigningRequest(build.id, build.unsignedTxCbor, build.txBodyHash, build.network, 'HSM signing + submit');
                const signingRequestRecord = await (0, server_1.getCardanoIndexer)().persistSigningRequest(db, { buildId, signingPayload });
                // 3. Sign with HSM
                const signedTxCbor = hsmSigner.signTransaction(build.unsignedTxCbor, build.txBodyHash);
                // 4. Verify HSM signature — reject (rolls back) if invalid before submitting
                const verificationResult = signerModule.verifySignedTransaction(signedTxCbor, build.txBodyHash);
                const hsmStatus = hsmSigner.getStatus();
                const hsmKeyIdentifier = hsmStatus.keyLabel || hsmStatus.keyId || 'unknown';
                if (!verificationResult.isValid) {
                    logger.error({ signingRequestId: signingRequestRecord.id, hsmKey: hsmKeyIdentifier }, 'HSM signature verification failed — aborting submission');
                    (0, errors_1.rejectInvalid)(req, 'SignAndSubmitWithHsm', 'HSM signature verification failed', 'signedTxCbor');
                }
                // Claim the request as 'submitting' in this same committed phase.
                // Deferred path: also persist the signed CBOR + signer metadata for
                // the boot-time redrive of interrupted submissions.
                await db.run(UPDATE.entity(SigningRequests).set({
                    status: 'submitting',
                    hsmKeyId: hsmKeyIdentifier,
                    ...(deferSubmit ? { signedTxCbor, signerType: 'hsm', signerInfo: `HSM key: ${hsmKeyIdentifier}` } : {}),
                }).where({ id: signingRequestRecord.id }));
                return { signingRequestId: signingRequestRecord.id, signedTxCbor, txHash: build.txBodyHash, verificationResult, hsmKeyIdentifier };
            };
            const finalizeParams = (prep) => ({
                signingRequestId: prep.signingRequestId,
                buildId,
                fullSignedTxCbor: prep.signedTxCbor,
                txHash: prep.txHash,
                verificationResult: prep.verificationResult,
                signerType: 'hsm',
                signerInfo: `HSM key: ${prep.hsmKeyIdentifier}`,
            });
            if (deferSubmit) {
                // Phase 1 on the CALLER's transaction (KNOWN_ISSUES #11, Layer 2):
                // sign + verify + claim commit with the caller; submit runs after its
                // commit. See SubmitVerifiedTransaction for the full rationale.
                const prep = await phase1(cds_1.default.tx(req));
                (0, submission_finalizer_1.scheduleDeferredSubmit)(req, SigningRequests, finalizeParams(prep));
                logger.info({ signingRequestId: prep.signingRequestId, txHash: prep.txHash }, 'HSM-signed and claimed — submit deferred until after the caller commits');
                return {
                    id: null,
                    build_id: buildId,
                    txHash: prep.txHash,
                    signedTxCbor: prep.signedTxCbor,
                    status: 'pending',
                    submittedAt: null,
                };
            }
            const prep = await (0, tx_utils_1.detachedTx)('HSM sign + claim signing request', phase1);
            logger.info({ signingRequestId: prep.signingRequestId, witnessCount: prep.verificationResult.witnessCount, hsmKey: prep.hsmKeyIdentifier }, 'HSM signature verified, proceeding with submission');
            // PHASES 2+3: submit outside any DB tx, then finalize (re-set hsmKeyId,
            // which indexVerifiedTransactionSubmission does not touch)
            const submissionRecord = await (0, submission_finalizer_1.submitAndFinalize)(SigningRequests, finalizeParams(prep), (db) => db.run(UPDATE.entity(SigningRequests).set({ hsmKeyId: prep.hsmKeyIdentifier }).where({ id: prep.signingRequestId })).then(() => undefined));
            logger.info({ signingRequestId: prep.signingRequestId, txHash: prep.txHash }, 'HSM-signed transaction submitted and all records updated');
            return submissionRecord;
        }
        catch (e) {
            logger.error({ err: e }, 'SignAndSubmitWithHsm error');
            return (0, mappers_1.mapError)(req, e, 'SignAndSubmitWithHsm');
        }
    });
    /**
     * Get HSM connection status and key information.
     * Returns null fields if HSM is not configured.
     */
    srv.on('GetHsmStatus', async (_req) => {
        enforceHsmRole(_req, 'GetHsmStatus');
        const hsmSigner = (0, hsm_signer_1.getHsmSigner)();
        if (!hsmSigner) {
            return {
                connected: false,
                keyId: null,
                keyLabel: null,
                publicKeyHash: null,
                cardanoAddress: null,
            };
        }
        const status = hsmSigner.getStatus();
        return {
            connected: status.connected,
            keyId: status.keyId || null,
            keyLabel: status.keyLabel || null,
            publicKeyHash: status.publicKeyHash || null,
            cardanoAddress: status.address || null,
        };
    });
};
//# sourceMappingURL=cardano-sign-service.js.map