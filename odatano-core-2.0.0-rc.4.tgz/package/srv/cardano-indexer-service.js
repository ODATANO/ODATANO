"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cds_1 = __importDefault(require("@sap/cds"));
const backend_request_handler_1 = require("./utils/backend-request-handler");
const errors_1 = require("./utils/errors");
const crawler_1 = require("./blockchain/crawler");
const sync_state_1 = require("./blockchain/crawler/sync-state");
const server_1 = require("./server");
const logger = cds_1.default.log('CardanoIndexerService');
/**
 * CardanoIndexerService handlers — thin control/observability surface over the crawler
 * singleton (srv/blockchain/crawler). Engine logic lives there; this only reads the
 * cursor and starts/stops the crawler.
 */
module.exports = (srv) => {
    // getStatus — live run state + sync progress (numeric fields as strings, CAP-10 aligned)
    srv.on('getStatus', async (req) => {
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const cursor = await (0, sync_state_1.readCursor)(db);
            const lastHeight = cursor?.lastHeight ?? 0;
            const tipHeight = cursor?.tipHeight ?? 0;
            const progress = tipHeight > 0 ? Math.min(100, (lastHeight / tipHeight) * 100) : 0;
            return {
                running: (0, sync_state_1.isCrawlerLeaseActive)(cursor),
                syncStatus: cursor?.syncStatus ?? 'stopped',
                lastSlot: String(cursor?.lastSlot ?? 0),
                lastHeight: String(lastHeight),
                tipHeight: String(tipHeight),
                syncProgress: progress.toFixed(2),
                consecutiveErrors: cursor?.consecutiveErrors ?? 0,
            };
        });
    });
    // pauseCrawler — stop the stream; the cursor is preserved so resume continues.
    srv.on('pauseCrawler', async (req) => {
        return (0, backend_request_handler_1.handleRequest)(req, async () => {
            await (0, crawler_1.stopCrawler)(true);
            logger.info('Crawler paused via control action');
            return true;
        });
    });
    // resumeCrawler — (re)start from the persisted cursor using the configured source.
    // Gated on config.enabled: the control action must not start a crawler the operator
    // never configured (an unconfigured start would otherwise sync from genesis).
    // NOTE: to apply CHANGED config to a running crawler, call pauseCrawler first —
    // resume on a running crawler is a no-op by design.
    srv.on('resumeCrawler', async (req) => {
        let config;
        try {
            config = (0, server_1.loadCrawlerConfigFromEnv)();
        }
        catch (err) {
            // e.g. ConfigError: enabled but no start block — a config problem is the
            // caller's 400, not a raw 500 from an escaping throw
            return (0, errors_1.rejectInvalid)(req, 'resumeCrawler', err instanceof Error ? err.message : String(err));
        }
        if (!config.enabled) {
            return (0, errors_1.rejectInvalid)(req, 'resumeCrawler', 'Crawler is not enabled — set cds.requires.odatano-core.crawler.enabled (or CRAWLER_ENABLED=true) with a start block before resuming.');
        }
        return (0, backend_request_handler_1.handleRequest)(req, async () => {
            const client = (0, server_1.getCardanoClient)();
            await (0, crawler_1.startCrawler)({
                client,
                indexer: (0, server_1.getCardanoIndexer)(),
                network: client.network,
                config,
            }, true);
            logger.info('Crawler resumed via control action');
            return (0, crawler_1.isCrawlerRunningInCluster)();
        });
    });
};
//# sourceMappingURL=cardano-indexer-service.js.map