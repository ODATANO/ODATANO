"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cds_1 = __importDefault(require("@sap/cds"));
const backend_request_handler_1 = require("./utils/backend-request-handler");
const errors_1 = require("./utils/errors");
const error_codes_1 = require("./utils/error-codes");
const validators_1 = require("./utils/validators");
const wallet_worker_1 = require("./blockchain/wallet-worker");
const job_store_1 = require("./blockchain/wallet-worker/job-store");
const server_1 = require("./server");
const logger = cds_1.default.log('CardanoWorkerService');
/**
 * CardanoWorkerService handlers — thin control surface over the wallet-worker
 * singleton (srv/blockchain/wallet-worker). Engine logic lives there; this only
 * validates inputs, inserts/reads job rows and starts/stops the worker.
 *
 * Validation rejections happen BEFORE handleRequest (project convention); the
 * job INSERT runs on the request's ambient transaction (NIGHTGATE lesson 1).
 */
function isAdmin(req) {
    return req.user?.is?.('Admin') ?? false;
}
/**
 * A job on an HSM-backed wallet spends the same server-held key as the synchronous
 * SignWithHsm path, so it inherits that path's role gate (enforceHsmRole in
 * cardano-sign-service.ts) — 'authenticated-user' alone must not reach the HSM.
 * Returns the role the caller is missing, or null when the wallet is not HSM-backed,
 * no role is configured, or the caller holds it.
 */
function missingHsmRole(req, signerType) {
    if (signerType !== 'hsm')
        return null;
    const requiresRole = (0, server_1.getHsmConfig)()?.requiresRole;
    if (!requiresRole || req.user?.is(requiresRole))
        return null;
    return requiresRole;
}
function toJobStatus(job) {
    return {
        jobId: job.ID,
        walletId: job.walletId,
        kind: job.kind,
        status: job.status,
        attempt: job.attempt,
        txHash: job.txHash,
        fee: job.fee != null ? String(job.fee) : null,
        errorCode: job.errorCode,
        errorMessage: job.errorMessage,
        submittedAt: job.submittedAt,
        confirmedAt: job.confirmedAt,
        finishedAt: job.finishedAt,
    };
}
module.exports = (srv) => {
    // SubmitWalletJob — queue an async transaction job; returns the jobId immediately.
    srv.on('SubmitWalletJob', async (req) => {
        const { walletId, kind, requestJson, idempotencyKey, priority, notBefore } = req.data;
        if (!walletId?.trim())
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', 'walletId is required', 'walletId');
        if (!kind || !job_store_1.WALLET_JOB_KINDS.includes(kind)) {
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', `Invalid kind "${String(kind)}" — must be one of: ${job_store_1.WALLET_JOB_KINDS.join(', ')}`, 'kind');
        }
        if (!requestJson?.trim())
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', 'requestJson is required', 'requestJson');
        const jsonResult = (0, validators_1.validateJsonWithLimits)(requestJson, 'requestJson');
        if (!jsonResult.valid)
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', jsonResult.error, 'requestJson');
        if (priority != null && (!Number.isInteger(priority) || priority < 0 || priority > 10_000)) {
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', 'priority must be an integer between 0 and 10000', 'priority');
        }
        if (notBefore != null && Number.isNaN(Date.parse(String(notBefore)))) {
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', 'notBefore must be a valid timestamp', 'notBefore');
        }
        if (idempotencyKey != null && String(idempotencyKey).length > 100) {
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', 'idempotencyKey exceeds 100 characters', 'idempotencyKey');
        }
        let config;
        try {
            config = (0, server_1.loadWalletWorkerConfigFromEnv)();
        }
        catch (err) {
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', err instanceof Error ? err.message : String(err));
        }
        if (!config.enabled) {
            return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', 'Wallet worker is not enabled — set cds.requires.odatano-core.walletWorker.enabled (or WALLET_WORKER_ENABLED=true) with configured wallets.');
        }
        // Role gate on this instance's config, mirroring the sign service's 403.
        const configuredRole = missingHsmRole(req, config.wallets.find((w) => w.walletId === walletId)?.signerType);
        if (configuredRole) {
            return req.reject(403, `SubmitWalletJob on HSM-backed wallet "${walletId}" requires role '${configuredRole}'`);
        }
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const wallet = await (0, job_store_1.readWallet)(db, walletId);
            if (!wallet)
                return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', `Unknown wallet "${walletId}" — configured wallets are registered at worker start`, 'walletId');
            if (!wallet.enabled)
                return (0, errors_1.rejectInvalid)(req, 'SubmitWalletJob', `Wallet "${walletId}" is disabled`, 'walletId');
            // Registered row too: another instance may run the HSM wallet this one has no config for.
            const registeredRole = missingHsmRole(req, wallet.signerType);
            if (registeredRole) {
                throw new errors_1.BackendError(`Wallet "${walletId}" is HSM-backed and requires role '${registeredRole}'`, 403, error_codes_1.ERROR_CODES.FORBIDDEN, undefined, undefined, 'walletId');
            }
            const result = await (0, job_store_1.insertJob)(db, {
                walletId,
                kind: kind,
                request: requestJson,
                idempotencyKey: idempotencyKey ?? null,
                priority,
                notBefore: notBefore ? new Date(notBefore).toISOString() : null,
                maxAttempts: config.defaultMaxAttempts,
                createdBy: req.user?.id ?? null,
            });
            logger.info(`Job ${result.jobId} accepted (wallet=${walletId}, kind=${kind}, dedup=${result.deduplicated})`);
            return result;
        });
    });
    // CancelJob — pending jobs only; scoped to the creator unless Admin.
    srv.on('CancelJob', async (req) => {
        const { jobId } = req.data;
        if (!jobId)
            return (0, errors_1.rejectInvalid)(req, 'CancelJob', 'jobId is required', 'jobId');
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const job = await (0, job_store_1.getJobById)(db, jobId);
            if (!job || (!isAdmin(req) && job.createdBy !== req.user?.id)) {
                // Same 404 for "not found" and "not yours" — no existence oracle.
                // THROW, don't req.reject: we are inside handleRequest, whose catch would
                // see a plain CAP error and remap it to 500 (mapError). A BackendError
                // carries its status through.
                throw new errors_1.NotFoundError(`Job ${jobId}`);
            }
            const cancelled = await (0, job_store_1.markCancelled)(db, jobId);
            if (!cancelled) {
                return (0, errors_1.rejectInvalid)(req, 'CancelJob', `Job ${jobId} is ${job.status} — only pending jobs can be cancelled`, 'jobId');
            }
            return true;
        });
    });
    // GetJobStatus — scoped to the creator unless Admin.
    srv.on('GetJobStatus', async (req) => {
        const { jobId } = req.data;
        if (!jobId)
            return (0, errors_1.rejectInvalid)(req, 'GetJobStatus', 'jobId is required', 'jobId');
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const job = await (0, job_store_1.getJobById)(db, jobId);
            if (!job || (!isAdmin(req) && job.createdBy !== req.user?.id)) {
                throw new errors_1.NotFoundError(`Job ${jobId}`); // see CancelJob: reject() here becomes a 500
            }
            return toJobStatus(job);
        });
    });
    // GetWorkerStatus — live summary of the local worker instance.
    srv.on('GetWorkerStatus', async (req) => {
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const worker = (0, wallet_worker_1.getWalletWorker)();
            const summary = worker?.getStatusSummary() ?? {
                running: false, wallets: [], executing: [], awaitingConfirmation: 0,
            };
            const pending = await (0, job_store_1.findDueJobs)(db, new Date(8640000000000000)); // all pending, ignore notBefore
            return { ...summary, pendingJobs: pending.length };
        });
    });
    // PauseWorker — stop the local instance; queued jobs stay pending.
    srv.on('PauseWorker', async (req) => {
        return (0, backend_request_handler_1.handleRequest)(req, async () => {
            await (0, wallet_worker_1.stopWalletWorker)();
            logger.info('Wallet worker paused via control action');
            return true;
        });
    });
    // ResumeWorker — (re)start the local instance from config. Gated on enabled,
    // mirroring resumeCrawler.
    srv.on('ResumeWorker', async (req) => {
        let config;
        try {
            config = (0, server_1.loadWalletWorkerConfigFromEnv)();
        }
        catch (err) {
            return (0, errors_1.rejectInvalid)(req, 'ResumeWorker', err instanceof Error ? err.message : String(err));
        }
        if (!config.enabled) {
            return (0, errors_1.rejectInvalid)(req, 'ResumeWorker', 'Wallet worker is not enabled — set cds.requires.odatano-core.walletWorker.enabled (or WALLET_WORKER_ENABLED=true) before resuming.');
        }
        return (0, backend_request_handler_1.handleRequest)(req, async () => {
            const client = (0, server_1.getCardanoClient)();
            await (0, wallet_worker_1.startWalletWorker)({
                client,
                indexer: (0, server_1.getCardanoIndexer)(),
                network: client.network,
                config,
            });
            logger.info('Wallet worker resumed via control action');
            return (0, wallet_worker_1.isWalletWorkerRunning)();
        });
    });
};
//# sourceMappingURL=cardano-worker-service.js.map