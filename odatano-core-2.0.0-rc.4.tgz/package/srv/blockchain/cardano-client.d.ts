import { ChainSyncBackend, PaginatingBackend } from './backends/cardano-backend';
import { type CircuitBreakerConfig } from './circuit-breaker';
import { Transaction, Address, UTxO, NetworkInformation, BlockData, EpochData, MetadataLabelTx, PoolData, DrepData, AccountData, AssetInfo, AssetHistoryEntry, LedgerProtocolParameters, ScriptEvaluationResult } from '../utils/types';
export type Network = 'mainnet' | 'preview' | 'preprod';
export type BackendName = 'blockfrost' | 'koios' | 'ogmios';
export type TransactionBuilderName = 'buildooor';
export type CardanoClientConfig = {
    network: Network;
    backends: BackendName[];
    blockfrostApiKey: string;
    blockfrostCustomBackend?: string;
    koiosApiKey: string;
    ogmiosUrl: string;
    transactionBuilders: TransactionBuilderName[];
    primaryTimeoutMs: number;
    fallbackTimeoutMs: number;
    indexTtlMs: number;
    circuitBreaker?: Partial<CircuitBreakerConfig>;
};
/**
 * CardanoClient - Smart Multi-backend Cardano Client
 *
 * Routes requests to appropriate backends:
 * - Live/State queries → Ogmios (if available)
 * - Historical queries → Blockfrost/Koios (if available)
 * - Automatic fallback between backends
 */
export declare class CardanoClient {
    private config;
    private liveBackend?;
    private historicalBackends;
    private initialized;
    private initPromise;
    private circuitBreaker;
    /** Backends whose init failed — kept in rotation and retried lazily per request */
    private uninitializedBackends;
    network: Network;
    max_age_ms: number;
    private protocolParamsCache?;
    private protocolParamsFetchPromise;
    private static readonly PROTOCOL_PARAMS_TTL_MS;
    private txCoalescer;
    private addrCoalescer;
    private credCoalescer;
    /**
     * Constructor for CardanoClient
     * @param liveBackend - Optional backend for live/state queries (typically Ogmios)
     * @param historicalBackends - Optional backends for historical queries (typically Blockfrost/Koios)
     */
    constructor(clientConfig: CardanoClientConfig);
    /** Names of the configured backends (live + historical), for status reporting. */
    listBackends(): string[];
    /**
     * Ensure backends are initialized.
     * A REJECTED init promise is cleared so the next request retries — previously
     * a transient startup failure (e.g. Ogmios briefly down) left the client
     * permanently broken until process restart.
     * @returns {Promise<void>}
     */
    private ensureInitialized;
    /**
     * Transient (retryable) init failures: a backend momentarily unreachable at
     * startup — e.g. Ogmios's /health response cut short while the node processes
     * a freshly-arrived block ("Premature close"), or the socket still coming up
     * (ECONNREFUSED). Config/validation errors are NOT transient.
     */
    private static isTransientInitError;
    /**
     * Init a backend, retrying brief transient failures. Deliberately SMALL: the
     * integration suites bootstrap under a 20s cds.test() hook, so total retry
     * time must stay well under it (≤3 attempts × 4s init-timeout + 1s backoff
     * ≈ 14s worst case; in practice "Premature close" returns sub-second). With
     * the node at tip these failures are momentary block-processing blips, so a
     * couple of quick retries ride over them; a sustained outage still fails fast.
     */
    private initBackendWithRetry;
    /**
     * Initialize all backends from configuration.
     * Backends that fail to initialize are KEPT (previously removed permanently)
     * and tracked in `uninitializedBackends` — the request loops retry their
     * init lazily, so a backend that comes back online recovers without a
     * process restart. The circuit breaker bounds the retry cost.
     * @returns {Promise<void>}
     */
    private initBackends;
    /**
     * Lazily retry a backend's init when it failed at startup. Returns true when
     * the backend is usable; false (after recording a breaker failure) when the
     * retry failed.
     */
    private ensureBackendInitialized;
    /**
     * Wrap a promise with a timeout
     * @param promise - the promise to wrap
     * @param ms - timeout in milliseconds
     * @param backendName - name of the backend (for error context)
     * @returns {Promise<T>} the result of the promise or a timeout error
     */
    private withTimeout;
    /**
     * Get timeout for specific backend
     * @param backend CardanoBackend instance
     * @returns {number} timeout in milliseconds
     */
    private getTimeoutForBackend;
    /**
     * Run a single-backend call with the same resilience contract as
     * executeWithPriority: circuit-breaker gate, timeout, success/failure
     * recording (4xx exempt). For the paths that cannot fail over (Koios-only,
     * Ogmios-only, batch-capable loops) — these previously bypassed timeout AND
     * breaker entirely, so a hanging socket blocked the caller indefinitely.
     */
    private callWithResilience;
    /**
     * Execute with priority-based backend selection and automatic fallback
     * @param fn function to execute on backend
     * @param preferLive whether to prefer live backend over historical
     * @returns {Promise<T>} result from backend
     */
    private executeWithPriority;
    /**
     * Route method call to appropriate backend based on method routing configuration
     * @param methodName name of the method being called
     * @param fn function to execute on backend
     * @returns {Promise<T>} result from backend
     */
    private route;
    /**
     * Get transaction by hash with fallback between backends
     * @param txHash transaction hash (hex)
     * @returns {Promise<Transaction>} transaction data
     */
    getTransaction(txHash: string): Promise<Transaction>;
    /**
     * Get address by bech32 address with fallback between backends
     * @param address bech32 address
     * @returns {Promise<Address>} address data
     */
    getAddress(address: string): Promise<Address>;
    /**
     * Get address UTxOs with fallback between backends
     * @param address bech32 address
     * @returns {Promise<UTxO[]>} list of UTxOs
     */
    getAddressUtxos(address: string): Promise<UTxO[]>;
    /**
     * Get UTxOs by 28-byte payment credential. Koios-only — bypasses generic
     * failover because no other backend exposes a credential-keyed UTxO endpoint.
     * Throws ProviderUnavailableError if Koios is not configured.
     * @param credHash 28-byte payment credential as 56-char lowercase hex
     * @returns {Promise<UTxO[]>} list of UTxOs across all bech32 forms sharing the credential
     */
    getCredentialUtxos(credHash: string): Promise<UTxO[]>;
    /**
     * Get address transactions with fallback between backends
     * @param address bech32 address
     * @returns {Promise<Transaction[]>} list of transactions for this address
     */
    getAddressTransactions(address: string, limit: number): Promise<Transaction[]>;
    /**
     * Get network information with fallback between backends
     * @returns {Promise<Network>} network information
     */
    getNetworkInformation(): Promise<NetworkInformation>;
    /**
     * Get transaction metadata with fallback between backends
     * @param tx_hash transaction hash (hex)
     * @returns {Promise<MetadataLabelTx[]>} transaction metadata
     */
    getTransactionMetadata(tx_hash: string): Promise<MetadataLabelTx[]>;
    /**
     * Get block data with fallback between backends
     * @param block_hash block hash (hex)
     * @returns {Promise<BlockData>} block data
     */
    getBlock(block_hash: string): Promise<BlockData>;
    /**
     * Get epoch data with fallback between backends
     * @param epochNumber epoch number
     * @returns {Promise<EpochData>} epoch data
     */
    getEpoch(epochNumber: number): Promise<EpochData>;
    /**
     * Get Pool data with fallback between backends
     * @param poolId pool id
     * @returns {Promise<PoolData>} pool data
     */
    getPool(poolId: string): Promise<PoolData>;
    /**
     * Get drep data with fallback between backends
     * @param drepId drep id
     * @returns {Promise<DrepData>} drep data
     */
    getDrep(drepId: string): Promise<DrepData>;
    /**
     * Get account data with fallback between backends
     * @param stakeAddress stake address
     * @returns {Promise<AccountData>} account data
     */
    getAccount(stakeAddress: string): Promise<AccountData>;
    /**
     * Get asset info (supply, mint history, CIP-25 + CIP-26 metadata) with fallback.
     * Both Blockfrost and Koios implement; Ogmios throws "not supported".
     * @param unit policyId + assetNameHex (concatenated hex)
     * @returns {Promise<AssetInfo>} canonical asset info
     */
    getAssetInfo(unit: string): Promise<AssetInfo>;
    /**
     * Get latest mint/burn events for an asset. Prefers Koios because it provides
     * block timestamps; Blockfrost is the fallback (timestamps left null).
     * Ogmios doesn't implement — fallback skips it via the optional method check.
     * @param unit policyId + assetNameHex (concatenated hex)
     * @param limit max number of events (default 100)
     * @returns {Promise<AssetHistoryEntry[]>} list of mint/burn events (most recent first)
     */
    getAssetHistory(unit: string, limit?: number): Promise<AssetHistoryEntry[]>;
    /**
     * Get transaction hashes for an address (lightweight — no full tx details).
     * Uses getAddressTransactionHashes() if backend supports it, otherwise
     * falls back to getAddressTransactions() and extracts hashes.
     * @param address bech32 address
     * @param limit maximum number of hashes
     * @returns {Promise<string[]>} list of transaction hashes
     */
    getAddressTransactionHashes(address: string, limit: number): Promise<string[]>;
    /**
     * Batch fetch multiple transactions by hash.
     * Uses getTransactionsBatch() if backend supports it, otherwise
     * falls back to individual getTransaction() calls (still coalesced).
     * @param txHashes array of transaction hashes
     * @returns {Promise<Map<string, Transaction>>} map of hash -> Transaction
     */
    getTransactionsBatch(txHashes: string[]): Promise<Map<string, Transaction>>;
    /**
     * Backends in historical-first order. Used by the batch methods — both
     * always prefer historical data, so the former preferLive parameter was a
     * dead branch.
     */
    private getOrderedBackends;
    /**
     * Get a backend that supports streamed chain-synchronization (Ogmios), or null.
     * The crawler's primary, reorg-aware source. Checks the live backend first.
     * Backends whose init() failed are skipped — the crawler uses these instances
     * DIRECTLY (outside executeWithPriority's lazy-retry/breaker), so handing out an
     * uninitialized backend would wedge it.
     */
    getChainSyncBackend(): ChainSyncBackend | null;
    /**
     * Get a backend that can be walked forward by pagination (Blockfrost/Koios), or null.
     * The crawler's fallback source when no Ogmios chain-sync is available.
     * Skips backends whose init() failed (see getChainSyncBackend).
     *
     * Koios is preferred over Blockfrost for bulk block-crawling: Koios batches 100 txs
     * per POST /tx_info, while Blockfrost has no batch endpoint (~3 HTTP calls per tx) —
     * roughly a 40x difference in request volume per crawled block.
     */
    getPaginatingBackend(): PaginatingBackend | null;
    /**
     * Get protocol parameters with caching (5 minute TTL)
     * Protocol parameters rarely change (once per epoch at most), so caching improves performance
     * @returns {Promise<LedgerProtocolParameters>} protocol parameters
     */
    getProtocolParameters(): Promise<LedgerProtocolParameters>;
    /**
     * Shutdown all backends (for cleanup in tests)
     */
    shutdown(): Promise<void>;
    /**
     * Get latest block data with fallback between backends
     * @returns {Promise<BlockData>} latest block data
     */
    getLatestBlock(): Promise<BlockData>;
    /**
     * Get latest epoch data with fallback between backends
     * @returns {Promise<EpochData>} latest epoch data
     */
    getLatestEpoch(): Promise<EpochData>;
    /**
     * Get the current chain slot with fallback between backends.
     * @returns {Promise<number>} current chain slot
     */
    getCurrentSlot(): Promise<number>;
    /**
     * Check whether a UTxO is still unspent with fallback between backends.
     * @param txHash 64-char lowercase hex transaction hash
     * @param outputIndex non-negative integer output index
     * @returns {Promise<boolean>} true iff the UTxO exists and is unspent
     */
    isUtxoUnspent(txHash: string, outputIndex: number): Promise<boolean>;
    /**
     * Submit transaction with fallback between backends
     * @param signedTxCbor signed transaction in CBOR hex format
     * @returns {Promise<string>} transaction hash
     *
     * NOTE on failover semantics: when the preferred backend ACCEPTS the tx but
     * its response is lost (timeout), the failover resubmits on the next backend,
     * which may answer 409 "already submitted". Callers should treat a
     * TransactionAlreadySubmittedError after a submit attempt as success — the
     * transaction IS in the mempool.
     */
    submitTransaction(signedTxCbor: string): Promise<string>;
    /**
     * Check if Ogmios backend is available for transaction evaluation
     * @returns {boolean} true if Ogmios is the live backend
     */
    hasOgmiosBackend(): boolean;
    /**
     * Evaluate transaction script execution units (Ogmios only)
     * @param unsignedTxCbor unsigned transaction in CBOR hex format
     * @returns {Promise<ScriptEvaluationResult[]>} evaluation results
     */
    evaluateTransaction(unsignedTxCbor: string): Promise<ScriptEvaluationResult[]>;
}
//# sourceMappingURL=cardano-client.d.ts.map