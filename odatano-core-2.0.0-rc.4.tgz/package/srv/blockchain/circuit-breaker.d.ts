export type CircuitState = 'closed' | 'open' | 'half-open';
export interface CircuitBreakerConfig {
    /** Number of failures before opening the circuit (default: 5) */
    failureThreshold: number;
    /** Number of successes in half-open before closing (default: 2) */
    successThreshold: number;
    /** Time in ms before transitioning from open to half-open (default: 30000) */
    resetTimeoutMs: number;
}
/**
 * Circuit Breaker for backend failover.
 * Tracks per-backend failure counts and prevents hammering unhealthy backends.
 *
 * States:
 *   closed    → normal operation, requests pass through
 *   open      → backend is unhealthy, requests are skipped
 *   half-open → probe period, limited requests allowed to test recovery
 */
export declare class CircuitBreakerManager {
    private circuits;
    private config;
    constructor(config?: Partial<CircuitBreakerConfig>);
    /**
     * Check if a backend should be attempted.
     * Transitions open → half-open if reset timeout has elapsed.
     */
    shouldAttempt(backendName: string): boolean;
    /** Record a successful call to a backend. */
    recordSuccess(backendName: string): void;
    /** Record a failed call to a backend. */
    recordFailure(backendName: string): void;
    /** Get the current state of a backend's circuit. */
    getState(backendName: string): CircuitState;
    /** Reset all circuit states (for testing). */
    reset(): void;
}
//# sourceMappingURL=circuit-breaker.d.ts.map