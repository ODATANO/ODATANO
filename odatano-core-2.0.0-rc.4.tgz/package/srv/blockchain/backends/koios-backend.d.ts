import { CardanoBackend, PaginatingBackend } from './cardano-backend';
import { Transaction, BlockData, Address, UTxO, NetworkInformation, EpochData, MetadataLabelTx, PoolData, DrepData, AccountData, AssetInfo, AssetHistoryEntry, LedgerProtocolParameters } from '../../utils/types';
import { Network } from '../cardano-client';
/**
 * KoiosBackend Implementation for CardanoBackend Interface
 * Implements the CardanoBackend interface using Koios API with Axios
 */
export declare class KoiosBackend implements CardanoBackend, PaginatingBackend {
    readonly name = "koios";
    private api;
    private network;
    /**
     * Constructor
     */
    constructor(network: Network, timeoutMs: number, apiKey?: string);
    /**
     * Initialize the backend
     */
    init(): Promise<boolean>;
    /**
     * Retry a Koios API call up to 3 times with exponential backoff if the
     * result is an empty array.  Koios sometimes returns [] transiently for
     * valid queries — a single retry is not always sufficient for historical
     * epoch lookups, so we retry with increasing delays (500 → 1000 → 2000 ms).
     */
    private fetchWithRetryOnEmpty;
    /**
     * Koios runs several load-balanced grest instances and they are occasionally
     * version-skewed: some return HTTP 400 with Postgres error 42804 ("structure
     * of query does not match function result type", e.g. `out_sum_lovelace`
     * word128 vs numeric on /epoch_info) while healthy instances serve the
     * IDENTICAL request fine. The same request therefore flips 200/400 between
     * calls. Retrying a few times lands on a healthy instance. Scoped strictly to
     * the 42804 type-skew error so genuine 400s (bad params) still fail fast.
     */
    private getWithRetryOn42804;
    /**
     * Get Transaction Data for specified transaction hash
     * @param hash transaction hash (hex)
     * @returns {Promise<Transaction>} transaction data
     */
    getTransaction(hash: string): Promise<Transaction>;
    /**
     * Get Block Data for specified block hash
     * @param blockHash block hash (hex)
     * @returns {Promise<BlockData>} block data
     */
    getBlock(blockHash: string): Promise<BlockData>;
    /**
     * Get Epoch Data for specified epoch number
     * @param epochNumber epoch number
     * @returns {Promise<EpochData>} epoch data
     */
    getEpoch(epochNumber: number): Promise<EpochData>;
    /**
     * Get Address Data (without transactions - use getAddressTransactions() separately)
     * @param address bech32 address
     * @returns {Promise<Address>} address data
     */
    getAddress(address: string): Promise<Address>;
    /**
     * Get Address Transactions
     * @param address bech32 address
     * @returns {Promise<Transaction[]>} list of transactions for this address
     */
    getAddressTransactions(address: string, limit: number): Promise<Transaction[]>;
    /**
     * Get Address UTxOs for specified address
     * @param address bech32 address
     * @returns {Promise<UTxO[]>} list of UTxOs
     */
    getAddressUtxos(address: string): Promise<UTxO[]>;
    /**
     * Get UTxOs by payment credential. Returns UTxOs across all bech32 addresses
     * sharing the given 28-byte payment credential (key hash or script hash).
     * Native Koios endpoint — single round-trip with inline-datum hydration.
     * @param credHash 28-byte payment credential as 56-char lowercase hex
     * @returns {Promise<UTxO[]>} list of UTxOs across all bech32 forms
     */
    getCredentialUtxos(credHash: string): Promise<UTxO[]>;
    /**
     * Get Network Information
     * @returns {Promise<Network>} network information
     */
    getNetworkInformation(): Promise<NetworkInformation>;
    /**
     * Get Transaction Metadata for specified transaction hash
     * @param tx_hash transaction hash (hex)
     * @returns {Promise<MetadataLabelTx[]>} transaction metadata list
     */
    getTransactionMetadata(tx_hash: string): Promise<MetadataLabelTx[]>;
    /**
     * Get Pool Data for specified pool id
     * @param poolId pool id
     * @returns {Promise<PoolData>} pool data
     */
    getPool(poolId: string): Promise<PoolData>;
    /**
     * Get Asset Info (supply, mint history, CIP-25 + CIP-26 metadata).
     * Koios's `asset_info` returns total_supply, mint/burn counts split,
     * minting tx + creation_time, and both on-chain and registry metadata.
     * @param unit policyId + assetNameHex (concatenated hex)
     * @returns {Promise<AssetInfo>} canonical asset info
     */
    getAssetInfo(unit: string): Promise<AssetInfo>;
    /**
     * Get latest mint/burn events for an asset.
     * Koios's `asset_history` returns minting_txs[{ tx_hash, block_time, quantity }]
     * with `quantity` SIGNED (negative = burn). Action is derived from sign;
     * the canonical `quantity` field stores absolute value.
     * @param unit policyId + assetNameHex (concatenated hex)
     * @param limit max number of events (default 100). Note: Koios returns ALL events;
     *              limit is applied client-side after sort-by-block_time desc.
     * @returns {Promise<AssetHistoryEntry[]>} list of mint/burn events (most recent first)
     */
    getAssetHistory(unit: string, limit?: number): Promise<AssetHistoryEntry[]>;
    /**
     * Get Drep Data for specified drep id
     * @param drepId drep id
     * @returns {Promise<DrepData>} drep data
     */
    getDrep(drepId: string): Promise<DrepData>;
    /**
     * Get Account Data for specified stake address
     * @param accountId account id
     * @returns {Promise<AccountData>} account data
     */
    getAccount(accountId: string): Promise<AccountData>;
    /**
     * Submit Transaction
     * @param signedTxCbor signed transaction in CBOR hex format
     * @returns {Promise<string>} transaction hash
     */
    submitTransaction(signedTxCbor: string): Promise<string>;
    /**
     * Get Protocol Parameters
     * @returns {Promise<any>} protocol parameters
     */
    getProtocolParameters(): Promise<LedgerProtocolParameters>;
    /**
     * Get Latest Block Data
     * @returns {Promise<BlockData>} latest block data
     */
    getLatestBlock(): Promise<BlockData>;
    /**
     * Get Latest Epoch Data
     * @returns {Promise<EpochData>} latest epoch data
     */
    getLatestEpoch(): Promise<EpochData>;
    /**
     * Get the latest chain tip slot.
     * @returns {Promise<number>} current chain slot
     */
    getCurrentSlot(): Promise<number>;
    /**
     * Check whether a UTxO is still unspent via Koios `POST /utxo_info`.
     * @param txHash 64-char lowercase hex
     * @param outputIndex non-negative integer
     * @returns {Promise<boolean>} true iff the UTxO exists and is unspent
     */
    isUtxoUnspent(txHash: string, outputIndex: number): Promise<boolean>;
    /**
     * Get transaction hashes for an address (lightweight — no full tx details).
     * @param address bech32 address
     * @param limit maximum number of hashes
     * @returns {Promise<string[]>} most recent tx hashes
     */
    getAddressTransactionHashes(address: string, limit: number): Promise<string[]>;
    /**
     * Batch fetch multiple transactions by hash using Koios POST /tx_info.
     * Sends all hashes in one request (chunked at 100 per Koios limit).
     * @param txHashes array of transaction hashes
     * @returns {Promise<Map<string, Transaction>>} map of hash -> Transaction
     */
    getTransactionsBatch(txHashes: string[]): Promise<Map<string, Transaction>>;
    /**
     * Map a Koios /block_info response object to our BlockData (same shape getBlock
     * maps inline; kept private to avoid touching getBlock).
     */
    private mapKoiosBlockInfo;
    /**
     * Get a block by its height via the PostgREST-filtered /blocks list, then resolve
     * full data through /block_info.
     */
    getBlockByHeight(height: number): Promise<BlockData>;
    /**
     * Get up to `count` blocks following `afterHash`, in ascending chain order.
     * Koios has no "next after hash" endpoint, so we list blocks above the anchor height
     * (PostgREST gt + order + limit), then batch /block_info. When the caller already
     * knows the anchor height (the crawler's cursor), the hash→height resolution
     * round-trip is skipped entirely.
     */
    getNextBlocks(afterHash: string, count: number, afterHeight?: number): Promise<BlockData[]>;
    /**
     * Get the full transaction list of a block in block order via /block_txs → /tx_info
     * batch. Handles both the current flattened shape ({tx_hash} per row) and the older
     * {tx_hashes:[...]} shape defensively.
     */
    getBlockTransactions(blockHash: string): Promise<Transaction[]>;
    /**
     * Map a Koios /tx_info response object to the normalized Transaction type.
     */
    private _mapKoiosTx;
}
//# sourceMappingURL=koios-backend.d.ts.map