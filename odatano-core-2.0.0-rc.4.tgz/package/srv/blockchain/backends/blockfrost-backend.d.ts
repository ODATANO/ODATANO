import { CardanoBackend, PaginatingBackend } from './cardano-backend';
import { Transaction, BlockData, Address, UTxO, NetworkInformation, EpochData, MetadataLabelTx, PoolData, AccountData, DrepData, AssetInfo, AssetHistoryEntry, LedgerProtocolParameters } from '../../utils/types';
import { Network } from '../cardano-client';
/**
 * BlockfrostBackend Implementation for CardanoBackend Interface
 * Implements the CardanoBackend interface using Blockfrost API SDK
 */
export declare class BlockfrostBackend implements CardanoBackend, PaginatingBackend {
    readonly name = "blockfrost";
    private api;
    private network;
    private timeoutMs;
    /**
     * Constructor
     */
    constructor(network: Network, timeoutMs: number, projectId: string, customBackend?: string);
    /**
     * Initialize the backend
     */
    init(): Promise<boolean>;
    /**
     * Get Network Information
     * @returns {Promise<NetworkInformation>} network information
     */
    getNetworkInformation(): Promise<NetworkInformation>;
    /**
     * Get Block Data
     * @param blockHash block hash (hex)
     * @returns {Promise<BlockData>} block data
     */
    getBlock(blockHash: string): Promise<BlockData>;
    /**
     * Get Epoch Data
     * @param epochNumber epoch number
     * @returns {Promise<EpochData>} epoch data
     */
    getEpoch(epochNumber: number): Promise<EpochData>;
    /**
     * Get Transaction Data
     * @param hash transaction hash (hex)
     * @returns {Promise<Transaction>} transaction data
     */
    getTransaction(hash: string): Promise<Transaction>;
    /**
     * Get Transaction Metadata
     * @param tx_hash transaction hash (hex)
     * @returns {Promise<MetadataLabelTx[]>} transaction metadata list
     */
    getTransactionMetadata(tx_hash: string): Promise<MetadataLabelTx[]>;
    /**
     * Get Address Data (without transactions - use getAddressTransactions() separately)
     * @param address bech32 address string
     * @returns {Promise<Address>} address data
     */
    getAddress(address: string): Promise<Address>;
    /**
     * Get Address Transactions
     * @param address bech32 address string
     * @returns {Promise<Transaction[]>} list of transactions for this address
     */
    getAddressTransactions(address: string, limit?: number): Promise<Transaction[]>;
    /**
     * Get Address UTxOs
     * @param address bech32 address string
     * @returns {Promise<UTxO[]>} list of UTxOs
     */
    getAddressUtxos(address: string): Promise<UTxO[]>;
    /**
     * Get Pool Data
     * @param poolId stake pool id (hex)
     * @return {Promise<PoolData>} pool data
     */
    getPool(poolId: string): Promise<PoolData>;
    /**
     * Get Asset Info (supply, mint history, CIP-25 + CIP-26 metadata).
     * Blockfrost does NOT expose initial-mint timestamp in this endpoint —
     * `initialMintTime` is left null. Filling it would cost an extra tx fetch.
     * @param unit policyId + assetNameHex (concatenated hex)
     * @return {Promise<AssetInfo>} canonical asset info
     */
    getAssetInfo(unit: string): Promise<AssetInfo>;
    /**
     * Get latest mint/burn events for an asset, with backfilled block metadata.
     * Blockfrost's `assetsHistory` returns tx_hash + action + amount only; we
     * backfill `blockTime` and `blockHeight` via concurrent `api.txs(...)` calls.
     * Cost: 1 extra API call per history entry. Failed tx fetches leave the
     * timestamp fields null instead of failing the whole call (best-effort).
     * @param unit policyId + assetNameHex (concatenated hex)
     * @param limit max number of events (default 100, max 100 per Blockfrost page)
     * @return {Promise<AssetHistoryEntry[]>} list of mint/burn events (most recent first)
     */
    getAssetHistory(unit: string, limit?: number): Promise<AssetHistoryEntry[]>;
    /**
     * Get Drep Data
     * @param drepId drep id (bech32)
     * @return {Promise<DrepData>} drep data
     */
    getDrep(drepId: string): Promise<DrepData>;
    /**
     * Get Account Data
     * @param stakeAddress bech32 stake address
     * @return {Promise<AccountData>} account data
     */
    getAccount(stakeAddress: string): Promise<AccountData>;
    /**
     * Submit Transaction
     * @param signedTxCbor hex-encoded signed transaction CBOR
     * @returns {Promise<string>} transaction hash
     */
    submitTransaction(signedTxCbor: string): Promise<string>;
    /**
     * Get Protocol Parameters
     * @returns {Promise<LedgerProtocolParameters>} protocol parameters
     */
    getProtocolParameters(): Promise<LedgerProtocolParameters>;
    /**
     * Get Latest Epoch Data
     * @returns {Promise<EpochData>} latest epoch data
     */
    getLatestEpoch(): Promise<EpochData>;
    /**
     * Get Latest Block Data
     * @returns {Promise<BlockData>} latest block data
     */
    getLatestBlock(): Promise<BlockData>;
    /**
     * Get the latest chain tip slot.
     * @returns {Promise<number>} current chain slot
     */
    getCurrentSlot(): Promise<number>;
    /**
     * Check whether a UTxO is still unspent via Blockfrost's `consumed_by_tx` field.
     * @param txHash 64-char lowercase hex
     * @param outputIndex non-negative integer
     * @returns {Promise<boolean>} true iff the UTxO exists and is unspent
     */
    isUtxoUnspent(txHash: string, outputIndex: number): Promise<boolean>;
    /** Max concurrent Blockfrost API calls (free tier: ~10 req/s) */
    private static readonly MAX_CONCURRENT;
    /**
     * Get transaction hashes for an address (lightweight — no full tx details).
     * @param address bech32 address
     * @param limit maximum number of hashes
     * @returns {Promise<string[]>} most recent tx hashes
     */
    getAddressTransactionHashes(address: string, limit: number): Promise<string[]>;
    /**
     * Batch fetch multiple transactions by hash.
     * Blockfrost has no batch endpoint — uses concurrency-limited parallel calls.
     * @param txHashes array of transaction hashes
     * @returns {Promise<Map<string, Transaction>>} map of hash -> Transaction
     */
    getTransactionsBatch(txHashes: string[]): Promise<Map<string, Transaction>>;
    /**
     * Map a Blockfrost block summary (from blocks()/blocksNext()) to our BlockData.
     * Same shape getBlock() maps inline — kept private to avoid touching getBlock().
     */
    private toBlockData;
    /**
     * Get a block by its height. Blockfrost's `blocks` endpoint accepts a height as
     * well as a hash.
     */
    getBlockByHeight(height: number): Promise<BlockData>;
    /**
     * Get up to `count` blocks immediately following `afterHash`, in ascending chain order.
     */
    getNextBlocks(afterHash: string, count: number): Promise<BlockData[]>;
    /**
     * Get the full transaction list of a block in block order. Blockfrost returns tx
     * hashes; details are batched via getTransactionsBatch. Order is preserved.
     */
    getBlockTransactions(blockHash: string): Promise<Transaction[]>;
}
//# sourceMappingURL=blockfrost-backend.d.ts.map