"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OgmiosBackend = void 0;
exports.resolveOgmiosTip = resolveOgmiosTip;
exports.resolveOgmiosHeight = resolveOgmiosHeight;
const cds_1 = __importDefault(require("@sap/cds"));
const node_http_1 = __importDefault(require("node:http"));
const client_1 = require("@cardano-ogmios/client");
const backend_request_handler_1 = require("../../utils/backend-request-handler");
const errors_1 = require("../../utils/errors");
const mappers_1 = require("../../utils/mappers");
const const_1 = require("../../utils/const");
const logger = cds_1.default.log('OgmiosBackend');
/**
 * First absolute slot of the given epoch, from the network's Shelley anchor.
 * Replaces the old `epoch * 432000` math, which was wrong on preview (86 400
 * slots per epoch) and on mainnet/preprod (Byron offset).
 */
function epochStartSlot(network, epoch) {
    const cfg = const_1.EPOCH_CONFIG_BY_NETWORK[network];
    return cfg.shelleyStartSlot + (epoch - cfg.shelleyStartEpoch) * cfg.slotsPerEpoch;
}
/**
 * Absolute POSIX seconds for a slot, via the same Shelley-anchored genesis infos
 * the transaction builder uses for validity windows. The previous code treated
 * Ogmios' `eraStart.time` (RelativeTime since SYSTEM start) as a Unix timestamp.
 */
function slotToPosixSeconds(network, slot) {
    const genesis = const_1.GENESIS_INFOS_BY_NETWORK[network];
    return Math.floor((genesis.systemStartPosixMs + (slot - genesis.startSlotNo) * genesis.slotLengthMs) / 1000);
}
/**
 * Parse an Ogmios `Ratio` ("num/den" string, e.g. "3/1000") into a number.
 * `Number("3/1000")` is NaN — previously every ratio-typed protocol parameter
 * (priceMem, priceStep, a0, rho, tau) came out as NaN.
 */
function parseOgmiosRatio(ratio) {
    if (ratio === null || ratio === undefined)
        return 0;
    if (typeof ratio === 'number')
        return ratio;
    const m = /^(-?\d+)\s*\/\s*(\d+)$/.exec(ratio);
    if (m) {
        const den = Number(m[2]);
        return den === 0 ? 0 : Number(m[1]) / den;
    }
    const n = Number(ratio);
    return Number.isFinite(n) ? n : 0;
}
/**
 * Extract a lovelace amount from Ogmios' value shapes. Ogmios v6 returns
 * `{ ada: { lovelace } }` objects — calling `.toString()` on those yields
 * "[object Object]", which previously ended up in the AccountData fields.
 */
function ogmiosValueToLovelaceString(value) {
    if (value === null || value === undefined)
        return '0';
    if (typeof value === 'bigint' || typeof value === 'number')
        return String(value);
    const lovelace = value.ada?.lovelace;
    return lovelace === undefined ? '0' : String(lovelace);
}
/** Resolve Ogmios ledger tip which may be 'origin' (genesis block) or a point */
function resolveOgmiosTip(tip) {
    return tip === 'origin' ? { slot: 0, hash: '' } : { slot: tip.slot, hash: tip.id };
}
/** Resolve Ogmios block height which may be 'origin' (genesis block) or a number */
function resolveOgmiosHeight(height) {
    return height === 'origin' ? 0 : height;
}
class OgmiosBackend {
    name = 'ogmios';
    /**
     * Capability declaration — the orchestrator skips Ogmios for these without
     * counting circuit failures. Historic queries are out of protocol scope;
     * getAddress/getNetworkInformation previously FABRICATED placeholder data
     * (type:'base'/isScript:false/stakeAddress:null resp. maxSupply as
     * total/circulating) which preferLive routing then preferred over correct
     * Blockfrost/Koios data.
     */
    unsupportedMethods = new Set([
        // getEpoch is NOT listed: Ogmios can serve the CURRENT epoch and only
        // rejects historic ones — routing prefers historical backends anyway.
        'getBlock',
        'getTransaction',
        'getTransactionMetadata',
        'getAddressTransactions',
        'getDrep',
        'getAssetInfo',
        'getAddress',
        'getNetworkInformation',
    ]);
    stateQueryClient = null;
    txSubmissionClient = null;
    context = null;
    isShutdown = false;
    reconnectPromise = null;
    network;
    timeoutMs;
    ogmiosUrl;
    /**
     * Constructor
     */
    constructor(network, timeoutMs, ogmiosUrl) {
        if (!ogmiosUrl) {
            throw new errors_1.BackendInitError('ogmios', new Error('ogmiosUrl is not set'));
        }
        this.network = network;
        this.timeoutMs = timeoutMs;
        this.ogmiosUrl = ogmiosUrl;
    }
    /**
     * Force fresh (non-keep-alive) HTTP connections for the Ogmios `/health` probe.
     *
     * createInteractionContext() opens the WebSocket, but FIRST probes
     * `GET http://<ogmios>/health` via the library's `cross-fetch` → node-fetch v2
     * → Node-core `http`. Since Node 19, `http.globalAgent` defaults to
     * keepAlive:true, so node-fetch reuses pooled sockets. Against Ogmios' Warp
     * server on Node 22/24 a reused socket the server has already half-closed
     * yields "Invalid response body … Premature close" the instant the body is
     * read — deterministically (Node 20's older http client tolerated it; `curl`
     * does too, so the /health response itself is well-formed and the node is
     * healthy). The lib pins cross-fetch even in 7.0 and exposes no way to inject
     * an agent into that internal fetch, so we neutralise keep-alive process-wide
     * for `http://`. Blast radius is tiny: the only `http://` consumer is the local
     * Ogmios probe — Blockfrost/Koios run over `https` with their own axios agents
     * and are unaffected. Runs once, lazily, only when Ogmios is actually used.
     */
    static keepAliveDisabled = false;
    static disableHttpKeepAlive() {
        if (OgmiosBackend.keepAliveDisabled)
            return;
        node_http_1.default.globalAgent = new node_http_1.default.Agent({ keepAlive: false });
        OgmiosBackend.keepAliveDisabled = true;
    }
    /** Validate Ogmios URL scheme and reject dangerous protocols */
    static validateOgmiosUrl(rawUrl) {
        const url = new URL(rawUrl);
        // Only allow WebSocket schemes (block file://, http://, etc.)
        if (url.protocol !== 'ws:' && url.protocol !== 'wss:') {
            throw new errors_1.BackendInitError('ogmios', new Error(`Invalid Ogmios URL scheme "${url.protocol}" — only ws:// and wss:// are allowed`));
        }
        // In production, block link-local / metadata IPs (SSRF prevention).
        // Private/loopback IPs are allowed since Ogmios typically runs on the local node.
        const host = url.hostname.toLowerCase();
        const dangerousPatterns = [
            /^169\.254\./, // AWS/cloud metadata endpoint range
            /^\[?fe80/ // IPv6 link-local
        ];
        if (dangerousPatterns.some(p => p.test(host))) {
            throw new errors_1.BackendInitError('ogmios', new Error('Ogmios URL must not point to a link-local or metadata address'));
        }
    }
    /**
     * Bound an init step in time. A hung WebSocket connect/handshake (e.g. the
     * node is alive but too busy catching up to answer) would otherwise block
     * forever — there is no built-in connect timeout — hanging the whole
     * app-context bootstrap (seen as a 6h CI job timeout). On timeout we reject
     * with a message containing "timeout" so the orchestrator's transient-error
     * retry picks it up instead of dying.
     */
    withInitTimeout(p, label) {
        // Keep this SHORT: the orchestrator retries init a few times within the
        // integration suite's 20s cds.test() hook, so each attempt must be brief.
        // Still bounds a genuinely hung connect in production.
        const ms = Math.max(1, Math.min(this.timeoutMs, 4000));
        let timer;
        const timeout = new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error(`Ogmios init timeout after ${ms}ms (${label})`)), ms);
            timer.unref?.();
        });
        return Promise.race([p, timeout]).finally(() => clearTimeout(timer));
    }
    /**
     * Force-release an Ogmios interaction socket after a failed/expired open or
     * close step. The runtime uses `ws` (and therefore supports `terminate`), but
     * the close fallback keeps the helper compatible with the public structural
     * InteractionContext type and lightweight test doubles.
     */
    forceCloseContext(context) {
        const socket = context.socket;
        try {
            if (typeof socket.terminate === 'function') {
                socket.terminate();
            }
            else if (typeof socket.close === 'function' && socket.readyState !== (socket.CLOSED ?? 3)) {
                socket.close();
            }
        }
        catch {
            // Best effort only: the socket may already have completed its close event.
        }
    }
    /**
     * Initialize the Ogmios backend connection
     */
    async init() {
        OgmiosBackend.disableHttpKeepAlive();
        OgmiosBackend.validateOgmiosUrl(this.ogmiosUrl);
        const url = new URL(this.ogmiosUrl);
        const connection = {
            host: url.hostname,
            port: Number(url.port) || (url.protocol === 'wss:' ? 443 : 80),
            tls: url.protocol === 'wss:'
        };
        const context = await this.withInitTimeout((0, client_1.createInteractionContext)(
        /* c8 ignore next */
        (err) => logger.error(`[OgmiosBackend] Interaction context error: ${err.message}`), () => {
            // Socket closed: clear the clients so the next request reconnects via
            // ensureConnected — previously this handler only logged and the backend
            // stayed dead until process restart.
            if (this.isShutdown)
                return;
            logger.warn('[OgmiosBackend] WebSocket closed — will reconnect on next request');
            this.stateQueryClient = null;
            this.txSubmissionClient = null;
        }, { connection }), 'createInteractionContext');
        try {
            this.stateQueryClient = await this.withInitTimeout((0, client_1.createLedgerStateQueryClient)(context), 'ledgerStateQueryClient');
            this.txSubmissionClient = await this.withInitTimeout((0, client_1.createTransactionSubmissionClient)(context), 'txSubmissionClient');
        }
        catch (err) {
            // don't leak the WebSocket when client creation fails mid-init
            // (runtime socket is node `ws`, which exposes terminate())
            try {
                context.socket.terminate();
            }
            catch { /* best effort */ }
            throw err;
        }
        this.context = context;
        return true;
    }
    /**
     * Reconnect when the WebSocket has died since the last successful init.
     * No-op when never initialized (test-injected clients) — startup-init
     * recovery is the orchestrator's job (lazy init retry in CardanoClient).
     * Concurrent callers share one reconnect attempt.
     */
    async ensureConnected() {
        this.ensureNotShutdown();
        if (!this.context)
            return;
        const socket = this.context.socket;
        const socketOpen = !socket || socket.readyState === (socket.OPEN ?? 1);
        if (this.stateQueryClient && socketOpen)
            return;
        if (!this.reconnectPromise) {
            logger.warn('[OgmiosBackend] WebSocket not connected — reconnecting');
            this.reconnectPromise = this.init()
                .then(() => undefined)
                .finally(() => { this.reconnectPromise = null; });
        }
        await this.reconnectPromise;
    }
    /**
     * Get specific Block Data (not supported)
     * @param _hash block hash (hex)
     * @returns {Promise<BlockData>} block data
     */
    async getBlock(_hash) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.NotFoundError('Historic Block queries not supported', this.name);
        }, this.name);
    }
    /**
     * Get specific Epoch Data (not supported)
     * @param _epochNumber epoch number
     * @returns {Promise<EpochData>} epoch data
     */
    async getEpoch(epochNumber) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            // Get current epoch directly via epoch() query
            const currentEpoch = await this.stateQueryClient.epoch();
            // Ogmios only supports current epoch queries
            if (epochNumber !== currentEpoch) {
                throw new errors_1.NotFoundError(`Historic Epoch ${epochNumber} not supported (current: ${currentEpoch})`, this.name);
            }
            // Return current epoch data
            return this.getLatestEpoch();
        }, this.name);
    }
    /**
     * Get specific Transaction Data (not supported)
     * @param _hash transaction hash (hex)
     * @returns {Promise<Transaction>} transaction data
     */
    async getTransaction(_hash) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.NotFoundError('Historic Transaction queries not supported', this.name);
        }, this.name);
    }
    /**
     * Get specific Transaction Metadata (not supported)
     * @param _tx_hash transaction hash (hex)
     * @returns {Promise<MetadataLabelTx[]>} transaction metadata list
     */
    async getTransactionMetadata(_tx_hash) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.NotFoundError('Historic Transaction metadata not supported', this.name);
        }, this.name);
    }
    /**
     * Get specific Drep Data (not supported for Ogmios)
     * @param _drepId drep id
     * @returns {Promise<DrepData>} drep data
     */
    async getDrep(_drepId) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.ProviderUnavailableError('DRep queries not supported by Ogmios backend', this.name);
        }, this.name);
    }
    /**
     * Get Asset Info (not supported for Ogmios — no aggregate-supply query in the protocol)
     * @param _unit asset unit (policyId + assetNameHex)
     * @returns {Promise<AssetInfo>} asset info
     */
    async getAssetInfo(_unit) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.ProviderUnavailableError('Asset info queries not supported by Ogmios backend', this.name);
        }, this.name);
    }
    /**
     * Get specific Network Information (not supported — Ogmios state queries
     * expose no supply/stake aggregates; the previous implementation fabricated
     * maxSupply as total/circulating, which preferLive routing then preferred
     * over correct Blockfrost/Koios data)
     */
    async getNetworkInformation() {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.ProviderUnavailableError('Network information not supported by Ogmios backend — use Blockfrost/Koios', this.name);
        }, this.name);
    }
    /**
     * Get current specific Address Data (not supported — address type, script
     * flag and stake address are not derivable from Ogmios state queries; the
     * previous implementation fabricated type:'base'/isScript:false/
     * stakeAddress:null. UTxOs remain available via getAddressUtxos.)
     */
    async getAddress(_address) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            throw new errors_1.ProviderUnavailableError('Address detail queries not supported by Ogmios backend — use Blockfrost/Koios', this.name);
        }, this.name);
    }
    /** get current specific Address UTxOs
     * @param address bech32 address
     * @returns {Promise<UTxO[]>} address UTxOs
     */
    async getAddressUtxos(address) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            const utxos = await this.stateQueryClient.utxo({ addresses: [address] });
            return utxos.map((u) => {
                // convert Ogmios value format to standard amount array
                const amount = this.convertOgmiosValue(u.value);
                return {
                    txHash: u.transaction?.id || '',
                    outputIndex: u.index || 0,
                    address: u.address || address,
                    amount: amount,
                    blockHash: '',
                    datumHash: u.datumHash,
                    // Ogmios delivers the inline datum as CBOR hex in `datum` — it was
                    // dropped before, breaking inline-datum spends when Ogmios serves UTxOs
                    inlineDatum: typeof u.datum === 'string' ? u.datum : null,
                    scriptRef: u.script?.hash
                };
            });
        }, this.name);
    }
    /**
     * Get Address Transactions (not supported by Ogmios - use historical backend)
     * Ogmios is a live state query backend and does not provide historical transaction data
     * @param _address bech32 address
     * @returns {Promise<Transaction[]>} always throws - use historical backend instead
     */
    async getAddressTransactions(_address) {
        throw new errors_1.NotFoundError('Address transactions not available via Ogmios - use historical backend (Blockfrost/Koios)', this.name);
    }
    /**
     * Get current specific Pool Data
     * @param poolId pool id
     * @returns {Promise<PoolData>} pool data
     */
    async getPool(poolId) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            // Query from tip (no acquire needed) with stake included
            const pools = await this.stateQueryClient.stakePools([{ id: poolId }], true);
            // Extract pool from response - stakePools returns object keyed by poolId
            const pool = pools[poolId];
            if (!pool)
                throw new errors_1.NotFoundError('Pool', this.name);
            return {
                poolId,
                vrfKeyHash: pool.vrf || pool.vrfKeyHash || '',
                blocksMinted: 0,
                blocksEpoch: 0,
                liveStake: pool.stake?.ada?.lovelace ? String(pool.stake.ada.lovelace) : '0',
                liveSize: 0,
                liveDelegators: 0,
                liveSaturation: 0,
                // activeStake is not available from Ogmios pool params — report 0 instead
                // of fabricating it from the pledge
                activeStake: '0',
                activeSize: 0,
                // pledge/cost are ValueAdaOnly objects in Ogmios v6 — String() on those
                // yielded "[object Object]"; margin is a Ratio string ("1/10")
                pledge: ogmiosValueToLovelaceString(pool.pledge),
                margin: parseOgmiosRatio(pool.margin),
                fixedCost: ogmiosValueToLovelaceString(pool.cost),
                rewardAccount: pool.rewardAccount || ''
            };
        }, this.name);
    }
    /**
     * Get Account Data for specified stake address
     * @param stakeAddress stake address
     * @returns {Promise<AccountData>} account data
     */
    async getAccount(stakeAddress) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            const rawResult = await this.stateQueryClient.rewardAccountSummaries({ keys: [stakeAddress] });
            // Ogmios returns a record keyed by stake address; normalize to array
            const summaries = Array.isArray(rawResult)
                ? rawResult
                : Object.values(rawResult);
            // Ogmios API returns array of account summaries
            const account = summaries && summaries.length > 0 ? summaries[0] : null;
            if (!account) {
                throw new errors_1.NotFoundError('Account', this.name);
            }
            return {
                stakeaddress: stakeAddress,
                // Ogmios only returns reward-account summaries for REGISTERED stake keys —
                // reaching this point (summary found) therefore implies the account is active.
                active: true,
                activeEpoch: 0,
                controlledAmount: ogmiosValueToLovelaceString(account.controlledAmount),
                rewardsSum: ogmiosValueToLovelaceString(account.rewards),
                withdrawalsSum: ogmiosValueToLovelaceString(account.withdrawals),
                reservesSum: '0',
                treasurySum: '0',
                withdrawableAmount: ogmiosValueToLovelaceString(account.rewards),
                poolId: account.delegate?.id || account.delegation?.poolId || null,
                drepId: account.vote?.id || account.drep?.id || null,
                addresses: []
            };
        }, this.name);
    }
    /**
     * Submit Transaction to the network
     * @param signedTxCbor signed transaction in CBOR hex format
     * @returns {Promise<string>} transaction hash
     */
    async submitTransaction(signedTxCbor) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            const txHash = await this.txSubmissionClient.submitTransaction(signedTxCbor);
            return txHash;
        }, this.name);
    }
    /**
     * Evaluate transaction script execution units
     * @param unsignedTxCbor unsigned transaction in CBOR hex format
     * @returns {Promise<ScriptEvaluationResult[]>} evaluation results
     */
    async evaluateTransaction(unsignedTxCbor) {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            const results = await this.txSubmissionClient.evaluateTransaction(unsignedTxCbor);
            return results;
        }, this.name);
    }
    /**
     * Get current Protocol Parameters
     * @returns {Promise<LedgerProtocolParameters>} protocol parameters
     */
    async getProtocolParameters() {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            // Query protocol parameters and epoch in parallel
            const [params, currentEpoch] = await Promise.all([
                this.stateQueryClient.protocolParameters(),
                this.stateQueryClient.epoch()
            ]);
            return {
                network: this.network,
                epoch: currentEpoch,
                minUtxo: params.minUtxoDepositCoefficient?.toString() || '0',
                nonce: '',
                costModels: JSON.stringify((0, mappers_1.normalizeCostModels)(params.plutusCostModels || {})),
                minFeeA: params.minFeeCoefficient || 0,
                minFeeB: Number(params.minFeeConstant?.ada?.lovelace || 0),
                maxBlockSize: params.maxBlockBodySize?.bytes || 0,
                priceMem: parseOgmiosRatio(params.scriptExecutionPrices?.memory),
                priceStep: parseOgmiosRatio(params.scriptExecutionPrices?.cpu),
                maxTxExMem: (params.maxExecutionUnitsPerTransaction?.memory || 0).toString(),
                maxTxExSteps: (params.maxExecutionUnitsPerTransaction?.cpu || 0).toString(),
                maxBlockExMem: (params.maxExecutionUnitsPerBlock?.memory || 0).toString(),
                maxBlockExSteps: (params.maxExecutionUnitsPerBlock?.cpu || 0).toString(),
                maxValSize: (params.maxValueSize?.bytes || 0).toString(),
                collateralPercent: params.collateralPercentage || 0,
                maxCollateralInputs: params.maxCollateralInputs || 0,
                coinsPerUtxoSize: params.minUtxoDepositCoefficient?.toString() || '0',
                maxBlockHeaderSize: params.maxBlockHeaderSize?.bytes || 0,
                maxTxSize: params.maxTransactionSize?.bytes || 0,
                keyDeposit: params.stakeCredentialDeposit?.ada?.lovelace?.toString() || '0',
                minPoolCost: params.minStakePoolCost?.ada?.lovelace?.toString() || '0',
                poolDeposit: params.stakePoolDeposit?.ada?.lovelace?.toString() || '0',
                eMax: params.stakePoolRetirementEpochBound || 0,
                nOpt: params.desiredNumberOfStakePools || 0,
                a0: parseOgmiosRatio(params.stakePoolPledgeInfluence),
                // ρ = monetaryExpansion, τ = treasuryExpansion (was swapped; Koios maps it correctly)
                rho: parseOgmiosRatio(params.monetaryExpansion),
                tau: parseOgmiosRatio(params.treasuryExpansion),
                decentralisationParam: 0,
                extraEntropy: null,
                protocolMajorVer: params.version?.major || 0,
                protocolMinorVer: params.version?.minor || 0,
                fetchedAt: new Date().toISOString(),
                source: this.name
            };
        }, this.name);
    }
    /**
     * Get Latest Epoch Data
     * @returns {Promise<EpochData>} latest epoch data
     */
    async getLatestEpoch() {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            const [currentEpoch, tip] = await Promise.all([
                this.stateQueryClient.epoch(),
                this.stateQueryClient.ledgerTip()
            ]);
            const { slot } = resolveOgmiosTip(tip);
            // Network-aware epoch geometry + Shelley-anchored slot→time conversion
            const startSlot = epochStartSlot(this.network, currentEpoch);
            const endSlot = startSlot + const_1.EPOCH_CONFIG_BY_NETWORK[this.network].slotsPerEpoch;
            return {
                epoch: currentEpoch,
                start_time: slotToPosixSeconds(this.network, startSlot),
                end_time: slotToPosixSeconds(this.network, endSlot),
                first_block_time: slotToPosixSeconds(this.network, startSlot),
                last_block_time: slotToPosixSeconds(this.network, slot),
                block_count: 0, // Not available from Ogmios state queries
                tx_count: 0, // Not available from Ogmios state queries
                output: '0',
                fees: '0',
                active_stake: null,
            };
        }, this.name);
    }
    /**
     * Get current Latest Block Data
     * @returns {Promise<BlockData>} latest block data
     */
    async getLatestBlock() {
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            // Fetch ledger tip, block height and epoch in parallel
            const [tip, blockHeight, epoch] = await Promise.all([
                this.stateQueryClient.ledgerTip(),
                this.stateQueryClient.networkBlockHeight(),
                this.stateQueryClient.epoch()
            ]);
            const { slot, hash } = resolveOgmiosTip(tip);
            const height = resolveOgmiosHeight(blockHeight);
            // network-aware slot-in-epoch (the old `slot % 432000` was wrong on every network)
            const epochSlot = Math.max(0, slot - epochStartSlot(this.network, epoch));
            return {
                time: slotToPosixSeconds(this.network, slot), // seconds (mapBlock expects seconds)
                height,
                hash,
                slot,
                epoch,
                epochSlot,
                slotLeader: '', // Not available via ledgerTip - would need chainSync
                size: 0, // Not available via ledgerTip - would need full block data
                txCount: 0, // Not available via ledgerTip - would need full block data
                fees: '0', // Not available via ledgerTip - would need full block data
            };
        }, this.name);
    }
    /**
     * Get the latest chain tip slot.
     * @returns {Promise<number>} current chain slot
     */
    async getCurrentSlot() {
        const block = await this.getLatestBlock();
        if (block.slot == null) {
            throw new errors_1.ProviderUnavailableError(`${this.name}: latest block has no slot`, this.name);
        }
        return block.slot;
    }
    /**
     * Check whether a UTxO is still unspent via Ogmios `queryLedgerState/utxo`
     * with an outputReferences filter. Empty result means spent or nonexistent.
     * @param txHash 64-char lowercase hex
     * @param outputIndex non-negative integer
     * @returns {Promise<boolean>} true iff the UTxO exists and is unspent
     */
    async isUtxoUnspent(txHash, outputIndex) {
        if (!Number.isInteger(outputIndex) || outputIndex < 0)
            return false;
        return (0, backend_request_handler_1.handleBackendRequest)(async () => {
            await this.ensureConnected();
            const result = await this.stateQueryClient.utxo({
                outputReferences: [{ transaction: { id: txHash }, index: outputIndex }],
            });
            return Array.isArray(result) && result.length > 0;
        }, this.name);
    }
    /**
     * Shutdown the Ogmios Backend
     * Closes all connections and marks as shutdown
     */
    async shutdown() {
        if (this.isShutdown)
            return;
        this.isShutdown = true;
        // Terminate the WebSocket and wait for close confirmation
        if (this.context?.socket) {
            // Ogmios's typed `socket` is browser WebSocket, but at runtime it's the
            // node `ws` WebSocket which exposes `once`/`terminate` and readyState consts.
            const socket = this.context.socket;
            if (socket.readyState === socket.OPEN || socket.readyState === socket.CONNECTING) {
                await new Promise((resolve) => {
                    const timer = setTimeout(resolve, 3000);
                    timer.unref(); // Don't keep event loop alive for this timeout
                    socket.once('close', () => { clearTimeout(timer); resolve(); });
                    socket.terminate();
                });
            }
        }
        this.stateQueryClient = null;
        this.txSubmissionClient = null;
        this.context = null;
    }
    /**
     * Check if backend is connected
     */
    isConnected() {
        if (this.isShutdown || !this.context?.socket) {
            return false;
        }
        const socket = this.context.socket;
        return socket.readyState === socket.OPEN;
    }
    // ---------------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------------
    /**
     * Ensure the client is not shutdown before operations
     */
    ensureNotShutdown() {
        if (this.isShutdown) {
            throw new errors_1.ProviderUnavailableError('Ogmios client has been shutdown', this.name);
        }
    }
    /**
     * Convert Ogmios value format to odatano amount array
     * Ogmios: { ada: { lovelace: 1000000 }, policyId: { assetName: quantity } }
     * Standard: [{ unit: 'lovelace', quantity: '1000000' }, { unit: 'policyId.assetName', quantity: 'N' }]
     */
    convertOgmiosValue(value) {
        const amounts = [];
        // Handle ADA (lovelace)
        if (value.ada?.lovelace) {
            amounts.push({
                unit: 'lovelace',
                quantity: value.ada.lovelace.toString()
            });
        }
        // handle native assets (policy.assetName)
        for (const [policyId, assets] of Object.entries(value)) {
            if (policyId === 'ada')
                continue;
            for (const [assetName, quantity] of Object.entries(assets)) {
                amounts.push({
                    unit: `${policyId}${assetName}`,
                    quantity: quantity.toString()
                });
            }
        }
        return amounts;
    }
    // ---------------------------------------------------------------------------
    // ChainSyncBackend — streamed forward sync for the chain crawler (v2.0)
    // ---------------------------------------------------------------------------
    /**
     * Open a dedicated chain-synchronization stream. Uses its own InteractionContext
     * (a separate WebSocket) from the query/submission clients, because it is a
     * long-lived stream. `sequential: true` + `inFlight: 1` deliver blocks one at a
     * time in order, which the crawler needs for reorg detection and serial persist.
     *
     * KNOWN LIMITATIONS (documented, to harden against a live node — see CRAWLER_DESIGN.md):
     *  - Input address/amount are left empty: Ogmios chain-sync inputs are bare
     *    references ({txId,index}); the indexer resolves them from already-indexed
     *    outputs (indexBlockFull, C3).
     *  - Per-tx `size` and `deposit` are not surfaced by chain-sync (set 0).
     *  - Output `referenceScriptHash` is not derived from the inline script yet.
     */
    async openChainSync(from, callbacks) {
        OgmiosBackend.validateOgmiosUrl(this.ogmiosUrl);
        const url = new URL(this.ogmiosUrl);
        const connection = {
            host: url.hostname,
            port: Number(url.port) || (url.protocol === 'wss:' ? 443 : 80),
            tls: url.protocol === 'wss:'
        };
        let intentionalClose = false;
        let terminalErrorReported = false;
        // Context callbacks are synchronous, while the crawler callback is async.
        // Start it without leaving an unhandled rejection and suppress the common
        // error+close double notification for a single broken socket.
        const reportStreamError = async (err) => {
            if (intentionalClose || this.isShutdown || terminalErrorReported)
                return;
            terminalErrorReported = true;
            try {
                await callbacks.onError?.(err);
            }
            catch (callbackError) {
                logger.error('[OgmiosBackend] chain-sync onError callback failed:', callbackError);
            }
        };
        const contextPromise = (0, client_1.createInteractionContext)((err) => {
            logger.error(`[OgmiosBackend] chain-sync context error: ${err.message}`);
            void reportStreamError(err);
        }, (code, reason) => {
            if (intentionalClose || this.isShutdown)
                return;
            const detail = reason?.toString() || 'no reason supplied';
            const err = new errors_1.ProviderUnavailableError(`Ogmios chain-sync socket closed unexpectedly (code ${code}: ${detail})`, this.name);
            logger.warn(`[OgmiosBackend] ${err.message}`);
            void reportStreamError(err);
        }, { connection });
        let context;
        try {
            context = await this.withInitTimeout(contextPromise, 'chainSync/createInteractionContext');
        }
        catch (err) {
            // A timeout rejects our race but cannot cancel the library's health probe /
            // handshake. If it resolves later, close that late socket as well.
            intentionalClose = true;
            void contextPromise.then(lateContext => this.forceCloseContext(lateContext)).catch(() => undefined);
            throw err;
        }
        // Both handlers are fully try/caught: the ogmios client lib awaits them with NO
        // catch of its own, and with sequential+inFlight:1 a throw before nextBlock()
        // stalls the stream forever. On error we deliberately do NOT call nextBlock()
        // (stopping deterministically instead of skipping a block) and surface the error
        // via callbacks.onError so the consumer can record it and close/restart.
        const handlers = {
            rollForward: async ({ block, tip }, nextBlock) => {
                try {
                    const b = block;
                    // Byron epoch-boundary (ebb) / bft blocks carry no indexable Praos txs — skip.
                    if (b.type !== 'praos') {
                        nextBlock();
                        return;
                    }
                    const mapped = this.mapOgmiosBlock(b);
                    const t = tip;
                    const tipPoint = t && t !== 'origin' && t.slot != null && t.id
                        ? { slot: t.slot, hash: t.id, height: t.height }
                        : undefined;
                    await callbacks.rollForward(mapped.block, mapped.txs, tipPoint);
                    nextBlock();
                }
                catch (err) {
                    logger.error('[OgmiosBackend] chain-sync rollForward failed — stream halted:', err);
                    await reportStreamError(err);
                }
            },
            rollBackward: async ({ point }, nextBlock) => {
                try {
                    const p = point;
                    await callbacks.rollBackward(p === 'origin' ? 'origin' : { slot: p.slot, hash: p.id });
                    nextBlock();
                }
                catch (err) {
                    logger.error('[OgmiosBackend] chain-sync rollBackward failed — stream halted:', err);
                    await reportStreamError(err);
                }
            },
        };
        let client;
        try {
            client = await this.withInitTimeout((0, client_1.createChainSynchronizationClient)(context, handlers, { sequential: true }), 'chainSync/createClient');
            // Ogmios intersects at the FIRST of these still on its chain, so ancestors
            // turn a fork we slept through into a rollBackward instead of a hard failure.
            const points = from === 'origin' ? ['origin'] : from.map((p) => ({ slot: p.slot, id: p.hash }));
            await this.withInitTimeout(client.resume(points, 1), 'chainSync/resume');
        }
        catch (err) {
            intentionalClose = true;
            if (client) {
                try {
                    await this.withInitTimeout(client.shutdown(), 'chainSync/failedOpenShutdown');
                }
                catch {
                    // forceCloseContext below is the final cleanup path
                }
            }
            this.forceCloseContext(context);
            throw err;
        }
        let closePromise = null;
        return {
            close: () => {
                // Idempotency matters when an operator stop races an onError-triggered halt.
                if (!closePromise) {
                    intentionalClose = true;
                    closePromise = (async () => {
                        try {
                            await this.withInitTimeout(client.shutdown(), 'chainSync/shutdown');
                        }
                        finally {
                            // Also handles a shutdown timeout or an already-closed socket.
                            this.forceCloseContext(context);
                        }
                    })();
                }
                return closePromise;
            }
        };
    }
    /**
     * Map an Ogmios Praos block into our BlockData + its transactions. Block-level
     * fees are the sum of per-tx fees; epoch/epochSlot are derived from the slot via
     * the network's Shelley anchor (same config the tx-builder uses).
     */
    mapOgmiosBlock(block) {
        const txs = (block.transactions ?? []).map((t, i) => this.mapOgmiosTx(t, block, i));
        const totalFees = txs.reduce((sum, t) => sum + BigInt(t.fee || 0), 0n);
        const cfg = const_1.EPOCH_CONFIG_BY_NETWORK[this.network];
        const epoch = cfg.shelleyStartEpoch + Math.floor((block.slot - cfg.shelleyStartSlot) / cfg.slotsPerEpoch);
        // reuse the Shelley-anchored helper (carries the preview/preprod/Byron-offset fix)
        // instead of a second inline modulo formula
        const epochSlot = block.slot - epochStartSlot(this.network, epoch);
        const blockData = {
            time: slotToPosixSeconds(this.network, block.slot),
            height: block.height,
            hash: block.id,
            slot: block.slot,
            slotLeader: block.issuer?.verificationKey ?? '',
            epoch,
            epochSlot,
            size: block.size?.bytes ?? 0,
            txCount: txs.length,
            fees: totalFees.toString(),
        };
        return { block: blockData, txs };
    }
    /**
     * Map a single Ogmios chain-sync transaction into our Transaction. Outputs, fee
     * and metadata are mapped fully; inputs are kept as bare references (address/amount
     * resolved downstream by the indexer). `spends` selects the ledger-applied
     * partition: a phase-2-invalid transaction consumes collaterals and creates only
     * its collateral-return output, never its declared regular inputs/outputs.
     */
    mapOgmiosTx(tx, block, index) {
        const mapInput = (input, flags = {}) => ({
            address: '',
            amount: [],
            txHash: input.transaction.id,
            outputIndex: input.index,
            ...flags,
        });
        const spendsCollaterals = tx.spends === 'collaterals';
        const inputs = [
            ...(spendsCollaterals ? [] : (tx.inputs ?? []).map(input => mapInput(input))),
            ...(tx.collaterals ?? []).map(input => mapInput(input, { isCollateral: true })),
            ...(tx.references ?? []).map(input => mapInput(input, { isReference: true })),
        ];
        const mapOutput = (output, outputIndex, isCollateral) => ({
            address: output.address,
            amount: this.convertOgmiosValue(output.value),
            txHash: tx.id,
            outputIndex,
            dataHash: output.datumHash ?? null,
            inlineDatum: output.datum ?? null,
            isCollateral,
            referenceScriptHash: null,
        });
        const outputs = spendsCollaterals
            ? (tx.collateralReturn
                // The ledger assigns collateral return the index immediately after the
                // declared regular outputs, even though those outputs are not produced.
                ? [mapOutput(tx.collateralReturn, tx.outputs?.length ?? 0, true)]
                : [])
            : (tx.outputs ?? []).map((output, outputIndex) => mapOutput(output, outputIndex, false));
        const metadataEntries = tx.metadata?.labels
            ? Object.entries(tx.metadata.labels).map(([label, v]) => ({
                txHash: tx.id,
                label,
                json: v.json,
            }))
            : [];
        return {
            hash: tx.id,
            blockHash: block.id,
            blockHeight: block.height,
            slot: block.slot,
            index,
            fee: (tx.fee?.ada?.lovelace ?? 0).toString(),
            deposit: '0',
            // null = unknown (chain-sync doesn't surface the serialized size) — matches the
            // lazy path's `size ?? null` convention; 0 would masquerade as a real size
            size: null,
            blockTime: slotToPosixSeconds(this.network, block.slot),
            inputs,
            outputs,
            // undefined (not []) when absent — matches the Blockfrost path so
            // mapTransaction's hasMetadata flag stays false for metadata-less txs
            metadata: metadataEntries.length ? metadataEntries : undefined,
        };
    }
}
exports.OgmiosBackend = OgmiosBackend;
//# sourceMappingURL=ogmios-backend.js.map