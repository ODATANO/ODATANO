"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isEvaluatingBackend = isEvaluatingBackend;
exports.isChainSyncBackend = isChainSyncBackend;
exports.isPaginatingBackend = isPaginatingBackend;
/**
 * Type guard to check if a backend supports transaction evaluation
 * @param backend - The backend to check
 * @returns true if the backend supports evaluateTransaction
 */
function isEvaluatingBackend(backend) {
    return typeof backend.evaluateTransaction === 'function';
}
/** Type guard: does this backend support streamed chain-sync? */
function isChainSyncBackend(backend) {
    return typeof backend.openChainSync === 'function';
}
/** Type guard: can this backend be walked forward by pagination? */
function isPaginatingBackend(backend) {
    const b = backend;
    return typeof b.getBlockByHeight === 'function'
        && typeof b.getNextBlocks === 'function'
        && typeof b.getBlockTransactions === 'function';
}
//# sourceMappingURL=cardano-backend.js.map