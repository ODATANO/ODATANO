import { Transaction, BlockData, Address, UTxO, NetworkInformation, EpochData, MetadataLabelTx, PoolData, AccountData, DrepData, AssetInfo, LedgerProtocolParameters, ScriptEvaluationResult } from '../../utils/types';
import { EvaluatingBackend, ChainSyncBackend, ChainSyncCallbacks, ChainSyncHandle, ChainPoint } from './cardano-backend';
import { Network } from '../cardano-client';
/** Resolve Ogmios ledger tip which may be 'origin' (genesis block) or a point */
export declare function resolveOgmiosTip(tip: 'origin' | {
    slot: number;
    id: string;
}): {
    slot: number;
    hash: string;
};
/** Resolve Ogmios block height which may be 'origin' (genesis block) or a number */
export declare function resolveOgmiosHeight(height: 'origin' | number): number;
export declare class OgmiosBackend implements EvaluatingBackend, ChainSyncBackend {
    readonly name = "ogmios";
    /**
     * Capability declaration — the orchestrator skips Ogmios for these without
     * counting circuit failures. Historic queries are out of protocol scope;
     * getAddress/getNetworkInformation previously FABRICATED placeholder data
     * (type:'base'/isScript:false/stakeAddress:null resp. maxSupply as
     * total/circulating) which preferLive routing then preferred over correct
     * Blockfrost/Koios data.
     */
    readonly unsupportedMethods: ReadonlySet<string>;
    private stateQueryClient;
    private txSubmissionClient;
    private context;
    private isShutdown;
    private reconnectPromise;
    private network;
    private timeoutMs;
    private ogmiosUrl;
    /**
     * Constructor
     */
    constructor(network: Network, timeoutMs: number, ogmiosUrl: string);
    /**
     * Force fresh (non-keep-alive) HTTP connections for the Ogmios `/health` probe.
     *
     * createInteractionContext() opens the WebSocket, but FIRST probes
     * `GET http://<ogmios>/health` via the library's `cross-fetch` → node-fetch v2
     * → Node-core `http`. Since Node 19, `http.globalAgent` defaults to
     * keepAlive:true, so node-fetch reuses pooled sockets. Against Ogmios' Warp
     * server on Node 22/24 a reused socket the server has already half-closed
     * yields "Invalid response body … Premature close" the instant the body is
     * read — deterministically (Node 20's older http client tolerated it; `curl`
     * does too, so the /health response itself is well-formed and the node is
     * healthy). The lib pins cross-fetch even in 7.0 and exposes no way to inject
     * an agent into that internal fetch, so we neutralise keep-alive process-wide
     * for `http://`. Blast radius is tiny: the only `http://` consumer is the local
     * Ogmios probe — Blockfrost/Koios run over `https` with their own axios agents
     * and are unaffected. Runs once, lazily, only when Ogmios is actually used.
     */
    private static keepAliveDisabled;
    private static disableHttpKeepAlive;
    /** Validate Ogmios URL scheme and reject dangerous protocols */
    private static validateOgmiosUrl;
    /**
     * Bound an init step in time. A hung WebSocket connect/handshake (e.g. the
     * node is alive but too busy catching up to answer) would otherwise block
     * forever — there is no built-in connect timeout — hanging the whole
     * app-context bootstrap (seen as a 6h CI job timeout). On timeout we reject
     * with a message containing "timeout" so the orchestrator's transient-error
     * retry picks it up instead of dying.
     */
    private withInitTimeout;
    /**
     * Force-release an Ogmios interaction socket after a failed/expired open or
     * close step. The runtime uses `ws` (and therefore supports `terminate`), but
     * the close fallback keeps the helper compatible with the public structural
     * InteractionContext type and lightweight test doubles.
     */
    private forceCloseContext;
    /**
     * Initialize the Ogmios backend connection
     */
    init(): Promise<boolean>;
    /**
     * Reconnect when the WebSocket has died since the last successful init.
     * No-op when never initialized (test-injected clients) — startup-init
     * recovery is the orchestrator's job (lazy init retry in CardanoClient).
     * Concurrent callers share one reconnect attempt.
     */
    private ensureConnected;
    /**
     * Get specific Block Data (not supported)
     * @param _hash block hash (hex)
     * @returns {Promise<BlockData>} block data
     */
    getBlock(_hash: string): Promise<BlockData>;
    /**
     * Get specific Epoch Data (not supported)
     * @param _epochNumber epoch number
     * @returns {Promise<EpochData>} epoch data
     */
    getEpoch(epochNumber: number): Promise<EpochData>;
    /**
     * Get specific Transaction Data (not supported)
     * @param _hash transaction hash (hex)
     * @returns {Promise<Transaction>} transaction data
     */
    getTransaction(_hash: string): Promise<Transaction>;
    /**
     * Get specific Transaction Metadata (not supported)
     * @param _tx_hash transaction hash (hex)
     * @returns {Promise<MetadataLabelTx[]>} transaction metadata list
     */
    getTransactionMetadata(_tx_hash: string): Promise<MetadataLabelTx[]>;
    /**
     * Get specific Drep Data (not supported for Ogmios)
     * @param _drepId drep id
     * @returns {Promise<DrepData>} drep data
     */
    getDrep(_drepId: string): Promise<DrepData>;
    /**
     * Get Asset Info (not supported for Ogmios — no aggregate-supply query in the protocol)
     * @param _unit asset unit (policyId + assetNameHex)
     * @returns {Promise<AssetInfo>} asset info
     */
    getAssetInfo(_unit: string): Promise<AssetInfo>;
    /**
     * Get specific Network Information (not supported — Ogmios state queries
     * expose no supply/stake aggregates; the previous implementation fabricated
     * maxSupply as total/circulating, which preferLive routing then preferred
     * over correct Blockfrost/Koios data)
     */
    getNetworkInformation(): Promise<NetworkInformation>;
    /**
     * Get current specific Address Data (not supported — address type, script
     * flag and stake address are not derivable from Ogmios state queries; the
     * previous implementation fabricated type:'base'/isScript:false/
     * stakeAddress:null. UTxOs remain available via getAddressUtxos.)
     */
    getAddress(_address: string): Promise<Address>;
    /** get current specific Address UTxOs
     * @param address bech32 address
     * @returns {Promise<UTxO[]>} address UTxOs
     */
    getAddressUtxos(address: string): Promise<UTxO[]>;
    /**
     * Get Address Transactions (not supported by Ogmios - use historical backend)
     * Ogmios is a live state query backend and does not provide historical transaction data
     * @param _address bech32 address
     * @returns {Promise<Transaction[]>} always throws - use historical backend instead
     */
    getAddressTransactions(_address: string): Promise<Transaction[]>;
    /**
     * Get current specific Pool Data
     * @param poolId pool id
     * @returns {Promise<PoolData>} pool data
     */
    getPool(poolId: string): Promise<PoolData>;
    /**
     * Get Account Data for specified stake address
     * @param stakeAddress stake address
     * @returns {Promise<AccountData>} account data
     */
    getAccount(stakeAddress: string): Promise<AccountData>;
    /**
     * Submit Transaction to the network
     * @param signedTxCbor signed transaction in CBOR hex format
     * @returns {Promise<string>} transaction hash
     */
    submitTransaction(signedTxCbor: string): Promise<string>;
    /**
     * Evaluate transaction script execution units
     * @param unsignedTxCbor unsigned transaction in CBOR hex format
     * @returns {Promise<ScriptEvaluationResult[]>} evaluation results
     */
    evaluateTransaction(unsignedTxCbor: string): Promise<ScriptEvaluationResult[]>;
    /**
     * Get current Protocol Parameters
     * @returns {Promise<LedgerProtocolParameters>} protocol parameters
     */
    getProtocolParameters(): Promise<LedgerProtocolParameters>;
    /**
     * Get Latest Epoch Data
     * @returns {Promise<EpochData>} latest epoch data
     */
    getLatestEpoch(): Promise<EpochData>;
    /**
     * Get current Latest Block Data
     * @returns {Promise<BlockData>} latest block data
     */
    getLatestBlock(): Promise<BlockData>;
    /**
     * Get the latest chain tip slot.
     * @returns {Promise<number>} current chain slot
     */
    getCurrentSlot(): Promise<number>;
    /**
     * Check whether a UTxO is still unspent via Ogmios `queryLedgerState/utxo`
     * with an outputReferences filter. Empty result means spent or nonexistent.
     * @param txHash 64-char lowercase hex
     * @param outputIndex non-negative integer
     * @returns {Promise<boolean>} true iff the UTxO exists and is unspent
     */
    isUtxoUnspent(txHash: string, outputIndex: number): Promise<boolean>;
    /**
     * Shutdown the Ogmios Backend
     * Closes all connections and marks as shutdown
     */
    shutdown(): Promise<void>;
    /**
     * Check if backend is connected
     */
    isConnected(): boolean;
    /**
     * Ensure the client is not shutdown before operations
     */
    private ensureNotShutdown;
    /**
     * Convert Ogmios value format to odatano amount array
     * Ogmios: { ada: { lovelace: 1000000 }, policyId: { assetName: quantity } }
     * Standard: [{ unit: 'lovelace', quantity: '1000000' }, { unit: 'policyId.assetName', quantity: 'N' }]
     */
    private convertOgmiosValue;
    /**
     * Open a dedicated chain-synchronization stream. Uses its own InteractionContext
     * (a separate WebSocket) from the query/submission clients, because it is a
     * long-lived stream. `sequential: true` + `inFlight: 1` deliver blocks one at a
     * time in order, which the crawler needs for reorg detection and serial persist.
     *
     * KNOWN LIMITATIONS (documented, to harden against a live node — see CRAWLER_DESIGN.md):
     *  - Input address/amount are left empty: Ogmios chain-sync inputs are bare
     *    references ({txId,index}); the indexer resolves them from already-indexed
     *    outputs (indexBlockFull, C3).
     *  - Per-tx `size` and `deposit` are not surfaced by chain-sync (set 0).
     *  - Output `referenceScriptHash` is not derived from the inline script yet.
     */
    openChainSync(from: ChainPoint[] | 'origin', callbacks: ChainSyncCallbacks): Promise<ChainSyncHandle>;
    /**
     * Map an Ogmios Praos block into our BlockData + its transactions. Block-level
     * fees are the sum of per-tx fees; epoch/epochSlot are derived from the slot via
     * the network's Shelley anchor (same config the tx-builder uses).
     */
    private mapOgmiosBlock;
    /**
     * Map a single Ogmios chain-sync transaction into our Transaction. Outputs, fee
     * and metadata are mapped fully; inputs are kept as bare references (address/amount
     * resolved downstream by the indexer). `spends` selects the ledger-applied
     * partition: a phase-2-invalid transaction consumes collaterals and creates only
     * its collateral-return output, never its declared regular inputs/outputs.
     */
    private mapOgmiosTx;
}
//# sourceMappingURL=ogmios-backend.d.ts.map