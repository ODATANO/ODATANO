"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardanoCrawler = void 0;
const cds_1 = __importDefault(require("@sap/cds"));
const errors_1 = require("../../utils/errors");
const collections_1 = require("../../utils/collections");
const hooks_1 = require("./hooks");
const cardano_1 = require("#cds-models/odatano/cardano");
const sync_state_1 = require("./sync-state");
const { SELECT, DELETE, INSERT } = cds_1.default.ql;
const logger = cds_1.default.log('CardanoCrawler');
const CHAIN_POINT_MISMATCH_PREFIX = 'CHAIN_POINT_MISMATCH:';
class CrawlerStoppedError extends Error {
    constructor() { super('Crawler stopped'); this.name = 'CrawlerStoppedError'; }
}
class CrawlerLeaseLostError extends Error {
    constructor() { super('Crawler DB lease lost'); this.name = 'CrawlerLeaseLostError'; }
}
/**
 * CardanoCrawler — pre-sync engine (v2.0). Streams the chain forward from a configured
 * start block and bulk-indexes Blocks + Transactions (+ inputs/outputs/assets) into the
 * DB, so consumers can query local data instead of hitting a backend per request.
 *
 * Two sources (see CRAWLER_DESIGN.md):
 *  - **Ogmios chain-sync** (primary): ordered rollForward + native rollBackward (reorg).
 *  - **Blockfrost/Koios pagination** (fallback): forward walk + parent-hash reorg recovery.
 *
 * Lifecycle: start() launches the ingest pipeline detached so the HTTP server binds
 * immediately, but the pipeline promise is retained — stop() halts the loops (waking
 * any pending poll sleep) and AWAITS the pipeline, so shutdown never races in-flight
 * block writes. All per-block writes are atomic. The crawler NEVER crawls from genesis
 * implicitly — it requires an explicit configured start point or an existing cursor.
 */
class CardanoCrawler {
    client;
    indexer;
    network;
    config;
    leaseOwner;
    /** Transient-failure retries per block before giving up. */
    static PERSIST_RETRIES = 3;
    /** Timeout for direct backend calls (the crawler bypasses the client's resilience layer). */
    static CALL_TIMEOUT_MS = 60_000;
    running = false;
    chainSyncHandle = null;
    /** The detached ingest pipeline — awaited by stop() so teardown never races it. */
    pipeline = null;
    /** Resolver that cancels a pending poll sleep (set while sleeping). */
    wake = null;
    /** Cancellers for backend waits, so shutdown is not held hostage by their timeout. */
    callCancels = new Set();
    /** Chain-sync callback promises outlive openChainSync(); stop() explicitly drains them. */
    inFlightCallbacks = new Set();
    haltPromise = null;
    finalStatus = 'stopped';
    /** Set only by an unrecoverable halt — clears desiredRunning so restarts stay down. */
    latchOnHalt = false;
    leaseHeld = false;
    leaseHeartbeat = null;
    leaseWake = null;
    constructor(client, indexer, network, config, 
    /** Present for production instances created by index.ts; omitted in engine unit tests. */
    leaseOwner) {
        this.client = client;
        this.indexer = indexer;
        this.network = network;
        this.config = config;
        this.leaseOwner = leaseOwner;
    }
    isRunning() {
        return this.running;
    }
    /**
     * Start crawling. Does NOT await the ingest pipeline (fire-and-forget).
     * Refuses to start without a resume point: an explicit configured start block or an
     * existing cursor — never an implicit full-chain sync from genesis.
     */
    async start() {
        if (this.running)
            return;
        if (this.haltPromise)
            await this.haltPromise;
        const start = this.config.startSlot != null && this.config.startBlockHash
            ? { slot: this.config.startSlot, hash: this.config.startBlockHash, height: this.config.startHeight }
            : undefined;
        // Keep running=false until every DB guard succeeds. A cursor read/config error
        // must never leave a healthy-looking crawler behind.
        const cursor = await cds_1.default.tx((tx) => (0, sync_state_1.ensureSyncStateSingleton)(tx, this.network, start));
        if (!cursor.lastBlockHash && !start) {
            logger.error('Crawler start refused: no start block configured and no existing cursor — set crawler.startSlot + crawler.startBlockHash.');
            return;
        }
        if (this.leaseOwner) {
            const leaseOwner = this.leaseOwner;
            this.leaseHeld = await cds_1.default.tx((tx) => (0, sync_state_1.tryAcquireCrawlerLease)(tx, leaseOwner));
            if (!this.leaseHeld) {
                logger.info('Crawler start skipped: another instance owns the DB lease or the cluster is paused.');
                return;
            }
        }
        this.running = true;
        this.startLeaseHeartbeat();
        // A pipeline crash (e.g. chain-sync intersection not found after downtime) must
        // surface on the cursor — otherwise the crawler looks healthy while doing nothing.
        this.pipeline = this.runIngestPipeline().catch(async (err) => {
            if (err instanceof CrawlerStoppedError || err instanceof CrawlerLeaseLostError) {
                await this.halt('stopped');
                return;
            }
            logger.error('Ingest pipeline crashed:', err);
            const streak = await this.recordCrawlerError(err);
            await this.halt(streak < 0 ? 'stopped' : 'error');
        });
    }
    /**
     * Stop crawling and WAIT for the pipeline to finish its in-flight step: halts the
     * loops (waking any pending poll sleep), closes the chain-sync stream, records the
     * final status, then awaits the detached pipeline so callers (shutdownAppContext)
     * can safely tear down backends/DB afterwards.
     */
    async stop(finalStatus = 'stopped') {
        this.beginHalt(finalStatus);
        if (this.haltPromise)
            await this.haltPromise;
        this.pipeline = null;
    }
    /**
     * Halt without awaiting the pipeline — the variant safe to call FROM INSIDE the
     * pipeline (persistBlock failure, stream onError), where awaiting the pipeline
     * would deadlock.
     */
    /**
     * @param latch clears `desiredRunning`, so NO restart brings the crawler back —
     *   only an operator's resumeCrawler does. Reserved for failures a restart cannot
     *   fix (misconfiguration, missing resume point). Runtime failures — a dropped
     *   chain-sync socket, a provider outage, a node restart — must leave it false,
     *   otherwise a routine node restart silently disables the pre-sync for good.
     */
    async halt(finalStatus = 'stopped', latch = false) {
        this.beginHalt(finalStatus, latch);
    }
    /**
     * Start teardown without awaiting it. Internal callers can therefore halt from
     * inside a tracked callback/pipeline without waiting on their own promise.
     */
    beginHalt(finalStatus, latch = false) {
        if (latch)
            this.latchOnHalt = true;
        // Once a real failure was observed, a concurrent shutdown must not hide it.
        if (this.finalStatus !== 'error' || finalStatus === 'error')
            this.finalStatus = finalStatus;
        this.running = false;
        this.wake?.(); // cancel a pending poll sleep so the loop exits now
        this.leaseWake?.();
        for (const cancel of [...this.callCancels])
            cancel();
        if (this.haltPromise)
            return;
        this.haltPromise = Promise.resolve().then(async () => {
            const handle = this.chainSyncHandle;
            this.chainSyncHandle = null;
            if (handle) {
                try {
                    await handle.close();
                }
                catch (e) {
                    logger.warn('chain-sync close failed:', e);
                }
            }
            // Pagination work lives in pipeline; streamed work lives in callback promises.
            // Drain both before releasing the lease or reporting the terminal state.
            const pipeline = this.pipeline;
            if (pipeline)
                await pipeline.catch(() => undefined);
            while (this.inFlightCallbacks.size) {
                await Promise.allSettled([...this.inFlightCallbacks]);
            }
            if (this.leaseHeartbeat)
                await this.leaseHeartbeat.catch(() => undefined);
            try {
                if (this.leaseOwner && this.leaseHeld) {
                    await cds_1.default.tx((tx) => (0, sync_state_1.releaseCrawlerLease)(tx, this.leaseOwner, this.finalStatus, this.latchOnHalt));
                    this.leaseHeld = false;
                }
                else if (!this.leaseOwner) {
                    await cds_1.default.tx((tx) => (0, sync_state_1.setSyncStatus)(tx, this.finalStatus, this.latchOnHalt));
                }
            }
            catch { /* best effort during teardown */ }
        });
    }
    async runIngestPipeline() {
        const chainSync = this.config.source !== 'pagination' ? this.client.getChainSyncBackend() : null;
        if (chainSync) {
            await this.runChainSync(chainSync);
            return;
        }
        if (this.config.source === 'ogmios') {
            // 'ogmios' means chain-sync ONLY — never silently degrade to the weaker
            // pagination reorg handling the operator explicitly opted out of.
            logger.error("Crawler source is 'ogmios' but no chain-sync backend is available — crawler not started (use source 'auto' to allow pagination fallback).");
            await this.halt('error', true); // config error: a restart cannot fix it
            return;
        }
        await this.runPagination();
    }
    /** Bound a direct backend call — these bypass the client's timeout/breaker layer. */
    withTimeout(p, label, ms = CardanoCrawler.CALL_TIMEOUT_MS) {
        return new Promise((resolve, reject) => {
            let settled = false;
            let timer;
            let cancel;
            const finish = (cb) => {
                if (settled)
                    return;
                settled = true;
                clearTimeout(timer);
                this.callCancels.delete(cancel);
                cb();
            };
            timer = setTimeout(() => finish(() => reject(new errors_1.ProviderUnavailableError(`${label} timed out`, 'crawler', ms))), ms);
            timer.unref?.(); // never keep the process alive for a watchdog timer
            cancel = () => finish(() => reject(new CrawlerStoppedError()));
            this.callCancels.add(cancel);
            p.then((v) => finish(() => resolve(v)), (e) => finish(() => reject(e)));
        });
    }
    // ---------------------------------------------------------------------------
    // Chain-sync (Ogmios) — primary, reorg-aware
    // ---------------------------------------------------------------------------
    async runChainSync(backend) {
        const cursor = await cds_1.default.tx((tx) => (0, sync_state_1.readCursor)(tx));
        const points = await this.buildIntersectionPoints(cursor);
        if (!points.length) {
            // Defense in depth — start() already refuses this state.
            logger.error('Chain-sync refused: no resume point (configured start block or cursor) available.');
            await this.halt('error', true); // config error: a restart cannot fix it
            return;
        }
        const handle = await backend.openChainSync(points, {
            rollForward: (block, txs, tip) => this.trackCallback(async () => {
                if (!this.running)
                    return;
                await this.persistBlock(block, txs, tip);
            }),
            rollBackward: (point) => this.trackCallback(async () => {
                if (!this.running)
                    return;
                // Ogmios ALWAYS opens the stream with a rollBackward to the intersection
                // point — that is the protocol handshake, not a reorg. Only roll back when
                // the point differs from our cursor.
                const current = await cds_1.default.tx((tx) => (0, sync_state_1.readCursor)(tx));
                if (point !== 'origin' && current?.lastBlockHash === point.hash) {
                    logger.debug(`chain-sync intersection acknowledged at slot ${point.slot} — no reorg`);
                    return;
                }
                await this.handleReorg(point);
            }),
            onError: (err) => this.trackCallback(async () => {
                if (err instanceof CrawlerStoppedError || err instanceof CrawlerLeaseLostError)
                    return;
                // The stream is stalled (mapping/callback failure) — record and halt cleanly
                // so the cursor status shows 'error' instead of a healthy-looking hang.
                const streak = await this.recordCrawlerError(err);
                logger.error('Chain-sync stream error — stopping crawler:', err);
                await this.halt(streak < 0 ? 'stopped' : 'error');
            }),
        });
        // stop() may have raced the async open — close the fresh socket instead of leaking it.
        if (!this.running) {
            try {
                await handle.close();
            }
            catch { /* best effort */ }
            return;
        }
        this.chainSyncHandle = handle;
        logger.info(`Crawler running (chain-sync) from ${points[0].hash} (+${points.length - 1} fallback intersection point(s))`);
    }
    /**
     * Candidate intersection points, NEWEST FIRST: the cursor, then an exponentially
     * spaced ladder of our own already-crawled ancestors, then the configured start
     * block as the deepest anchor.
     *
     * Why more than the cursor: if the cursor's block was orphaned while the crawler
     * was down, a single-point intersection fails outright ("No intersection found")
     * and the stream never opens. With ancestors on the list the node intersects at
     * the last common block and reports it as a rollBackward — the ordinary reorg path
     * that handleReorg already implements. Doubling offsets cover ~32k blocks with 16
     * points; anything deeper is past any realistic rollback and should fail loudly.
     */
    async buildIntersectionPoints(cursor) {
        const points = [];
        const seen = new Set();
        const add = (p) => {
            if (!p?.hash || seen.has(p.hash))
                return;
            seen.add(p.hash);
            points.push(p);
        };
        if (cursor?.lastBlockHash) {
            add({ slot: cursor.lastSlot, hash: cursor.lastBlockHash, height: cursor.lastHeight });
            // Dense over the last DENSE_DEPTH blocks, doubling after that. Real rollbacks
            // are a handful of blocks deep, and those must intersect EXACTLY — a gap in
            // the ladder is not wrong (rolling back too far only re-crawls), but it costs
            // needless work on the common case. The doubling tail keeps the deep-reorg
            // reach without sending hundreds of points.
            const DENSE_DEPTH = 10;
            const heights = [];
            const pushHeight = (height) => { if (height > 0 && !heights.includes(height))
                heights.push(height); };
            for (let step = 1; step <= DENSE_DEPTH; step++)
                pushHeight(cursor.lastHeight - step);
            for (let step = 16; step <= 1 << 14; step *= 2)
                pushHeight(cursor.lastHeight - step);
            if (heights.length) {
                const rows = await cds_1.default.tx((tx) => tx.run(SELECT.from(cardano_1.Blocks).columns('height', 'slot', 'hash').where({ height: { in: heights } })));
                for (const row of (rows ?? []).sort((a, b) => Number(b.height ?? 0) - Number(a.height ?? 0))) {
                    if (row.hash && row.slot != null)
                        add({ slot: Number(row.slot), hash: row.hash, height: Number(row.height) });
                }
            }
        }
        if (this.config.startBlockHash && this.config.startSlot != null) {
            add({ slot: this.config.startSlot, hash: this.config.startBlockHash, height: this.config.startHeight });
        }
        return points;
    }
    /** Track streamed callbacks because closing a socket does not imply DB callbacks finished. */
    trackCallback(callback) {
        const promise = Promise.resolve().then(callback);
        this.inFlightCallbacks.add(promise);
        void promise.then(() => this.inFlightCallbacks.delete(promise), () => this.inFlightCallbacks.delete(promise));
        return promise;
    }
    // ---------------------------------------------------------------------------
    // Pagination (Blockfrost/Koios) — fallback
    // ---------------------------------------------------------------------------
    async runPagination() {
        const backend = this.client.getPaginatingBackend();
        if (!backend) {
            logger.error('No paginating backend available — cannot crawl without Ogmios or Blockfrost/Koios');
            await this.halt('error', true); // config error: a restart cannot fix it
            return;
        }
        logger.info('Crawler running (pagination)');
        // Tip cache: during deep catch-up the exact tip is irrelevant (only "am I still
        // behind the target" matters) — refetching it every round wasted one HTTP call
        // per batch. Refresh only when the cursor reaches the cached target.
        let tip = null;
        let target = Number.NEGATIVE_INFINITY;
        while (this.running) {
            try {
                const cursor = await cds_1.default.tx((tx) => (0, sync_state_1.readCursor)(tx));
                if (!cursor?.lastBlockHash) {
                    logger.error('Pagination refused: cursor has no resume block hash.');
                    await this.halt('error', true); // broken precondition: a restart cannot fix it
                    return;
                }
                if (!tip || cursor.lastHeight >= target) {
                    tip = await this.withTimeout(this.client.getLatestBlock(), 'getLatestBlock');
                    target = (tip.height ?? 0) - this.config.confirmationDepth;
                }
                const tipHeight = tip.height ?? 0;
                // Unknown tip slot must mean "NOT at tip" — a 0-fallback would mark every
                // block 'synced' (block.slot >= 0 is always true).
                const tipPoint = tip.slot != null
                    ? { slot: tip.slot, hash: tip.hash, height: tipHeight }
                    : undefined;
                if (cursor.lastHeight >= target) {
                    const statusWritten = await cds_1.default.tx(async (tx) => {
                        if (this.leaseOwner && !(await (0, sync_state_1.renewCrawlerLease)(tx, this.leaseOwner)))
                            return false;
                        await (0, sync_state_1.setSyncStatus)(tx, 'synced');
                        return true;
                    });
                    if (!statusWritten) {
                        await this.halt('stopped');
                        return;
                    }
                    await this.sleep(this.config.pollIntervalMs);
                    continue;
                }
                const blocks = await this.withTimeout(
                // pass the cursor height as anchor hint (>0 only — 0 can mean "unknown"
                // on a fresh start without configured startHeight)
                backend.getNextBlocks(cursor.lastBlockHash, this.config.batchSize, cursor.lastHeight > 0 ? cursor.lastHeight : undefined), 'getNextBlocks');
                if (!blocks.length) {
                    await this.sleep(this.config.pollIntervalMs);
                    continue;
                }
                for (const block of blocks) {
                    if (!this.running)
                        break;
                    if ((block.height ?? 0) > target)
                        break; // stay behind the confirmation window
                    const txs = await this.withTimeout(backend.getBlockTransactions(block.hash), 'getBlockTransactions');
                    const ok = await this.persistBlock(block, txs, tipPoint);
                    if (!ok)
                        return; // persistBlock already recorded + halted
                }
            }
            catch (err) {
                if (!this.running || err instanceof CrawlerStoppedError)
                    return;
                // Only the backend's explicit anchor/hash mismatch proves that our cursor may
                // be orphaned. Provider outages and partial tx responses must back off instead
                // of launching up to 100 additional provider calls.
                if (err instanceof Error && err.message.startsWith(CHAIN_POINT_MISMATCH_PREFIX)) {
                    const recovered = await this.tryReorgRecovery(backend).catch(() => false);
                    if (recovered)
                        continue;
                    if (!this.running)
                        return;
                }
                const streak = await this.recordCrawlerError(err);
                if (streak < 0) {
                    await this.halt('stopped');
                    return;
                }
                logger.error(`pagination round failed (error streak ${streak}):`, err);
                if (streak >= sync_state_1.MAX_CONSECUTIVE_ERRORS) {
                    await this.halt('error');
                    return;
                }
                await this.sleep(this.config.pollIntervalMs);
            }
        }
    }
    /**
     * Pagination reorg recovery: walk back by height comparing the on-chain block hash with
     * our stored one until they agree — that height is the fork point. If the last-indexed
     * block still matches on-chain, there is no reorg (returns false → treat as transient).
     */
    async tryReorgRecovery(backend) {
        if (!this.running)
            return false;
        const cursor = await cds_1.default.tx((tx) => (0, sync_state_1.readCursor)(tx));
        if (!cursor || !cursor.lastBlockHash)
            return false;
        const MAX_DEPTH = 100;
        const floor = Math.max(0, cursor.lastHeight - MAX_DEPTH);
        for (let h = cursor.lastHeight; h > floor; h--) {
            if (!this.running)
                return false;
            let onChain;
            try {
                onChain = await this.withTimeout(backend.getBlockByHeight(h), `getBlockByHeight(${h})`);
            }
            catch {
                // One unavailable height means the provider cannot currently prove a fork.
                // Abort this recovery round instead of multiplying a provider outage by 100.
                return false;
            }
            if (!this.running)
                return false;
            const ours = await cds_1.default.tx((tx) => tx.run(SELECT.one.from(cardano_1.Blocks).where({ height: h })));
            if (ours?.hash && onChain.hash === ours.hash) {
                if (h === cursor.lastHeight)
                    return false; // tip still matches → not a reorg
                // handleReorg deletes everything with slot > forkSlot. A null provider slot
                // (BlockData.slot is nullable) would make forkSlot 0 and wipe the ENTIRE
                // crawled dataset — abort this round instead; the next round can retry with
                // a healthy provider response. (Same guard philosophy as the height axis.)
                if (onChain.slot == null)
                    return false;
                await this.handleReorg({ slot: onChain.slot, hash: onChain.hash, height: h });
                return true;
            }
        }
        return false;
    }
    // ---------------------------------------------------------------------------
    // Persist + reorg (shared)
    // ---------------------------------------------------------------------------
    /**
     * Persist one block atomically and advance the cursor. Transient failures are retried
     * a few times (recording the error streak); only repeated failure stops the crawler —
     * the cursor is not advanced on failure, so a resume re-syncs cleanly from it.
     * Marks the cursor 'synced' when the block is at the reported tip.
     * @returns true when the block was persisted, false when the crawler was stopped
     */
    async persistBlock(block, txs, tip) {
        if (txs.length !== block.txCount) {
            throw new errors_1.ProviderUnavailableError(`Incomplete block ${block.hash}: backend returned ${txs.length}/${block.txCount} transactions`, 'crawler');
        }
        const isAtTip = tip != null && block.slot != null && block.slot >= tip.slot;
        // Epoch enrichment needs a backend round-trip on epoch boundaries — do it BEFORE
        // opening the write transaction so the DB lock is never held across network I/O.
        if (block.epoch != null) {
            await this.indexer.prefetchCrawlEpoch(block.epoch);
        }
        for (let attempt = 1;; attempt++) {
            if (!this.running)
                return false;
            try {
                await cds_1.default.tx(async (tx) => {
                    if (this.leaseOwner) {
                        const renewed = await (0, sync_state_1.renewCrawlerLease)(tx, this.leaseOwner);
                        if (!renewed)
                            throw new CrawlerLeaseLostError();
                    }
                    await this.indexer.indexBlockFull(tx, block, txs);
                    await (0, sync_state_1.advanceCursor)(tx, { slot: block.slot ?? 0, hash: block.hash, height: block.height ?? 0 }, tip ? { slot: tip.slot, height: tip.height } : undefined, isAtTip ? 'synced' : 'syncing');
                });
                // Notify observers (wallet-worker confirmation tracker) AFTER the commit —
                // listener failures are swallowed inside emitBlockIndexed.
                (0, hooks_1.emitBlockIndexed)({
                    hash: block.hash,
                    slot: block.slot ?? null,
                    height: block.height ?? null,
                    txHashes: txs.map((t) => t.hash),
                    tipSlot: tip?.slot ?? null,
                    tipHeight: tip?.height ?? null,
                });
                return true;
            }
            catch (err) {
                if (err instanceof CrawlerLeaseLostError) {
                    logger.warn('Crawler write fenced because its DB lease is no longer valid.');
                    await this.halt('stopped');
                    return false;
                }
                const streak = await this.recordCrawlerError(err);
                if (streak < 0) {
                    await this.halt('stopped');
                    return false;
                }
                if (attempt < CardanoCrawler.PERSIST_RETRIES && streak < sync_state_1.MAX_CONSECUTIVE_ERRORS) {
                    logger.warn(`persistBlock ${block.hash} failed (attempt ${attempt}/${CardanoCrawler.PERSIST_RETRIES}, streak ${streak}) — retrying:`, err);
                    await this.sleep(1000 * attempt);
                    continue;
                }
                logger.error(`persistBlock failed for ${block.hash} after ${attempt} attempts — stopping crawler (resume re-syncs from cursor):`, err);
                await this.halt('error');
                return false;
            }
        }
    }
    /**
     * Handle a chain rollback: in one transaction, delete every block after the fork point
     * and exactly the transactions belonging to those blocks (plus their child rows), reset
     * the cursor to the fork, and write a CardanoReorgLog audit row.
     *
     * The cut runs on the absolute-slot axis of Blocks (same axis as the fork point), and
     * transactions are resolved via their blockHash — so:
     *  - an unresolvable fork height can never widen the delete (no height-0 fallback), and
     *  - lazily-indexed transactions of blocks the crawler never wrote are left untouched.
     */
    async handleReorg(point) {
        const forkSlot = point === 'origin' ? (this.config.startSlot ?? 0) : point.slot;
        let blocksRolledBack = 0;
        let txsRolledBack = 0;
        let emittedForkHeight = null;
        try {
            await cds_1.default.tx(async (tx) => {
                if (this.leaseOwner) {
                    const renewed = await (0, sync_state_1.renewCrawlerLease)(tx, this.leaseOwner);
                    if (!renewed)
                        throw new CrawlerLeaseLostError();
                }
                // Fork height is metrics/cursor info only — NEVER a delete axis.
                let forkHeight = point === 'origin' ? 0 : point.height;
                if (forkHeight == null && point !== 'origin') {
                    const fb = await tx.run(SELECT.one.from(cardano_1.Blocks).where({ hash: point.hash }));
                    forkHeight = fb ? Number(fb.height) : undefined;
                }
                emittedForkHeight = forkHeight ?? null;
                // Blocks strictly after the fork, cut on the absolute-slot axis. Rows without a
                // slot (pre-v2.0 lazily indexed blocks) are deliberately excluded.
                const staleBlocks = await tx.run(SELECT.from(cardano_1.Blocks).columns('hash').where({ slot: { '>': forkSlot } }));
                const blockHashes = staleBlocks.map((b) => b.hash);
                blocksRolledBack = blockHashes.length;
                for (const blockChunk of (0, collections_1.chunk)(blockHashes, collections_1.IN_CHUNK)) {
                    // Only transactions of the rolled-back blocks — resolved via blockHash, so
                    // lazily-indexed txs of unrelated blocks are not collateral damage.
                    const staleTxs = await tx.run(SELECT.from(cardano_1.Transactions).columns('hash').where({ blockHash: { in: blockChunk } }));
                    const txHashes = staleTxs.map((t) => t.hash);
                    txsRolledBack += txHashes.length;
                    for (const txChunk of (0, collections_1.chunk)(txHashes, collections_1.IN_CHUNK)) {
                        // These denormalized/lazy indexes have no generated FK cascades. Remove
                        // them before their parent tx/output rows so orphan data cannot leak via OData.
                        await tx.run(DELETE.from(cardano_1.UTxOAssets).where({ utxo_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.AddressUTxOs).where({ hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.AddressTransactions).where({ tx_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.AssetHistory_).where({ txHash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.TransactionInputAssets).where({ input_tx_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.TransactionOutputAssets).where({ output_tx_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.TransactionInputs).where({ tx_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.TransactionOutputs).where({ tx_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.TransactionMetadata_).where({ tx_hash: { in: txChunk } }));
                        await tx.run(DELETE.from(cardano_1.Transactions).where({ hash: { in: txChunk } }));
                    }
                    await tx.run(DELETE.from(cardano_1.Blocks).where({ hash: { in: blockChunk } }));
                }
                await (0, sync_state_1.resetCursorTo)(tx, point === 'origin'
                    ? { slot: forkSlot, hash: this.config.startBlockHash ?? '', height: 0 }
                    : { slot: point.slot, hash: point.hash, height: forkHeight ?? 0 });
                await tx.run(INSERT.into(cardano_1.CardanoReorgLog).entries({
                    ID: cds_1.default.utils.uuid(),
                    detectedAt: new Date().toISOString(),
                    forkSlot,
                    forkHeight: forkHeight ?? null,
                    oldTipHash: null,
                    newTipHash: point === 'origin' ? null : point.hash,
                    blocksRolledBack,
                    status: 'completed',
                }));
            });
        }
        catch (err) {
            if (err instanceof CrawlerLeaseLostError) {
                await this.halt('stopped');
                throw new CrawlerStoppedError();
            }
            throw err;
        }
        // Notify observers (wallet-worker confirmation tracker + CAP subscribers) AFTER
        // the rollback commit.
        (0, hooks_1.emitReorg)({ forkSlot, forkHeight: emittedForkHeight, blocksRolledBack });
        logger.warn(`Reorg handled: rolled back ${blocksRolledBack} blocks (${txsRolledBack} txs) to slot ${forkSlot}`);
    }
    /** Renew the lease while an Ogmios stream is idle; block writes renew it transactionally. */
    startLeaseHeartbeat() {
        if (!this.leaseOwner || this.leaseHeartbeat)
            return;
        const intervalMs = Math.max(1_000, Math.floor(sync_state_1.CRAWLER_LEASE_TTL_MS / 3));
        this.leaseHeartbeat = (async () => {
            while (this.running) {
                await this.leaseSleep(intervalMs);
                if (!this.running)
                    return;
                try {
                    const renewed = await cds_1.default.tx((tx) => (0, sync_state_1.renewCrawlerLease)(tx, this.leaseOwner));
                    if (!renewed) {
                        logger.warn('Crawler heartbeat lost the DB lease or observed a cluster pause.');
                        await this.halt('stopped');
                        return;
                    }
                }
                catch (err) {
                    logger.error('Crawler lease heartbeat failed:', err);
                    const streak = await this.recordCrawlerError(err);
                    await this.halt(streak < 0 ? 'stopped' : 'error');
                    return;
                }
            }
        })();
    }
    /** Record state only while this instance still owns the lease. */
    async recordCrawlerError(err) {
        if (err instanceof CrawlerStoppedError || err instanceof CrawlerLeaseLostError) {
            return -1;
        }
        return await cds_1.default.tx((tx) => (0, sync_state_1.recordError)(tx, err, this.leaseOwner)).catch(() => 0);
    }
    leaseSleep(ms) {
        return new Promise((resolve) => {
            const timer = setTimeout(() => { this.leaseWake = null; resolve(); }, ms);
            timer.unref?.();
            this.leaseWake = () => { clearTimeout(timer); this.leaseWake = null; resolve(); };
        });
    }
    /** Cancellable, unref'd delay — halt() wakes it so shutdown never waits out a poll. */
    sleep(ms) {
        return new Promise((resolve) => {
            const timer = setTimeout(() => { this.wake = null; resolve(); }, ms);
            timer.unref?.();
            this.wake = () => { clearTimeout(timer); this.wake = null; resolve(); };
        });
    }
}
exports.CardanoCrawler = CardanoCrawler;
//# sourceMappingURL=crawler.js.map