import type { Transaction as CapTransaction } from '@sap/cds';
/**
 * Chain crawler cursor helpers (v2.0 pre-sync).
 *
 * `CardanoSyncState` is a singleton row (key = SINGLETON_ID) that records how far
 * the crawler has indexed the chain, so a restart resumes instead of re-crawling.
 *
 * NOTE (CAP 10): Integer64 / Decimal columns are read back from SQLite/HANA as
 * STRINGS, not JS numbers — the same change that makes them strings over OData.
 * Every read here therefore coerces numeric fields with `num()`; callers get a
 * clean numeric `SyncCursor` and never have to think about it.
 */
export declare const SINGLETON_ID = "SINGLETON";
/** Circuit-breaker threshold: pause crawling after this many back-to-back failures. */
export declare const MAX_CONSECUTIVE_ERRORS = 10;
/** A short, renewable DB lease prevents two app instances from advancing one cursor. */
export declare const CRAWLER_LEASE_TTL_MS = 15000;
export type CrawlSyncStatusValue = 'stopped' | 'syncing' | 'synced' | 'error';
/** A chain point the crawler can start from or roll back to. */
export interface CrawlPoint {
    slot: number;
    hash: string;
    height?: number;
}
/** Normalized, number-typed view of the cursor row (numeric fields already coerced). */
export interface SyncCursor {
    network: string | null;
    startSlot: number | null;
    startBlockHash: string | null;
    lastSlot: number;
    lastBlockHash: string | null;
    lastHeight: number;
    tipSlot: number | null;
    tipHeight: number | null;
    syncStatus: CrawlSyncStatusValue;
    consecutiveErrors: number;
    desiredRunning: boolean;
    leaseOwner: string | null;
    leaseUntil: string | null;
}
/**
 * Idempotently ensure the singleton cursor row exists and return it.
 * On first call (fresh DB) the row is created with the configured start point
 * (if given) and status 'stopped'. Subsequent calls just return the current row.
 * Safe to call from both the crawler and the control service.
 */
export declare function ensureSyncStateSingleton(db: CapTransaction, network: string, start?: CrawlPoint): Promise<SyncCursor>;
/** Read the current cursor, or null if it has not been initialized yet. */
export declare function readCursor(db: CapTransaction): Promise<SyncCursor | null>;
/** Whether the shared lease currently represents a live cluster-wide crawler. */
export declare function isCrawlerLeaseActive(cursor: SyncCursor | null, now?: Date): boolean;
/**
 * Atomically acquire an expired/unowned lease with compare-and-swap semantics.
 * The post-update read is intentional: CAP adapters consistently return the row
 * for SELECT, whereas affected-row return shapes differ between SQLite and HANA.
 */
export declare function tryAcquireCrawlerLease(db: CapTransaction, owner: string, now?: Date, ttlMs?: number): Promise<boolean>;
/**
 * Renew/fence a lease. Call this inside the same transaction as every crawler write:
 * the conditional UPDATE serializes a former leader against a newly elected one.
 */
export declare function renewCrawlerLease(db: CapTransaction, owner: string, now?: Date, ttlMs?: number): Promise<boolean>;
/**
 * Release only the caller's lease; a stale process can never clear a successor.
 *
 * `pauseCluster` clears `desiredRunning`, which no restart undoes — every instance
 * then refuses to start until an operator calls resumeCrawler. Reserve it for
 * failures a restart genuinely cannot fix (misconfiguration, no resume point). A
 * crashed stream, a provider outage or a node restart must NOT latch: those are
 * exactly the cases where coming back up should resume the pre-sync by itself.
 */
export declare function releaseCrawlerLease(db: CapTransaction, owner: string, status: CrawlSyncStatusValue, pauseCluster?: boolean): Promise<void>;
/** Persist the pause/resume intent shared by every app instance. */
export declare function setCrawlerDesiredRunning(db: CapTransaction, desiredRunning: boolean): Promise<void>;
/**
 * Advance the cursor to a freshly-indexed block. Sets the status (default 'syncing';
 * pass 'synced' when the block is at the tip), clears the error streak, and refreshes
 * lastIndexedAt. Optionally records the latest known tip (for progress).
 */
export declare function advanceCursor(db: CapTransaction, block: CrawlPoint, tip?: {
    slot: number;
    height?: number;
}, status?: CrawlSyncStatusValue): Promise<void>;
/** Reset the cursor to a rollback point (used by reorg handling). */
export declare function resetCursorTo(db: CapTransaction, point: CrawlPoint): Promise<void>;
/** Set the crawler status (e.g. 'synced' when caught up, 'stopped' on shutdown). */
export declare function setSyncStatus(db: CapTransaction, status: CrawlSyncStatusValue, pauseCluster?: boolean): Promise<void>;
/**
 * Record a crawler error. Increments the consecutive-error counter and flips status
 * to 'error' once the circuit-breaker threshold is reached. Returns the new streak
 * length so the caller can decide whether to back off / stop.
 */
export declare function recordError(db: CapTransaction, err: unknown, leaseOwner?: string): Promise<number>;
//# sourceMappingURL=sync-state.d.ts.map