"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CRAWLER_LEASE_TTL_MS = exports.MAX_CONSECUTIVE_ERRORS = exports.SINGLETON_ID = void 0;
exports.ensureSyncStateSingleton = ensureSyncStateSingleton;
exports.readCursor = readCursor;
exports.isCrawlerLeaseActive = isCrawlerLeaseActive;
exports.tryAcquireCrawlerLease = tryAcquireCrawlerLease;
exports.renewCrawlerLease = renewCrawlerLease;
exports.releaseCrawlerLease = releaseCrawlerLease;
exports.setCrawlerDesiredRunning = setCrawlerDesiredRunning;
exports.advanceCursor = advanceCursor;
exports.resetCursorTo = resetCursorTo;
exports.setSyncStatus = setSyncStatus;
exports.recordError = recordError;
const cds_1 = __importDefault(require("@sap/cds"));
const cardano_1 = require("#cds-models/odatano/cardano");
const errors_1 = require("../../utils/errors");
const { SELECT, INSERT, UPDATE } = cds_1.default.ql;
const logger = cds_1.default.log('CardanoCrawler');
/**
 * Chain crawler cursor helpers (v2.0 pre-sync).
 *
 * `CardanoSyncState` is a singleton row (key = SINGLETON_ID) that records how far
 * the crawler has indexed the chain, so a restart resumes instead of re-crawling.
 *
 * NOTE (CAP 10): Integer64 / Decimal columns are read back from SQLite/HANA as
 * STRINGS, not JS numbers — the same change that makes them strings over OData.
 * Every read here therefore coerces numeric fields with `num()`; callers get a
 * clean numeric `SyncCursor` and never have to think about it.
 */
exports.SINGLETON_ID = 'SINGLETON';
/** Circuit-breaker threshold: pause crawling after this many back-to-back failures. */
exports.MAX_CONSECUTIVE_ERRORS = 10;
/** A short, renewable DB lease prevents two app instances from advancing one cursor. */
exports.CRAWLER_LEASE_TTL_MS = 15_000;
/**
 * Coerce a CAP-10 numeric-as-string (or number/bigint/null) into a JS number.
 * Separate optional/required helpers avoid overload declarations (and the
 * no-redeclare lint false-positive they caused).
 */
function optionalNum(v) {
    if (v === null || v === undefined || v === '')
        return null;
    const n = Number(v);
    return Number.isNaN(n) ? null : n;
}
function requiredNum(v, fallback = 0) {
    return optionalNum(v) ?? fallback;
}
function timestamp(v) {
    if (v === null || v === undefined || v === '')
        return null;
    if (v instanceof Date)
        return v.toISOString();
    return String(v);
}
function leaseDeadlineReached(cursor, owner, expectedMs) {
    if (cursor?.desiredRunning !== true || cursor.leaseOwner !== owner || !cursor.leaseUntil)
        return false;
    const actualMs = Date.parse(cursor.leaseUntil);
    // Some adapters normalize Timestamp precision/format. One second tolerance covers
    // that representation change without accepting an old lease interval.
    return Number.isFinite(actualMs) && actualMs >= expectedMs - 1_000;
}
/** Map a raw DB row into the normalized numeric cursor. */
function toCursor(row) {
    return {
        network: row.network ?? null,
        startSlot: optionalNum(row.startSlot),
        startBlockHash: row.startBlockHash ?? null,
        lastSlot: requiredNum(row.lastSlot),
        lastBlockHash: row.lastBlockHash ?? null,
        lastHeight: requiredNum(row.lastHeight),
        tipSlot: optionalNum(row.tipSlot),
        tipHeight: optionalNum(row.tipHeight),
        syncStatus: (row.syncStatus ?? 'stopped'),
        consecutiveErrors: requiredNum(row.consecutiveErrors),
        desiredRunning: row.desiredRunning !== false,
        leaseOwner: row.leaseOwner ?? null,
        leaseUntil: timestamp(row.leaseUntil),
    };
}
/**
 * Idempotently ensure the singleton cursor row exists and return it.
 * On first call (fresh DB) the row is created with the configured start point
 * (if given) and status 'stopped'. Subsequent calls just return the current row.
 * Safe to call from both the crawler and the control service.
 */
async function ensureSyncStateSingleton(db, network, start) {
    const existing = await db.run(SELECT.one.from(cardano_1.CardanoSyncState).where({ ID: exports.SINGLETON_ID }));
    if (existing) {
        const cursor = toCursor(existing);
        if (cursor.network !== network) {
            throw new errors_1.ConfigError(`Crawler cursor network mismatch: persisted cursor tracks ${cursor.network ?? 'an unknown network'}, configured client is ${network}.`);
        }
        return cursor;
    }
    const row = {
        ID: exports.SINGLETON_ID,
        network,
        startSlot: start?.slot ?? null,
        startBlockHash: start?.hash ?? null,
        lastSlot: start?.slot ?? 0,
        lastBlockHash: start?.hash ?? null,
        lastHeight: start?.height ?? 0,
        tipSlot: null,
        tipHeight: null,
        syncStatus: 'stopped',
        consecutiveErrors: 0,
        desiredRunning: true,
        leaseOwner: null,
        leaseUntil: null,
    };
    await db.run(INSERT.into(cardano_1.CardanoSyncState).entries(row));
    logger.info(`Sync cursor initialized (network=${network}, start=${start ? `${start.slot}/${start.hash}` : 'none'})`);
    return toCursor(row);
}
/** Read the current cursor, or null if it has not been initialized yet. */
async function readCursor(db) {
    const row = await db.run(SELECT.one.from(cardano_1.CardanoSyncState).where({ ID: exports.SINGLETON_ID }));
    return row ? toCursor(row) : null;
}
/** Whether the shared lease currently represents a live cluster-wide crawler. */
function isCrawlerLeaseActive(cursor, now = new Date()) {
    if (!cursor?.desiredRunning || !cursor.leaseOwner || !cursor.leaseUntil)
        return false;
    const deadline = Date.parse(cursor.leaseUntil);
    return Number.isFinite(deadline) && deadline > now.getTime();
}
/**
 * Atomically acquire an expired/unowned lease with compare-and-swap semantics.
 * The post-update read is intentional: CAP adapters consistently return the row
 * for SELECT, whereas affected-row return shapes differ between SQLite and HANA.
 */
async function tryAcquireCrawlerLease(db, owner, now = new Date(), ttlMs = exports.CRAWLER_LEASE_TTL_MS) {
    const raw = await db.run(SELECT.one.from(cardano_1.CardanoSyncState).where({ ID: exports.SINGLETON_ID }));
    if (!raw)
        return false;
    const current = toCursor(raw);
    if (!current.desiredRunning)
        return false;
    const deadline = current.leaseUntil ? Date.parse(current.leaseUntil) : Number.NEGATIVE_INFINITY;
    if (current.leaseOwner && current.leaseOwner !== owner && deadline > now.getTime())
        return false;
    // CAS on the observed OWNER only (a plain string that round-trips identically
    // on every adapter). If two instances race, the first writer changes leaseOwner
    // and the loser's UPDATE matches 0 rows → its read-back verification fails.
    // Deliberately NOT comparing leaseUntil: HANA/driver timestamp normalization can
    // make the read-back representation differ from what the WHERE serializes, so a
    // timestamp-equality CAS may NEVER match again after a leader crash — the lease
    // would be stuck until the row is cleared by hand. The residual race (the old
    // owner renewing concurrently) resolves via fencing: its next renew no longer
    // matches leaseOwner and it halts.
    const where = {
        ID: exports.SINGLETON_ID,
        leaseOwner: raw.leaseOwner ?? null,
    };
    if (Object.prototype.hasOwnProperty.call(raw, 'desiredRunning')) {
        where.desiredRunning = raw.desiredRunning;
    }
    const leaseUntil = new Date(now.getTime() + ttlMs).toISOString();
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set({ leaseOwner: owner, leaseUntil }).where(where));
    const verified = await readCursor(db);
    return leaseDeadlineReached(verified, owner, now.getTime() + ttlMs);
}
/**
 * Renew/fence a lease. Call this inside the same transaction as every crawler write:
 * the conditional UPDATE serializes a former leader against a newly elected one.
 */
async function renewCrawlerLease(db, owner, now = new Date(), ttlMs = exports.CRAWLER_LEASE_TTL_MS) {
    const leaseUntil = new Date(now.getTime() + ttlMs).toISOString();
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set({ leaseUntil }).where({
        ID: exports.SINGLETON_ID,
        leaseOwner: owner,
        desiredRunning: true,
    }));
    const verified = await readCursor(db);
    return leaseDeadlineReached(verified, owner, now.getTime() + ttlMs);
}
/**
 * Release only the caller's lease; a stale process can never clear a successor.
 *
 * `pauseCluster` clears `desiredRunning`, which no restart undoes — every instance
 * then refuses to start until an operator calls resumeCrawler. Reserve it for
 * failures a restart genuinely cannot fix (misconfiguration, no resume point). A
 * crashed stream, a provider outage or a node restart must NOT latch: those are
 * exactly the cases where coming back up should resume the pre-sync by itself.
 */
async function releaseCrawlerLease(db, owner, status, pauseCluster = false) {
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set({
        leaseOwner: null,
        leaseUntil: null,
        syncStatus: status,
        ...(pauseCluster ? { desiredRunning: false } : {}),
    }).where({ ID: exports.SINGLETON_ID, leaseOwner: owner }));
}
/** Persist the pause/resume intent shared by every app instance. */
async function setCrawlerDesiredRunning(db, desiredRunning) {
    const set = { desiredRunning };
    if (!desiredRunning)
        set.syncStatus = 'stopped';
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set(set).where({ ID: exports.SINGLETON_ID }));
}
/**
 * Advance the cursor to a freshly-indexed block. Sets the status (default 'syncing';
 * pass 'synced' when the block is at the tip), clears the error streak, and refreshes
 * lastIndexedAt. Optionally records the latest known tip (for progress).
 */
async function advanceCursor(db, block, tip, status = 'syncing') {
    const set = {
        lastSlot: block.slot,
        lastBlockHash: block.hash,
        lastHeight: block.height ?? 0,
        lastIndexedAt: new Date().toISOString(),
        syncStatus: status,
        consecutiveErrors: 0,
        lastError: null,
    };
    if (tip) {
        set.tipSlot = tip.slot;
        if (tip.height !== undefined)
            set.tipHeight = tip.height;
    }
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set(set).where({ ID: exports.SINGLETON_ID }));
}
/** Reset the cursor to a rollback point (used by reorg handling). */
async function resetCursorTo(db, point) {
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set({
        lastSlot: point.slot,
        lastBlockHash: point.hash,
        lastHeight: point.height ?? 0,
        lastIndexedAt: new Date().toISOString(),
    }).where({ ID: exports.SINGLETON_ID }));
    logger.warn(`Sync cursor reset to fork point ${point.slot}/${point.hash}`);
}
/** Set the crawler status (e.g. 'synced' when caught up, 'stopped' on shutdown). */
async function setSyncStatus(db, status, pauseCluster = false) {
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set({
        syncStatus: status,
        ...(pauseCluster ? { desiredRunning: false } : {}),
    }).where({ ID: exports.SINGLETON_ID }));
}
/**
 * Record a crawler error. Increments the consecutive-error counter and flips status
 * to 'error' once the circuit-breaker threshold is reached. Returns the new streak
 * length so the caller can decide whether to back off / stop.
 */
async function recordError(db, err, leaseOwner) {
    if (leaseOwner && !(await renewCrawlerLease(db, leaseOwner)))
        return -1;
    const current = await readCursor(db);
    const streak = (current?.consecutiveErrors ?? 0) + 1;
    const message = err instanceof Error ? err.message : String(err);
    await db.run(UPDATE.entity(cardano_1.CardanoSyncState).set({
        consecutiveErrors: streak,
        lastError: message.slice(0, 500),
        lastErrorAt: new Date().toISOString(),
        syncStatus: streak >= exports.MAX_CONSECUTIVE_ERRORS ? 'error' : 'syncing',
    }).where({ ID: exports.SINGLETON_ID }));
    return streak;
}
//# sourceMappingURL=sync-state.js.map