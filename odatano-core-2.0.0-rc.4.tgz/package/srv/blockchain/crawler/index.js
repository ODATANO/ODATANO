"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startCrawler = startCrawler;
exports.stopCrawler = stopCrawler;
exports.isCrawlerRunning = isCrawlerRunning;
exports.getCrawler = getCrawler;
exports.isCrawlerRunningInCluster = isCrawlerRunningInCluster;
const cds_1 = __importDefault(require("@sap/cds"));
const node_crypto_1 = require("node:crypto");
const crawler_1 = require("./crawler");
const sync_state_1 = require("./sync-state");
const logger = cds_1.default.log('CardanoCrawler');
/**
 * Module-level singleton lifecycle for the chain crawler. Mirrors NIGHTGATE's
 * srv/crawler/index.ts: one active crawler per process, started fire-and-forget from
 * the server's `served` hook and controlled (pause/resume/status) via the indexer service.
 */
let active = null;
let lifecycleQueue = Promise.resolve();
let standbyDeps = null;
let standbyTimer = null;
let standbyGeneration = 0;
const STANDBY_RETRY_MS = 5_000;
/**
 * Start the crawler (idempotent — a no-op if one is already running). Fire-and-forget:
 * returns once the ingest pipeline is launched, not when catch-up completes.
 */
async function startCrawler(deps, resumeCluster = false) {
    const generation = ++standbyGeneration;
    standbyDeps = deps;
    if (standbyTimer) {
        clearTimeout(standbyTimer);
        standbyTimer = null;
    }
    scheduleStandby(generation);
    return startCrawlerAttempt(deps, resumeCluster, generation);
}
async function startCrawlerAttempt(deps, resumeCluster, generation) {
    return serializeLifecycle(async () => {
        if (generation !== standbyGeneration)
            return;
        if (resumeCluster) {
            await cds_1.default.tx((tx) => (0, sync_state_1.setCrawlerDesiredRunning)(tx, true));
        }
        if (active?.isRunning()) {
            logger.debug('startCrawler: already running');
            return;
        }
        if (active) {
            const previous = active;
            await previous.stop();
            if (active === previous)
                active = null;
        }
        const candidate = new crawler_1.CardanoCrawler(deps.client, deps.indexer, deps.network, deps.config, `${process.pid}:${(0, node_crypto_1.randomUUID)()}`);
        active = candidate;
        try {
            await candidate.start();
        }
        catch (err) {
            if (active === candidate)
                active = null;
            throw err;
        }
        // A lease loser stays in standby, not as a misleading process-local singleton.
        if (!candidate.isRunning() && active === candidate)
            active = null;
    });
}
/**
 * Stop the local crawler. `pauseCluster=true` additionally fences every instance via
 * shared DB intent; ordinary app shutdown leaves the desired state intact for failover.
 */
async function stopCrawler(pauseCluster = false) {
    ++standbyGeneration; // invalidate callbacks that already left the timer queue
    standbyDeps = null;
    if (standbyTimer) {
        clearTimeout(standbyTimer);
        standbyTimer = null;
    }
    return serializeLifecycle(async () => {
        if (pauseCluster) {
            await cds_1.default.tx((tx) => (0, sync_state_1.setCrawlerDesiredRunning)(tx, false));
        }
        const crawler = active;
        if (!crawler)
            return;
        await crawler.stop();
        // A queued/re-entrant start can never be erased by an older stop continuation.
        if (active === crawler)
            active = null;
    });
}
/** Whether a crawler is currently running. */
function isCrawlerRunning() {
    return active?.isRunning() ?? false;
}
/** The active crawler instance, or null. */
function getCrawler() {
    return active;
}
/** Read the lease in a fresh transaction (control actions must not use a stale request snapshot). */
async function isCrawlerRunningInCluster() {
    const cursor = await cds_1.default.tx((tx) => (0, sync_state_1.readCursor)(tx));
    return (0, sync_state_1.isCrawlerLeaseActive)(cursor);
}
function serializeLifecycle(operation) {
    const result = lifecycleQueue.then(operation, operation);
    lifecycleQueue = result.catch(() => undefined);
    return result;
}
/** Keep non-leader instances warm so an expired/released lease fails over automatically. */
function scheduleStandby(generation) {
    if (standbyTimer || !standbyDeps)
        return;
    standbyTimer = setTimeout(() => {
        standbyTimer = null;
        if (generation !== standbyGeneration)
            return;
        const deps = standbyDeps;
        if (!deps)
            return;
        void startCrawlerAttempt(deps, false, generation)
            .catch((err) => logger.error('standby lease attempt failed:', err))
            .finally(() => {
            if (generation === standbyGeneration)
                scheduleStandby(generation);
        });
    }, STANDBY_RETRY_MS);
    standbyTimer.unref?.();
}
//# sourceMappingURL=index.js.map