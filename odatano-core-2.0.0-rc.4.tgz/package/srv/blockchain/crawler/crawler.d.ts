import type { CardanoClient } from '../cardano-client';
import type { CardanoIndexer } from '../cardano-indexer';
import { type CrawlSyncStatusValue } from './sync-state';
/** Runtime configuration for the chain crawler (loaded from cds.requires by the server). */
export interface CrawlerConfig {
    enabled: boolean;
    /** Pre-sync origin. Required (slot+hash) when enabled; the crawler resumes from here on a fresh DB. */
    startSlot?: number;
    startBlockHash?: string;
    startHeight?: number;
    /** 'ogmios' = chain-sync only, 'pagination' = Blockfrost/Koios only, 'auto' = chain-sync if available else pagination. */
    source: 'ogmios' | 'pagination' | 'auto';
    /** Blocks fetched per catch-up round (pagination path). */
    batchSize: number;
    /** Stay this many blocks behind the tip to avoid the volatile chain edge. */
    confirmationDepth: number;
    /** Poll cadence when caught up / on transient errors (pagination path). */
    pollIntervalMs: number;
}
/**
 * CardanoCrawler — pre-sync engine (v2.0). Streams the chain forward from a configured
 * start block and bulk-indexes Blocks + Transactions (+ inputs/outputs/assets) into the
 * DB, so consumers can query local data instead of hitting a backend per request.
 *
 * Two sources (see CRAWLER_DESIGN.md):
 *  - **Ogmios chain-sync** (primary): ordered rollForward + native rollBackward (reorg).
 *  - **Blockfrost/Koios pagination** (fallback): forward walk + parent-hash reorg recovery.
 *
 * Lifecycle: start() launches the ingest pipeline detached so the HTTP server binds
 * immediately, but the pipeline promise is retained — stop() halts the loops (waking
 * any pending poll sleep) and AWAITS the pipeline, so shutdown never races in-flight
 * block writes. All per-block writes are atomic. The crawler NEVER crawls from genesis
 * implicitly — it requires an explicit configured start point or an existing cursor.
 */
export declare class CardanoCrawler {
    private readonly client;
    private readonly indexer;
    private readonly network;
    private readonly config;
    /** Present for production instances created by index.ts; omitted in engine unit tests. */
    private readonly leaseOwner?;
    /** Transient-failure retries per block before giving up. */
    private static readonly PERSIST_RETRIES;
    /** Timeout for direct backend calls (the crawler bypasses the client's resilience layer). */
    private static readonly CALL_TIMEOUT_MS;
    private running;
    private chainSyncHandle;
    /** The detached ingest pipeline — awaited by stop() so teardown never races it. */
    private pipeline;
    /** Resolver that cancels a pending poll sleep (set while sleeping). */
    private wake;
    /** Cancellers for backend waits, so shutdown is not held hostage by their timeout. */
    private readonly callCancels;
    /** Chain-sync callback promises outlive openChainSync(); stop() explicitly drains them. */
    private readonly inFlightCallbacks;
    private haltPromise;
    private finalStatus;
    /** Set only by an unrecoverable halt — clears desiredRunning so restarts stay down. */
    private latchOnHalt;
    private leaseHeld;
    private leaseHeartbeat;
    private leaseWake;
    constructor(client: CardanoClient, indexer: CardanoIndexer, network: string, config: CrawlerConfig, 
    /** Present for production instances created by index.ts; omitted in engine unit tests. */
    leaseOwner?: string | undefined);
    isRunning(): boolean;
    /**
     * Start crawling. Does NOT await the ingest pipeline (fire-and-forget).
     * Refuses to start without a resume point: an explicit configured start block or an
     * existing cursor — never an implicit full-chain sync from genesis.
     */
    start(): Promise<void>;
    /**
     * Stop crawling and WAIT for the pipeline to finish its in-flight step: halts the
     * loops (waking any pending poll sleep), closes the chain-sync stream, records the
     * final status, then awaits the detached pipeline so callers (shutdownAppContext)
     * can safely tear down backends/DB afterwards.
     */
    stop(finalStatus?: CrawlSyncStatusValue): Promise<void>;
    /**
     * Halt without awaiting the pipeline — the variant safe to call FROM INSIDE the
     * pipeline (persistBlock failure, stream onError), where awaiting the pipeline
     * would deadlock.
     */
    /**
     * @param latch clears `desiredRunning`, so NO restart brings the crawler back —
     *   only an operator's resumeCrawler does. Reserved for failures a restart cannot
     *   fix (misconfiguration, missing resume point). Runtime failures — a dropped
     *   chain-sync socket, a provider outage, a node restart — must leave it false,
     *   otherwise a routine node restart silently disables the pre-sync for good.
     */
    private halt;
    /**
     * Start teardown without awaiting it. Internal callers can therefore halt from
     * inside a tracked callback/pipeline without waiting on their own promise.
     */
    private beginHalt;
    private runIngestPipeline;
    /** Bound a direct backend call — these bypass the client's timeout/breaker layer. */
    private withTimeout;
    private runChainSync;
    /**
     * Candidate intersection points, NEWEST FIRST: the cursor, then an exponentially
     * spaced ladder of our own already-crawled ancestors, then the configured start
     * block as the deepest anchor.
     *
     * Why more than the cursor: if the cursor's block was orphaned while the crawler
     * was down, a single-point intersection fails outright ("No intersection found")
     * and the stream never opens. With ancestors on the list the node intersects at
     * the last common block and reports it as a rollBackward — the ordinary reorg path
     * that handleReorg already implements. Doubling offsets cover ~32k blocks with 16
     * points; anything deeper is past any realistic rollback and should fail loudly.
     */
    private buildIntersectionPoints;
    /** Track streamed callbacks because closing a socket does not imply DB callbacks finished. */
    private trackCallback;
    private runPagination;
    /**
     * Pagination reorg recovery: walk back by height comparing the on-chain block hash with
     * our stored one until they agree — that height is the fork point. If the last-indexed
     * block still matches on-chain, there is no reorg (returns false → treat as transient).
     */
    private tryReorgRecovery;
    /**
     * Persist one block atomically and advance the cursor. Transient failures are retried
     * a few times (recording the error streak); only repeated failure stops the crawler —
     * the cursor is not advanced on failure, so a resume re-syncs cleanly from it.
     * Marks the cursor 'synced' when the block is at the reported tip.
     * @returns true when the block was persisted, false when the crawler was stopped
     */
    private persistBlock;
    /**
     * Handle a chain rollback: in one transaction, delete every block after the fork point
     * and exactly the transactions belonging to those blocks (plus their child rows), reset
     * the cursor to the fork, and write a CardanoReorgLog audit row.
     *
     * The cut runs on the absolute-slot axis of Blocks (same axis as the fork point), and
     * transactions are resolved via their blockHash — so:
     *  - an unresolvable fork height can never widen the delete (no height-0 fallback), and
     *  - lazily-indexed transactions of blocks the crawler never wrote are left untouched.
     */
    private handleReorg;
    /** Renew the lease while an Ogmios stream is idle; block writes renew it transactionally. */
    private startLeaseHeartbeat;
    /** Record state only while this instance still owns the lease. */
    private recordCrawlerError;
    private leaseSleep;
    /** Cancellable, unref'd delay — halt() wakes it so shutdown never waits out a poll. */
    private sleep;
}
//# sourceMappingURL=crawler.d.ts.map