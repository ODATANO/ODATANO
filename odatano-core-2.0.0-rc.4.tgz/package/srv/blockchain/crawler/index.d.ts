import type { CardanoClient } from '../cardano-client';
import type { CardanoIndexer } from '../cardano-indexer';
import { CardanoCrawler, type CrawlerConfig } from './crawler';
export interface StartCrawlerDeps {
    client: CardanoClient;
    indexer: CardanoIndexer;
    network: string;
    config: CrawlerConfig;
}
/**
 * Start the crawler (idempotent — a no-op if one is already running). Fire-and-forget:
 * returns once the ingest pipeline is launched, not when catch-up completes.
 */
export declare function startCrawler(deps: StartCrawlerDeps, resumeCluster?: boolean): Promise<void>;
/**
 * Stop the local crawler. `pauseCluster=true` additionally fences every instance via
 * shared DB intent; ordinary app shutdown leaves the desired state intact for failover.
 */
export declare function stopCrawler(pauseCluster?: boolean): Promise<void>;
/** Whether a crawler is currently running. */
export declare function isCrawlerRunning(): boolean;
/** The active crawler instance, or null. */
export declare function getCrawler(): CardanoCrawler | null;
/** Read the lease in a fresh transaction (control actions must not use a stale request snapshot). */
export declare function isCrawlerRunningInCluster(): Promise<boolean>;
//# sourceMappingURL=index.d.ts.map