"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerBlockIndexedListener = registerBlockIndexedListener;
exports.unregisterBlockIndexedListener = unregisterBlockIndexedListener;
exports.registerReorgListener = registerReorgListener;
exports.unregisterReorgListener = unregisterReorgListener;
exports.hasBlockIndexedListeners = hasBlockIndexedListeners;
exports.emitBlockIndexed = emitBlockIndexed;
exports.emitReorg = emitReorg;
const cds_1 = __importDefault(require("@sap/cds"));
const service_events_1 = require("../../utils/service-events");
const logger = cds_1.default.log('CardanoCrawler');
const blockListeners = new Set();
const reorgListeners = new Set();
function registerBlockIndexedListener(listener) {
    blockListeners.add(listener);
}
function unregisterBlockIndexedListener(listener) {
    blockListeners.delete(listener);
}
function registerReorgListener(listener) {
    reorgListeners.add(listener);
}
function unregisterReorgListener(listener) {
    reorgListeners.delete(listener);
}
/** True when at least one consumer observes crawler progress. */
function hasBlockIndexedListeners() {
    return blockListeners.size > 0;
}
function emitBlockIndexed(event) {
    // Mirrored onto the CAP service so external consumers can subscribe; the
    // in-process registry below stays the fast path for our own subsystems.
    (0, service_events_1.emitServiceEvent)('CardanoIndexerService', 'blockIndexed', { ...event });
    for (const listener of blockListeners) {
        try {
            listener(event);
        }
        catch (err) {
            logger.warn('blockIndexed listener failed (ignored):', err);
        }
    }
}
function emitReorg(event) {
    (0, service_events_1.emitServiceEvent)('CardanoIndexerService', 'reorg', {
        forkSlot: event.forkSlot,
        forkHeight: event.forkHeight,
        blocksRolledBack: event.blocksRolledBack ?? 0,
    });
    for (const listener of reorgListeners) {
        try {
            listener(event);
        }
        catch (err) {
            logger.warn('reorg listener failed (ignored):', err);
        }
    }
}
//# sourceMappingURL=hooks.js.map