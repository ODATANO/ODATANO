/**
 * Crawler event hooks (v2.1).
 *
 * Small listener registry that lets other subsystems (currently the wallet-worker
 * confirmation tracker) observe crawler progress without the crawler importing
 * them (dependency direction stays crawler ← consumer). The crawler emits:
 *  - `blockIndexed` after each successfully persisted block (with its tx hashes), and
 *  - `reorg` after a completed rollback (with the fork slot).
 *
 * Listener failures are logged and swallowed — a broken consumer must never
 * stop the crawler.
 */
export interface BlockIndexedEvent {
    hash: string;
    slot: number | null;
    height: number | null;
    txHashes: string[];
    /** Latest known chain tip at the time of indexing (when the source reports one). */
    tipSlot: number | null;
    tipHeight: number | null;
}
export interface ReorgEvent {
    /** Absolute slot of the fork point — everything after it was rolled back. */
    forkSlot: number;
    /** How many blocks the rollback removed (0 when the fork was already the tip). */
    blocksRolledBack?: number;
    /**
     * Block height of the fork point, when known. Listeners tracking confirmation
     * depth must clamp their tip to this — the pre-fork tip height no longer exists.
     */
    forkHeight: number | null;
}
export type BlockIndexedListener = (event: BlockIndexedEvent) => void;
export type ReorgListener = (event: ReorgEvent) => void;
export declare function registerBlockIndexedListener(listener: BlockIndexedListener): void;
export declare function unregisterBlockIndexedListener(listener: BlockIndexedListener): void;
export declare function registerReorgListener(listener: ReorgListener): void;
export declare function unregisterReorgListener(listener: ReorgListener): void;
/** True when at least one consumer observes crawler progress. */
export declare function hasBlockIndexedListeners(): boolean;
export declare function emitBlockIndexed(event: BlockIndexedEvent): void;
export declare function emitReorg(event: ReorgEvent): void;
//# sourceMappingURL=hooks.d.ts.map