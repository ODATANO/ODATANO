import type { Transaction as CapTransaction } from '@sap/cds';
import type { CardanoClient } from './cardano-client';
import type { CardanoTransactionBuilder } from './cardano-tx-builder';
import { Transaction as CardanoTransaction, AddressUTxOs, TransactionMetadata, NetworkInformation, Block, Epoch, AssetHistory, Account, Drep, Pool, Asset, Address, LedgerProtocolParameter, AddressTransactions } from '#cds-models/CardanoODataService';
import { TransactionBuild, TransactionSubmission } from '#cds-models/CardanoTransactionService';
import { TxBuildRequest, Transaction as ProviderTransaction, BlockData } from '../utils/types';
import type { TxCacheTargets } from '../utils/tx-build-helper';
/**
 * CardanoIndexer - Indexer for Cardano blockchain data into OData entities
 *
 * Provides methods to index & manage db consistency for various Cardano blockchain data (transactions, addresses, blocks, epochs, accounts, pools, dreps)
 * 1. Fetches data from the configured Cardano data provider via the CardanoClient
 * 2. Maps the provider data into corresponding OData entity rows
 * 3. Upserts the data rows into the database via CAP transactions
 * 4. Ensures referential integrity and consistency across related entities (e.g., addresses in transactions, UTxOs in addresses)
 * 5. Returns the indexed entity data for further processing
 *
 * Each method corresponds to a specific Cardano Entity type and handles the necessary mapping and persistence
 * into the corresponding OData entities defined in the CardanoODataService(M1) and CardanoTransactionService(M2) models.
 */
export declare class CardanoIndexer {
    private client;
    private txBuilder;
    private lastParamsFetchTime;
    private static readonly CRAWL_EPOCH_REFRESH_MS;
    private static readonly CRAWL_EPOCH_RETRY_MS;
    /**
     * Crawler epoch memo. Network reads are refreshed periodically while an epoch is
     * live and once more when the next epoch starts, so counters such as block_count,
     * fees and lastBlockTime do not remain frozen at their first observed value.
     *
     * At most the current and immediately previous epoch are retained. The rows are
     * intentionally UPSERTed in every block transaction: the caller owns that
     * transaction, so an in-memory "persisted" bit cannot know whether its commit later
     * succeeded. Repeating one local UPSERT is cheap and remains correct after rollback.
     */
    private crawlEpochCache;
    private crawlEpochCurrent;
    private crawlEpochPrevious;
    /**
     * Network-only epoch prefetch for the crawler. Call BEFORE opening the per-block
     * write transaction — the backend round-trip must never run while the DB write
     * lock is held (indexBlockFull then serves the epoch from this memo). Never throws.
     */
    prefetchCrawlEpoch(epochNumber: number): Promise<void>;
    private refreshCrawlEpoch;
    /**
     * Create a new CardanoIndexer instance
     * @param client - The CardanoClient instance for blockchain queries
     * @param txBuilder - The CardanoTransactionBuilder instance for transaction building
     */
    constructor(client: CardanoClient, txBuilder: CardanoTransactionBuilder);
    /**
     * Index & return a single transaction with inputs/outputs/assets/UTxOs/addresses
     * All UPSERTs execute within the same CAP transaction (cds.tx), which ensures
     * atomicity: either all entities are persisted or none are (automatic rollback on error).
     * @param tx      CAP transaction (cds.tx(req))
     * @param txHash  Cardano transaction hash (hex)
     * @returns {Promise<CardanoTransaction>} transaction entity data
     */
    indexTransaction(tx: CapTransaction, txHash: string): Promise<CardanoTransaction>;
    /**
     * Index & return address data with assets and UTxOs (without transactions)
     * Transactions are loaded separately via indexAddressTransactions() for better performance
     * @param tx       CAP transaction
     * @param addr     bech32 address
     * @return {Promise<Address>} address entity data
     */
    indexAddress(tx: CapTransaction, addr: string): Promise<Address>;
    /**
     * Index UTxOs by 28-byte payment credential. Always-fresh fetch from Koios
     * (bypasses cache) — credential queries serve dApp-state use cases that require
     * current data. Underlying AddressUTxOs/UTxOAssets rows are UPSERTed and stay
     * available for follow-up address-keyed queries within the TTL.
     *
     * Does NOT upsert parent Addresses rows; child rows reference bech32 addresses
     * that may not yet have a parent stub. Same pattern as TransactionInputs.
     *
     * @param tx       CAP transaction
     * @param credHash 28-byte payment credential as 56-char lowercase hex
     * @return UTxO entity rows across all bech32 addresses sharing the credential
     */
    indexCredentialUtxos(tx: CapTransaction, credHash: string): Promise<AddressUTxOs[]>;
    /**
     * Index ONLY the UTxOs at a bech32 address via getAddressUtxos — deliberately
     * WITHOUT a getAddress (address-detail) call, so it works on backends that serve
     * the live UTxO set but not address aggregation (e.g. Ogmios). Used as the
     * GetUTxOsByAddress fallback when no configured backend supports getAddress.
     *
     * Does NOT upsert a parent Addresses row (same pattern as indexCredentialUtxos);
     * AddressUTxOs/UTxOAssets reference the bech32 address directly.
     *
     * @param tx    CAP transaction
     * @param addr  bech32 address
     * @return UTxO entity rows for the address (empty when the address holds none)
     */
    indexAddressUtxos(tx: CapTransaction, addr: string): Promise<AddressUTxOs[]>;
    /**
     * Evict cached rows a submitted transaction made stale, so the next read
     * refetches instead of serving spent UTxOs for up to indexTtlMs:
     *   - every consumed input ref (spent under WHATEVER address cached it),
     *   - all address-level rows of the output addresses (their UTxO set gained
     *     the new outputs — sender change included) and of `extraAddresses`
     *     (e.g. the build's sender when the CBOR could not be parsed).
     *
     * Only the read cache is touched; submissions/builds stay untouched. Note the
     * next refetch may STILL see pre-submit state on lagging backends
     * (Blockfrost/Koios propagation) — that matches cache-less behaviour and is
     * not recoverable server-side.
     *
     * @param tx             CAP transaction
     * @param targets        input refs + output addresses from extractTxCacheTargets
     * @param extraAddresses additional bech32 addresses to evict
     */
    invalidateUtxoCacheForTx(tx: CapTransaction, targets: TxCacheTargets, extraAddresses?: string[]): Promise<void>;
    /**
     * Index & return address transactions (separate from indexAddress for lazy loading)
     * @param tx       CAP transaction
     * @param addr     bech32 address
     * @param limit    maximum number of transactions to fetch
     * @return {Promise<AddressTransactions[]>} address transaction entities
     */
    indexAddressTransactions(tx: CapTransaction, addr: string, limit: number): Promise<AddressTransactions[]>;
    /**
     * Index & return address signing request association
     * Links an address to a signing request for address-based queries
     * @param tx       CAP transaction
     * @param addr     bech32 address
     * @param signingRequestId signing request UUID
     * @return {Promise<void>}
     */
    indexAddressSigningRequests(tx: CapTransaction, addr: string, signingRequestId: string): Promise<void>;
    /**
     * Index & return address transaction build association
     * Links an address to a transaction build for address-based queries
     * @param tx       CAP transaction
     * @param addr     bech32 address
     * @param buildId  transaction build UUID
     * @return {Promise<void>}
     */
    indexAddressTransactionBuilds(tx: CapTransaction, addr: string, buildId: string): Promise<void>;
    /**
     * Index & return metadata for a single transaction (Metadata)
     * @param tx       CAP transaction
     * @param txHash   transaction hash
     * @param metadata raw metadata object (label -> JSONValue)
     * @return {Promise<TransactionMetadata[]>} array of transaction metadata rows
     */
    indexTransactionMetadata(tx: CapTransaction, tx_hash: string): Promise<TransactionMetadata[]>;
    /**
     * Index & return the network information data
     * @param tx CAP transaction object
     * @returns {Promise<NetworkInformation>} network information entity data
     */
    indexNetworkInformation(tx: CapTransaction): Promise<NetworkInformation>;
    /**
     * Index & return the block information data
     * @param tx CAP transaction object
     * @param blockHash block hash (hex)
     * @returns {Promise<Block>} block entity data
     */
    indexBlock(tx: CapTransaction, blockHash: string): Promise<Block>;
    /**
     * Bulk-index a whole block and all of its transactions in ONE pass (chain crawler,
     * v2.0). Unlike indexTransaction()/indexBlock() this does NOT re-fetch per hash — the
     * crawler already carries the block + full tx list from the stream/page. Rows are
     * accumulated across the block's txs and UPSERTed once per table (few statements).
     *
     * All writes run inside the caller's CAP transaction (`tx`), so a block is persisted
     * atomically — a failure mid-block rolls the whole block back, keeping the cursor and
     * the data consistent.
     *
     * Inputs from the Ogmios chain-sync path arrive as bare references (no address/amount);
     * resolveInputs() backfills them from this block's own outputs and previously-indexed
     * outputs before mapping. Blockfrost/Koios inputs already carry address/amount and are
     * left untouched.
     *
     * @param tx        CAP transaction (one per block, committed by the crawler)
     * @param blockData block header/summary from the crawler source
     * @param txs       the block's full transaction list (in block order)
     */
    indexBlockFull(tx: CapTransaction, blockData: BlockData, txs: ProviderTransaction[]): Promise<void>;
    /**
     * Backfill input address/amount for chain-sync transactions whose inputs are bare
     * references. Resolves first from this block's own outputs (a tx may spend an earlier
     * tx's output in the same block), then batch-reads previously-indexed outputs from the
     * DB. Inputs that already carry an address (Blockfrost/Koios) are skipped.
     */
    private resolveInputs;
    /**
     * Index & return the epoch information data
     * @param tx CAP transaction object
     * @param epochNumber epoch number
     * @returns {Promise<Epoch>} epoch entity data
     */
    indexEpoch(tx: CapTransaction, epochNumber: number): Promise<Epoch>;
    /**
     * Index & return the account information data
     * @param tx CAP transaction object
     * @param stakeAddress stake address (bech32)
     * @returns {Promise<Account>} account entity data
    */
    indexAccount(tx: CapTransaction, stakeAddress: string): Promise<Account>;
    /**
     * Index & return the drep information data
     * @param tx CAP transaction object
     * @param drepId drep id (bech32)
     * @returns {Promise<Drep>} drep entity data
     */
    indexDrep(tx: CapTransaction, drepId: string): Promise<Drep>;
    /**
     * Index & return the pool information data
     * @param tx CAP transaction object
     * @param poolId pool id (hex)
     * @returns {Promise<Pool>} pool entity data
     */
    indexPool(tx: CapTransaction, poolId: string): Promise<Pool>;
    /**
     * Index & return the asset information data
     * @param tx CAP transaction object
     * @param unit asset unit (policyId + assetNameHex)
     * @returns {Promise<Asset>} asset entity data
     */
    indexAsset(tx: CapTransaction, unit: string): Promise<Asset>;
    /**
     * Index & return mint/burn history for an asset. Always-fresh from the
     * preferred backend (Koios for block timestamps, Blockfrost as fallback).
     * UPSERTs entries by (unit, txHash) — events are immutable, so re-fetching
     * just refreshes the cap of recent entries; older cached entries persist.
     * @param tx CAP transaction object
     * @param unit asset unit (policyId + assetNameHex)
     * @param limit max number of recent events to fetch (default 100)
     * @returns {Promise<AssetHistory[]>} list of mint/burn event entity rows
     */
    indexAssetHistory(tx: CapTransaction, unit: string, limit?: number): Promise<AssetHistory[]>;
    /**
     * Common method: build a transaction, persist build result with inputs/outputs/address associations.
     * All four public indexBuild*Result methods delegate to this to eliminate duplication.
     * @param tx      CAP transaction object
     * @param buildreq transaction build request data
     * @param buildFn  the specific builder method to call
     * @returns {Promise<TransactionBuild>} transaction build entity data
     */
    private _indexBuildResult;
    indexSimpleBuildResult(tx: CapTransaction, buildreq: TxBuildRequest): Promise<TransactionBuild>;
    indexMetadataBuildResult(tx: CapTransaction, buildreq: TxBuildRequest): Promise<TransactionBuild>;
    indexMultiAssetBuildResult(tx: CapTransaction, buildreq: TxBuildRequest): Promise<TransactionBuild>;
    indexMintBuildResult(tx: CapTransaction, buildreq: TxBuildRequest): Promise<TransactionBuild>;
    indexPlutusSpendBuildResult(tx: CapTransaction, buildreq: TxBuildRequest): Promise<TransactionBuild>;
    /**
     * Index & return the protocol parameters data
     * @param tx CAP transaction object
     * @returns {Promise<LedgerProtocolParameter>} protocol parameters entity data
     */
    indexProtocolParameters(tx: CapTransaction): Promise<LedgerProtocolParameter>;
    /**
     * Persist a transaction submission with optional build association
     * Handles: TransactionSubmission insert, optional Build status update
     * @param tx CAP transaction object
     * @param params submission parameters
     * @returns {Promise<TransactionSubmission>} persisted transaction submission entity
     */
    persistTransactionSubmission(tx: CapTransaction, params: {
        signedTxCbor: string;
        txHash: string;
        buildId?: string | null;
    }): Promise<TransactionSubmission>;
    /**
     * Update the status of a transaction submission
     * Used for the two-phase submit flow: pending → submitted (or failed)
     * @param tx CAP transaction object
     * @param submissionId the submission to update
     * @param status new status value
     * @param errorMessage optional error message for failed status
     */
    updateSubmissionStatus(tx: CapTransaction, submissionId: string, status: string, errorMessage?: string): Promise<void>;
    /**
     * Persist a new signing request
     * @param tx CAP transaction object
     * @param params signing request parameters from external signer module
     * @returns persisted signing request record
     */
    persistSigningRequest(tx: CapTransaction, params: {
        buildId: string;
        signingPayload: {
            signingRequestId: string;
            txBodyHash: string;
            unsignedTxCbor: string;
            network: string;
            createdAt: string;
            expiresAt: string;
            signingInstructions: {
                cardanoCliCommand?: string;
                cip30SigningRequest?: {
                    txCbor: string;
                };
            };
        };
    }): Promise<{
        id: string;
        build_id: string;
        txBodyHash: string;
        unsignedTxCbor: string;
        network: string;
        status: "pending";
        createdAt: string;
        expiresAt: string;
        cardanoCliCommand: string | undefined;
        cip30TxCbor: string | undefined;
    }>;
    /**
     * Persist a signature verification with signing request status update
     * Handles: SignatureVerification insert, SigningRequest status update
     * @param tx CAP transaction object
     * @param params verification parameters
     * @returns persisted signature verification record
     */
    persistSignatureVerification(tx: CapTransaction, params: {
        signingRequestId: string;
        signedTxCbor: string;
        verificationResult: {
            isValid: boolean;
            txBodyHash: string;
            witnessCount: number;
            signerKeyHashes: string[];
            errorMessage?: string | null;
            warnings: string[];
        };
        signerType?: string;
        signerInfo?: string;
    }): Promise<{
        id: string;
        signingRequest_id: string;
        signedTxCbor: string;
        isValid: boolean;
        txBodyHash: string;
        witnessCount: number;
        signerKeyHashes: string;
        errorMessage: string | null;
        warnings: string;
        verifiedAt: string;
    }>;
    /**
     * Index a verified transaction submission with all related records
     * Handles persistence of: SignatureVerification, TransactionSubmission, SigningRequest update, Build update
     * @param tx CAP transaction object
     * @param params submission parameters
     * @returns {Promise<TransactionSubmission>} transaction submission entity data
     */
    indexVerifiedTransactionSubmission(tx: CapTransaction, params: {
        signingRequestId: string;
        buildId: string;
        fullSignedTxCbor: string;
        txHash: string;
        verificationResult: {
            txBodyHash: string;
            witnessCount: number;
            signerKeyHashes: string[];
            warnings: string[];
        };
        signerType?: string;
        signerInfo?: string;
    }): Promise<TransactionSubmission>;
    /**
     * Index & return the latest epoch information data
     * @param tx CAP transaction object
     * @returns {Promise<Epoch>} epoch entity data
     */
    indexLatestEpoch(tx: CapTransaction): Promise<Epoch>;
    /**
     * Index & return the latest block information data
     * @param tx CAP transaction object
     * @returns {Promise<Block>} block entity data
     */
    indexLatestBlock(tx: CapTransaction): Promise<Block>;
    /** Max addresses to index concurrently (avoid overloading backends) */
    private static readonly ADDR_CONCURRENCY;
    /**
     * Ensure a set of transactions are indexed — batch DB-check + batch fetch.
     * 1. Deduplicate hashes
     * 2. Check which hashes already exist in DB
     * 3. Batch-fetch missing transactions from backend
     * 4. UPSERT all entities (Transactions, Inputs, Outputs, Assets, Metadata)
     *
     * @param tx       CAP transaction (cds.tx)
     * @param txHashes array of transaction hashes to ensure
     * @returns Map of txHash → provider Transaction (all requested, from DB fetch or backend)
     */
    ensureTransactionsIndexed(tx: CapTransaction, txHashes: string[]): Promise<Map<string, ProviderTransaction>>;
    /**
     * Index multiple addresses with concurrency-limited parallelism.
     * Processes addresses in chunks to avoid overwhelming backends.
     * @param tx CAP transaction object
     * @param bech32List array of bech32 addresses
     */
    private _ensureAddresses;
}
//# sourceMappingURL=cardano-indexer.d.ts.map