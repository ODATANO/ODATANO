import cds, { Request } from '@sap/cds';
/** Shape persisted by indexVerifiedTransactionSubmission. */
export interface FinalizeParams {
    signingRequestId: string;
    buildId: string;
    fullSignedTxCbor: string;
    txHash: string;
    verificationResult: {
        txBodyHash: string;
        witnessCount: number;
        signerKeyHashes: string[];
        warnings: string[];
    };
    signerType?: string;
    signerInfo?: string;
}
/**
 * Submit a verified+claimed signing request to the blockchain and persist the
 * outcome — DELIBERATELY outside the caller's request transaction.
 *
 * The caller must already have durably committed `status:'submitting'` (the
 * claim). This function then:
 *   1. submits with NO DB write-lock held (the lock was the reason concurrent
 *      submits serialized and the SQLite busy-timeout could fire mid-network),
 *   2. on submit failure: marks the request 'failed' in its own committed tx
 *      and rethrows (NOT rolled back to a pre-submit status — losing the
 *      attempt would hide a tx the node may have accepted),
 *   3. on success: persists the submission + 'submitted' status in a committed
 *      transaction.
 *
 * Crash window: a process death between (1) and (3) leaves the request durably
 * at 'submitting'. Deferred-path requests carry their signed CBOR on the row
 * and are re-driven at the next boot (redriveInterruptedSubmissions); sync-path
 * requests are left for the operator/poller exactly as before.
 */
export declare function submitAndFinalize(SigningRequests: unknown, params: FinalizeParams, afterFinalize?: (db: cds.Transaction) => Promise<void>): Promise<unknown>;
/**
 * Deferred-submit scheduler (KNOWN_ISSUES #11, Layer 2).
 *
 * Called by an action handler AFTER verify + claim ran on the CALLER's
 * transaction. Hooks the request's post-commit event: only once the caller's
 * root transaction has committed (claim durable, pooled connection released)
 * does the network submit + finalize run — detached via setImmediate +
 * runWithoutAmbientTx, so no ambient transaction is held across it.
 *
 * If the caller's transaction rolls back instead, 'succeeded' never fires and
 * nothing was claimed — strictly consistent.
 */
export declare function scheduleDeferredSubmit(req: Request, SigningRequests: unknown, params: FinalizeParams): void;
/**
 * Boot-time recovery: re-drive submissions that were claimed on the deferred
 * path (status 'submitting' WITH persisted signedTxCbor) but never finalized —
 * i.e. the process died between the caller's commit and the detached submit.
 *
 * Safe to repeat: a tx the node already holds finalizes as 'submitted' via the
 * TransactionAlreadySubmittedError path in submitAndFinalize. Rows at
 * 'submitting' WITHOUT signed CBOR (sync-path crash window) are deliberately
 * left untouched for the operator/poller, exactly as before Layer 2.
 *
 * @returns number of rows re-driven (attempted, not necessarily succeeded)
 */
export declare function redriveInterruptedSubmissions(): Promise<number>;
//# sourceMappingURL=submission-finalizer.d.ts.map