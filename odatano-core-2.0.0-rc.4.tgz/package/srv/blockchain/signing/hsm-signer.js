"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HsmSigner = void 0;
exports.setPkcs11Loader = setPkcs11Loader;
exports.getHsmSigner = getHsmSigner;
exports.setHsmSigner = setHsmSigner;
const cds_1 = __importDefault(require("@sap/cds"));
const errors_1 = require("../../utils/errors");
const error_codes_1 = require("../../utils/error-codes");
const cbor_1 = require("@harmoniclabs/cbor");
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const logger = cds_1.default.log('HsmSigner');
/**
 * CKM_EDDSA mechanism ID (PKCS#11 v3.0)
 * Used for Ed25519 signing operations
 */
const CKM_EDDSA = 0x00001057;
const defaultPkcs11Loader = () => require('pkcs11js');
let pkcs11Loader = defaultPkcs11Loader;
/** Test seam: inject a fake pkcs11js module loader (null restores the default). */
function setPkcs11Loader(loader) {
    pkcs11Loader = loader ?? defaultPkcs11Loader;
}
class HsmSigner {
    pkcs11;
    session;
    privateKeyHandle;
    publicKeyBytes = Buffer.alloc(0);
    publicKeyHashHex = '';
    cardanoAddress = '';
    config;
    connected = false;
    constructor(config) {
        this.config = config;
    }
    /**
     * Initialize PKCS#11 session and locate the signing key.
     * Called once during plugin startup.
     *
     * @param network - Cardano network (mainnet, preview, preprod) for address derivation
     */
    async init(network) {
        // Dynamic import — pkcs11js is only loaded when HSM is configured
        let pkcs11js;
        try {
            pkcs11js = pkcs11Loader();
        }
        catch {
            throw new errors_1.HsmError('pkcs11js is not installed. Install it with: npm install pkcs11js', 500, error_codes_1.ERROR_CODES.HSM_UNAVAILABLE);
        }
        this.pkcs11 = new pkcs11js.PKCS11();
        try {
            // 1. Load PKCS#11 module
            this.pkcs11.load(this.config.pkcs11Module);
            this.pkcs11.C_Initialize();
            logger.info({ module: this.config.pkcs11Module }, 'PKCS#11 module loaded');
            // 2. Open session on configured slot.
            // NOTE: `config.slot` is the 0-based INDEX into the list of slots-with-token
            // returned by C_GetSlotList(true), NOT the PKCS#11 slot ID (which need not be
            // contiguous or zero-based). Configure it as a position, not a hardware slot id.
            const slots = this.pkcs11.C_GetSlotList(true);
            if (this.config.slot >= slots.length) {
                throw new errors_1.HsmError(`HSM slot index ${this.config.slot} not found. ${slots.length} slot(s) with a token present (valid indices 0..${slots.length - 1}).`, 503, error_codes_1.ERROR_CODES.HSM_UNAVAILABLE);
            }
            this.session = this.pkcs11.C_OpenSession(slots[this.config.slot], pkcs11js.CKF_SERIAL_SESSION | pkcs11js.CKF_RW_SESSION);
            logger.debug({ slot: this.config.slot }, 'PKCS#11 session opened');
            // 3. Login with PIN
            try {
                this.pkcs11.C_Login(this.session, pkcs11js.CKU_USER, this.config.pin);
            }
            finally {
                // Zero the PIN everywhere it could residue after login (crash-dump /
                // heap-inspection hardening), regardless of login outcome:
                //  - this.config (shared reference with the server-side hsmConfigInstance
                //    singleton) — mutate IN PLACE, not reassign, so the singleton clears too
                //  - the HSM_PIN environment variable
                //  - the CAP config (cds.env.requires['odatano-core'].hsm.pin)
                this.config.pin = '';
                if (process.env.HSM_PIN)
                    delete process.env.HSM_PIN;
                try {
                    const hsmCds = cds_1.default.env?.requires?.['odatano-core']?.hsm;
                    if (hsmCds && 'pin' in hsmCds)
                        hsmCds.pin = '';
                }
                catch { /* best effort */ }
            }
            logger.debug('PKCS#11 login successful');
            // 4. Find private key by label or ID
            this.privateKeyHandle = this._findKey(pkcs11js, pkcs11js.CKO_PRIVATE_KEY);
            // 5. Export public key
            this.publicKeyBytes = this._exportPublicKey(pkcs11js);
            logger.debug({ publicKeyLength: this.publicKeyBytes.length }, 'Ed25519 public key exported');
            // 6. Derive Cardano key hash and enterprise address
            const blake2b = require('blake2b');
            const hashOut = Buffer.alloc(28);
            blake2b(28).update(this.publicKeyBytes).digest(hashOut);
            this.publicKeyHashHex = hashOut.toString('hex');
            // Enterprise key-hash address: header 0x61 (mainnet) or 0x60 (testnet)
            const { bech32 } = require('bech32');
            const headerByte = network === 'mainnet' ? 0x61 : 0x60;
            const payload = Buffer.alloc(29);
            payload[0] = headerByte;
            hashOut.copy(payload, 1);
            const words = bech32.toWords(payload);
            const hrp = network === 'mainnet' ? 'addr' : 'addr_test';
            this.cardanoAddress = bech32.encode(hrp, words, 120);
            this.connected = true;
            logger.info({
                keyLabel: this.config.keyLabel,
                keyId: this.config.keyId,
                publicKeyHash: this.publicKeyHashHex,
                address: this.cardanoAddress,
            }, 'HSM signer initialized successfully');
        }
        catch (err) {
            this.connected = false;
            if (err instanceof errors_1.HsmError)
                throw err;
            const msg = err instanceof Error ? err.message : String(err);
            throw new errors_1.HsmError(`Failed to initialize HSM: ${msg}`, 503, error_codes_1.ERROR_CODES.HSM_UNAVAILABLE, err);
        }
    }
    /**
     * Sign a 32-byte transaction body hash using the HSM.
     * Returns the Ed25519 signature + public key for witness construction.
     *
     * @param txBodyHash - 32-byte hash of the transaction body
     * @returns HsmSignResult with signature, public key, and key hash
     */
    sign(txBodyHash) {
        if (!this.connected) {
            throw new errors_1.HsmError('HSM not connected', 503, error_codes_1.ERROR_CODES.HSM_UNAVAILABLE);
        }
        try {
            // CKM_EDDSA = Ed25519 signing mechanism
            this.pkcs11.C_SignInit(this.session, { mechanism: CKM_EDDSA }, this.privateKeyHandle);
            const signature = this.pkcs11.C_Sign(this.session, txBodyHash, Buffer.alloc(64));
            return {
                signatureHex: Buffer.from(signature).toString('hex'),
                publicKeyHex: this.publicKeyBytes.toString('hex'),
                publicKeyHash: this.publicKeyHashHex,
            };
        }
        catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            throw new errors_1.HsmError(`HSM signing failed: ${msg}`, 500, error_codes_1.ERROR_CODES.HSM_SIGNING_FAILED, err);
        }
    }
    /**
     * Sign a transaction and produce a complete signed transaction CBOR.
     *
     * Takes the unsigned transaction CBOR, signs the body hash via HSM,
     * builds a VKey witness [publicKey, signature], and merges it into
     * the transaction's witness set using raw CBOR manipulation.
     *
     * @param unsignedTxCbor - Unsigned transaction CBOR (hex)
     * @param txBodyHash - Transaction body hash (hex, 64 chars)
     * @returns Signed transaction CBOR (hex)
     */
    signTransaction(unsignedTxCbor, txBodyHash) {
        const hashBytes = Buffer.from(txBodyHash, 'hex');
        const result = this.sign(hashBytes);
        try {
            // Parse unsigned transaction at raw CBOR level
            const txObj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(unsignedTxCbor));
            if (!(txObj instanceof cbor_1.CborArray) || txObj.array.length < 2) {
                throw new errors_1.HsmError('Invalid transaction CBOR structure', 400, error_codes_1.ERROR_CODES.HSM_SIGNING_FAILED);
            }
            // Build VKey witness: [publicKey (32 bytes), signature (64 bytes)]
            const vkeyWitness = new cbor_1.CborArray([
                new cbor_1.CborBytes(Buffer.from(result.publicKeyHex, 'hex')),
                new cbor_1.CborBytes(Buffer.from(result.signatureHex, 'hex')),
            ]);
            // Merge into witness set (txObj.array[1])
            // Single-signer design: HSM is the sole signer for unsigned transactions.
            // Multi-sig (e.g. wallet + HSM) uses combineTransactionWithWitnesses() instead.
            const origWs = txObj.array[1];
            if (origWs instanceof cbor_1.CborMap) {
                // Replace VKey witnesses (key 0) with HSM witness only
                // Preserves all other entries (redeemers key 5, datums key 4, scripts keys 1-3, 6-7)
                const entries = origWs.map.filter((e) => !(e.k instanceof cbor_1.CborUInt && Number(e.k.num) === 0));
                entries.push({
                    k: new cbor_1.CborUInt(0),
                    v: new cbor_1.CborArray([vkeyWitness]),
                });
                txObj.array[1] = new cbor_1.CborMap(entries, { indefinite: origWs.indefinite });
            }
            else {
                throw new errors_1.HsmError('Witness set must be CBOR map', 400, error_codes_1.ERROR_CODES.HSM_SIGNING_FAILED);
            }
            // Re-encode preserving encoding metadata
            const signedTxCbor = (0, uint8array_utils_1.toHex)(cbor_1.Cbor.encode(new cbor_1.CborArray(txObj.array, { indefinite: txObj.indefinite })));
            logger.info({
                txBodyHash,
                publicKeyHash: result.publicKeyHash,
                signedTxLength: signedTxCbor.length,
            }, 'Transaction signed with HSM');
            return signedTxCbor;
        }
        catch (err) {
            if (err instanceof errors_1.HsmError)
                throw err;
            const msg = err instanceof Error ? err.message : String(err);
            throw new errors_1.HsmError(`Failed to build signed transaction: ${msg}`, 500, error_codes_1.ERROR_CODES.HSM_SIGNING_FAILED, err);
        }
    }
    /** Get the HSM-derived Cardano enterprise address */
    getAddress() {
        return this.cardanoAddress;
    }
    /** Get the public key hash (for requiredSigners) */
    getPublicKeyHash() {
        return this.publicKeyHashHex;
    }
    /** Check connection status */
    isConnected() {
        return this.connected;
    }
    /** Get status for monitoring */
    getStatus() {
        return {
            connected: this.connected,
            keyId: this.config.keyId,
            keyLabel: this.config.keyLabel,
            publicKeyHash: this.connected ? this.publicKeyHashHex : undefined,
            address: this.connected ? this.cardanoAddress : undefined,
        };
    }
    /** Graceful shutdown — close PKCS#11 session */
    shutdown() {
        if (this.session) {
            try {
                this.pkcs11.C_Logout(this.session);
                this.pkcs11.C_CloseSession(this.session);
                this.pkcs11.C_Finalize();
                logger.info('HSM session closed');
            }
            catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                logger.warn({ error: msg }, 'HSM shutdown error (best effort)');
            }
            this.connected = false;
        }
    }
    // ---------------------------------------------------------------------------
    // Private helpers
    // ---------------------------------------------------------------------------
    /**
     * Find a key object (private or public) in the HSM by label and/or ID
     */
    _findKey(pkcs11js, objectClass) {
        const template = [
            { type: pkcs11js.CKA_CLASS, value: objectClass },
        ];
        // CKK_EC_EDWARDS (0x40) — PKCS#11 v3.0, may not be defined in older pkcs11js versions
        const CKK_EC_EDWARDS = pkcs11js.CKK_EC_EDWARDS ?? 0x00000040;
        template.push({ type: pkcs11js.CKA_KEY_TYPE, value: CKK_EC_EDWARDS });
        if (this.config.keyLabel) {
            template.push({ type: pkcs11js.CKA_LABEL, value: this.config.keyLabel });
        }
        if (this.config.keyId) {
            const idHex = this.config.keyId.replace('0x', '');
            template.push({ type: pkcs11js.CKA_ID, value: Buffer.from(idHex, 'hex') });
        }
        this.pkcs11.C_FindObjectsInit(this.session, template);
        const handles = this.pkcs11.C_FindObjects(this.session, 1);
        this.pkcs11.C_FindObjectsFinal(this.session);
        if (handles.length === 0) {
            throw new errors_1.HsmError(`Ed25519 key not found in HSM (class: ${objectClass}, label: ${this.config.keyLabel}, id: ${this.config.keyId})`, 500, error_codes_1.ERROR_CODES.HSM_SIGNING_FAILED);
        }
        return handles[0];
    }
    /**
     * Export the Ed25519 public key from the HSM.
     * Handles both DER-wrapped (04 20 <32 bytes>) and raw 32-byte formats.
     */
    _exportPublicKey(pkcs11js) {
        const pubKeyHandle = this._findKey(pkcs11js, pkcs11js.CKO_PUBLIC_KEY);
        // Extract CKA_EC_POINT (DER-encoded public key)
        const attrs = this.pkcs11.C_GetAttributeValue(this.session, pubKeyHandle, [
            { type: pkcs11js.CKA_EC_POINT },
        ]);
        // CKA_EC_POINT for Ed25519 is DER OCTET STRING wrapping 32-byte public key
        // Format: 04 20 <32 bytes>
        const ecPoint = Buffer.from(attrs[0].value);
        if (ecPoint.length === 34 && ecPoint[0] === 0x04 && ecPoint[1] === 0x20) {
            return ecPoint.slice(2);
        }
        // Some HSMs return raw 32 bytes
        if (ecPoint.length === 32) {
            return ecPoint;
        }
        throw new errors_1.HsmError(`Unexpected Ed25519 public key format from HSM (length: ${ecPoint.length})`, 500, error_codes_1.ERROR_CODES.HSM_SIGNING_FAILED);
    }
}
exports.HsmSigner = HsmSigner;
// ---------------------------------------------------------------------------
// Singleton pattern (same as getExternalSignerModule())
// ---------------------------------------------------------------------------
let hsmSignerInstance = null;
/**
 * Get the initialized HsmSigner instance.
 * Returns null if HSM is not configured.
 */
function getHsmSigner() {
    return hsmSignerInstance;
}
/**
 * Set the HsmSigner instance (called during initialization and shutdown).
 */
function setHsmSigner(signer) {
    hsmSignerInstance = signer;
}
//# sourceMappingURL=hsm-signer.js.map