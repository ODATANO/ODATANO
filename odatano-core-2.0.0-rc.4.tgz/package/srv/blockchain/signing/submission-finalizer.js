"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.submitAndFinalize = submitAndFinalize;
exports.scheduleDeferredSubmit = scheduleDeferredSubmit;
exports.redriveInterruptedSubmissions = redriveInterruptedSubmissions;
const cds_1 = __importDefault(require("@sap/cds"));
const errors_1 = require("../../utils/errors");
const tx_utils_1 = require("../../utils/tx-utils");
const tx_build_helper_1 = require("../../utils/tx-build-helper");
const external_signer_1 = require("./external-signer");
const { SELECT, UPDATE } = cds_1.default.ql;
const logger = cds_1.default.log('SubmissionFinalizer');
// Lazy require breaks the srv/server.ts <-> this-module import cycle (the
// server calls redriveInterruptedSubmissions at boot; we need its app-context
// getters at runtime only). Same pattern as src/plugin.ts.
function server() {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    return require('../../server');
}
/**
 * Submit a verified+claimed signing request to the blockchain and persist the
 * outcome — DELIBERATELY outside the caller's request transaction.
 *
 * The caller must already have durably committed `status:'submitting'` (the
 * claim). This function then:
 *   1. submits with NO DB write-lock held (the lock was the reason concurrent
 *      submits serialized and the SQLite busy-timeout could fire mid-network),
 *   2. on submit failure: marks the request 'failed' in its own committed tx
 *      and rethrows (NOT rolled back to a pre-submit status — losing the
 *      attempt would hide a tx the node may have accepted),
 *   3. on success: persists the submission + 'submitted' status in a committed
 *      transaction.
 *
 * Crash window: a process death between (1) and (3) leaves the request durably
 * at 'submitting'. Deferred-path requests carry their signed CBOR on the row
 * and are re-driven at the next boot (redriveInterruptedSubmissions); sync-path
 * requests are left for the operator/poller exactly as before.
 */
async function submitAndFinalize(SigningRequests, params, afterFinalize) {
    // Persist the submission + 'submitted' status in its own committed transaction.
    const finalizeSubmitted = () => (0, tx_utils_1.detachedTx)('finalize transaction submission', async (db) => {
        const submission = await server().getCardanoIndexer().indexVerifiedTransactionSubmission(db, params);
        if (afterFinalize)
            await afterFinalize(db);
        // Invalidate stale UTxO cache (spent inputs + output addresses) — best-effort,
        // must never roll back the durable submission record.
        try {
            await server().getCardanoIndexer().invalidateUtxoCacheForTx(db, (0, tx_build_helper_1.extractTxCacheTargets)(params.fullSignedTxCbor));
        }
        catch (invalidateErr) {
            logger.warn(`UTxO cache invalidation failed (submit unaffected): ${invalidateErr instanceof Error ? invalidateErr.message : String(invalidateErr)}`);
        }
        return submission;
    });
    try {
        await server().getCardanoClient().submitTransaction(params.fullSignedTxCbor);
    }
    catch (submitErr) {
        // Already-submitted means the tx reached the mempool — e.g. the first backend accepted
        // it but its response was lost and a fallback observed the duplicate. That is SUCCESS,
        // not failure: finalize it as 'submitted' (same as the happy path) instead of durably
        // recording a spurious 'failed' for a tx the node already holds.
        if (submitErr instanceof errors_1.TransactionAlreadySubmittedError) {
            logger.info({ signingRequestId: params.signingRequestId, txHash: params.txHash }, 'Submit reported already-submitted — finalizing as submitted (tx already in mempool)');
            return finalizeSubmitted();
        }
        try {
            await (0, tx_utils_1.detachedTx)('mark signing request failed', (db) => db.run(UPDATE.entity(SigningRequests).set({ status: 'failed' }).where({ id: params.signingRequestId })));
        }
        catch (markErr) {
            logger.error({ err: markErr, signingRequestId: params.signingRequestId }, 'Could not durably mark signing request failed after submit error');
        }
        throw submitErr;
    }
    return finalizeSubmitted();
}
/**
 * Deferred-submit scheduler (KNOWN_ISSUES #11, Layer 2).
 *
 * Called by an action handler AFTER verify + claim ran on the CALLER's
 * transaction. Hooks the request's post-commit event: only once the caller's
 * root transaction has committed (claim durable, pooled connection released)
 * does the network submit + finalize run — detached via setImmediate +
 * runWithoutAmbientTx, so no ambient transaction is held across it.
 *
 * If the caller's transaction rolls back instead, 'succeeded' never fires and
 * nothing was claimed — strictly consistent.
 */
function scheduleDeferredSubmit(req, SigningRequests, params) {
    req.on('succeeded', () => {
        setImmediate(() => {
            (0, tx_utils_1.runWithoutAmbientTx)(() => submitAndFinalize(SigningRequests, params))
                .then(() => {
                logger.info({ signingRequestId: params.signingRequestId, txHash: params.txHash }, 'Deferred submit finalized');
            })
                .catch((err) => {
                // submitAndFinalize already durably marked the request 'failed'.
                logger.error({ err, signingRequestId: params.signingRequestId }, 'Deferred submit failed (signing request marked failed)');
            });
        });
    });
}
/**
 * Boot-time recovery: re-drive submissions that were claimed on the deferred
 * path (status 'submitting' WITH persisted signedTxCbor) but never finalized —
 * i.e. the process died between the caller's commit and the detached submit.
 *
 * Safe to repeat: a tx the node already holds finalizes as 'submitted' via the
 * TransactionAlreadySubmittedError path in submitAndFinalize. Rows at
 * 'submitting' WITHOUT signed CBOR (sync-path crash window) are deliberately
 * left untouched for the operator/poller, exactly as before Layer 2.
 *
 * @returns number of rows re-driven (attempted, not necessarily succeeded)
 */
async function redriveInterruptedSubmissions() {
    const SigningRequests = 'odatano.cardano.SigningRequests';
    const rows = await (0, tx_utils_1.detachedTx)('load interrupted deferred submissions', (db) => db.run(SELECT.from(SigningRequests)
        .where({ status: 'submitting' })
        .and('signedTxCbor is not null')));
    if (!rows.length)
        return 0;
    logger.info(`Re-driving ${rows.length} interrupted deferred submission(s)`);
    let attempted = 0;
    for (const row of rows) {
        try {
            // Re-verify from the persisted CBOR (deterministic — it passed at claim
            // time; this recomputes the witness metadata the finalize step persists).
            const verificationResult = (0, external_signer_1.getExternalSignerModule)().verifyOrThrow(row.signedTxCbor, row.txBodyHash);
            attempted++;
            await submitAndFinalize(SigningRequests, {
                signingRequestId: row.id,
                buildId: row.build_id ?? '',
                fullSignedTxCbor: row.signedTxCbor,
                txHash: row.txBodyHash,
                verificationResult,
                signerType: row.signerType ?? undefined,
                signerInfo: row.signerInfo ?? undefined,
            });
            logger.info({ signingRequestId: row.id, txHash: row.txBodyHash }, 'Interrupted submission re-driven');
        }
        catch (err) {
            // submitAndFinalize marked the row 'failed' on submit errors; verification
            // errors leave it at 'submitting' for manual inspection (should not happen
            // for CBOR that verified once).
            logger.error({ err, signingRequestId: row.id }, 'Re-drive of interrupted submission failed');
        }
    }
    return attempted;
}
//# sourceMappingURL=submission-finalizer.js.map