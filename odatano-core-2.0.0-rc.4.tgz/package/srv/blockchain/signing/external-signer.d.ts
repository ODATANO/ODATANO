import { SignatureVerifier } from './signature-verifier';
import { ExternalSignerType, UnsignedTxExportPayload, SignedTxPayload, SigningWorkflowState, SignatureVerificationResult, VerificationOptions } from '../../utils/types';
/**
 * ExternalSignerModule - Manages the external signing workflow
 *
 * This module orchestrates the complete flow:
 * 1. Create signing request from build result
 * 2. Export unsigned transaction for external signing
 * 3. Receive and verify signed transaction
 * 4. Prepare for submission
 *
 * Key security principles:
 * - NO private keys are ever handled by this service
 * - Signature verification ensures transaction integrity
 * - Complete audit trail of the signing workflow
 */
export declare class ExternalSignerModule {
    private verifier;
    private signingTtlMs;
    constructor(options?: {
        signingTtlMs?: number;
    });
    /**
     * Create an unsigned transaction export payload for external signing
     *
     * This is the entry point for the external signing workflow.
     * Call this after building a transaction to get a standardized
     * payload that external signers can use.
     *
     * @param buildId - The build ID from TransactionBuilds
     * @param unsignedTxCbor - The unsigned transaction CBOR
     * @param txBodyHash - The transaction body hash
     * @param network - The Cardano network
     * @param options - Additional options
     * @returns Unsigned transaction export payload
     */
    createSigningRequest(buildId: string, unsignedTxCbor: string, txBodyHash: string, network: string, message: string, options?: {
        requiredSigners?: string[];
        signerTypeHint?: ExternalSignerType;
    }): UnsignedTxExportPayload;
    /**
     * Generate signing instructions for different signer types
     */
    private generateSigningInstructions;
    /**
     * Verify a signed transaction
     *
     * Call this after receiving a signed transaction from an external signer.
     * This verifies the signature integrity before submission.
     *
     * @param signedTxCbor - The signed transaction CBOR
     * @param expectedTxBodyHash - The expected transaction body hash (from the build)
     * @param options - Additional verification options
     * @returns Verification result
     */
    verifySignedTransaction(signedTxCbor: string, expectedTxBodyHash: string, options?: Omit<VerificationOptions, 'expectedTxBodyHash'> & {
        expiresAt?: string;
    }): SignatureVerificationResult;
    /**
     * Verify signed transaction and throw on failure
     *
     * @param signedTxCbor - The signed transaction CBOR
     * @param expectedTxBodyHash - The expected transaction body hash
     * @param options - Additional verification options
     * @throws {TransactionValidationError} if verification fails
     */
    verifyOrThrow(signedTxCbor: string, expectedTxBodyHash: string, options?: Omit<VerificationOptions, 'expectedTxBodyHash'>): SignatureVerificationResult;
    /**
     * Create a complete signing workflow state
     *
     * This creates a trackable workflow state that can be stored
     * and updated throughout the signing process.
     *
     * @param signingRequest - The unsigned transaction export payload
     * @returns Initial workflow state
     */
    createWorkflowState(signingRequest: UnsignedTxExportPayload): SigningWorkflowState;
    /**
     * Update workflow state after signing
     *
     * @param state - Current workflow state
     * @param signedTxCbor - The signed transaction CBOR
     * @returns Updated workflow state
     */
    markAsSigned(state: SigningWorkflowState, signedTxCbor: string): SigningWorkflowState;
    /**
     * Update workflow state after verification
     *
     * @param state - Current workflow state
     * @param verificationResult - The verification result
     * @returns Updated workflow state
     */
    markAsVerified(state: SigningWorkflowState, verificationResult: SignatureVerificationResult): SigningWorkflowState;
    /**
     * Update workflow state after submission
     *
     * @param state - Current workflow state
     * @param txHash - The submitted transaction hash
     * @returns Updated workflow state
     */
    markAsSubmitted(state: SigningWorkflowState, txHash: string): SigningWorkflowState;
    /**
     * Update workflow state on failure
     *
     * @param state - Current workflow state
     * @param errorMessage - The error message
     * @returns Updated workflow state
     */
    markAsFailed(state: SigningWorkflowState, errorMessage: string): SigningWorkflowState;
    /**
     * Check if a signing request has expired
     *
     * @param expiresAt - The expiration timestamp (ISO 8601)
     * @returns true if expired
     */
    isExpired(expiresAt: string): boolean;
    /**
     * Validate a signed transaction payload before submission
     *
     * This performs all pre-submission checks:
     * 1. Verify the signature
     * 2. Check transaction hasn't been tampered with
     * 3. Ensure the build ID matches
     *
     * @param payload - The signed transaction payload
     * @param originalBuildTxBodyHash - The original transaction body hash from the build
     * @returns Validation result with verification details
     * @throws {TransactionValidationError} if validation fails
     */
    validateForSubmission(payload: SignedTxPayload, originalBuildTxBodyHash: string): SignatureVerificationResult;
    /**
     * Get the signature verifier instance
     */
    getVerifier(): SignatureVerifier;
}
/**
 * Get the singleton ExternalSignerModule instance
 */
export declare function getExternalSignerModule(): ExternalSignerModule;
/**
 * Create a new ExternalSignerModule instance with custom options
 */
export declare function createExternalSignerModule(options?: {
    signingTtlMs?: number;
}): ExternalSignerModule;
//# sourceMappingURL=external-signer.d.ts.map