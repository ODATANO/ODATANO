"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignatureVerifier = void 0;
exports.getSignatureVerifier = getSignatureVerifier;
const cds_1 = __importDefault(require("@sap/cds"));
const cbor_1 = require("@harmoniclabs/cbor");
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const crypto_1 = require("@harmoniclabs/crypto");
const errors_1 = require("../../utils/errors");
const error_codes_1 = require("../../utils/error-codes");
const logger = cds_1.default.log('SignatureVerifier');
/**
 * blake2b-256 over the ORIGINAL transaction-body bytes (CBOR array index 0).
 * subCborRef preserves the exact received bytes, so the hash matches what was signed
 * and re-serialization can never drift it. (Historically this also sidestepped the
 * ledger-ts AuxiliaryData.fromCbor bug on metadata-only aux_data — fixed in 0.5.6 —
 * but byte-exactness remains the reason to stay at the raw-CBOR level.)
 */
function computeBodyHash(txBytes) {
    const tx = cbor_1.Cbor.parse(txBytes);
    if (!(tx instanceof cbor_1.CborArray) || tx.array.length < 1 || !tx.array[0].subCborRef) {
        throw new Error('Invalid transaction CBOR: missing body');
    }
    return (0, uint8array_utils_1.toHex)((0, crypto_1.blake2b_256)(tx.array[0].subCborRef.toBuffer()));
}
/**
 * Extract vkey witnesses (raw public key + signature bytes) from a transaction's
 * witness set (CBOR array index 1, map key 0). Conway wraps the witness array in CBOR
 * tag 258 (set) — unwrapped here. Returns [] when the tx has no vkey witnesses.
 */
function extractVkeyWitnesses(txBytes) {
    const tx = cbor_1.Cbor.parse(txBytes);
    if (!(tx instanceof cbor_1.CborArray) || !(tx.array[1] instanceof cbor_1.CborMap))
        return [];
    const entry = tx.array[1].map.find(e => e.k instanceof cbor_1.CborUInt && Number(e.k.num) === 0);
    if (!entry)
        return [];
    let arr = entry.v;
    if (arr instanceof cbor_1.CborTag)
        arr = arr.data;
    if (!(arr instanceof cbor_1.CborArray))
        return [];
    // Parse defensively: a malformed witness entry (wrong shape or non-bytes members)
    // would otherwise throw a TypeError and surface as an opaque internal error. Skip
    // any entry that isn't a [vkey, signature] pair of byte strings.
    const witnesses = [];
    let skipped = 0;
    for (const pair of arr.array) {
        if (!(pair instanceof cbor_1.CborArray) || pair.array.length !== 2) {
            skipped++;
            continue;
        }
        const [vk, sg] = pair.array;
        if (!(vk instanceof cbor_1.CborBytes) || !(sg instanceof cbor_1.CborBytes)) {
            skipped++;
            continue;
        }
        witnesses.push({ pubKey: vk.bytes, signature: sg.bytes });
    }
    if (skipped > 0) {
        // not fatal, but a malformed witness in a signed tx is suspicious — surface it
        logger.warn(`Skipped ${skipped} malformed vkey witness entr${skipped === 1 ? 'y' : 'ies'} while verifying (expected [vkey, signature] byte pairs)`);
    }
    return witnesses;
}
/**
 * SignatureVerifier - Verifies transaction signatures without accessing private keys
 *
 * This module provides signature verification for externally signed transactions.
 * It ensures:
 * 1. The signed CBOR is valid and parseable
 * 2. The transaction body hash matches the expected hash (integrity check)
 * 3. Required signatures are present (when specified)
 * 4. No tampering occurred between build and sign steps
 */
class SignatureVerifier {
    /**
     * Verify a signed transaction
     *
     * @param signedTxCbor - The signed transaction in CBOR hex format
     * @param options - Verification options
     * @returns Verification result with details
     */
    verify(signedTxCbor, options = {}) {
        const result = {
            isValid: false,
            txBodyHash: '',
            witnessCount: 0,
            signerKeyHashes: [],
            warnings: [],
        };
        try {
            // Compute the body hash over the original CBOR body bytes (no re-serialization),
            // matching exactly what was signed.
            const txBytes = (0, uint8array_utils_1.fromHex)(signedTxCbor);
            const computedHash = computeBodyHash(txBytes);
            result.txBodyHash = computedHash;
            logger.debug(`Computed transaction body hash: ${computedHash}`);
            // verify transaction body hash matches expected
            if (options.expectedTxBodyHash) {
                if (computedHash.toLowerCase() !== options.expectedTxBodyHash.toLowerCase()) {
                    result.errorMessage = `Transaction body hash mismatch. Expected: ${options.expectedTxBodyHash}, Got: ${computedHash}. The transaction may have been tampered with.`;
                    logger.warn(result.errorMessage);
                    return result;
                }
                logger.debug('Transaction body hash verified successfully');
            }
            // Extract vkey witnesses (raw pubkey + signature bytes)
            const vkeyWitnesses = extractVkeyWitnesses(txBytes);
            result.witnessCount = vkeyWitnesses.length;
            if (vkeyWitnesses.length > 0) {
                // signer key hash = blake2b-224 of the Ed25519 public key
                for (const w of vkeyWitnesses) {
                    result.signerKeyHashes.push((0, uint8array_utils_1.toHex)((0, crypto_1.blake2b_224)(w.pubKey)));
                }
                logger.debug(`Found ${result.witnessCount} witness(es): ${result.signerKeyHashes.join(', ')}`);
            }
            // check if signature is required but missing
            if (options.requireSignature !== false && result.witnessCount === 0) {
                result.errorMessage = 'No signatures found in transaction. The transaction must be signed before submission.';
                logger.warn(result.errorMessage);
                return result;
            }
            // verify required signers (if specified)
            if (options.requiredSigners && options.requiredSigners.length > 0) {
                const missingSigners = options.requiredSigners.filter(required => !result.signerKeyHashes.some(signer => signer.toLowerCase() === required.toLowerCase()));
                if (missingSigners.length > 0) {
                    result.errorMessage = `Missing required signatures from: ${missingSigners.join(', ')}`;
                    result.warnings.push(result.errorMessage);
                    logger.warn(result.errorMessage);
                    return result;
                }
            }
            // verify each signature cryptographically against the transaction body hash
            if (vkeyWitnesses.length > 0) {
                const bodyHashBytes = (0, uint8array_utils_1.fromHex)(computedHash);
                for (let i = 0; i < vkeyWitnesses.length; i++) {
                    const { pubKey, signature } = vkeyWitnesses[i];
                    const isValidSig = (0, crypto_1.verifyEd25519Signature_sync)(signature, bodyHashBytes, pubKey);
                    if (!isValidSig) {
                        result.errorMessage = `Invalid signature at witness index ${i}. The signature does not match the transaction body.`;
                        logger.warn(result.errorMessage);
                        return result;
                    }
                }
                logger.debug('All signatures verified cryptographically');
            }
            // All checks passed
            result.isValid = true;
            logger.info(`Signature verification successful. ${result.witnessCount} valid signature(s).`);
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            result.errorMessage = `Failed to verify signature: ${msg}`;
            logger.error(result.errorMessage);
        }
        return result;
    }
    /**
     * Verify signature and throw on failure
     *
     * @param signedTxCbor - The signed transaction in CBOR hex format
     * @param options - Verification options
     * @throws {TransactionValidationError} if verification fails
     */
    verifyOrThrow(signedTxCbor, options = {}) {
        const result = this.verify(signedTxCbor, options);
        if (!result.isValid) {
            throw new errors_1.TransactionValidationError(result.errorMessage || 'Signature verification failed', new Error(result.errorMessage));
        }
        return result;
    }
    /**
     * Extract transaction body hash from unsigned or signed CBOR
     *
     * @param txCbor - Transaction CBOR (signed or unsigned)
     * @returns Transaction body hash as hex string
     * @throws {Error} if CBOR is invalid
     */
    extractTxBodyHash(txCbor) {
        try {
            return computeBodyHash((0, uint8array_utils_1.fromHex)(txCbor));
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            throw new errors_1.BackendError(`Failed to extract transaction body hash: ${msg}`, 400, error_codes_1.ERROR_CODES.INVALID_INPUT);
        }
    }
    /**
     * Check if a transaction is signed (has witnesses)
     *
     * @param txCbor - Transaction CBOR
     * @returns true if transaction has at least one witness
     */
    isSigned(txCbor) {
        try {
            return extractVkeyWitnesses((0, uint8array_utils_1.fromHex)(txCbor)).length > 0;
        }
        catch {
            return false;
        }
    }
    /**
     * Get witness count from transaction
     *
     * @param txCbor - Transaction CBOR
     * @returns Number of witnesses
     */
    getWitnessCount(txCbor) {
        try {
            return extractVkeyWitnesses((0, uint8array_utils_1.fromHex)(txCbor)).length;
        }
        catch {
            return 0;
        }
    }
}
exports.SignatureVerifier = SignatureVerifier;
// Singleton instance
let verifierInstance = null;
/**
 * Get the singleton SignatureVerifier instance
 */
function getSignatureVerifier() {
    if (!verifierInstance) {
        verifierInstance = new SignatureVerifier();
    }
    return verifierInstance;
}
//# sourceMappingURL=signature-verifier.js.map