"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyDataSignature = verifyDataSignature;
const cds_1 = __importDefault(require("@sap/cds"));
const cbor_1 = require("@harmoniclabs/cbor");
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const crypto_1 = require("@harmoniclabs/crypto");
const validators_1 = require("../../utils/validators");
const logger = cds_1.default.log('CoseVerifier');
/** CBOR tag 18 = COSE_Sign1 (RFC 8152). signData may or may not wrap in it. */
const COSE_SIGN1_TAG = 18;
/** COSE_Key label for the OKP public key x-coordinate (the raw Ed25519 key). */
const COSE_KEY_LABEL_X = -2;
const ED25519_PUBKEY_LEN = 32;
/** Find a COSE map entry by its integer label (handles +ve and -ve labels). */
function findIntLabel(map, label) {
    const entry = map.map.find(e => {
        if (e.k instanceof cbor_1.CborUInt)
            return Number(e.k.num) === label;
        if (e.k instanceof cbor_1.CborNegInt)
            return Number(e.k.num) === label;
        return false;
    });
    return entry?.v;
}
function parseCoseSign1(hex) {
    let obj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(hex));
    // CIP-30 signData may emit the COSE_Sign1 wrapped in tag 18 or bare.
    if (obj instanceof cbor_1.CborTag && Number(obj.tag) === COSE_SIGN1_TAG)
        obj = obj.data;
    if (!(obj instanceof cbor_1.CborArray) || obj.array.length !== 4) {
        throw new Error('COSE_Sign1 must be a 4-element array [protected, unprotected, payload, signature]');
    }
    const [prot, , payload, signature] = obj.array;
    if (!(prot instanceof cbor_1.CborBytes))
        throw new Error('COSE_Sign1 protected header must be a byte string');
    if (!(payload instanceof cbor_1.CborBytes))
        throw new Error('COSE_Sign1 payload must be a byte string (detached payloads are not supported)');
    if (!(signature instanceof cbor_1.CborBytes))
        throw new Error('COSE_Sign1 signature must be a byte string');
    return { protectedBytes: prot.bytes, payload: payload.bytes, signature: signature.bytes };
}
/** Extract the raw 32-byte Ed25519 public key from a COSE_Key (label -2). */
function parseCoseKey(hex) {
    const obj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(hex));
    if (!(obj instanceof cbor_1.CborMap))
        throw new Error('COSE_Key must be a CBOR map');
    const x = findIntLabel(obj, COSE_KEY_LABEL_X);
    if (!(x instanceof cbor_1.CborBytes))
        throw new Error('COSE_Key is missing the Ed25519 public key (label -2)');
    if (x.bytes.length !== ED25519_PUBKEY_LEN) {
        throw new Error(`COSE_Key public key must be ${ED25519_PUBKEY_LEN} bytes, got ${x.bytes.length}`);
    }
    return x.bytes;
}
/**
 * Build the COSE Sig_structure that was actually signed and CBOR-encode it:
 *   [ "Signature1" (tstr), protected (bstr, exact bytes), external_aad (h''), payload (bstr) ]
 * external_aad is empty for CIP-8 / CIP-30 signData.
 */
function buildSigStructure(protectedBytes, payload) {
    const sigStruct = new cbor_1.CborArray([
        new cbor_1.CborText('Signature1'),
        new cbor_1.CborBytes(protectedBytes),
        new cbor_1.CborBytes(new Uint8Array(0)),
        new cbor_1.CborBytes(payload),
    ]);
    return cbor_1.Cbor.encode(sigStruct);
}
/**
 * Verify a CIP-30 `signData` (COSE_Sign1) message signature against a bech32
 * address. Stateless crypto only & no nonce/replay/session handling.
 * Never throws: all failures are returned as `{ valid: false, reason }`.
 *
 * Checks, in order:
 *   1. COSE_Sign1 + COSE_Key parse
 *   2. signer key hash (blake2b-224) == the address payment credential (key, not script)
 *   3. (optional) signed payload == expectedPayload
 *   4. Ed25519 signature over the COSE Sig_structure
 */
function verifyDataSignature(input) {
    const result = { valid: false, reason: '', signedPayload: '', signerVkh: '' };
    try {
        const { protectedBytes, payload, signature } = parseCoseSign1(input.coseSignature);
        const pubKey = parseCoseKey(input.coseKey);
        result.signedPayload = Buffer.from(payload).toString('utf8');
        result.signerVkh = (0, uint8array_utils_1.toHex)((0, crypto_1.blake2b_224)(pubKey));
        // 2. signer key hash must equal the address payment credential (key hash, not script)
        const cred = (0, validators_1.extractPaymentCredential)(input.address);
        if (!cred) {
            result.reason = 'Address could not be decoded or has no payment credential (base/enterprise key-hash address required)';
            return result;
        }
        if (cred.isScript) {
            result.reason = 'Address payment credential is a script hash; a key-hash address is required';
            return result;
        }
        if (cred.hash.toLowerCase() !== result.signerVkh.toLowerCase()) {
            result.reason = `Signer key hash ${result.signerVkh} does not match address payment credential ${cred.hash}`;
            return result;
        }
        // 3. optional anti-replay payload check
        if (input.expectedPayload !== undefined && input.expectedPayload !== null) {
            if (result.signedPayload !== input.expectedPayload) {
                result.reason = 'Signed payload does not match the expected payload';
                return result;
            }
        }
        // 4. Ed25519 signature over the rebuilt Sig_structure
        const sigStructure = buildSigStructure(protectedBytes, payload);
        if (!(0, crypto_1.verifyEd25519Signature_sync)(signature, sigStructure, pubKey)) {
            result.reason = 'Ed25519 signature does not verify against the signed message';
            return result;
        }
        result.valid = true;
        logger.debug({ signerVkh: result.signerVkh }, 'COSE_Sign1 data signature verified');
        return result;
    }
    catch (err) {
        result.reason = `Failed to verify data signature: ${err instanceof Error ? err.message : String(err)}`;
        logger.warn(result.reason);
        return result;
    }
}
//# sourceMappingURL=cose-verifier.js.map