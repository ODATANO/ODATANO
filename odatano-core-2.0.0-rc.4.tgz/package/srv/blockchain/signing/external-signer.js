"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExternalSignerModule = void 0;
exports.getExternalSignerModule = getExternalSignerModule;
exports.createExternalSignerModule = createExternalSignerModule;
const cds_1 = __importDefault(require("@sap/cds"));
const signature_verifier_1 = require("./signature-verifier");
const errors_1 = require("../../utils/errors");
const types_1 = require("../../utils/types");
const logger = cds_1.default.log('ExternalSigner');
/**
 * Default TTL for signing requests (30 minutes)
 */
const DEFAULT_SIGNING_TTL_MS = 30 * 60 * 1000;
/** Network flag for cardano-cli (mainnet vs testnet-magic). */
const CLI_NETWORK_FLAG = {
    mainnet: '--mainnet',
    preprod: '--testnet-magic 1',
    preview: '--testnet-magic 2',
};
/**
 * Build a copy-pasteable cardano-cli signing recipe for the unsigned tx.
 * Templated (the caller supplies their own signing key file); the network flag
 * and the unsigned CBOR are filled in. Previously this was always NULL despite
 * the schema exposing a `cardanoCliCommand` field.
 */
function buildCardanoCliCommand(network, unsignedTxCbor) {
    const netFlag = CLI_NETWORK_FLAG[network] ?? '--testnet-magic <MAGIC>';
    return [
        '# 1) Save the unsigned transaction to a file:',
        `echo '{"type":"Unwitnessed Tx ConwayEra","description":"","cborHex":"${unsignedTxCbor}"}' > tx.unsigned`,
        '# 2) Sign it with your payment key:',
        `cardano-cli conway transaction sign --tx-file tx.unsigned --signing-key-file payment.skey ${netFlag} --out-file tx.signed`,
        '# 3) Submit the cborHex from tx.signed via SubmitSignedTransaction / SubmitVerifiedTransaction',
    ].join('\n');
}
/**
 * ExternalSignerModule - Manages the external signing workflow
 *
 * This module orchestrates the complete flow:
 * 1. Create signing request from build result
 * 2. Export unsigned transaction for external signing
 * 3. Receive and verify signed transaction
 * 4. Prepare for submission
 *
 * Key security principles:
 * - NO private keys are ever handled by this service
 * - Signature verification ensures transaction integrity
 * - Complete audit trail of the signing workflow
 */
class ExternalSignerModule {
    verifier;
    signingTtlMs;
    constructor(options) {
        this.verifier = (0, signature_verifier_1.getSignatureVerifier)();
        this.signingTtlMs = options?.signingTtlMs ?? DEFAULT_SIGNING_TTL_MS;
    }
    /**
     * Create an unsigned transaction export payload for external signing
     *
     * This is the entry point for the external signing workflow.
     * Call this after building a transaction to get a standardized
     * payload that external signers can use.
     *
     * @param buildId - The build ID from TransactionBuilds
     * @param unsignedTxCbor - The unsigned transaction CBOR
     * @param txBodyHash - The transaction body hash
     * @param network - The Cardano network
     * @param options - Additional options
     * @returns Unsigned transaction export payload
     */
    createSigningRequest(buildId, unsignedTxCbor, txBodyHash, network, message, options) {
        const signingRequestId = cds_1.default.utils.uuid();
        const now = new Date();
        const expiresAt = new Date(now.getTime() + this.signingTtlMs);
        const signerTypeHint = options?.signerTypeHint ?? types_1.ExternalSignerType.CARDANO_CLI;
        const payload = {
            signingRequestId,
            buildId,
            txBodyHash,
            unsignedTxCbor,
            network,
            createdAt: now.toISOString(),
            expiresAt: expiresAt.toISOString(),
            requiredSigners: options?.requiredSigners,
            signingInstructions: this.generateSigningInstructions(unsignedTxCbor, network, message, signerTypeHint),
        };
        logger.info({
            signingRequestId,
            buildId,
            txBodyHash,
            network,
            expiresAt: expiresAt.toISOString(),
        }, 'Created signing request');
        return payload;
    }
    /**
     * Generate signing instructions for different signer types
     */
    generateSigningInstructions(unsignedTxCbor, network, message, signerTypeHint) {
        return {
            signerTypeHint,
            message: message,
            network,
            cip30SigningRequest: {
                txCbor: unsignedTxCbor,
                partialSign: false,
            },
            cardanoCliCommand: buildCardanoCliCommand(network, unsignedTxCbor),
        };
    }
    /**
     * Verify a signed transaction
     *
     * Call this after receiving a signed transaction from an external signer.
     * This verifies the signature integrity before submission.
     *
     * @param signedTxCbor - The signed transaction CBOR
     * @param expectedTxBodyHash - The expected transaction body hash (from the build)
     * @param options - Additional verification options
     * @returns Verification result
     */
    verifySignedTransaction(signedTxCbor, expectedTxBodyHash, options) {
        logger.debug({ expectedTxBodyHash }, 'Verifying signed transaction');
        // Enforce signing TTL if expiresAt is provided
        if (options?.expiresAt && this.isExpired(options.expiresAt)) {
            return {
                isValid: false,
                txBodyHash: '',
                witnessCount: 0,
                signerKeyHashes: [],
                warnings: [],
                errorMessage: 'Signing request has expired',
            };
        }
        const result = this.verifier.verify(signedTxCbor, {
            ...options,
            expectedTxBodyHash,
            requireSignature: true,
        });
        if (result.isValid) {
            logger.info({
                txBodyHash: result.txBodyHash,
                witnessCount: result.witnessCount,
                signers: result.signerKeyHashes,
            }, 'Signature verification successful');
        }
        else {
            logger.warn({
                error: result.errorMessage,
                warnings: result.warnings,
            }, 'Signature verification failed');
        }
        return result;
    }
    /**
     * Verify signed transaction and throw on failure
     *
     * @param signedTxCbor - The signed transaction CBOR
     * @param expectedTxBodyHash - The expected transaction body hash
     * @param options - Additional verification options
     * @throws {TransactionValidationError} if verification fails
     */
    verifyOrThrow(signedTxCbor, expectedTxBodyHash, options) {
        const result = this.verifySignedTransaction(signedTxCbor, expectedTxBodyHash, options);
        if (!result.isValid) {
            throw new errors_1.TransactionValidationError(result.errorMessage || 'Signature verification failed');
        }
        return result;
    }
    /**
     * Create a complete signing workflow state
     *
     * This creates a trackable workflow state that can be stored
     * and updated throughout the signing process.
     *
     * @param signingRequest - The unsigned transaction export payload
     * @returns Initial workflow state
     */
    createWorkflowState(signingRequest) {
        return {
            status: types_1.SigningStatus.PENDING,
            request: signingRequest,
            timestamps: {
                created: signingRequest.createdAt,
            },
        };
    }
    /**
     * Update workflow state after signing
     *
     * @param state - Current workflow state
     * @param signedTxCbor - The signed transaction CBOR
     * @returns Updated workflow state
     */
    markAsSigned(state, signedTxCbor) {
        return {
            ...state,
            status: types_1.SigningStatus.SIGNED,
            signedTxCbor,
            timestamps: {
                ...state.timestamps,
                signed: new Date().toISOString(),
            },
        };
    }
    /**
     * Update workflow state after verification
     *
     * @param state - Current workflow state
     * @param verificationResult - The verification result
     * @returns Updated workflow state
     */
    markAsVerified(state, verificationResult) {
        if (!verificationResult.isValid) {
            return this.markAsFailed(state, String(verificationResult.errorMessage));
        }
        return {
            ...state,
            status: types_1.SigningStatus.VERIFIED,
            verificationResult,
            timestamps: {
                ...state.timestamps,
                verified: new Date().toISOString(),
            },
        };
    }
    /**
     * Update workflow state after submission
     *
     * @param state - Current workflow state
     * @param txHash - The submitted transaction hash
     * @returns Updated workflow state
     */
    markAsSubmitted(state, txHash) {
        return {
            ...state,
            status: types_1.SigningStatus.SUBMITTED,
            txHash,
            timestamps: {
                ...state.timestamps,
                submitted: new Date().toISOString(),
            },
        };
    }
    /**
     * Update workflow state on failure
     *
     * @param state - Current workflow state
     * @param errorMessage - The error message
     * @returns Updated workflow state
     */
    markAsFailed(state, errorMessage) {
        return {
            ...state,
            status: types_1.SigningStatus.FAILED,
            errorMessage,
            timestamps: {
                ...state.timestamps,
                failed: new Date().toISOString(),
            },
        };
    }
    /**
     * Check if a signing request has expired
     *
     * @param expiresAt - The expiration timestamp (ISO 8601)
     * @returns true if expired
     */
    isExpired(expiresAt) {
        return new Date(expiresAt) < new Date();
    }
    /**
     * Validate a signed transaction payload before submission
     *
     * This performs all pre-submission checks:
     * 1. Verify the signature
     * 2. Check transaction hasn't been tampered with
     * 3. Ensure the build ID matches
     *
     * @param payload - The signed transaction payload
     * @param originalBuildTxBodyHash - The original transaction body hash from the build
     * @returns Validation result with verification details
     * @throws {TransactionValidationError} if validation fails
     */
    validateForSubmission(payload, originalBuildTxBodyHash) {
        // Verify the signature and transaction integrity
        const result = this.verifyOrThrow(payload.signedTxCbor, originalBuildTxBodyHash);
        logger.info({
            signingRequestId: payload.signingRequestId,
            buildId: payload.buildId,
            signerType: payload.signerType,
            witnessCount: result.witnessCount,
        }, 'Transaction validated for submission');
        return result;
    }
    /**
     * Get the signature verifier instance
     */
    getVerifier() {
        return this.verifier;
    }
}
exports.ExternalSignerModule = ExternalSignerModule;
// Singleton instance
let moduleInstance = null;
/**
 * Get the singleton ExternalSignerModule instance
 */
function getExternalSignerModule() {
    if (!moduleInstance) {
        moduleInstance = new ExternalSignerModule();
    }
    return moduleInstance;
}
/**
 * Create a new ExternalSignerModule instance with custom options
 */
function createExternalSignerModule(options) {
    return new ExternalSignerModule(options);
}
//# sourceMappingURL=external-signer.js.map