/**
 * Input to {@link verifyDataSignature}. Mirrors the CIP-30 `signData` result:
 * `coseSignature` is the hex `signature` field (COSE_Sign1), `coseKey` is the
 * hex `key` field (COSE_Key).
 */
export interface CoseVerifyInput {
    address: string;
    coseSignature: string;
    coseKey: string;
    expectedPayload?: string;
}
/** Result of a COSE_Sign1 verification. Shape mirrors the CDS action return. */
export interface CoseVerifyResult {
    valid: boolean;
    /** failure detail when !valid; empty string when valid */
    reason: string;
    /** UTF-8 of the signed payload, echoed back for the caller to inspect */
    signedPayload: string;
    /** hex blake2b-224 of the signer public key (empty until the key is parsed) */
    signerVkh: string;
}
/**
 * Verify a CIP-30 `signData` (COSE_Sign1) message signature against a bech32
 * address. Stateless crypto only & no nonce/replay/session handling.
 * Never throws: all failures are returned as `{ valid: false, reason }`.
 *
 * Checks, in order:
 *   1. COSE_Sign1 + COSE_Key parse
 *   2. signer key hash (blake2b-224) == the address payment credential (key, not script)
 *   3. (optional) signed payload == expectedPayload
 *   4. Ed25519 signature over the COSE Sig_structure
 */
export declare function verifyDataSignature(input: CoseVerifyInput): CoseVerifyResult;
//# sourceMappingURL=cose-verifier.d.ts.map