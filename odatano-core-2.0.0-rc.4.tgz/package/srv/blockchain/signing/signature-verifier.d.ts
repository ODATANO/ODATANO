import { SignatureVerificationResult, VerificationOptions } from '../../utils/types';
/**
 * SignatureVerifier - Verifies transaction signatures without accessing private keys
 *
 * This module provides signature verification for externally signed transactions.
 * It ensures:
 * 1. The signed CBOR is valid and parseable
 * 2. The transaction body hash matches the expected hash (integrity check)
 * 3. Required signatures are present (when specified)
 * 4. No tampering occurred between build and sign steps
 */
export declare class SignatureVerifier {
    /**
     * Verify a signed transaction
     *
     * @param signedTxCbor - The signed transaction in CBOR hex format
     * @param options - Verification options
     * @returns Verification result with details
     */
    verify(signedTxCbor: string, options?: VerificationOptions): SignatureVerificationResult;
    /**
     * Verify signature and throw on failure
     *
     * @param signedTxCbor - The signed transaction in CBOR hex format
     * @param options - Verification options
     * @throws {TransactionValidationError} if verification fails
     */
    verifyOrThrow(signedTxCbor: string, options?: VerificationOptions): SignatureVerificationResult;
    /**
     * Extract transaction body hash from unsigned or signed CBOR
     *
     * @param txCbor - Transaction CBOR (signed or unsigned)
     * @returns Transaction body hash as hex string
     * @throws {Error} if CBOR is invalid
     */
    extractTxBodyHash(txCbor: string): string;
    /**
     * Check if a transaction is signed (has witnesses)
     *
     * @param txCbor - Transaction CBOR
     * @returns true if transaction has at least one witness
     */
    isSigned(txCbor: string): boolean;
    /**
     * Get witness count from transaction
     *
     * @param txCbor - Transaction CBOR
     * @returns Number of witnesses
     */
    getWitnessCount(txCbor: string): number;
}
/**
 * Get the singleton SignatureVerifier instance
 */
export declare function getSignatureVerifier(): SignatureVerifier;
//# sourceMappingURL=signature-verifier.d.ts.map