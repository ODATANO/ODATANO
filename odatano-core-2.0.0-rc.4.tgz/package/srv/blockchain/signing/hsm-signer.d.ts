import { HsmConfig, HsmSignResult } from '../../utils/types';
/**
 * HsmSigner - PKCS#11 Hardware Security Module integration for Cardano transaction signing
 *
 * Wraps a PKCS#11 compliant HSM (YubiHSM 2, AWS CloudHSM, Thales Luna, etc.)
 * to provide Ed25519 signing for Cardano transactions. Private keys never leave
 * the HSM chip — only signatures are returned.
 *
 * Lifecycle:
 *   1. constructor(config) — stores config
 *   2. init(network) — connects to HSM, locates key, exports public key, derives Cardano address
 *   3. sign() / signTransaction() — signing operations
 *   4. shutdown() — closes session
 */
/** Minimal PKCS#11 module surface used here. Loaded dynamically; no static type
 * package is depended on. We narrow to the actual handful of methods invoked. */
interface PKCS11Instance {
    load(path: string): void;
    C_Initialize(): void;
    C_Finalize(): void;
    C_OpenSession(slot: Buffer, flags: number): Buffer;
    C_CloseSession(session: Buffer): void;
    C_Login(session: Buffer, userType: number, pin: string): void;
    C_Logout(session: Buffer): void;
    C_FindObjectsInit(session: Buffer, template: Pkcs11Attribute[]): void;
    C_FindObjects(session: Buffer, count: number): Buffer[];
    C_FindObjectsFinal(session: Buffer): void;
    C_GetAttributeValue(session: Buffer, handle: Buffer, template: Pkcs11Attribute[]): Pkcs11Attribute[];
    C_SignInit(session: Buffer, mechanism: {
        mechanism: number;
    }, key: Buffer): void;
    C_Sign(session: Buffer, data: Buffer, signature: Buffer): Buffer;
    C_GetSlotList(tokenPresent: boolean): Buffer[];
}
interface Pkcs11Attribute {
    type: number;
    value?: Buffer | number | boolean | string;
}
type Pkcs11JsModule = {
    PKCS11: new () => PKCS11Instance;
    [k: string]: unknown;
};
type Pkcs11Loader = () => Pkcs11JsModule;
/** Test seam: inject a fake pkcs11js module loader (null restores the default). */
export declare function setPkcs11Loader(loader: Pkcs11Loader | null): void;
export declare class HsmSigner {
    private pkcs11;
    private session;
    private privateKeyHandle;
    private publicKeyBytes;
    private publicKeyHashHex;
    private cardanoAddress;
    private config;
    private connected;
    constructor(config: HsmConfig);
    /**
     * Initialize PKCS#11 session and locate the signing key.
     * Called once during plugin startup.
     *
     * @param network - Cardano network (mainnet, preview, preprod) for address derivation
     */
    init(network: 'mainnet' | 'preview' | 'preprod' | string): Promise<void>;
    /**
     * Sign a 32-byte transaction body hash using the HSM.
     * Returns the Ed25519 signature + public key for witness construction.
     *
     * @param txBodyHash - 32-byte hash of the transaction body
     * @returns HsmSignResult with signature, public key, and key hash
     */
    sign(txBodyHash: Buffer): HsmSignResult;
    /**
     * Sign a transaction and produce a complete signed transaction CBOR.
     *
     * Takes the unsigned transaction CBOR, signs the body hash via HSM,
     * builds a VKey witness [publicKey, signature], and merges it into
     * the transaction's witness set using raw CBOR manipulation.
     *
     * @param unsignedTxCbor - Unsigned transaction CBOR (hex)
     * @param txBodyHash - Transaction body hash (hex, 64 chars)
     * @returns Signed transaction CBOR (hex)
     */
    signTransaction(unsignedTxCbor: string, txBodyHash: string): string;
    /** Get the HSM-derived Cardano enterprise address */
    getAddress(): string;
    /** Get the public key hash (for requiredSigners) */
    getPublicKeyHash(): string;
    /** Check connection status */
    isConnected(): boolean;
    /** Get status for monitoring */
    getStatus(): {
        connected: boolean;
        keyId?: string;
        keyLabel?: string;
        publicKeyHash?: string;
        address?: string;
    };
    /** Graceful shutdown — close PKCS#11 session */
    shutdown(): void;
    /**
     * Find a key object (private or public) in the HSM by label and/or ID
     */
    private _findKey;
    /**
     * Export the Ed25519 public key from the HSM.
     * Handles both DER-wrapped (04 20 <32 bytes>) and raw 32-byte formats.
     */
    private _exportPublicKey;
}
/**
 * Get the initialized HsmSigner instance.
 * Returns null if HSM is not configured.
 */
export declare function getHsmSigner(): HsmSigner | null;
/**
 * Set the HsmSigner instance (called during initialization and shutdown).
 */
export declare function setHsmSigner(signer: HsmSigner | null): void;
export {};
//# sourceMappingURL=hsm-signer.d.ts.map