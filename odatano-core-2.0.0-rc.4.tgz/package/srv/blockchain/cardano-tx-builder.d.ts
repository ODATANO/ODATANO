import type { CardanoClient } from './cardano-client';
import type { TxBuildRequest, TxBuildResult, LedgerProtocolParameters } from '../utils/types';
import type { CardanoTxBuilder } from './transaction-building/cardano-tx';
import { LedgerProtocolParameter } from '#cds-models/CardanoODataService';
/**
 * CardanoTransactionBuilder - High-level transaction builder that utilizes specific CardanoTxBuilder implementations
 * to build various types of Cardano transactions.
 */
export declare class CardanoTransactionBuilder {
    private client;
    private txBuilder;
    private initialized;
    /**
     * Create a new CardanoTransactionBuilder instance
     * @param client - The CardanoClient instance for UTxO fetching
     */
    constructor(client: CardanoClient);
    /**
     * Initialize the transaction builder
     * @param protocolParams - Optional protocol parameters (if not provided, fetched from backend)
     */
    init(protocolParams?: LedgerProtocolParameters): Promise<void>;
    /**
     * Ensure the builder is initialized and return it (lazy init)
     * @returns {Promise<CardanoTxBuilder>} initialized builder
     * @throws {Error} if builder cannot be initialized
     */
    private ensureInitialized;
    /**
     * Reset the transaction builder (useful for testing)
     */
    reset(): void;
    /**
     * Set the transaction builder directly (for testing)
     * @param builder - The builder to set
     */
    setBuilder(builder: CardanoTxBuilder): void;
    /**
     * Build a simple ADA transfer transaction
     * @param req transaction build request
     * @param protocolParameters current protocol parameters
     * @returns {Promise<TxBuildResult>} transaction build result
     */
    buildSimpleAdaTransaction(req: TxBuildRequest, protocolParameters: LedgerProtocolParameter): Promise<TxBuildResult>;
    /**
     * Build a transaction with Metadata (for both simple and multi-asset transactions)
     * @param req transaction build request
     * @param protocolParameters current protocol parameters
     * @returns {Promise<TxBuildResult>} transaction build result
     */
    buildTransactionWithMetadata(req: TxBuildRequest, protocolParameters: LedgerProtocolParameter): Promise<TxBuildResult>;
    /**
     * Build a multi-asset transaction
     * @param req transaction build request
     * @param protocolParameters current protocol parameters
     * @returns {Promise<TxBuildResult>} transaction build result
     */
    buildMultiAssetTransaction(req: TxBuildRequest, protocolParameters: LedgerProtocolParameter): Promise<TxBuildResult>;
    /**
     * Build a minting transaction
     * @param req transaction build request
     * @param protocolParameters current protocol parameters
     * @returns {Promise<TxBuildResult>} transaction build result
     */
    buildMintTransaction(req: TxBuildRequest, protocolParameters: LedgerProtocolParameter): Promise<TxBuildResult>;
    /**
     * Build a Plutus spending transaction (consume UTxO at script address)
     * @param req transaction build request
     * @param protocolParameters current protocol parameters
     * @returns {Promise<TxBuildResult>} transaction build result
     */
    buildPlutusSpendTransaction(req: TxBuildRequest, protocolParameters: LedgerProtocolParameter): Promise<TxBuildResult>;
    /**
     * Verify that a transaction output resolved via getTransaction is still unspent,
     * by checking the live UTxO set of its address. getTransaction only proves the
     * output EXISTED — a spent output would otherwise surface as a cryptic node-side
     * rejection at submit instead of a clear 400 here.
     *
     * Lookup failures are logged and tolerated (the check is best-effort; refusing to
     * build on a flaky backend would be a new failure mode).
     */
    private _assertUnspent;
    /**
     * Resolve forced-input refs (consumed) to full UTxO records.
     * Thin wrapper over _resolveInputRefs — see it for behaviour.
     */
    private _resolveForceInputs;
    /**
     * Resolve CIP-31 reference input refs (read-only, NOT merged into the
     * coin-selection set) to full UTxO records.
     */
    private _resolveReferenceInputs;
    /**
     * Resolve a list of {txHash, outputIndex} refs to full UTxO records.
     * Prefers matching against already-known UTxOs to avoid extra backend calls;
     * otherwise fetches the producing transaction and verifies the output is
     * unspent. Throws TransactionValidationError (labelled by `kind`) if any ref
     * cannot be resolved (missing or spent). Deduplicates refs before lookup.
     *
     * @param refs input refs from the request
     * @param knownUtxos UTxOs already fetched (cheap-match pool)
     * @param kind label used in error messages / the spent-check
     * @returns resolved UTxOs, in the same order as the deduped refs
     */
    private _resolveInputRefs;
    /**
     * Fetch UTxOs for a given address
     * @param address bech32 address
     * @returns {Promise<UTxO[]>} list of UTxOs
     */
    private _fetchUtxosForAddress;
}
//# sourceMappingURL=cardano-tx-builder.d.ts.map