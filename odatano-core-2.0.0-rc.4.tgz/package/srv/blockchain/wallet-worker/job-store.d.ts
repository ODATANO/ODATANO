import type { Transaction as CapTransaction } from '@sap/cds';
/**
 * Wallet-worker job store (v2.0).
 *
 * Persistence layer for `CardanoWalletJobs` + `CardanoWorkerWallets`. Ports the two
 * hard-won CAP lessons from NIGHTGATE's background-job runner:
 *
 *  1. `insertJob` runs on the CALLER's ambient transaction. CAP wraps every action
 *     handler in its own root tx which may already hold the SQLite write lock; a
 *     detached insert would deadlock against it. The row simply commits together
 *     with the handler, and the worker's dispatch loop only sees it once visible.
 *  2. Every transition helper runs in its own short `db.tx()` (callers pass a fresh
 *     tx or use `runWithoutAmbientTx`), so the single pooled SQLite connection is
 *     never held across the seconds-to-minutes job execution.
 *
 * State machine (see WALLET_WORKER_DESIGN.md §5):
 *   pending → building → submitting → submitted → confirmed
 *      │          │           │            └────→ failed
 *      │          │           └→ submitted (reconciled) | failed (proven absent)
 *      │          └→ pending (transient retry) | failed
 *      └→ cancelled
 *
 * `submitting` is the durable pre-submit state: the signed CBOR, its hash and the
 * fee are committed BEFORE the transaction can reach the network, so a process
 * death anywhere around `submitTransaction` leaves a row that can be reconciled
 * against the chain (or re-submitted verbatim) instead of a `building` row that
 * looks un-submitted. It is a NON-terminal state, so it keeps holding the
 * idempotency key — a caller retry gets the same job back rather than a rebuild.
 *
 * Transitions use guarded UPDATEs (WHERE includes the expected source status) with
 * a read-back verification — the wallet lease already fences concurrent workers,
 * this is defense in depth. NOTE (CAP 10): numeric columns read back as STRINGS;
 * all reads coerce via `num()` so callers get clean numbers.
 */
/** Per-wallet DB lease TTL — same rationale as the crawler lease. */
export declare const WORKER_LEASE_TTL_MS = 15000;
export declare const JOB_ERROR_CODES: {
    readonly PROCESS_RESTART: "PROCESS_RESTART";
    readonly TX_DROPPED: "TX_DROPPED";
    readonly RETRIES_EXHAUSTED: "RETRIES_EXHAUSTED";
    readonly CANCELLED: "CANCELLED";
    /** Reconciliation proved the tx is not on-chain and the node rejects it for good. */
    readonly SUBMIT_REJECTED: "SUBMIT_REJECTED";
};
export type WalletJobStatusValue = 'pending' | 'building' | 'submitting' | 'submitted' | 'confirmed' | 'failed' | 'cancelled';
export type WalletJobKindValue = 'simpleAda' | 'metadata' | 'multiAsset' | 'mint' | 'plutusSpend' | 'submitSigned';
export type WorkerSignerTypeValue = 'hsm' | 'software';
export declare const WALLET_JOB_KINDS: readonly WalletJobKindValue[];
/** Normalized, number-typed view of a job row. */
export interface WalletJobRow {
    ID: string;
    walletId: string;
    kind: WalletJobKindValue;
    status: WalletJobStatusValue;
    idempotencyKey: string | null;
    request: string | null;
    priority: number;
    notBefore: string | null;
    attempt: number;
    maxAttempts: number;
    txHash: string | null;
    unsignedTxCbor: string | null;
    signedTxCbor: string | null;
    fee: number | null;
    submittedAt: string | null;
    confirmedAt: string | null;
    confirmedSlot: number | null;
    confirmedHeight: number | null;
    errorCode: string | null;
    errorMessage: string | null;
    createdAt: string | null;
    createdBy: string | null;
    finishedAt: string | null;
}
/** Normalized view of a worker-wallet row. */
export interface WorkerWalletRow {
    walletId: string;
    signerType: WorkerSignerTypeValue;
    address: string | null;
    publicKeyHash: string | null;
    enabled: boolean;
    leaseOwner: string | null;
    leaseUntil: string | null;
    lastJobAt: string | null;
    jobsConfirmed: number;
    jobsFailed: number;
}
export { runWithoutAmbientTx } from '../../utils/tx-utils';
export interface InsertJobArgs {
    walletId: string;
    kind: WalletJobKindValue;
    /** Build-action payload as a JSON string (already validated + size-limited). */
    request: string;
    idempotencyKey?: string | null;
    priority?: number;
    notBefore?: string | null;
    maxAttempts?: number;
    createdBy?: string | null;
}
export interface InsertJobResult {
    jobId: string;
    status: WalletJobStatusValue;
    /** True when an idempotent retry matched an existing non-failed job. */
    deduplicated: boolean;
}
/**
 * Insert a job row ON THE CALLER'S transaction (NIGHTGATE lesson 1 — see module
 * docs). Idempotency: an active-or-successful row with the same (walletId, kind,
 * idempotencyKey) is returned instead of creating a duplicate. `failed` AND
 * `cancelled` rows do NOT block a retry — both are terminal states in which the
 * intended work never reached the chain, so re-using the key must be able to
 * actually execute it (a cancelled job would otherwise burn its key forever).
 *
 * The deduplication is enforced by the `dedup` UNIQUE constraint on
 * (walletId, kind, dedupKey), NOT by the read below: two concurrent retries — two
 * app instances, or two HANA sessions — can both read "no such job" before either
 * commits, and would both insert. The read is only a fast path; the constraint is
 * what makes it correct, and the loser of the race returns the winner's job.
 *
 * `dedupKey` holds the caller's key while the job owns it and the job's own ID
 * otherwise, so keyless jobs never collide and terminated jobs free their key
 * (see releaseDedupClaim) — without depending on how a database treats NULLs
 * inside a unique index.
 */
export declare function insertJob(db: CapTransaction, args: InsertJobArgs): Promise<InsertJobResult>;
export declare function getJobById(db: CapTransaction, jobId: string): Promise<WalletJobRow | null>;
/**
 * All dispatchable jobs: status pending, ordered by (priority, createdAt).
 * `notBefore` gating happens in JS — queue depths are small and the JS filter
 * avoids adapter-specific NULL/OR predicate quirks.
 */
export declare function findDueJobs(db: CapTransaction, now?: Date): Promise<WalletJobRow[]>;
/** All jobs awaiting confirmation (used by the tracker on start/recovery). */
export declare function findSubmittedJobs(db: CapTransaction): Promise<WalletJobRow[]>;
/** Whether the wallet has a job currently in flight (building, submitting or submitted). */
export declare function walletHasActiveJob(db: CapTransaction, walletId: string): Promise<boolean>;
/**
 * The oldest `submitting` row of a wallet whose lease no longer belongs to a live
 * executor — its submit outcome is unknown (crash, or a submit call that failed
 * ambiguously), so it needs chain reconciliation rather than a rebuild. Rows whose
 * wallet lease is still held are being worked on right now and are left alone.
 */
export declare function findOrphanedSubmittingJob(db: CapTransaction, walletId: string, now?: Date): Promise<WalletJobRow | null>;
/**
 * Give up a job's idempotency key by pointing `dedupKey` at the job's own ID
 * (unique by construction). Called on every terminal-but-unsuccessful transition,
 * which is what lets a caller re-use the key for a fresh attempt while the row
 * itself — including its `idempotencyKey` — stays intact for the audit trail.
 *
 * Not called for `confirmed`: a completed job keeps its key so a late duplicate
 * request resolves to it instead of paying again.
 */
export declare function releaseDedupClaim(db: CapTransaction, jobId: string): Promise<void>;
/** pending → building. Increments the attempt counter. Returns false when lost. */
export declare function markBuilding(db: CapTransaction, jobId: string, attempt: number): Promise<boolean>;
/**
 * building → submitting. Commits the signed transaction, its hash, the unsigned
 * CBOR and the fee BEFORE the tx is handed to a backend — the whole point of the
 * state: whatever happens to the process during `submitTransaction`, the exact
 * bytes that may be on-chain survive, and the job keeps holding its idempotency
 * key so a caller retry can never turn into a second, differently-built payment.
 * `submittedAt` is the attempt time (timeout base), not proof of acceptance.
 */
export declare function markSubmitting(db: CapTransaction, jobId: string, artifacts: {
    txHash: string;
    unsignedTxCbor: string | null;
    signedTxCbor: string;
    fee: string | number | null;
}): Promise<boolean>;
/**
 * submitting → submitted: a backend accepted the tx (or reconciliation found it
 * on-chain). The artifacts are already durable from markSubmitting; only the hash
 * is re-asserted, in case the backend canonicalized it.
 */
export declare function markSubmitted(db: CapTransaction, jobId: string, txHash: string): Promise<boolean>;
/**
 * building → pending (transient failure, attempts left). Keeps the error visible
 * and defers the next attempt via `notBefore` (exponential backoff).
 *
 * Guarded on `building` ON PURPOSE: once a job is `submitting` its tx may be in a
 * mempool, and re-queueing it would rebuild a different transaction from the same
 * request — the duplicate-payment path. Those rows go to reconciliation instead.
 */
export declare function requeueForRetry(db: CapTransaction, jobId: string, err: unknown, notBefore?: string): Promise<boolean>;
/** Record where the submitted tx was seen on-chain (not yet at depth). */
export declare function recordConfirmationPoint(db: CapTransaction, jobId: string, point: {
    slot: number | null;
    height: number | null;
}): Promise<void>;
/** A rollback invalidated the recorded confirmation point — back to watching. */
export declare function clearConfirmationPoint(db: CapTransaction, jobId: string): Promise<void>;
/** submitted → confirmed (depth reached). */
export declare function markConfirmed(db: CapTransaction, jobId: string): Promise<boolean>;
/**
 * Any active state → failed (terminal). Failing a `submitting`/`submitted` row is
 * only safe once the chain has been consulted — a failed row releases the
 * idempotency key, so a premature failure invites the caller's retry to pay twice.
 */
export declare function markFailed(db: CapTransaction, jobId: string, code: string, err: unknown): Promise<boolean>;
/** pending → cancelled. Only pending jobs are cancellable (the tx may otherwise reach the chain). */
export declare function markCancelled(db: CapTransaction, jobId: string): Promise<boolean>;
export interface RecoveryResult {
    /** `building` rows flipped to failed (never signed+stored, so never submitted). */
    failedBuilding: number;
    /** `submitted` rows to re-enqueue into the confirmation tracker — the chain decides. */
    submittedToReconcile: WalletJobRow[];
    /** `submitting` rows with an unknown submit outcome — reconciled by the dispatch loop. */
    submittingToReconcile: WalletJobRow[];
}
/**
 * Fail one wallet's orphaned `building` row(s) — but ONLY when the wallet's lease
 * is expired/unowned, i.e. no live instance is executing them. Rows whose wallet
 * lease is held belong to a running executor (possibly on another instance) and
 * must not be touched.
 *
 * Safe by construction: a `building` row is pre-submit by definition — the worker
 * transitions to `submitting` (with the signed CBOR) before anything can reach a
 * backend, so nothing that is still `building` has ever been sent. Rows that made
 * it past that point are `submitting` and are reconciled, never failed here.
 */
export declare function failOrphanedBuildingJobs(db: CapTransaction, walletId: string, now?: Date): Promise<number>;
/**
 * Boot-time recovery (design §8), by state:
 *  - `building` — nothing was signed and stored yet, so nothing was submitted:
 *    fail with PROCESS_RESTART (caller retries via idempotencyKey).
 *  - `submitting` — the signed tx is durable but its fate is unknown: NOT failed
 *    and NOT rebuilt. Returned so the dispatch loop reconciles it against the
 *    chain and re-submits those exact bytes if needed.
 *  - `submitted` — NOT failed: handed to the confirmation tracker; the chain
 *    decides (found → confirm; absent past the timeout → TX_DROPPED).
 *
 * Multi-instance safety: a `building` row is only failed when its wallet's lease
 * is expired/unowned. A held lease means ANOTHER live instance is executing that
 * job right now (rolling deploy) — failing it here while its submit succeeds
 * would leave a failed row for an on-chain tx, and since failed rows don't block
 * idempotency dedup, the caller's documented retry would pay twice. Rows skipped
 * here are cleaned up later by failOrphanedBuildingJobs once the lease expires.
 */
export declare function recoverInterruptedJobs(db: CapTransaction, now?: Date): Promise<RecoveryResult>;
/** Idempotently register/refresh a configured wallet row (no key material). */
export declare function upsertWalletRegistration(db: CapTransaction, wallet: {
    walletId: string;
    signerType: WorkerSignerTypeValue;
    address: string;
    publicKeyHash: string;
}): Promise<void>;
export declare function readWallet(db: CapTransaction, walletId: string): Promise<WorkerWalletRow | null>;
export declare function listWallets(db: CapTransaction): Promise<WorkerWalletRow[]>;
/**
 * Atomically acquire an expired/unowned per-wallet lease (compare-and-swap +
 * read-back verification, same shape as the crawler lease). At most one worker
 * instance may execute jobs for a wallet at any time.
 */
export declare function tryAcquireWalletLease(db: CapTransaction, walletId: string, owner: string, now?: Date, ttlMs?: number): Promise<boolean>;
/** Renew/fence the caller's lease. Call before every job-advancing write. */
export declare function renewWalletLease(db: CapTransaction, walletId: string, owner: string, now?: Date, ttlMs?: number): Promise<boolean>;
/** Release only the caller's lease; a stale process can never clear a successor. */
export declare function releaseWalletLease(db: CapTransaction, walletId: string, owner: string): Promise<void>;
/** Bump rolling per-wallet stats on a terminal job state. */
export declare function bumpWalletStats(db: CapTransaction, walletId: string, outcome: 'confirmed' | 'failed'): Promise<void>;
//# sourceMappingURL=job-store.d.ts.map