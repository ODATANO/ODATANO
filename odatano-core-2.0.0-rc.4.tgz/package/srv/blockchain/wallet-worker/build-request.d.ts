import type { TxBuildRequest } from '../../utils/types';
import type { Network } from '../cardano-client';
import type { WalletJobKindValue } from './job-store';
/**
 * Transform a stored wallet-job `requestJson` (the documented Build*-action
 * payload shape — assetsJson, mintActionsJson, metadataJson strings, …) into
 * the TxBuildRequest shape the CardanoIndexer build methods expect (assets,
 * mintActions with bigint quantities, parsed metadata, assembled
 * plutusScriptExecution, …).
 *
 * The synchronous CardanoTransactionService handlers do this transformation
 * inline per action; the worker executes the SAME payload asynchronously, so
 * this module mirrors that logic using the shared parsers
 * (srv/utils/tx-request-parsers.ts). Validation failures throw
 * BackendError 400 INVALID_INPUT — deterministic, so the job fails terminally
 * instead of burning retries.
 */
type RawRequest = Record<string, unknown>;
/**
 * Transform the raw job request (documented Build*-action payload) into the
 * TxBuildRequest the matching CardanoIndexer build method expects. Throws
 * BackendError 400 INVALID_INPUT for malformed payloads (terminal job failure).
 */
export declare function prepareWorkerBuildRequest(kind: WalletJobKindValue, raw: RawRequest, network: Network): TxBuildRequest;
export {};
//# sourceMappingURL=build-request.d.ts.map