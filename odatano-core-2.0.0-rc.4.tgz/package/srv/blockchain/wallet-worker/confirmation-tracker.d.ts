import type { CardanoClient } from '../cardano-client';
/**
 * Confirmation tracker (v2.0, design §7).
 *
 * Watches `submitted` jobs until their tx sits at depth ≥ `confirmationDepth`:
 *  - Crawler hook (preferred, zero extra load): `blockIndexed` events match
 *    submitted tx hashes and carry the advancing tip; `reorg` events invalidate
 *    confirmation points behind the fork and optionally re-submit the SAME
 *    signed CBOR (never a rebuild — the double-spend guard).
 *  - Polling fallback (always on, hook path just accelerates): every
 *    `pollIntervalMs` unfound txs are looked up via `client.getTransaction`
 *    and the tip via `client.getLatestBlock`.
 *
 * A tx that stays unseen past `confirmationTimeoutMs` fails as TX_DROPPED —
 * safe to retry from the caller, because the guard is the on-chain lookup itself.
 *
 * Confirmations are counted as `tipHeight - foundHeight + 1`, so depth 1 means
 * "confirmed as soon as included in a block".
 */
export interface TrackedJob {
    jobId: string;
    walletId: string;
    /** Job kind, carried so terminal events can name it without a DB read. */
    kind: string | null;
    txHash: string;
    signedTxCbor: string | null;
    /** ISO timestamp of mempool acceptance (timeout base). */
    submittedAt: string;
    foundSlot: number | null;
    foundHeight: number | null;
}
export interface ConfirmationTrackerOptions {
    confirmationDepth: number;
    confirmationTimeoutMs: number;
    pollIntervalMs: number;
    resubmitOnRollback: boolean;
}
export interface ConfirmationTrackerDeps {
    client: CardanoClient;
    options: ConfirmationTrackerOptions;
    /** Called exactly once per job when it reaches a terminal state. */
    onFinal?: (job: {
        jobId: string;
        walletId: string;
        outcome: 'confirmed' | 'failed';
        kind: string | null;
        /** The tracked transaction — present even on failure (it was submitted). */
        txHash: string;
        errorCode?: string;
        errorMessage?: string;
    }) => void;
}
export declare class ConfirmationTracker {
    private readonly deps;
    private readonly pending;
    private readonly blockListener;
    private readonly reorgListener;
    private pollTimer;
    private running;
    private polling;
    private lastKnownTipHeight;
    constructor(deps: ConfirmationTrackerDeps);
    start(): void;
    stop(): void;
    /** Number of jobs currently awaiting confirmation. */
    size(): number;
    /** Register a submitted job for confirmation watching. Idempotent per jobId. */
    track(job: {
        jobId: string;
        walletId: string;
        kind?: string | null;
        txHash: string;
        signedTxCbor: string | null;
        submittedAt?: string | null;
        confirmedSlot?: number | null;
        confirmedHeight?: number | null;
    }): void;
    private onBlockIndexed;
    private onReorg;
    /** One polling round. Public for tests; guarded against overlapping rounds. */
    pollOnce(): Promise<void>;
    /** Confirm every found job whose depth requirement is met by the known tip. */
    private confirmMature;
    private finalize;
}
//# sourceMappingURL=confirmation-tracker.d.ts.map