/**
 * Keeps a per-wallet lease alive for as long as a job execution runs.
 *
 * Building and signing a transaction can easily outlast WORKER_LEASE_TTL_MS (a
 * multi-backend build plus an HSM round-trip); a single renewal before the build
 * is therefore not enough. Without a heartbeat the lease silently expires
 * mid-execution, another instance adopts the wallet, fails this executor's row as
 * orphaned and starts the next job — two executors on one wallet, which is exactly
 * what the per-wallet lease exists to prevent.
 *
 * Renewals run at a third of the TTL, so two consecutive misses (slow DB, event
 * loop hiccup) are tolerated before the lease can lapse. A process that is truly
 * wedged stops beating and correctly loses the wallet.
 *
 * Two failure semantics, on purpose:
 *  - the periodic `beat` is lenient: a DB error is logged and retried next tick,
 *    only a definitive "not yours" marks the lease lost.
 *  - `fence()` is strict: it is called right before an irreversible step, where
 *    "cannot prove ownership" must be treated as "not ours". Aborting there is
 *    free (nothing has been sent yet); guessing wrong is a double spend.
 */
export declare const LEASE_HEARTBEAT_INTERVAL_MS: number;
export declare class LeaseHeartbeat {
    private readonly renew;
    private readonly label;
    private readonly intervalMs;
    private timer;
    private lost;
    /**
     * @param renew   renews the lease and reports whether it is (still) ours
     * @param label   what the lease covers, for log messages
     */
    constructor(renew: () => Promise<boolean>, label: string, intervalMs?: number);
    start(): void;
    stop(): void;
    /** True once a renewal proved the lease is no longer ours — abort the execution. */
    isLost(): boolean;
    /** Renew now; false means "do not touch this wallet any further". */
    fence(): Promise<boolean>;
    private beat;
    private markLost;
}
//# sourceMappingURL=lease-heartbeat.d.ts.map