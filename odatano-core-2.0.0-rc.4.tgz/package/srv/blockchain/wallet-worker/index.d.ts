import { CardanoWalletWorker, type WalletWorkerConfig, type WalletWorkerDeps } from './wallet-worker';
export type StartWalletWorkerDeps = Omit<WalletWorkerDeps, 'instanceId'> & {
    instanceId?: string;
};
export type { WalletWorkerConfig };
/** Start the worker (idempotent — a no-op when one is already running). */
export declare function startWalletWorker(deps: StartWalletWorkerDeps): Promise<void>;
/** Stop the local worker (in-flight execution steps are awaited). */
export declare function stopWalletWorker(): Promise<void>;
/** Whether a worker is currently running in this process. */
export declare function isWalletWorkerRunning(): boolean;
/** The active worker instance, or null. */
export declare function getWalletWorker(): CardanoWalletWorker | null;
//# sourceMappingURL=index.d.ts.map