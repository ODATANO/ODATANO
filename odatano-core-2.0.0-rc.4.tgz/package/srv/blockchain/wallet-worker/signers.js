"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SoftwareWorkerSigner = void 0;
exports.mergeVkeyWitness = mergeVkeyWitness;
exports.deriveEnterpriseAddress = deriveEnterpriseAddress;
exports.createWorkerSigner = createWorkerSigner;
const cds_1 = __importDefault(require("@sap/cds"));
const cbor_1 = require("@harmoniclabs/cbor");
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const crypto_1 = require("@harmoniclabs/crypto");
const bech32_1 = require("bech32");
const hsm_signer_1 = require("../signing/hsm-signer");
const errors_1 = require("../../utils/errors");
const crypto_2 = require("../../utils/crypto");
const logger = cds_1.default.log('CardanoWalletWorker');
/**
 * Merge a single VKey witness [publicKey, signature] into an unsigned transaction's
 * witness set at the raw CBOR level, preserving all non-vkey entries (scripts,
 * datums, redeemers) and encoding metadata. Same single-signer semantics as
 * HsmSigner.signTransaction — the worker wallet is the sole signer of its builds.
 */
function mergeVkeyWitness(unsignedTxCbor, publicKeyHex, signatureHex) {
    const txObj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(unsignedTxCbor));
    if (!(txObj instanceof cbor_1.CborArray) || txObj.array.length < 2) {
        throw new errors_1.TransactionValidationError('Invalid transaction CBOR structure', undefined);
    }
    const vkeyWitness = new cbor_1.CborArray([
        new cbor_1.CborBytes((0, uint8array_utils_1.fromHex)(publicKeyHex)),
        new cbor_1.CborBytes((0, uint8array_utils_1.fromHex)(signatureHex)),
    ]);
    const origWs = txObj.array[1];
    if (!(origWs instanceof cbor_1.CborMap)) {
        throw new errors_1.TransactionValidationError('Witness set must be a CBOR map', undefined);
    }
    const entries = origWs.map.filter((e) => !(e.k instanceof cbor_1.CborUInt && Number(e.k.num) === 0));
    entries.push({ k: new cbor_1.CborUInt(0), v: new cbor_1.CborArray([vkeyWitness]) });
    txObj.array[1] = new cbor_1.CborMap(entries, { indefinite: origWs.indefinite });
    return (0, uint8array_utils_1.toHex)(cbor_1.Cbor.encode(new cbor_1.CborArray(txObj.array, { indefinite: txObj.indefinite })));
}
/** Derive the bech32 enterprise key-hash address for a 28-byte key hash. */
function deriveEnterpriseAddress(publicKeyHash, network) {
    const headerByte = network === 'mainnet' ? 0x61 : 0x60;
    const payload = Buffer.alloc(29);
    payload[0] = headerByte;
    Buffer.from(publicKeyHash).copy(payload, 1);
    const hrp = network === 'mainnet' ? 'addr' : 'addr_test';
    return bech32_1.bech32.encode(hrp, bech32_1.bech32.toWords(payload), 120);
}
/** hsm — delegates to the process-wide HsmSigner initialized at bootstrap. */
class HsmWorkerSigner {
    type = 'hsm';
    get signer() {
        const hsm = (0, hsm_signer_1.getHsmSigner)();
        if (!hsm || !hsm.isConnected()) {
            throw new errors_1.ConfigError('Wallet worker: HSM signer is not configured or not connected');
        }
        return hsm;
    }
    getAddress() {
        return this.signer.getAddress();
    }
    getPublicKeyHash() {
        return this.signer.getPublicKeyHash();
    }
    signTransaction(unsignedTxCbor, txBodyHash) {
        return this.signer.signTransaction(unsignedTxCbor, txBodyHash);
    }
}
/** software — in-memory Ed25519 key (dev/test). */
class SoftwareWorkerSigner {
    type = 'software';
    privateKey;
    publicKeyHex;
    publicKeyHashHex;
    address;
    constructor(privateKeyHex, network) {
        if (!/^[0-9a-f]{64}$/i.test(privateKeyHex)) {
            throw new errors_1.ConfigError('Wallet worker: software signing key must be 64 hex characters (32-byte Ed25519 key)');
        }
        this.privateKey = (0, uint8array_utils_1.fromHex)(privateKeyHex);
        const publicKey = (0, crypto_1.deriveEd25519PublicKey_sync)(this.privateKey);
        this.publicKeyHex = (0, uint8array_utils_1.toHex)(Uint8Array.from(publicKey));
        const keyHash = Uint8Array.from((0, crypto_1.blake2b_224)(Uint8Array.from(publicKey)));
        this.publicKeyHashHex = (0, uint8array_utils_1.toHex)(keyHash);
        this.address = deriveEnterpriseAddress(keyHash, network);
    }
    getAddress() {
        return this.address;
    }
    getPublicKeyHash() {
        return this.publicKeyHashHex;
    }
    signTransaction(unsignedTxCbor, txBodyHash) {
        const { signature } = (0, crypto_1.signEd25519_sync)((0, uint8array_utils_1.fromHex)(txBodyHash), this.privateKey);
        return mergeVkeyWitness(unsignedTxCbor, this.publicKeyHex, (0, uint8array_utils_1.toHex)(Uint8Array.from(signature)));
    }
}
exports.SoftwareWorkerSigner = SoftwareWorkerSigner;
/**
 * Resolve the software key material for a wallet: plain hex passes through,
 * the AES-256-GCM combined format (contains ':') is decrypted with ENCRYPTION_KEY.
 */
function resolveSoftwareKey(wallet) {
    if (!wallet.keyEnv) {
        throw new errors_1.ConfigError(`Wallet worker: wallet "${wallet.walletId}" is signerType=software but has no keyEnv configured`);
    }
    const raw = process.env[wallet.keyEnv];
    if (!raw) {
        throw new errors_1.ConfigError(`Wallet worker: environment variable ${wallet.keyEnv} (key for wallet "${wallet.walletId}") is not set`);
    }
    return raw.includes(':') ? (0, crypto_2.decrypt)(raw.trim(), (0, crypto_2.getEncryptionKey)()) : raw.trim();
}
/** Build the signer for a configured worker wallet. Throws ConfigError on bad setup. */
function createWorkerSigner(wallet, network) {
    if (wallet.signerType === 'hsm') {
        const signer = new HsmWorkerSigner();
        // Fail fast at worker start when the HSM is absent, not on the first job.
        signer.getAddress();
        return signer;
    }
    if (wallet.signerType === 'software') {
        const signer = new SoftwareWorkerSigner(resolveSoftwareKey(wallet), network);
        logger.info(`Software signer for wallet "${wallet.walletId}" initialized (address=${signer.getAddress()})`);
        return signer;
    }
    throw new errors_1.ConfigError(`Wallet worker: unknown signerType "${String(wallet.signerType)}" for wallet "${wallet.walletId}"`);
}
//# sourceMappingURL=signers.js.map