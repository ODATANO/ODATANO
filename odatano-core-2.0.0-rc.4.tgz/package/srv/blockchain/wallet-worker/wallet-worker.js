"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardanoWalletWorker = void 0;
exports.retryBackoffMs = retryBackoffMs;
exports.isTransientJobError = isTransientJobError;
const cds_1 = __importDefault(require("@sap/cds"));
const errors_1 = require("../../utils/errors");
const error_codes_1 = require("../../utils/error-codes");
const tx_build_helper_1 = require("../../utils/tx-build-helper");
const confirmation_tracker_1 = require("./confirmation-tracker");
const lease_heartbeat_1 = require("./lease-heartbeat");
const build_request_1 = require("./build-request");
const service_events_1 = require("../../utils/service-events");
const signers_1 = require("./signers");
const job_store_1 = require("./job-store");
const logger = cds_1.default.log('CardanoWalletWorker');
/** Retry backoff: 5s · 2^(attempt-1), capped at 60s. */
function retryBackoffMs(attempt) {
    return Math.min(5_000 * 2 ** Math.max(0, attempt - 1), 60_000);
}
/**
 * Transient errors are worth a bounded retry; everything else is deterministic
 * (a retry cannot change the outcome) and fails the job immediately.
 */
function isTransientJobError(err) {
    if (err instanceof errors_1.ProviderUnavailableError)
        return true;
    if (err instanceof errors_1.RateLimitError)
        return true;
    if (err instanceof errors_1.AllBackendsFailedError)
        return true;
    if (err instanceof errors_1.HsmError)
        return true;
    if (err instanceof errors_1.BackendError)
        return err.statusCode >= 500 || err.statusCode === 429;
    return false;
}
function terminalErrorCode(err) {
    if (err instanceof errors_1.BackendError && err.code)
        return String(err.code);
    return 'EXECUTION_FAILED';
}
class CardanoWalletWorker {
    deps;
    signers = new Map();
    executing = new Set(); // walletIds with an execution in flight in THIS process
    executionPromises = new Set();
    tracker;
    dispatchTimer = null;
    running = false;
    ticking = false;
    constructor(deps) {
        this.deps = deps;
        this.tracker = new confirmation_tracker_1.ConfirmationTracker({
            client: deps.client,
            options: {
                confirmationDepth: deps.config.confirmationDepth,
                confirmationTimeoutMs: deps.config.confirmationTimeoutMs,
                pollIntervalMs: Math.max(deps.config.pollIntervalMs, 5_000),
                resubmitOnRollback: deps.config.resubmitOnRollback,
            },
            onFinal: ({ jobId, walletId, outcome, kind, txHash, errorCode, errorMessage }) => {
                logger.debug(`Wallet ${walletId} unblocked (job ${outcome}) — next tick dispatches`);
                // Fired only on a TERMINAL outcome, after the transition is committed, so a
                // subscriber that reads the job row sees the state the event announces.
                (0, service_events_1.emitServiceEvent)('CardanoWorkerService', outcome === 'confirmed' ? 'jobConfirmed' : 'jobFailed', {
                    jobId,
                    walletId,
                    kind,
                    txHash,
                    ...(outcome === 'failed' ? { errorCode: errorCode ?? null, errorMessage: errorMessage ?? null } : {}),
                });
                void this.tickSafe();
            },
        });
    }
    isRunning() {
        return this.running;
    }
    /** Wallets this instance can sign for (signer init succeeded). */
    getWalletIds() {
        return [...this.signers.keys()];
    }
    getSigner(walletId) {
        return this.signers.get(walletId);
    }
    /** Live status summary for the control service. */
    getStatusSummary() {
        return {
            running: this.running,
            wallets: this.getWalletIds(),
            executing: [...this.executing],
            awaitingConfirmation: this.tracker.size(),
        };
    }
    async start() {
        if (this.running)
            return;
        if (!this.deps.config.wallets.length) {
            logger.warn('Wallet worker refused to start: no wallets configured');
            return;
        }
        // 1. Initialize signers — a broken wallet config skips that wallet, not the worker.
        for (const walletCfg of this.deps.config.wallets) {
            try {
                const signer = (0, signers_1.createWorkerSigner)(walletCfg, this.deps.network);
                this.signers.set(walletCfg.walletId, signer);
                await cds_1.default.tx((tx) => (0, job_store_1.upsertWalletRegistration)(tx, {
                    walletId: walletCfg.walletId,
                    signerType: walletCfg.signerType,
                    address: signer.getAddress(),
                    publicKeyHash: signer.getPublicKeyHash(),
                }));
            }
            catch (err) {
                logger.error(`Wallet "${walletCfg.walletId}" skipped — signer initialization failed:`, err);
            }
        }
        if (this.signers.size === 0) {
            logger.error('Wallet worker not started: no wallet signer could be initialized');
            return;
        }
        // 2. Crash recovery: fail interrupted builds, re-watch submitted jobs. Rows
        //    interrupted around the submit call stay `submitting` — the first tick
        //    reconciles them against the chain (reconcileOrphanedSubmissions).
        const recovery = await cds_1.default.tx((tx) => (0, job_store_1.recoverInterruptedJobs)(tx));
        if (recovery.submittingToReconcile.length) {
            logger.warn(`${recovery.submittingToReconcile.length} job(s) with an unresolved submit will be reconciled on the next dispatch tick`);
        }
        for (const job of recovery.submittedToReconcile) {
            if (!job.txHash)
                continue; // defensive: submitted implies txHash
            this.tracker.track({
                jobId: job.ID,
                walletId: job.walletId,
                kind: job.kind,
                txHash: job.txHash,
                signedTxCbor: job.signedTxCbor,
                submittedAt: job.submittedAt,
                confirmedSlot: job.confirmedSlot,
                confirmedHeight: job.confirmedHeight,
            });
        }
        // 3. Go.
        this.running = true;
        this.tracker.start();
        this.dispatchTimer = setInterval(() => { void this.tickSafe(); }, this.deps.config.pollIntervalMs);
        this.dispatchTimer.unref?.();
        void this.tickSafe();
        logger.info(`Wallet worker started (wallets=[${this.getWalletIds().join(', ')}], instance=${this.deps.instanceId})`);
    }
    async stop() {
        if (!this.running)
            return;
        this.running = false;
        if (this.dispatchTimer) {
            clearInterval(this.dispatchTimer);
            this.dispatchTimer = null;
        }
        this.tracker.stop();
        // Executions are short (build+sign+submit) — await them so teardown never races a write.
        await Promise.allSettled([...this.executionPromises]);
        for (const walletId of this.getWalletIds()) {
            try {
                await cds_1.default.tx((tx) => (0, job_store_1.releaseWalletLease)(tx, walletId, this.deps.instanceId));
            }
            catch (err) {
                logger.debug(`Lease release for ${walletId} failed (TTL expires it anyway):`, err);
            }
        }
        logger.info('Wallet worker stopped');
    }
    /** One dispatch round; serialized (overlapping timers collapse into one run). */
    async tickSafe() {
        if (!this.running || this.ticking)
            return;
        this.ticking = true;
        try {
            await this.tick();
        }
        catch (err) {
            logger.error('Wallet worker dispatch tick failed:', err);
        }
        finally {
            this.ticking = false;
        }
    }
    async tick() {
        // Interrupted submits first: a stuck `submitting` row blocks its wallet queue
        // and may be the only work there is (no pending job would ever surface it).
        await this.reconcileOrphanedSubmissions();
        const due = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.findDueJobs)(tx)));
        if (!due.length)
            return;
        // First runnable job per wallet, dispatch order (priority, createdAt) preserved.
        const nextPerWallet = new Map();
        for (const job of due) {
            if (!nextPerWallet.has(job.walletId))
                nextPerWallet.set(job.walletId, job);
        }
        for (const [walletId, job] of nextPerWallet) {
            if (!this.running)
                return;
            if (this.executing.size >= this.deps.config.maxConcurrentWallets)
                return;
            if (this.executing.has(walletId))
                continue;
            const signer = this.signers.get(walletId);
            if (!signer)
                continue; // job for a wallet this instance cannot sign for
            const dispatched = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx(async (tx) => {
                // Steady-state orphan cleanup: a building row whose wallet lease expired
                // belongs to a dead executor — fail it here so the wallet unblocks without
                // needing a reboot (boot recovery only covers restarts of THIS instance).
                await (0, job_store_1.failOrphanedBuildingJobs)(tx, walletId);
                // DB truth serializes across restarts and instances: a building OR submitted
                // job blocks the wallet queue until the tracker finalizes it (design §6).
                if (await (0, job_store_1.walletHasActiveJob)(tx, walletId))
                    return false;
                return (0, job_store_1.tryAcquireWalletLease)(tx, walletId, this.deps.instanceId);
            }));
            if (!dispatched)
                continue;
            this.spawn(walletId, () => this.executeJob(job, signer));
        }
    }
    /**
     * Adopt `submitting` rows left behind by a dead executor (this process before a
     * restart, or another instance whose lease expired) and resolve them against the
     * chain. Runs per wallet under the same lease the executor would hold.
     */
    async reconcileOrphanedSubmissions() {
        const { instanceId } = this.deps;
        for (const walletId of this.getWalletIds()) {
            if (!this.running)
                return;
            if (this.executing.size >= this.deps.config.maxConcurrentWallets)
                return;
            if (this.executing.has(walletId))
                continue;
            const orphan = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx(async (tx) => {
                const stuck = await (0, job_store_1.findOrphanedSubmittingJob)(tx, walletId);
                if (!stuck)
                    return null;
                return (await (0, job_store_1.tryAcquireWalletLease)(tx, walletId, instanceId)) ? stuck : null;
            }));
            if (!orphan)
                continue;
            this.spawn(walletId, () => this.reconcileSubmitting(orphan));
        }
    }
    /** Run one wallet's work in the background, tracked for concurrency + shutdown. */
    spawn(walletId, work) {
        this.executing.add(walletId);
        const execution = work()
            .catch((err) => logger.error(`Wallet ${walletId}: unhandled execution error:`, err))
            .finally(() => {
            this.executing.delete(walletId);
            this.executionPromises.delete(execution);
        });
        this.executionPromises.add(execution);
    }
    /** A heartbeat that keeps this instance's lease on `walletId` alive while it works. */
    leaseHeartbeat(walletId) {
        const { instanceId } = this.deps;
        const heartbeat = new lease_heartbeat_1.LeaseHeartbeat(async () => await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.renewWalletLease)(tx, walletId, instanceId))), `wallet ${walletId}`);
        heartbeat.start();
        return heartbeat;
    }
    /**
     * Execute one job: building → (build → sign) → submitting → submit → submitted,
     * then hand to the tracker. The wallet lease is held for the duration — renewed by
     * a heartbeat, because build+sign can outlast its TTL — and released afterwards
     * (queue serialization continues via the job row, not the lease).
     *
     * Everything up to and including the `submitting` commit may fail freely — nothing
     * has been sent, so the job re-queues or fails normally. Past that commit the job
     * belongs to `reconcileSubmitting`.
     */
    async executeJob(job, signer) {
        const { instanceId } = this.deps;
        const attempt = job.attempt + 1;
        const claimed = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.markBuilding)(tx, job.ID, attempt)));
        if (!claimed)
            return; // cancelled or claimed elsewhere
        const heartbeat = this.leaseHeartbeat(job.walletId);
        try {
            let unsignedTxCbor = null;
            let signedTxCbor;
            let fee = null;
            let buildId = null;
            if (job.kind === 'submitSigned') {
                const request = JSON.parse(job.request ?? '{}');
                if (!request.signedTxCbor) {
                    throw new errors_1.BackendError('submitSigned job has no signedTxCbor in its request', 400, error_codes_1.ERROR_CODES.INVALID_INPUT);
                }
                signedTxCbor = request.signedTxCbor;
            }
            else {
                const rawReq = JSON.parse(job.request ?? '{}');
                // The worker wallet is ALWAYS the sender/change target — callers cannot
                // spend from foreign addresses through a worker wallet.
                rawReq.network = this.deps.network;
                rawReq.senderAddress = signer.getAddress();
                if (!rawReq.changeAddress)
                    rawReq.changeAddress = signer.getAddress();
                // The stored request has the documented Build*-action payload shape
                // (assetsJson/mintActionsJson/… strings) — transform it into the
                // TxBuildRequest shape the indexer build methods expect.
                const buildReq = (0, build_request_1.prepareWorkerBuildRequest)(job.kind, rawReq, this.deps.network);
                // Fencing: if the lease was lost (instance stalled past the TTL, another
                // instance may have taken over the wallet), abort BEFORE building — the
                // orphan cleanup will fail the row once the lease is provably dead.
                if (!(await heartbeat.fence())) {
                    logger.warn(`Job ${job.ID}: wallet lease for ${job.walletId} lost before build — aborting execution`);
                    return;
                }
                const buildResult = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => this.buildForKind(tx, job, buildReq)));
                unsignedTxCbor = buildResult.unsignedTxCbor;
                fee = buildResult.fee ?? null;
                buildId = buildResult.id ?? null;
                signedTxCbor = signer.signTransaction(unsignedTxCbor, buildResult.txBodyHash);
            }
            // The hash comes from the signed bytes, not from the submit response, so the
            // row can name the transaction before anyone has seen it.
            const txHash = (0, tx_build_helper_1.getTxHashFromCbor)(signedTxCbor);
            // Last fence before the irreversible part. Build+sign just consumed real time;
            // if the wallet moved to another instance meanwhile, that instance is entitled
            // to spend the same UTxOs — submitting now would race it. Nothing has been sent
            // yet, so standing down here costs only a rebuild.
            if (!(await heartbeat.fence())) {
                logger.warn(`Job ${job.ID}: wallet lease for ${job.walletId} lost after signing — NOT submitting tx ${txHash}`);
                return;
            }
            // Point of no return: commit the signed tx BEFORE it can reach a backend.
            // A crash after this leaves a `submitting` row that reconciliation resolves;
            // a crash before it leaves a `building` row that was provably never sent.
            // The guard on `building` is also the second half of the fence: if a takeover
            // already failed this row, the transition returns false and nothing is sent.
            const stored = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.markSubmitting)(tx, job.ID, { txHash, unsignedTxCbor, signedTxCbor, fee })));
            if (!stored) {
                logger.warn(`Job ${job.ID}: submitting transition was fenced — not submitting (another executor owns this job)`);
                return;
            }
            await this.submitStoredTransaction(job, { txHash, signedTxCbor, buildId, attempt });
        }
        catch (err) {
            await this.handleExecutionFailure(job, attempt, err);
        }
        finally {
            heartbeat.stop();
            await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.releaseWalletLease)(tx, job.walletId, instanceId)))
                .catch(() => undefined);
        }
    }
    /**
     * Send a transaction that is already durable in its `submitting` row and advance
     * the job to `submitted`.
     *
     * A submit failure is NEVER propagated as a job failure here: a rejection from one
     * backend does not prove the tx is absent from every mempool (failover, timeouts,
     * a node that accepted before the connection dropped). The row simply stays
     * `submitting` and the next tick reconciles it against the chain.
     */
    async submitStoredTransaction(job, tx) {
        let submittedHash;
        try {
            submittedHash = await this.submitWithAlreadyKnownTolerance(tx.signedTxCbor);
        }
        catch (err) {
            logger.error(`Job ${job.ID}: submit failed for tx ${tx.txHash} — job stays submitting for chain reconciliation:`, err);
            return;
        }
        if (job.kind !== 'submitSigned') {
            // Observability parity with the synchronous flow: record the submission row.
            await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((t) => this.deps.indexer.persistTransactionSubmission(t, { signedTxCbor: tx.signedTxCbor, txHash: submittedHash, buildId: tx.buildId }))).catch((err) => logger.warn(`Job ${job.ID}: submission bookkeeping failed (job continues):`, err));
        }
        await this.adoptSubmitted(job, submittedHash, tx.signedTxCbor);
        logger.info(`Job ${job.ID} (wallet ${job.walletId}, kind ${job.kind}): submitted as ${submittedHash} (attempt ${tx.attempt})`);
    }
    /** submitting → submitted + hand to the confirmation tracker. */
    async adoptSubmitted(job, txHash, signedTxCbor) {
        const submitted = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.markSubmitted)(tx, job.ID, txHash)));
        if (!submitted) {
            logger.error(`Job ${job.ID}: tx ${txHash} is out there but the submitted transition was fenced — tracker adopts the tx anyway`);
        }
        this.tracker.track({
            jobId: job.ID,
            walletId: job.walletId,
            kind: job.kind,
            txHash,
            signedTxCbor,
            submittedAt: job.submittedAt ?? new Date().toISOString(),
        });
    }
    /**
     * Resolve a `submitting` job whose submit outcome is unknown (process died around
     * the network call, or the call failed ambiguously). The stored transaction is the
     * only one this job may ever have — it is re-submitted verbatim, never rebuilt.
     *
     * 1. Re-submit the same CBOR: mempool/ledger dedup makes this a no-op if it was
     *    accepted before, so success (or "already known") simply promotes the job.
     * 2. If that fails, ask the chain: found → the tx did make it, promote it.
     * 3. Only when the chain proves absence AND the node rejects the tx for good (or
     *    it has been absent past the confirmation timeout) is the job failed —
     *    failing releases the idempotency key, so it needs that proof.
     * Anything else leaves the row as-is; the next tick tries again.
     *
     * Runs under the same heartbeat-kept wallet lease as an execution: the chain
     * lookups here are slow enough to outlive the raw TTL. Losing the lease mid-way
     * is not dangerous (the re-submit is the same transaction, and every terminal
     * transition is row-guarded), so it only stops further work.
     */
    async reconcileSubmitting(job) {
        const { instanceId } = this.deps;
        const heartbeat = this.leaseHeartbeat(job.walletId);
        try {
            if (!job.signedTxCbor || !job.txHash) {
                // Cannot happen via markSubmitting; treat as a never-sent job rather than
                // leaving the wallet queue blocked forever.
                logger.error(`Job ${job.ID}: submitting row without signed transaction — failing as PROCESS_RESTART`);
                await this.failReconciled(job, job_store_1.JOB_ERROR_CODES.PROCESS_RESTART, new Error('Job was interrupted before its signed transaction was stored.'));
                return;
            }
            logger.warn(`Job ${job.ID}: reconciling interrupted submit of tx ${job.txHash}`);
            let submitError;
            try {
                const txHash = await this.submitWithAlreadyKnownTolerance(job.signedTxCbor);
                await this.adoptSubmitted(job, txHash, job.signedTxCbor);
                logger.info(`Job ${job.ID}: re-submitted the original signed tx (${txHash}) — now awaiting confirmation`);
                return;
            }
            catch (err) {
                submitError = err;
            }
            // The tx may have been rejected precisely BECAUSE it is already on-chain
            // (its inputs are spent), so the chain — not the rejection — decides.
            let onChain;
            try {
                await this.deps.client.getTransaction(job.txHash);
                onChain = true;
            }
            catch (lookupErr) {
                if (!(0, errors_1.isNotFoundOnAllBackends)(lookupErr)) {
                    logger.warn(`Job ${job.ID}: chain lookup for ${job.txHash} inconclusive — retrying next tick:`, lookupErr);
                    return;
                }
                onChain = false;
            }
            if (onChain) {
                logger.info(`Job ${job.ID}: tx ${job.txHash} is on-chain despite the failed submit — awaiting confirmation`);
                await this.adoptSubmitted(job, job.txHash, job.signedTxCbor);
                return;
            }
            const ageMs = job.submittedAt ? Date.now() - Date.parse(job.submittedAt) : 0;
            const expired = ageMs > this.deps.config.confirmationTimeoutMs;
            if (isTransientJobError(submitError) && !expired) {
                logger.warn(`Job ${job.ID}: re-submit failed transiently and tx is not on-chain — retrying next tick:`, submitError);
                return;
            }
            // Proven absent + a rejection that will not change (or a tx that is past its
            // mempool lifetime): no transaction of this job can reach the chain anymore,
            // so releasing the idempotency key is safe.
            const code = expired ? job_store_1.JOB_ERROR_CODES.TX_DROPPED : job_store_1.JOB_ERROR_CODES.SUBMIT_REJECTED;
            logger.error(`Job ${job.ID}: tx ${job.txHash} is not on-chain and cannot be submitted (${code}) — failing:`, submitError);
            await this.failReconciled(job, code, submitError);
        }
        finally {
            heartbeat.stop();
            await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.releaseWalletLease)(tx, job.walletId, instanceId)))
                .catch(() => undefined);
        }
    }
    async failReconciled(job, code, err) {
        await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx(async (tx) => {
            const transitioned = await (0, job_store_1.markFailed)(tx, job.ID, code, err ?? new Error(code));
            if (transitioned)
                await (0, job_store_1.bumpWalletStats)(tx, job.walletId, 'failed');
        })).catch((persistErr) => logger.error(`Job ${job.ID}: failure persist failed:`, persistErr));
    }
    /** Dispatch the job kind to the matching indexer build method. */
    buildForKind(tx, job, buildReq) {
        const indexer = this.deps.indexer;
        switch (job.kind) {
            case 'simpleAda': return indexer.indexSimpleBuildResult(tx, buildReq);
            case 'metadata': return indexer.indexMetadataBuildResult(tx, buildReq);
            case 'multiAsset': return indexer.indexMultiAssetBuildResult(tx, buildReq);
            case 'mint': return indexer.indexMintBuildResult(tx, buildReq);
            case 'plutusSpend': return indexer.indexPlutusSpendBuildResult(tx, buildReq);
            default:
                throw new errors_1.BackendError(`Unsupported job kind "${job.kind}"`, 400, error_codes_1.ERROR_CODES.INVALID_INPUT);
        }
    }
    /**
     * Submit tolerant of "already known": after a crash between submit and the
     * `submitted` transition, the retry re-submits the same CBOR — mempool dedup
     * answers with an already-submitted error that IS our success case.
     */
    async submitWithAlreadyKnownTolerance(signedTxCbor) {
        try {
            return await this.deps.client.submitTransaction(signedTxCbor);
        }
        catch (err) {
            if (err instanceof errors_1.TransactionAlreadySubmittedError) {
                const txHash = (0, tx_build_helper_1.getTxHashFromCbor)(signedTxCbor);
                logger.info(`Submit reported tx already known — treating as success (${txHash})`);
                return txHash;
            }
            throw err;
        }
    }
    async handleExecutionFailure(job, attempt, err) {
        // Only a pre-submit job may be re-queued (rebuild) or failed from here. Once the
        // row is `submitting`, a signed tx exists that may be in a mempool: rebuilding it
        // would double-pay and failing it would release the idempotency key on a
        // transaction the chain has not ruled on. Those rows go to reconciliation.
        const current = await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.getJobById)(tx, job.ID)))
            .catch(() => null);
        if (current && current.status !== 'building') {
            logger.error(`Job ${job.ID}: execution error while ${current.status} — leaving the outcome to reconciliation:`, err);
            return;
        }
        if (isTransientJobError(err) && attempt < job.maxAttempts) {
            const backoff = retryBackoffMs(attempt);
            logger.warn(`Job ${job.ID}: transient failure on attempt ${attempt}/${job.maxAttempts} — retrying in ${backoff}ms:`, err);
            await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx((tx) => (0, job_store_1.requeueForRetry)(tx, job.ID, err, new Date(Date.now() + backoff).toISOString()))).catch((persistErr) => logger.error(`Job ${job.ID}: retry re-queue failed:`, persistErr));
            return;
        }
        const code = isTransientJobError(err) ? job_store_1.JOB_ERROR_CODES.RETRIES_EXHAUSTED : terminalErrorCode(err);
        logger.error(`Job ${job.ID}: failed terminally (${code}) on attempt ${attempt}:`, err);
        await (0, job_store_1.runWithoutAmbientTx)(() => cds_1.default.tx(async (tx) => {
            const transitioned = await (0, job_store_1.markFailed)(tx, job.ID, code, err);
            if (transitioned)
                await (0, job_store_1.bumpWalletStats)(tx, job.walletId, 'failed');
        })).catch((persistErr) => logger.error(`Job ${job.ID}: failure persist failed:`, persistErr));
    }
}
exports.CardanoWalletWorker = CardanoWalletWorker;
//# sourceMappingURL=wallet-worker.js.map