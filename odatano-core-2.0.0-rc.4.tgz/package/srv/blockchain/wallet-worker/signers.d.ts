import type { WorkerSignerTypeValue } from './job-store';
/**
 * Wallet-worker signers (v2.0).
 *
 * `WorkerSigner` is the signer-agnostic surface the worker engine executes against:
 *  - `hsm` (production): thin wrapper around the already-initialized `HsmSigner`
 *    (PKCS#11 — keys never leave the module).
 *  - `software` (dev/test): operator-configured Ed25519 key from an environment
 *    variable, either plain 64-char hex or AES-256-GCM encrypted
 *    (`iv:authTag:ciphertext`, keyed by ENCRYPTION_KEY — see srv/utils/crypto.ts).
 *
 * Keys are NEVER accepted through the OData surface and never persisted; the
 * software key lives only in this process's memory.
 */
export interface WorkerSigner {
    readonly type: WorkerSignerTypeValue;
    /** Bech32 enterprise address the wallet spends from. */
    getAddress(): string;
    /** Blake2b-224 hash of the verification key (for requiredSigners). */
    getPublicKeyHash(): string;
    /** Sign the tx body hash and return the fully signed transaction CBOR (hex). */
    signTransaction(unsignedTxCbor: string, txBodyHash: string): string;
}
/** Operator wallet entry from config (see loadWalletWorkerConfigFromEnv). */
export interface WorkerWalletConfig {
    walletId: string;
    signerType: WorkerSignerTypeValue;
    /**
     * software only: name of the environment variable holding the Ed25519 signing
     * key — plain 64-char hex, or AES-256-GCM `iv:authTag:ciphertext` (base64 parts).
     */
    keyEnv?: string;
}
/**
 * Merge a single VKey witness [publicKey, signature] into an unsigned transaction's
 * witness set at the raw CBOR level, preserving all non-vkey entries (scripts,
 * datums, redeemers) and encoding metadata. Same single-signer semantics as
 * HsmSigner.signTransaction — the worker wallet is the sole signer of its builds.
 */
export declare function mergeVkeyWitness(unsignedTxCbor: string, publicKeyHex: string, signatureHex: string): string;
/** Derive the bech32 enterprise key-hash address for a 28-byte key hash. */
export declare function deriveEnterpriseAddress(publicKeyHash: Uint8Array, network: string): string;
/** software — in-memory Ed25519 key (dev/test). */
export declare class SoftwareWorkerSigner implements WorkerSigner {
    readonly type: "software";
    private readonly privateKey;
    private readonly publicKeyHex;
    private readonly publicKeyHashHex;
    private readonly address;
    constructor(privateKeyHex: string, network: string);
    getAddress(): string;
    getPublicKeyHash(): string;
    signTransaction(unsignedTxCbor: string, txBodyHash: string): string;
}
/** Build the signer for a configured worker wallet. Throws ConfigError on bad setup. */
export declare function createWorkerSigner(wallet: WorkerWalletConfig, network: string): WorkerSigner;
//# sourceMappingURL=signers.d.ts.map