"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfirmationTracker = void 0;
const cds_1 = __importDefault(require("@sap/cds"));
const errors_1 = require("../../utils/errors");
const hooks_1 = require("../crawler/hooks");
const job_store_1 = require("./job-store");
const logger = cds_1.default.log('CardanoWalletWorker');
class ConfirmationTracker {
    deps;
    pending = new Map();
    blockListener = (event) => this.onBlockIndexed(event);
    reorgListener = (event) => { void this.onReorg(event); };
    pollTimer = null;
    running = false;
    polling = false;
    lastKnownTipHeight = null;
    constructor(deps) {
        this.deps = deps;
    }
    start() {
        if (this.running)
            return;
        this.running = true;
        (0, hooks_1.registerBlockIndexedListener)(this.blockListener);
        (0, hooks_1.registerReorgListener)(this.reorgListener);
        this.pollTimer = setInterval(() => { void this.pollOnce(); }, this.deps.options.pollIntervalMs);
        this.pollTimer.unref?.();
    }
    stop() {
        this.running = false;
        (0, hooks_1.unregisterBlockIndexedListener)(this.blockListener);
        (0, hooks_1.unregisterReorgListener)(this.reorgListener);
        if (this.pollTimer) {
            clearInterval(this.pollTimer);
            this.pollTimer = null;
        }
        this.pending.clear();
    }
    /** Number of jobs currently awaiting confirmation. */
    size() {
        return this.pending.size;
    }
    /** Register a submitted job for confirmation watching. Idempotent per jobId. */
    track(job) {
        if (this.pending.has(job.jobId))
            return;
        this.pending.set(job.jobId, {
            jobId: job.jobId,
            walletId: job.walletId,
            kind: job.kind ?? null,
            txHash: job.txHash,
            signedTxCbor: job.signedTxCbor,
            submittedAt: job.submittedAt ?? new Date().toISOString(),
            foundSlot: job.confirmedSlot ?? null,
            foundHeight: job.confirmedHeight ?? null,
        });
    }
    // ---- Crawler hook path -----------------------------------------------------
    onBlockIndexed(event) {
        if (!this.running || this.pending.size === 0)
            return;
        const tipHeight = event.tipHeight ?? event.height;
        if (tipHeight != null) {
            this.lastKnownTipHeight = Math.max(this.lastKnownTipHeight ?? 0, tipHeight);
        }
        const txHashes = new Set(event.txHashes);
        const found = [...this.pending.values()].filter(j => j.foundHeight == null && txHashes.has(j.txHash));
        // Persist + depth-check detached: hook callers (the crawler) must not await us.
        void (async () => {
            for (const job of found) {
                job.foundSlot = event.slot;
                job.foundHeight = event.height;
                try {
                    await cds_1.default.tx((tx) => (0, job_store_1.recordConfirmationPoint)(tx, job.jobId, { slot: event.slot, height: event.height }));
                    logger.info(`Job ${job.jobId}: tx ${job.txHash} included in block ${event.hash} (height ${event.height})`);
                }
                catch (err) {
                    logger.warn(`Job ${job.jobId}: failed to persist confirmation point (will retry via polling):`, err);
                }
            }
            await this.confirmMature();
        })();
    }
    async onReorg(event) {
        if (!this.running)
            return;
        // The pre-fork tip no longer exists — clamp (or drop) lastKnownTipHeight so
        // confirmations are never counted against it. Without this, a tx re-included
        // on the new chain would reach "depth" instantly via the stale tip height,
        // defeating the confirmation-depth guarantee exactly in the rollback case.
        if (event.forkHeight != null) {
            if (this.lastKnownTipHeight != null && this.lastKnownTipHeight > event.forkHeight) {
                this.lastKnownTipHeight = event.forkHeight;
            }
        }
        else {
            this.lastKnownTipHeight = null; // unknown fork height → re-learn from the next block/poll
        }
        for (const job of this.pending.values()) {
            if (job.foundSlot != null && job.foundSlot > event.forkSlot) {
                logger.warn(`Job ${job.jobId}: confirmation point (slot ${job.foundSlot}) rolled back past fork ${event.forkSlot} — re-watching`);
                job.foundSlot = null;
                job.foundHeight = null;
                try {
                    await cds_1.default.tx((tx) => (0, job_store_1.clearConfirmationPoint)(tx, job.jobId));
                }
                catch (err) {
                    logger.warn(`Job ${job.jobId}: failed to clear confirmation point:`, err);
                }
                if (this.deps.options.resubmitOnRollback && job.signedTxCbor) {
                    // SAME signed CBOR only — never a rebuild. "Already known" means the tx
                    // survived into the new chain's mempool; that is success, not an error.
                    try {
                        await this.deps.client.submitTransaction(job.signedTxCbor);
                        logger.info(`Job ${job.jobId}: re-submitted original signed tx after rollback`);
                    }
                    catch (err) {
                        if (err instanceof errors_1.TransactionAlreadySubmittedError) {
                            logger.debug(`Job ${job.jobId}: tx already known after rollback — nothing to do`);
                        }
                        else {
                            logger.warn(`Job ${job.jobId}: rollback re-submit failed (polling continues to watch):`, err);
                        }
                    }
                }
            }
        }
    }
    // ---- Polling path ------------------------------------------------------------
    /** One polling round. Public for tests; guarded against overlapping rounds. */
    async pollOnce() {
        if (!this.running || this.polling || this.pending.size === 0)
            return;
        this.polling = true;
        try {
            // Tip first — also serves the depth check for hook-found entries when the
            // crawler is off.
            try {
                const tip = await this.deps.client.getLatestBlock();
                if (tip.height != null) {
                    this.lastKnownTipHeight = Math.max(this.lastKnownTipHeight ?? 0, tip.height);
                }
            }
            catch (err) {
                logger.debug('Confirmation polling: tip lookup failed (skipping round):', err);
                return;
            }
            for (const job of [...this.pending.values()]) {
                if (job.foundHeight != null)
                    continue;
                try {
                    const tx = await this.deps.client.getTransaction(job.txHash);
                    job.foundSlot = tx.slot ?? null;
                    job.foundHeight = tx.blockHeight ?? null;
                    await cds_1.default.tx((t) => (0, job_store_1.recordConfirmationPoint)(t, job.jobId, { slot: job.foundSlot, height: job.foundHeight }));
                    logger.info(`Job ${job.jobId}: tx ${job.txHash} found on-chain at height ${job.foundHeight} (polling)`);
                }
                catch (err) {
                    // The client's failover wraps per-backend 404s into AllBackendsFailedError,
                    // so a plain `instanceof NotFoundError` check never fires — the helper also
                    // accepts "every consulted backend said 404" as proof of absence.
                    if ((0, errors_1.isNotFoundOnAllBackends)(err)) {
                        // Not on-chain yet — check the mempool-TTL timeout.
                        const age = Date.now() - Date.parse(job.submittedAt);
                        if (age > this.deps.options.confirmationTimeoutMs) {
                            await this.finalize(job, 'failed', job_store_1.JOB_ERROR_CODES.TX_DROPPED, new Error(`Transaction ${job.txHash} not seen on-chain within ${this.deps.options.confirmationTimeoutMs}ms of submission`));
                        }
                    }
                    else {
                        logger.debug(`Job ${job.jobId}: confirmation lookup failed (transient, next round retries):`, err);
                    }
                }
            }
            await this.confirmMature();
        }
        finally {
            this.polling = false;
        }
    }
    // ---- Shared -----------------------------------------------------------------
    /** Confirm every found job whose depth requirement is met by the known tip. */
    async confirmMature() {
        const tip = this.lastKnownTipHeight;
        if (tip == null)
            return;
        for (const job of [...this.pending.values()]) {
            if (job.foundHeight == null)
                continue;
            const confirmations = tip - job.foundHeight + 1;
            if (confirmations >= this.deps.options.confirmationDepth) {
                await this.finalize(job, 'confirmed');
            }
        }
    }
    async finalize(job, outcome, errorCode, err) {
        try {
            await cds_1.default.tx(async (tx) => {
                const transitioned = outcome === 'confirmed'
                    ? await (0, job_store_1.markConfirmed)(tx, job.jobId)
                    : await (0, job_store_1.markFailed)(tx, job.jobId, errorCode ?? 'FAILED', err ?? new Error('unknown'));
                if (transitioned) {
                    await (0, job_store_1.bumpWalletStats)(tx, job.walletId, outcome);
                }
            });
        }
        catch (persistErr) {
            logger.error(`Job ${job.jobId}: failed to persist terminal state ${outcome} (next round retries):`, persistErr);
            return; // keep tracking — the next poll round retries the transition
        }
        this.pending.delete(job.jobId);
        logger.info(`Job ${job.jobId}: ${outcome}${outcome === 'failed' ? ` (${errorCode})` : ''}`);
        this.deps.onFinal?.({
            jobId: job.jobId,
            walletId: job.walletId,
            outcome,
            kind: job.kind,
            txHash: job.txHash,
            errorCode,
            errorMessage: err instanceof Error ? err.message : err != null ? String(err) : undefined,
        });
    }
}
exports.ConfirmationTracker = ConfirmationTracker;
//# sourceMappingURL=confirmation-tracker.js.map