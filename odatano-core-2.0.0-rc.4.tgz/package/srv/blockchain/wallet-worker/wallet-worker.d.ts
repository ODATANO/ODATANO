import type { CardanoClient } from '../cardano-client';
import type { CardanoIndexer } from '../cardano-indexer';
import { type WorkerSigner, type WorkerWalletConfig } from './signers';
/**
 * Wallet worker engine (v2.0, design §6).
 *
 * Dispatch loop over `CardanoWalletJobs`: per tick, for every configured wallet
 * with pending work and NO active job (building or submitted — the queue stays
 * blocked until the previous job CONFIRMS, which makes per-wallet UTxO contention
 * impossible by construction), acquire the per-wallet DB lease and execute:
 *
 *   building   → CardanoIndexer.index<Kind>BuildResult (build + TransactionBuilds row)
 *              → signer.signTransaction
 *   submitting → signed CBOR + hash committed, THEN client.submitTransaction
 *   submitted  → hand to the ConfirmationTracker (crawler hook or polling)
 *
 * The `submitting` commit is what makes the submit boundary crash-safe: the exact
 * bytes that may be on-chain are durable before the network call, and the row stays
 * non-terminal, so it keeps holding its idempotency key. Anything that goes wrong
 * from there on is reconciled against the chain (`reconcileSubmitting`) — the same
 * transaction is re-submitted, never a rebuild.
 *
 * Transient failures BEFORE the signed tx exists (provider outages, rate limits,
 * HSM hiccups during build/sign) re-queue the job with exponential backoff up to
 * `maxAttempts`; deterministic rejections (validation, insufficient funds) fail
 * immediately.
 *
 * All DB access runs in short fresh transactions (ambient context cleared —
 * NIGHTGATE lesson 2) so the single pooled SQLite connection is never held
 * across build/submit round-trips.
 */
export interface WalletWorkerConfig {
    enabled: boolean;
    wallets: WorkerWalletConfig[];
    maxConcurrentWallets: number;
    confirmationDepth: number;
    confirmationTimeoutMs: number;
    pollIntervalMs: number;
    defaultMaxAttempts: number;
    resubmitOnRollback: boolean;
}
export interface WalletWorkerDeps {
    client: CardanoClient;
    indexer: CardanoIndexer;
    network: string;
    config: WalletWorkerConfig;
    instanceId: string;
}
/** Retry backoff: 5s · 2^(attempt-1), capped at 60s. */
export declare function retryBackoffMs(attempt: number): number;
/**
 * Transient errors are worth a bounded retry; everything else is deterministic
 * (a retry cannot change the outcome) and fails the job immediately.
 */
export declare function isTransientJobError(err: unknown): boolean;
export declare class CardanoWalletWorker {
    private readonly deps;
    private readonly signers;
    private readonly executing;
    private readonly executionPromises;
    private readonly tracker;
    private dispatchTimer;
    private running;
    private ticking;
    constructor(deps: WalletWorkerDeps);
    isRunning(): boolean;
    /** Wallets this instance can sign for (signer init succeeded). */
    getWalletIds(): string[];
    getSigner(walletId: string): WorkerSigner | undefined;
    /** Live status summary for the control service. */
    getStatusSummary(): {
        running: boolean;
        wallets: string[];
        executing: string[];
        awaitingConfirmation: number;
    };
    start(): Promise<void>;
    stop(): Promise<void>;
    /** One dispatch round; serialized (overlapping timers collapse into one run). */
    private tickSafe;
    private tick;
    /**
     * Adopt `submitting` rows left behind by a dead executor (this process before a
     * restart, or another instance whose lease expired) and resolve them against the
     * chain. Runs per wallet under the same lease the executor would hold.
     */
    private reconcileOrphanedSubmissions;
    /** Run one wallet's work in the background, tracked for concurrency + shutdown. */
    private spawn;
    /** A heartbeat that keeps this instance's lease on `walletId` alive while it works. */
    private leaseHeartbeat;
    /**
     * Execute one job: building → (build → sign) → submitting → submit → submitted,
     * then hand to the tracker. The wallet lease is held for the duration — renewed by
     * a heartbeat, because build+sign can outlast its TTL — and released afterwards
     * (queue serialization continues via the job row, not the lease).
     *
     * Everything up to and including the `submitting` commit may fail freely — nothing
     * has been sent, so the job re-queues or fails normally. Past that commit the job
     * belongs to `reconcileSubmitting`.
     */
    private executeJob;
    /**
     * Send a transaction that is already durable in its `submitting` row and advance
     * the job to `submitted`.
     *
     * A submit failure is NEVER propagated as a job failure here: a rejection from one
     * backend does not prove the tx is absent from every mempool (failover, timeouts,
     * a node that accepted before the connection dropped). The row simply stays
     * `submitting` and the next tick reconciles it against the chain.
     */
    private submitStoredTransaction;
    /** submitting → submitted + hand to the confirmation tracker. */
    private adoptSubmitted;
    /**
     * Resolve a `submitting` job whose submit outcome is unknown (process died around
     * the network call, or the call failed ambiguously). The stored transaction is the
     * only one this job may ever have — it is re-submitted verbatim, never rebuilt.
     *
     * 1. Re-submit the same CBOR: mempool/ledger dedup makes this a no-op if it was
     *    accepted before, so success (or "already known") simply promotes the job.
     * 2. If that fails, ask the chain: found → the tx did make it, promote it.
     * 3. Only when the chain proves absence AND the node rejects the tx for good (or
     *    it has been absent past the confirmation timeout) is the job failed —
     *    failing releases the idempotency key, so it needs that proof.
     * Anything else leaves the row as-is; the next tick tries again.
     *
     * Runs under the same heartbeat-kept wallet lease as an execution: the chain
     * lookups here are slow enough to outlive the raw TTL. Losing the lease mid-way
     * is not dangerous (the re-submit is the same transaction, and every terminal
     * transition is row-guarded), so it only stops further work.
     */
    private reconcileSubmitting;
    private failReconciled;
    /** Dispatch the job kind to the matching indexer build method. */
    private buildForKind;
    /**
     * Submit tolerant of "already known": after a crash between submit and the
     * `submitted` transition, the retry re-submits the same CBOR — mempool dedup
     * answers with an already-submitted error that IS our success case.
     */
    private submitWithAlreadyKnownTolerance;
    private handleExecutionFailure;
}
//# sourceMappingURL=wallet-worker.d.ts.map