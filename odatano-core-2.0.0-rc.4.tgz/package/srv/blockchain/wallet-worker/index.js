"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startWalletWorker = startWalletWorker;
exports.stopWalletWorker = stopWalletWorker;
exports.isWalletWorkerRunning = isWalletWorkerRunning;
exports.getWalletWorker = getWalletWorker;
const cds_1 = __importDefault(require("@sap/cds"));
const node_crypto_1 = require("node:crypto");
const wallet_worker_1 = require("./wallet-worker");
const logger = cds_1.default.log('CardanoWalletWorker');
/**
 * Module-level singleton lifecycle for the wallet worker. Mirrors the crawler's
 * srv/blockchain/crawler/index.ts: one active worker per process, started
 * fire-and-forget from the server's `served` hook and controlled (pause/resume/
 * status) via the worker control service.
 *
 * Unlike the crawler there is no standby machinery: every instance may run a
 * dispatch loop — the per-WALLET DB leases decide which instance executes a
 * given wallet's jobs, so failover is inherent.
 */
let active = null;
let lifecycleQueue = Promise.resolve();
/** Start the worker (idempotent — a no-op when one is already running). */
async function startWalletWorker(deps) {
    return serializeLifecycle(async () => {
        if (active?.isRunning()) {
            logger.debug('startWalletWorker: already running');
            return;
        }
        if (active) {
            const previous = active;
            await previous.stop();
            if (active === previous)
                active = null;
        }
        const candidate = new wallet_worker_1.CardanoWalletWorker({
            ...deps,
            instanceId: deps.instanceId ?? `${process.pid}:${(0, node_crypto_1.randomUUID)()}`,
        });
        active = candidate;
        try {
            await candidate.start();
        }
        catch (err) {
            if (active === candidate)
                active = null;
            throw err;
        }
        if (!candidate.isRunning() && active === candidate)
            active = null;
    });
}
/** Stop the local worker (in-flight execution steps are awaited). */
async function stopWalletWorker() {
    return serializeLifecycle(async () => {
        const worker = active;
        if (!worker)
            return;
        await worker.stop();
        if (active === worker)
            active = null;
    });
}
/** Whether a worker is currently running in this process. */
function isWalletWorkerRunning() {
    return active?.isRunning() ?? false;
}
/** The active worker instance, or null. */
function getWalletWorker() {
    return active;
}
function serializeLifecycle(operation) {
    const result = lifecycleQueue.then(operation, operation);
    lifecycleQueue = result.catch(() => undefined);
    return result;
}
//# sourceMappingURL=index.js.map