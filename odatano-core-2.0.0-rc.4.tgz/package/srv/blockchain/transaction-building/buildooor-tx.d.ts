import type { CardanoTxBuilder } from "./cardano-tx";
import type { TxBuildRequest, TxBuildMintRequest, TxBuildPlutusSpendRequest, TxBuildContext, TxBuildResult, LedgerProtocolParameters } from "../../utils/types";
import { CardanoClient } from "../cardano-client";
/**
 * BuildooorTxBuilder - Implementation of CardanoTxBuilder using Buildooor library
 */
export declare class BuildooorTxBuilder implements CardanoTxBuilder {
    readonly name = "BuildooorTxBuilder";
    private txBuilder;
    private cardanoClient;
    private genesisInfos;
    private paramsFingerprint;
    /**
     * Chain cost-model arrays kept verbatim for language-view hashing. Maintained by
     * _mapCostModels (in lockstep with the named-key models the TxBuilder is built
     * with); consumed by _languageViewCostModels. Empty when the current parameters
     * carry no usable cost models (library defaults in effect).
     */
    private rawCostModelArrays;
    /**
     * Initialize the builder
     * @param client - The CardanoClient instance
     * @param protocolParams - Optional protocol parameters (if not provided, fetched from backend)
     */
    init(client: CardanoClient, protocolParams?: LedgerProtocolParameters): Promise<void>;
    /**
     * Rebuild the TxBuilder when the per-request protocol parameters differ from
     * the ones the current TxBuilder was constructed with. Buildooor's TxBuilder
     * has no setter for protocol params, but its constructor is cheap, so we
     * rebuild on change (effectively once per epoch) instead of staying frozen
     * at init-time parameters for the process lifetime.
     */
    private _ensureCurrentProtocolParameters;
    private _applyProtocolParameters;
    /**
     * Build unsigned transfer transaction (ADA-only or with native assets).
     */
    buildUnsignedTransfer(req: TxBuildRequest, ctx: TxBuildContext): Promise<TxBuildResult>;
    /**
     * Build unsigned transfer transaction with attached metadata.
     */
    buildUnsignedTransactionWithMetadata(req: TxBuildRequest, ctx: TxBuildContext): Promise<TxBuildResult>;
    /**
     * Shared non-script transfer build. The two public entry points only differ in
     * the optional pieces of the request they carry (assets/outputDatum on the
     * plain-transfer path, metadataJson on the metadata path) — all handled here
     * conditionally on the field being present, so behaviour matches both.
     */
    private _buildSimpleTransfer;
    buildUnsignedMintTransaction(req: TxBuildMintRequest, ctx: TxBuildContext): Promise<TxBuildResult>;
    buildUnsignedPlutusSpendTransaction(req: TxBuildPlutusSpendRequest, ctx: TxBuildContext): Promise<TxBuildResult>;
    /** Extract CBOR, hash, fee, size, inputs and outputs from a built Buildooor Tx */
    private _extractTxDetails;
    /** Build the standard TxBuildResult object */
    private _buildResult;
    /**
     * Build a script-bearing transaction whose redeemers carry *real* execution units and
     * whose fee covers them.
     *
     * Background (verified against the vendored Buildooor source): `initTxBuild` constructs
     * every redeemer with a dummy budget — caller-supplied execution units in the build args
     * are never read — and `onEvaluationResult` unconditionally stamps each redeemer with
     * the budget the local CEK run consumed, even when the script failed (partial budget).
     * So the declared units are whatever the *local* evaluation produced, and any cushion
     * passed into the args silently evaporates. This method makes the declared units real:
     *
     *   1. First pass: build once; redeemers now carry the local CEK budgets.
     *   2. Evaluate that CBOR via Ogmios (when configured) for authoritative per-redeemer
     *      budgets, cushioned by EXECUTION_UNIT_BUFFER / ABS_*_BUFFER.
     *   3. Resolve target units per redeemer (Ogmios beats buffered-local; a local failure
     *      without an Ogmios result aborts — see makeScriptBuildOpts).
     *   4. Second pass with a fee floor covering the target units (Buildooor prices the fee
     *      from its own local budgets, so the floor adds the price + encoding-size delta).
     *   5. Stamp the target units into the redeemers and recompute scriptDataHash.
     */
    private _buildScriptTx;
    /**
     * Evaluate a transaction via Ogmios and return cushioned budgets keyed per redeemer
     * (`tag:index`). Returns undefined when the evaluation is unusable (transient backend
     * failure, empty result) so callers fall back to buffered local units. A
     * TransactionValidationError or ScriptValidationError from the evaluator is
     * authoritative (the script really failed on the ledger) and is rethrown.
     */
    private _evaluateExUnitsByRedeemer;
    /**
     * Combined cushion: relative multiplier catches proportional drift on large
     * validators, absolute floor catches sub-percent drift on small ones (observed
     * when metadata affects the real tx body vs the evaluator's ScriptContext).
     */
    private _applyExUnitBuffer;
    /**
     * Decide the execution units each redeemer must declare.
     * - Local run succeeded + Ogmios result → max of both (local is a real lower bound).
     * - Local run succeeded, no Ogmios → buffered local (cushions local↔ledger drift).
     * - Local run failed + Ogmios result → Ogmios (the local partial budget is meaningless).
     * - Local run failed, no Ogmios → abort: declaring unreliable units would forfeit the
     *   collateral of whoever signs and submits the returned CBOR.
     */
    private _resolveTargetExUnits;
    /** Fee delta of the target vs local units, priced like Buildooor's own fee loop. */
    private _exUnitsPriceDelta;
    /** CBOR size growth (bytes) from stamping larger budgets into the redeemers. */
    private _exUnitsSizeDelta;
    private _txFeePerByte;
    /**
     * Replace the redeemers' execution units and recompute scriptDataHash.
     *
     * Still not implemented via TxBuilder.overrideTxRedeemers, although buildooor
     * 0.2.9 fixed its old-witness-set hashing (our PR): that method hashes with the
     * builder's named-key cost models, which clamp the chain array to the parameter
     * count the library release knows — wrong whenever the on-chain cost model has
     * grown past that (ScriptIntegrityHashMismatch at submit). This recompute with
     * _languageViewCostModels (raw chain arrays) stays governance-proof, so the hash
     * is recomputed here even when the target units already match.
     */
    private _stampExecUnits;
    /**
     * Language-view selection for scriptDataHash, mirroring Buildooor's initTxBuild
     * (which flags the languages of *executed* scripts). This builder only attaches
     * scripts inline, so the witness set carries every executed script.
     */
    private _usedLanguageViewOpts;
    /**
     * Cost models for language-view hashing. The named-key objects the TxBuilder was
     * constructed with clamp the chain array to the parameter count this costmodels-ts
     * release knows (e.g. 297 for V3 pre-protocol-11), but the ledger hashes EVERY
     * entry the chain serves (350 on protocol-11 networks). toCostModelArrVN passes
     * array form through unclamped, so substitute the raw chain arrays where we have
     * them. (The named-key form stays in the TxBuilder — the CEK machine needs it.)
     */
    private _languageViewCostModels;
    /**
     * Split UTxOs into forced inputs (must be consumed) and remaining candidates (free for
     * coin selection / collateral). Refs in forceInputs that are not present in utxos are
     * silently ignored — the resolver upstream has already validated existence.
     */
    private _partitionForcedInputs;
    /**
     * Map resolved CIP-31 reference input UTxOs to Buildooor LedgerUTxO format.
     * Returns empty array when no reference inputs are provided.
     */
    private _mapReferenceInputs;
    /**
     * Funding requirement contributed by extra outputs on a mint build:
     * the summed lovelace of all entries plus, per asset unit, the demand the
     * transaction's own positive mints do NOT cover. Minted quantities are
     * aggregated per unit and subtracted from the aggregated output demand;
     * only a positive remainder is requested from the wallet (a fully covered
     * unit is not requested at all — it does not exist before this tx).
     */
    private _extraOutputsFundingAfterMint;
    /**
     * The script an individual mint action executes under: its own
     * per-action policy when set (multi-policy mint FR), else the request's
     * top-level policy script.
     */
    private _mintActionScript;
    /**
     * Build the Buildooor mint-entry array shared by the mint-only flow and the
     * combined spend+mint flow (Buildooor ignores caller-supplied execution units;
     * they are stamped into the redeemers post-build by _buildScriptTx).
     *
     * Multi-policy mint FR: each action may carry its own policy script and
     * redeemer; absent fields fall back to the request-level ones. The ledger
     * carries ONE redeemer per policy, so actions resolving to the same policy
     * must agree on their redeemer, checked here.
     */
    private _buildMintEntries;
    /**
     * Consumer-facing context for insufficient-funds rejections after the
     * collateral partition: the builder's own "not enough …" message counts only
     * the funding pool, and without this the reservation is invisible ("but the
     * address HAS enough ADA").
     */
    private _collateralPartitionContext;
    /**
     * Pick a collateral UTxO and return remaining funding UTxOs.
     * Throws if no ADA-only UTxO is available.
     *
     * Selection: the SMALLEST ADA-only UTxO that still covers the static
     * COLLATERAL_LOVELACE floor (5 ADA ≳ collateralPercentage × any realistic fee).
     * The previous "first ADA-only" pick failed both ways: a dust UTxO below
     * collateralPercentage × fee is rejected at submit, and a large UTxO is
     * fully forfeited on phase-2 failure (Buildooor sets no collateralReturn
     * for ADA-only collateral). Everything above the floor is therefore handed
     * back via an explicit collateralReturn when the excess satisfies min-ADA.
     */
    private _setupCollateral;
    /** Build a Ledger Value from lovelace + optional multi-asset array */
    private _buildLedgerValue;
    /** Build a TxOut with optional inline datum and optional reference script (CIP-33) */
    private _buildTxOut;
    /**
     * Parse a consumer-provided, CBOR-wrapped Plutus script and reject UPLC 1.0.0
     * code (PlutusV1/V2). `Script.fromCbor` defaults to PlutusV3, so V1/V2 bytes
     * would be hashed with the 0x03 prefix — a silently wrong script hash, i.e.
     * wrong policy IDs and unspendable script addresses with no error anywhere
     * down the line. The UPLC version is the first three flat-encoded naturals
     * of the unwrapped script: [1,0,0] (V1/V2) vs [1,1,0] (V3).
     */
    private _parsePlutusV3Script;
    /** Parse a Plutus V3 CBOR hex into a Buildooor Script for refScript attachment. */
    private _parseReferenceScript;
    /**
     * Map an input UTxO's scriptRef field to a Buildooor Script when possible.
     * UTxO.scriptRef is overloaded across backends: Blockfrost/Ogmios set it to a 28-byte
     * hash (56 hex chars), Koios sets it to the full CBOR script bytes. Only full bytes
     * are usable here — hash-only entries are preserved only on-chain, not in local eval.
     */
    private _buildInputRefScript;
    /**
     * Compute the post-sort input order so __INPUT_IDX__ placeholders (FR-3) resolve to the
     * same indices Buildooor will assign during build(). Order: script-input first by convention,
     * then forced + funding sorted lexicographically on (txHash, outputIndex).
     * Buildooor sorts ALL inputs together; we mirror that exact behaviour via sortInputsLikeBuildooor.
     */
    private _computeSortedInputs;
    /** Extract InputRef list from the Buildooor-shaped funding inputs returned by keepRelevant. */
    private _extractFundingRefs;
    /**
     * Resolve __INPUT_IDX__ placeholders (FR-3) inside each extraOutput.inlineDatum.
     * Returns a new array with resolved datums; non-datum fields pass through unchanged.
     */
    private _resolveExtraOutputPlaceholders;
    /**
     * Append parsed extraOutputs (FR-2) to the outputs array, enforcing min-ADA per entry.
     * Throws TransactionValidationError with the required min-ADA in the message so consumers
     * can adjust without having to inspect Buildooor internals.
     */
    private _appendExtraOutputs;
    /**
     * Resolve the transaction's validity window (slots) from the request.
     * Falls back to `now - 2 min` / `now + 1 h` when the request omits bounds.
     * Script-validated builds must call this; plain transfers pass their own
     * explicit bounds through (no defaulting) so replay behavior is opt-in.
     */
    private _resolveValiditySlots;
    /**
     * Map ODATANO LedgerProtocolParameter to Buildooor's ProtocolParameters shape.
     *
     * Every field is null-guarded: a missing/null source value keeps the library
     * default instead of degrading to 0 (`Number(null) === 0` previously set
     * utxoCostPerByte = 0, disabling min-ADA checks entirely). Cost models and
     * execution-unit prices are mapped because they feed the scriptDataHash
     * (language views) and the fee/ExUnits math — stale defaults there cause
     * PPViewHashesDontMatch or fee underestimation on-chain.
     */
    private _mapLedgerParametersToBuildooorParams;
    /**
     * Parse the cost-models JSON blob (backend-normalized number arrays, keys
     * 'PlutusV1'/'PlutusV2'/'PlutusV3' or Ogmios 'plutus:vN') into Buildooor's
     * CostModels shape ('PlutusScriptVN' keys). Returns undefined when nothing
     * usable is found, so the caller can keep defaults and warn.
     *
     * Side effect: (re)sets this.rawCostModelArrays with the unclamped chain arrays
     * for the versions mapped here — the named-key conversion drops every entry past
     * the parameter count this costmodels-ts release knows, and the scriptDataHash
     * must cover all of them (see _languageViewCostModels).
     */
    private _mapCostModels;
    /**
     * Map ODATANO UTxO to Ledger UTxO (ADA-only)
     */
    private _mapOdatanoUtxoToLedgerUtxo;
    /**
     * Map ODATANO UTxO to Ledger UTxO (with multi-asset support)
     */
    private _mapMultiAssetUtxoToLedgerUtxo;
    /**
     * Map ODATANO metadata JSON to Ledger TxMetadata
     */
    private _mapOdatanoMetadataToLedgerMetadata;
    /**
     * Recursively convert JSON value to TxMetadatum.
     *
     * Ledger rules enforced here (instead of a node-side rejection or a raw 500):
     * - numbers must be integers (BigInt(1.5) would throw a bare RangeError)
     * - text and byte values are limited to 64 BYTES per metadatum — longer values
     *   are chunked into a list of ≤64-byte pieces (the established convention,
     *   e.g. CIP-25 long strings)
     * - strings prefixed with "0x" (even hex length) become byte metadata
     * - map keys are not auto-chunked (readers match on the literal key) — over-long
     *   keys are rejected with a clear 400
     *
     * @param path position of `value` inside the metadata JSON (label-rooted, e.g.
     *             "1155.result" or "721.files[0].src") — named in every rejection
     *             so the consumer can locate the offending value.
     */
    private _jsonToTxMetadatum;
}
//# sourceMappingURL=buildooor-tx.d.ts.map