"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BuildooorTxBuilder = void 0;
// Coin selection uses this.txBuilder.keepRelevant again since buildooor 0.2.9
// ships the fixed implementation (our PR); the vendored keep-relevant.ts is gone.
const buildooor_1 = require("@harmoniclabs/buildooor");
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const tx_build_helper_1 = require("../../utils/tx-build-helper");
const errors_1 = require("../../utils/errors");
const plutus_placeholders_1 = require("../../utils/plutus-placeholders");
const cds_1 = __importDefault(require("@sap/cds"));
const cardano_ledger_ts_1 = require("@harmoniclabs/cardano-ledger-ts");
// Metadata classes are imported from the DIST paths ON PURPOSE: buildooor's
// AuxiliaryData/TxMetadata do internal `instanceof` checks against these exact
// dist-class identities, which differ from the package-root re-exports. Mixing
// root + dist identities breaks those checks at runtime. (See cbor-parse.test.)
const TxMetadata_1 = require("@harmoniclabs/cardano-ledger-ts/dist/tx/metadata/TxMetadata");
const TxMetadatum_1 = require("@harmoniclabs/cardano-ledger-ts/dist/tx/metadata/TxMetadatum");
const plutus_data_1 = require("@harmoniclabs/plutus-data");
const const_1 = require("../../utils/const");
const logger = cds_1.default.log('BuildooorTxBuilder');
/**
 * Build options for script-bearing transactions.
 *
 * Buildooor evaluates every Plutus script locally during `build()` and unconditionally
 * stamps each redeemer with the budget its local CEK run consumed (`onEvaluationResult`
 * in TxBuilder) — execution units passed in the build args are never read. Without an
 * `onScriptInvalid` handler a local evaluation failure aborts the build; *with* one the
 * redeemer is left carrying the partial budget consumed up to the error, which would
 * fail phase-2 on-chain and forfeit the collateral if signed and submitted.
 *
 * We therefore only record local failures here; `_buildScriptTx` decides afterwards:
 * an authoritative Ogmios evaluation overrides the local result (so local false
 * negatives — e.g. cost-model drift — don't block the build), while a failure without
 * Ogmios aborts with a clear error instead of returning an unsubmittable transaction.
 */
function makeScriptBuildOpts(failures) {
    return {
        onScriptInvalid: (rdmr, logs) => {
            failures.push({ tag: rdmr.tag, index: rdmr.index, logs: logs.slice() });
            logger.warn(`Plutus script failed local evaluation (redeemer ${(0, cardano_ledger_ts_1.txRedeemerTagToString)(rdmr.tag)}:${rdmr.index}); ` +
                `deferring to Ogmios evaluation if available. Logs: [${logs.join(', ')}]`);
        }
    };
}
const redeemerKey = (tag, index) => `${tag}:${index}`;
/** Ogmios RedeemerPointer purpose → ledger TxRedeemerTag (Ogmios v6 wire names). */
const PURPOSE_TO_TAG = {
    spend: cardano_ledger_ts_1.TxRedeemerTag.Spend,
    mint: cardano_ledger_ts_1.TxRedeemerTag.Mint,
    publish: cardano_ledger_ts_1.TxRedeemerTag.Cert,
    certificate: cardano_ledger_ts_1.TxRedeemerTag.Cert,
    withdraw: cardano_ledger_ts_1.TxRedeemerTag.Withdraw,
    withdrawal: cardano_ledger_ts_1.TxRedeemerTag.Withdraw
};
/** CBOR-encoded length in bytes of an unsigned integer head + payload. */
function cborUIntLength(n) {
    if (n < 24n)
        return 1n;
    if (n < 256n)
        return 2n;
    if (n < 65536n)
        return 3n;
    if (n < 4294967296n)
        return 5n;
    return 9n;
}
function ceilDiv(a, b) {
    return (a + b - 1n) / b;
}
function maxBig(a, b) {
    return a > b ? a : b;
}
/**
 * Parse a ledger protocol-parameter value (number or decimal string) into a
 * non-negative safe integer. Returns undefined for null/undefined/empty/invalid
 * input so callers can fall back to library defaults instead of silently
 * coercing to 0 (which e.g. disables min-ADA when applied to utxoCostPerByte).
 */
function toUInt(value) {
    if (value === null || value === undefined || value === '')
        return undefined;
    const n = Number(value);
    return Number.isSafeInteger(n) && n >= 0 ? n : undefined;
}
/** Parse a strictly positive finite number (e.g. exUnit prices); undefined when absent/invalid. */
function toPositiveNumber(value) {
    if (value === null || value === undefined || value === '')
        return undefined;
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? n : undefined;
}
/**
 * Stable identity of a protocol-parameter set. Params only change at epoch
 * boundaries, so network#epoch is sufficient; fall back to full JSON when
 * either field is missing.
 */
function protocolParamsFingerprint(p) {
    if (p.network && p.epoch !== undefined && p.epoch !== null)
        return `${p.network}#${p.epoch}`;
    return JSON.stringify(p);
}
/** Ledger limit for a single text/bytes metadatum (bytes, not characters). */
const METADATA_BYTE_LIMIT = 64;
/**
 * Split a string into pieces of at most maxBytes UTF-8 bytes each, never
 * splitting inside a code point (which would produce invalid UTF-8 on-chain).
 */
function chunkUtf8(str, maxBytes) {
    const chunks = [];
    let current = '';
    let currentBytes = 0;
    for (const ch of str) {
        const chBytes = Buffer.byteLength(ch, 'utf8');
        if (currentBytes + chBytes > maxBytes) {
            chunks.push(current);
            current = ch;
            currentBytes = chBytes;
        }
        else {
            current += ch;
            currentBytes += chBytes;
        }
    }
    if (current.length > 0 || chunks.length === 0)
        chunks.push(current);
    return chunks;
}
/**
 * BuildooorTxBuilder - Implementation of CardanoTxBuilder using Buildooor library
 */
class BuildooorTxBuilder {
    name = 'BuildooorTxBuilder';
    txBuilder;
    cardanoClient;
    genesisInfos;
    paramsFingerprint;
    /**
     * Chain cost-model arrays kept verbatim for language-view hashing. Maintained by
     * _mapCostModels (in lockstep with the named-key models the TxBuilder is built
     * with); consumed by _languageViewCostModels. Empty when the current parameters
     * carry no usable cost models (library defaults in effect).
     */
    rawCostModelArrays = {};
    /**
     * Initialize the builder
     * @param client - The CardanoClient instance
     * @param protocolParams - Optional protocol parameters (if not provided, fetched from backend)
     */
    async init(client, protocolParams) {
        this.cardanoClient = client;
        const params = protocolParams ?? await client.getProtocolParameters();
        const genesisInfos = const_1.GENESIS_INFOS_BY_NETWORK[client.network];
        if (!genesisInfos) {
            throw new errors_1.ConfigError(`BuildooorTxBuilder: no genesis presets for network "${client.network}"`);
        }
        this.genesisInfos = genesisInfos;
        this._applyProtocolParameters(params, protocolParamsFingerprint(params));
        logger.debug(`Initialized with protocol parameters and ${client.network} genesis infos`);
    }
    /**
     * Rebuild the TxBuilder when the per-request protocol parameters differ from
     * the ones the current TxBuilder was constructed with. Buildooor's TxBuilder
     * has no setter for protocol params, but its constructor is cheap, so we
     * rebuild on change (effectively once per epoch) instead of staying frozen
     * at init-time parameters for the process lifetime.
     */
    _ensureCurrentProtocolParameters(ctx) {
        const params = ctx.protocolParameters;
        if (!params)
            return;
        const fingerprint = protocolParamsFingerprint(params);
        if (fingerprint === this.paramsFingerprint)
            return;
        this._applyProtocolParameters(params, fingerprint);
        logger.info(`Refreshed protocol parameters (${fingerprint})`);
    }
    _applyProtocolParameters(params, fingerprint) {
        this.txBuilder = new buildooor_1.TxBuilder(this._mapLedgerParametersToBuildooorParams(params), this.genesisInfos);
        this.paramsFingerprint = fingerprint;
    }
    /**
     * Build unsigned transfer transaction (ADA-only or with native assets).
     */
    buildUnsignedTransfer(req, ctx) {
        return this._buildSimpleTransfer(req, ctx, 'transfer');
    }
    /**
     * Build unsigned transfer transaction with attached metadata.
     */
    buildUnsignedTransactionWithMetadata(req, ctx) {
        return this._buildSimpleTransfer(req, ctx, 'metadata transfer');
    }
    /**
     * Shared non-script transfer build. The two public entry points only differ in
     * the optional pieces of the request they carry (assets/outputDatum on the
     * plain-transfer path, metadataJson on the metadata path) — all handled here
     * conditionally on the field being present, so behaviour matches both.
     */
    async _buildSimpleTransfer(req, ctx, label) {
        try {
            this._ensureCurrentProtocolParameters(ctx);
            if (!ctx.utxos || ctx.utxos.length === 0) {
                throw new errors_1.InsufficientFundsError('lovelace', BigInt(req.lovelaceAmount || 0), 0n);
            }
            const recipientAddress = cardano_ledger_ts_1.Address.fromString(req.recipientAddress);
            const changeAddress = cardano_ledger_ts_1.Address.fromString(req.changeAddress ?? req.senderAddress);
            const amount = BigInt(String(req.lovelaceAmount));
            // Build output value (lovelace + optional native assets)
            let outputValue = cardano_ledger_ts_1.Value.lovelaces(amount);
            if (req.assets && req.assets.length > 0) {
                outputValue = this._buildLedgerValue(amount, req.assets);
            }
            const refScript = this._parseReferenceScript(req.referenceScript);
            const outputs = [this._buildTxOut(recipientAddress, outputValue, req.outputDatum, refScript)];
            // Partition: forced UTxOs become fixed inputs; rest is the coin-selection pool
            const { forced, rest } = this._partitionForcedInputs(ctx.utxos, req.forceInputs);
            const forcedInputs = forced.map(u => ({ utxo: this._mapMultiAssetUtxoToLedgerUtxo(u) }));
            const candidateInputs = rest.map(u => ({ utxo: this._mapMultiAssetUtxoToLedgerUtxo(u) }));
            // Coin selection on candidates only; forced inputs are prepended unconditionally
            const selected = this.txBuilder.keepRelevant(outputValue, candidateInputs);
            const inputs = [...forcedInputs, ...selected];
            logger.debug(`Coin selection: ${selected.length}/${candidateInputs.length} UTxOs selected (${forcedInputs.length} forced) for ${label}`);
            const metadata = req.metadataJson !== undefined && req.metadataJson !== null
                ? this._mapOdatanoMetadataToLedgerMetadata(req.metadataJson)
                : undefined;
            const validity = this._resolveValiditySlots(req, 'passthrough');
            const tx = await this.txBuilder.build({ inputs, outputs, changeAddress, ...(metadata && { metadata }), ...validity });
            logger.debug(`Built unsigned transaction successfully.`);
            return this._buildResult(req, ctx, this._extractTxDetails(tx), { forcedInputsUsed: forcedInputs.length });
        }
        catch (err) {
            (0, tx_build_helper_1.mapBuilderError)(err);
        }
    }
    async buildUnsignedMintTransaction(req, ctx) {
        // Set once the collateral partition is known — an insufficient-funds rejection
        // after that point is usually CAUSED by it, and the builder's message can't know.
        let coinSelectionContext;
        try {
            this._ensureCurrentProtocolParameters(ctx);
            const recipientAddress = cardano_ledger_ts_1.Address.fromString(req.recipientAddress);
            const changeAddress = cardano_ledger_ts_1.Address.fromString(req.changeAddress ?? req.senderAddress);
            // Parse the minting policy script once
            const script = this._parsePlutusV3Script(req.mintingPolicyScript, 'mintingPolicyScript');
            // Calculate total mint value for output (only positive quantities - mints, not burns).
            // Multi-policy mint FR: each action mints under ITS script (own or top-level).
            let mintValue = cardano_ledger_ts_1.Value.lovelaces(0n);
            for (const [index, mintAction] of req.mintActions.entries()) {
                const quantity = BigInt(mintAction.quantity);
                if (quantity > 0n) {
                    const actionScript = this._mintActionScript(mintAction, script, index);
                    const { assetName } = (0, tx_build_helper_1.parseAssetUnit)(mintAction.assetUnit);
                    mintValue = cardano_ledger_ts_1.Value.add(mintValue, cardano_ledger_ts_1.Value.singleAsset(actionScript.hash, Buffer.from(assetName, 'hex'), quantity));
                }
            }
            // Partition forced vs candidate UTxOs. Forced inputs are already committed;
            // collateral and coin selection operate on the remainder only.
            const { forced, rest } = this._partitionForcedInputs(ctx.utxos, req.forceInputs);
            const forcedInputs = forced.map(u => ({ utxo: this._mapMultiAssetUtxoToLedgerUtxo(u) }));
            // Collateral + funding separation (from candidates only — forced inputs cannot double as collateral)
            const { collateralUtxos, fundingUtxos, collateralReturn } = this._setupCollateral(rest);
            coinSelectionContext = this._collateralPartitionContext(collateralUtxos, fundingUtxos);
            const fundingLedgerUtxos = fundingUtxos.map(utxo => this._mapMultiAssetUtxoToLedgerUtxo(utxo));
            const allFundingInputs = fundingLedgerUtxos.map(utxo => ({ utxo }));
            // Coin selection: only need enough ADA from funding UTxOs (minted tokens come from
            // thin air). Extra outputs (FR-2 on mint) add their lovelace plus, per unit, the
            // demand the mint does NOT cover (e.g. minting 1 while placing 2 means 1 must come
            // from the wallet).
            let requiredFundingValue = cardano_ledger_ts_1.Value.lovelaces(BigInt(req.lovelaceAmount));
            if (req.extraOutputs && req.extraOutputs.length > 0) {
                const { lovelace, assets } = this._extraOutputsFundingAfterMint(req.mintActions, req.extraOutputs);
                requiredFundingValue = cardano_ledger_ts_1.Value.add(requiredFundingValue, this._buildLedgerValue(lovelace, assets));
            }
            const selectedFunding = this.txBuilder.keepRelevant(requiredFundingValue, allFundingInputs);
            const inputs = [...forcedInputs, ...selectedFunding];
            logger.debug(`Coin selection: ${selectedFunding.length}/${allFundingInputs.length} UTxOs selected (${forcedInputs.length} forced) for mint`);
            // FR-3: resolve __INPUT_IDX__ placeholders in mintRedeemer + inlineDatum after final input order is known.
            const sortedInputs = (0, plutus_placeholders_1.sortInputsLikeBuildooor)([
                ...forced.map(u => ({ txHash: u.txHash, outputIndex: u.outputIndex })),
                ...this._extractFundingRefs(selectedFunding)
            ]);
            const resolveCtx = { sortedInputs };
            const resolvedMintRedeemer = req.mintRedeemer
                ? (0, plutus_placeholders_1.resolveIndexPlaceholders)(req.mintRedeemer, resolveCtx)
                : undefined;
            const resolvedInlineDatum = req.inlineDatum
                ? (0, plutus_placeholders_1.resolveIndexPlaceholders)(req.inlineDatum, resolveCtx)
                : undefined;
            const resolvedExtraOutputs = this._resolveExtraOutputPlaceholders(req.extraOutputs, resolveCtx);
            // Build output — recipient gets the minted assets + min ADA. When extra
            // outputs are declared (FR-2 on mint) THEY carry the minted assets (each
            // token on its own output with its own datum, e.g. datum-bound predicate
            // tokens), so the primary output stays ADA(+datum)-only.
            let outputValue = cardano_ledger_ts_1.Value.lovelaces(BigInt(req.lovelaceAmount));
            if (!resolvedExtraOutputs || resolvedExtraOutputs.length === 0) {
                outputValue = cardano_ledger_ts_1.Value.add(outputValue, mintValue);
            }
            const refScript = this._parseReferenceScript(req.referenceScript);
            const outputs = [this._buildTxOut(recipientAddress, outputValue, resolvedInlineDatum, refScript)];
            // Append extra outputs, each independently min-ADA checked.
            this._appendExtraOutputs(outputs, resolvedExtraOutputs);
            // Mint entries for the build args (uses pre-resolved redeemers; per-action
            // redeemers resolve their own placeholders). Note: Buildooor ignores
            // caller-supplied execution units — the real units are stamped into the
            // redeemers post-build by _buildScriptTx.
            const mints = this._buildMintEntries(req.mintActions, script, resolvedMintRedeemer, resolveCtx);
            // CIP-31: map resolved reference input UTxOs to Buildooor LedgerUTxO format
            const readonlyRefInputs = this._mapReferenceInputs(ctx.referenceInputUtxos);
            // Resolve validity bounds once — both passes must share them so redeemer ExUnits
            // and fee computation stay consistent (a mismatch would force re-evaluation).
            const { invalidBefore, invalidAfter } = this._resolveValiditySlots(req, 'script');
            // CIP-20 / label-674 etc. auxiliary metadata. Must be identical across eval + final
            // passes since auxiliary_data affects both tx size (→ fee) and script data hash (indirectly via tx hash).
            const mintMetadata = req.metadataJson
                ? this._mapOdatanoMetadataToLedgerMetadata(req.metadataJson)
                : undefined;
            // Single set of build args — both internal passes and the Ogmios evaluation share
            // validity bounds and metadata so redeemer ExUnits and fee stay consistent.
            const buildParams = {
                inputs, outputs, changeAddress, mints,
                collaterals: collateralUtxos, requiredSigners: req.requiredSigners,
                invalidBefore, invalidAfter,
                ...(collateralReturn && { collateralReturn }),
                ...(mintMetadata && { metadata: mintMetadata }),
                ...(readonlyRefInputs.length > 0 && { readonlyRefInputs })
            };
            const tx = await this._buildScriptTx(buildParams, ctx.evaluateTransaction);
            logger.debug(`Built unsigned minting transaction successfully with fee: ${tx.body.fee.toString()}`);
            return this._buildResult(req, ctx, this._extractTxDetails(tx), { scriptHash: script.hash.toString(), forcedInputsUsed: forcedInputs.length, referenceInputsUsed: readonlyRefInputs.length });
        }
        catch (err) {
            (0, tx_build_helper_1.mapBuilderError)(err, undefined, coinSelectionContext);
        }
    }
    async buildUnsignedPlutusSpendTransaction(req, ctx) {
        // See buildUnsignedMintTransaction — same collateral-partition context for rejections.
        let coinSelectionContext;
        try {
            this._ensureCurrentProtocolParameters(ctx);
            const { plutusScriptExecution } = req;
            // Parse the validator script
            const script = this._parsePlutusV3Script(plutusScriptExecution.validatorScript, 'plutusScriptExecution.validatorScript');
            if (!plutusScriptExecution.datum) {
                // When no explicit datum is provided, the UTxO must have an inline datum.
                // If neither exists, the Plutus validator will fail with a cryptic error.
                logger.debug('No datumJson provided — expecting inline datum on script UTxO');
            }
            // Find the specific script UTxO in the provided context UTxOs
            const scriptUtxoRef = plutusScriptExecution.scriptUtxo;
            const scriptOdatanoUtxo = ctx.utxos.find(u => u.txHash === scriptUtxoRef.txHash && u.outputIndex === scriptUtxoRef.outputIndex);
            if (!scriptOdatanoUtxo) {
                throw new errors_1.TransactionValidationError(`Script UTxO ${scriptUtxoRef.txHash}#${scriptUtxoRef.outputIndex} not found in provided UTxOs`);
            }
            const scriptLedgerUtxo = this._mapMultiAssetUtxoToLedgerUtxo(scriptOdatanoUtxo);
            // Map sender UTxOs (excluding the script UTxO) as regular inputs
            const senderUtxos = ctx.utxos.filter(u => !(u.txHash === scriptUtxoRef.txHash && u.outputIndex === scriptUtxoRef.outputIndex));
            const recipientAddress = cardano_ledger_ts_1.Address.fromString(req.recipientAddress);
            const changeAddress = cardano_ledger_ts_1.Address.fromString(req.changeAddress ?? req.senderAddress);
            // Partition forced inputs (excluding any ref that matches the script UTxO — silently ignored)
            const forceInputsFiltered = (req.forceInputs ?? []).filter(r => !(r.txHash === scriptUtxoRef.txHash && r.outputIndex === scriptUtxoRef.outputIndex));
            const { forced, rest } = this._partitionForcedInputs(senderUtxos, forceInputsFiltered);
            const forcedInputs = forced.map(u => ({ utxo: this._mapMultiAssetUtxoToLedgerUtxo(u) }));
            // Collateral + funding separation (from candidates only — forced inputs cannot double as collateral)
            const { collateralUtxos, fundingUtxos, collateralReturn } = this._setupCollateral(rest);
            coinSelectionContext = this._collateralPartitionContext(collateralUtxos, fundingUtxos);
            const fundingLedgerUtxos = fundingUtxos.map(utxo => this._mapMultiAssetUtxoToLedgerUtxo(utxo));
            // Coin selection: funding UTxOs only need to cover fee + min change (script UTxO covers the output).
            // Extra outputs (FR-2) add their lovelace + assets to the requirement; assets that the script UTxO
            // already provides will net out, so over-requesting is harmless — keepRelevant prefers smaller sets.
            const allFundingInputs = fundingLedgerUtxos.map(utxo => ({ utxo }));
            let requiredFundingValue = cardano_ledger_ts_1.Value.lovelaces(BigInt(req.lovelaceAmount || const_1.MIN_CHANGE_LOVELACE));
            if (req.extraOutputs && req.extraOutputs.length > 0) {
                for (const extra of req.extraOutputs) {
                    requiredFundingValue = cardano_ledger_ts_1.Value.add(requiredFundingValue, this._buildLedgerValue(BigInt(extra.lovelaceAmount), extra.assets));
                }
            }
            const selectedFundingInputs = this.txBuilder.keepRelevant(requiredFundingValue, allFundingInputs);
            logger.debug(`Coin selection: ${selectedFundingInputs.length}/${allFundingInputs.length} UTxOs selected (${forcedInputs.length} forced) for Plutus spend`);
            // FR-3: compute the final input order (replicates Buildooor's lex sort) and resolve any
            // __INPUT_IDX__ placeholders in redeemer / datum / output datums BEFORE PlutusData encoding.
            const sortedInputs = this._computeSortedInputs(scriptUtxoRef, forced, this._extractFundingRefs(selectedFundingInputs));
            const resolveCtx = { sortedInputs };
            const resolvedRedeemer = (0, plutus_placeholders_1.resolveIndexPlaceholders)(plutusScriptExecution.redeemer, resolveCtx);
            const redeemerData = (0, tx_build_helper_1.jsonToPlutusData)(resolvedRedeemer);
            const datum = plutusScriptExecution.datum
                ? (0, tx_build_helper_1.jsonToPlutusData)((0, plutus_placeholders_1.resolveIndexPlaceholders)(plutusScriptExecution.datum, resolveCtx))
                : "inline";
            const resolvedPrimaryInlineDatum = req.inlineDatum
                ? (0, plutus_placeholders_1.resolveIndexPlaceholders)(req.inlineDatum, resolveCtx)
                : undefined;
            const resolvedExtraOutputs = this._resolveExtraOutputPlaceholders(req.extraOutputs, resolveCtx);
            const resolvedMintRedeemer = req.mintRedeemer
                ? (0, plutus_placeholders_1.resolveIndexPlaceholders)(req.mintRedeemer, resolveCtx)
                : undefined;
            // FR-1: combined spend+mint flow. When mintActions are present, build mints alongside the spend input.
            const hasMint = !!(req.mintActions && req.mintActions.length > 0 && req.mintingPolicyScript);
            let mintScript;
            let mintScriptHash;
            if (hasMint) {
                mintScript = this._parsePlutusV3Script(req.mintingPolicyScript, 'mintingPolicyScript');
                mintScriptHash = mintScript.hash.toString();
            }
            // Build outputs — include multi-assets from script UTxO in continuing output
            const scriptNonAdaAssets = scriptOdatanoUtxo.amount.filter(a => a.unit.toLowerCase() !== 'lovelace' && BigInt(a.quantity) > 0n);
            let outputValue = cardano_ledger_ts_1.Value.lovelaces(BigInt(req.lovelaceAmount || const_1.MIN_CHANGE_LOVELACE));
            if (scriptNonAdaAssets.length > 0) {
                outputValue = this._buildLedgerValue(BigInt(req.lovelaceAmount || const_1.MIN_CHANGE_LOVELACE), scriptOdatanoUtxo.amount);
            }
            // If mints are present and no extraOutputs handle the minted assets, attach positive mints to the primary output.
            if (hasMint && (!resolvedExtraOutputs || resolvedExtraOutputs.length === 0)) {
                for (const [index, action] of req.mintActions.entries()) {
                    const qty = BigInt(action.quantity);
                    if (qty > 0n) {
                        const actionScript = this._mintActionScript(action, mintScript, index);
                        const { assetName } = (0, tx_build_helper_1.parseAssetUnit)(action.assetUnit);
                        outputValue = cardano_ledger_ts_1.Value.add(outputValue, cardano_ledger_ts_1.Value.singleAsset(actionScript.hash, Buffer.from(assetName, 'hex'), qty));
                    }
                }
            }
            const primaryRefScript = this._parseReferenceScript(req.referenceScript);
            const outputs = [this._buildTxOut(recipientAddress, outputValue, resolvedPrimaryInlineDatum, primaryRefScript)];
            // Append extra outputs (FR-2). Each is independently min-ADA checked so consumers
            // get a clear, field-attributed error before Buildooor's coin selection runs.
            this._appendExtraOutputs(outputs, resolvedExtraOutputs);
            // Mint entries (FR-1) and inputs for the build args. Note: Buildooor ignores
            // caller-supplied execution units — the real units are stamped into the
            // redeemers post-build by _buildScriptTx.
            const mints = hasMint
                ? this._buildMintEntries(req.mintActions, mintScript, resolvedMintRedeemer, resolveCtx)
                : undefined;
            const scriptInput = {
                utxo: scriptLedgerUtxo,
                inputScript: { script, datum, redeemer: redeemerData }
            };
            const inputs = [scriptInput, ...forcedInputs, ...selectedFundingInputs];
            // CIP-31: map resolved reference input UTxOs to Buildooor LedgerUTxO format
            const readonlyRefInputs = this._mapReferenceInputs(ctx.referenceInputUtxos);
            // Resolve validity bounds once — both passes must share them so redeemer ExUnits
            // and fee computation stay consistent (a mismatch would force re-evaluation).
            const { invalidBefore, invalidAfter } = this._resolveValiditySlots(req, 'script');
            // Single set of build args — both internal passes and the Ogmios evaluation share
            // validity bounds so redeemer ExUnits and fee stay consistent.
            const buildParams = {
                inputs, outputs, changeAddress,
                mints,
                collaterals: collateralUtxos, requiredSigners: req.requiredSigners,
                invalidBefore, invalidAfter,
                ...(collateralReturn && { collateralReturn }),
                ...(readonlyRefInputs.length > 0 && { readonlyRefInputs })
            };
            const tx = await this._buildScriptTx(buildParams, ctx.evaluateTransaction);
            logger.debug(`Built unsigned Plutus spending transaction successfully with fee: ${tx.body.fee.toString()}`);
            return this._buildResult(req, ctx, this._extractTxDetails(tx), {
                scriptHash: script.hash.toString(),
                mintScriptHash,
                forcedInputsUsed: forcedInputs.length,
                referenceInputsUsed: readonlyRefInputs.length
            });
        }
        catch (err) {
            (0, tx_build_helper_1.mapBuilderError)(err, undefined, coinSelectionContext);
        }
    }
    //---------------------------------------------------------------------------
    // Shared Helper Methods
    //---------------------------------------------------------------------------
    /** Extract CBOR, hash, fee, size, inputs and outputs from a built Buildooor Tx */
    _extractTxDetails(tx) {
        const unsignedTxBytes = tx.toCbor();
        return {
            unsignedTxCbor: (0, uint8array_utils_1.toHex)(unsignedTxBytes),
            txBodyHash: tx.hash.toString(),
            sizeBytes: unsignedTxBytes.length,
            feeLovelace: tx.body.fee.toString(),
            inputRefs: tx.body.inputs.map((inp) => ({
                txHash: inp.utxoRef.id.toString(),
                index: inp.utxoRef.index
            })),
            outputs: tx.body.outputs.map((o) => ({
                address: o.address?.toString?.() ?? "",
                lovelace: o.value?.lovelaces?.toString?.() ?? "0"
            })),
        };
    }
    /** Build the standard TxBuildResult object */
    _buildResult(req, ctx, txDetails, extra) {
        // Map actual tx inputs (from built CBOR) back to context UTxOs for lovelace amounts
        const inputs = txDetails.inputRefs.map(ref => {
            const ctxUtxo = ctx.utxos.find(u => u.txHash === ref.txHash && u.outputIndex === ref.index);
            return {
                txHash: ref.txHash,
                index: ref.index,
                lovelace: ctxUtxo ? (0, tx_build_helper_1.getLovelace)(ctxUtxo).toString() : "0"
            };
        });
        return {
            unsignedTxCbor: txDetails.unsignedTxCbor,
            txBodyHash: txDetails.txBodyHash,
            senderAddress: req.senderAddress,
            network: this.cardanoClient.network,
            builderEngine: this.name,
            sizeBytes: txDetails.sizeBytes,
            feeLovelace: txDetails.feeLovelace,
            inputs,
            outputs: txDetails.outputs,
            ...extra,
            warnings: [],
        };
    }
    /**
     * Build a script-bearing transaction whose redeemers carry *real* execution units and
     * whose fee covers them.
     *
     * Background (verified against the vendored Buildooor source): `initTxBuild` constructs
     * every redeemer with a dummy budget — caller-supplied execution units in the build args
     * are never read — and `onEvaluationResult` unconditionally stamps each redeemer with
     * the budget the local CEK run consumed, even when the script failed (partial budget).
     * So the declared units are whatever the *local* evaluation produced, and any cushion
     * passed into the args silently evaporates. This method makes the declared units real:
     *
     *   1. First pass: build once; redeemers now carry the local CEK budgets.
     *   2. Evaluate that CBOR via Ogmios (when configured) for authoritative per-redeemer
     *      budgets, cushioned by EXECUTION_UNIT_BUFFER / ABS_*_BUFFER.
     *   3. Resolve target units per redeemer (Ogmios beats buffered-local; a local failure
     *      without an Ogmios result aborts — see makeScriptBuildOpts).
     *   4. Second pass with a fee floor covering the target units (Buildooor prices the fee
     *      from its own local budgets, so the floor adds the price + encoding-size delta).
     *   5. Stamp the target units into the redeemers and recompute scriptDataHash.
     */
    async _buildScriptTx(buildParams, evaluator) {
        const pass1Failures = [];
        const tx1 = await this.txBuilder.build(buildParams, makeScriptBuildOpts(pass1Failures));
        if (!tx1) {
            throw new errors_1.TransactionValidationError('Buildooor txBuilder.build() returned null — check inputs, datum, and collateral configuration');
        }
        const rdmrs1 = tx1.witnesses.redeemers ?? [];
        if (rdmrs1.length === 0) {
            // Defensive — callers always attach a script. Nothing to evaluate or stamp,
            // and Buildooor's calcMinFee already budgets the vkey witnesses to come.
            return tx1;
        }
        // The first-pass CBOR is exactly what a dedicated "evaluation build" would produce
        // (identical args ⇒ identical tx, since passed ExUnits are ignored anyway).
        const evaluatedUnits = evaluator
            ? await this._evaluateExUnitsByRedeemer((0, uint8array_utils_1.toHex)(tx1.toCbor()), evaluator)
            : undefined;
        if (!evaluator) {
            logger.debug('No evaluator available — falling back to buffered local execution units');
        }
        const targets1 = this._resolveTargetExUnits(rdmrs1, evaluatedUnits, pass1Failures);
        // Fee floor: Buildooor's fee covers its local budgets AND the vkey witnesses to
        // come (calcMinFee budgets 104 bytes per estimated signer); add only the price
        // delta of the stamped units, their (slightly longer) CBOR encoding, and a small
        // pad for change-output size wobble between the two passes.
        const feeFloor = BigInt(tx1.body.fee.toString())
            + this._exUnitsPriceDelta(rdmrs1, targets1)
            + this._exUnitsSizeDelta(rdmrs1, targets1) * this._txFeePerByte()
            + 10n * this._txFeePerByte();
        const pass2Failures = [];
        const tx2 = await this.txBuilder.build({ ...buildParams, fee: feeFloor }, makeScriptBuildOpts(pass2Failures));
        const rdmrs2 = tx2.witnesses.redeemers ?? [];
        const targets2 = this._resolveTargetExUnits(rdmrs2, evaluatedUnits, pass2Failures);
        return this._stampExecUnits(tx2, targets2);
    }
    /**
     * Evaluate a transaction via Ogmios and return cushioned budgets keyed per redeemer
     * (`tag:index`). Returns undefined when the evaluation is unusable (transient backend
     * failure, empty result) so callers fall back to buffered local units. A
     * TransactionValidationError or ScriptValidationError from the evaluator is
     * authoritative (the script really failed on the ledger) and is rethrown.
     */
    async _evaluateExUnitsByRedeemer(evalTxCbor, evaluator) {
        try {
            const evalResults = await evaluator(evalTxCbor);
            logger.debug(`Evaluation results: ${JSON.stringify(evalResults)}`);
            if (!evalResults || evalResults.length === 0)
                return undefined;
            const byRedeemer = new Map();
            for (const result of evalResults) {
                const v = result.validator;
                let purpose;
                let index;
                if (typeof v === 'string') {
                    // Legacy "purpose:index" form
                    const [p, i] = v.split(':');
                    purpose = p;
                    index = Number(i);
                }
                else {
                    purpose = v.purpose;
                    index = Number(v.index);
                }
                const tag = PURPOSE_TO_TAG[purpose];
                if (tag === undefined || !Number.isInteger(index)) {
                    logger.warn(`Skipping evaluation result with unrecognized validator pointer: ${JSON.stringify(v)}`);
                    continue;
                }
                byRedeemer.set(redeemerKey(tag, index), this._applyExUnitBuffer(result.budget.memory, result.budget.cpu));
            }
            return byRedeemer.size > 0 ? byRedeemer : undefined;
        }
        catch (evalError) {
            if (evalError instanceof errors_1.TransactionValidationError || evalError instanceof errors_1.ScriptValidationError) {
                // Authoritative: Ogmios executed the script and the ledger rejected it. This is
                // either a TransactionValidationError or, after normalizeBackendError, a
                // ScriptValidationError (PlutusFailure / CekError / budget overspend). Falling
                // back to local buffered units here would hand back a transaction the node has
                // already rejected — so propagate the failure instead.
                throw evalError;
            }
            const msg = evalError instanceof Error ? evalError.message : String(evalError);
            logger.warn(`Evaluation failed (transient), falling back to local execution units: ${msg}`);
            return undefined;
        }
    }
    /**
     * Combined cushion: relative multiplier catches proportional drift on large
     * validators, absolute floor catches sub-percent drift on small ones (observed
     * when metadata affects the real tx body vs the evaluator's ScriptContext).
     */
    _applyExUnitBuffer(mem, cpu) {
        return {
            mem: BigInt(Math.ceil(Number(mem) * const_1.EXECUTION_UNIT_BUFFER) + const_1.ABS_MEM_BUFFER),
            cpu: BigInt(Math.ceil(Number(cpu) * const_1.EXECUTION_UNIT_BUFFER) + const_1.ABS_CPU_BUFFER)
        };
    }
    /**
     * Decide the execution units each redeemer must declare.
     * - Local run succeeded + Ogmios result → max of both (local is a real lower bound).
     * - Local run succeeded, no Ogmios → buffered local (cushions local↔ledger drift).
     * - Local run failed + Ogmios result → Ogmios (the local partial budget is meaningless).
     * - Local run failed, no Ogmios → abort: declaring unreliable units would forfeit the
     *   collateral of whoever signs and submits the returned CBOR.
     */
    _resolveTargetExUnits(rdmrs, evaluatedUnits, failures) {
        return rdmrs.map(r => {
            const local = { mem: BigInt(r.execUnits.mem), cpu: BigInt(r.execUnits.cpu) };
            const evaluated = evaluatedUnits?.get(redeemerKey(r.tag, r.index));
            const failure = failures.find(f => f.tag === r.tag && f.index === r.index);
            if (failure) {
                if (!evaluated) {
                    throw new errors_1.TransactionValidationError(`Plutus script failed local evaluation (redeemer ${(0, cardano_ledger_ts_1.txRedeemerTagToString)(r.tag)}:${r.index}) ` +
                        `and no Ogmios evaluation is available to certify its execution units. Refusing to return a ` +
                        `transaction with unreliable execution units — signing and submitting it would forfeit the collateral. ` +
                        `Configure an Ogmios backend for authoritative script evaluation, or fix the script/datum/redeemer. ` +
                        `Script logs: [${failure.logs.join(', ')}]`);
                }
                return evaluated;
            }
            return evaluated
                ? { mem: maxBig(local.mem, evaluated.mem), cpu: maxBig(local.cpu, evaluated.cpu) }
                : this._applyExUnitBuffer(local.mem, local.cpu);
        });
    }
    /** Fee delta of the target vs local units, priced like Buildooor's own fee loop. */
    _exUnitsPriceDelta(rdmrs, targets) {
        let deltaMem = 0n;
        let deltaCpu = 0n;
        rdmrs.forEach((r, i) => {
            const dMem = targets[i].mem - BigInt(r.execUnits.mem);
            const dCpu = targets[i].cpu - BigInt(r.execUnits.cpu);
            if (dMem > 0n)
                deltaMem += dMem;
            if (dCpu > 0n)
                deltaCpu += dCpu;
        });
        if (deltaMem === 0n && deltaCpu === 0n)
            return 0n;
        const prices = this.txBuilder.protocolParamters.executionUnitPrices;
        if (Array.isArray(prices)) {
            const [memRational, cpuRational] = prices;
            return ceilDiv(deltaMem * memRational.num, memRational.den)
                + ceilDiv(deltaCpu * cpuRational.num, cpuRational.den);
        }
        // Plain { priceMemory, priceSteps } number form (pre-normalization shape)
        const obj = prices;
        return BigInt(Math.ceil(Number(deltaMem) * obj.priceMemory) + Math.ceil(Number(deltaCpu) * obj.priceSteps));
    }
    /** CBOR size growth (bytes) from stamping larger budgets into the redeemers. */
    _exUnitsSizeDelta(rdmrs, targets) {
        return rdmrs.reduce((sum, r, i) => {
            const dMem = cborUIntLength(targets[i].mem) - cborUIntLength(BigInt(r.execUnits.mem));
            const dCpu = cborUIntLength(targets[i].cpu) - cborUIntLength(BigInt(r.execUnits.cpu));
            return sum + (dMem > 0n ? dMem : 0n) + (dCpu > 0n ? dCpu : 0n);
        }, 0n);
    }
    _txFeePerByte() {
        return BigInt(this.txBuilder.protocolParamters.txFeePerByte);
    }
    /**
     * Replace the redeemers' execution units and recompute scriptDataHash.
     *
     * Still not implemented via TxBuilder.overrideTxRedeemers, although buildooor
     * 0.2.9 fixed its old-witness-set hashing (our PR): that method hashes with the
     * builder's named-key cost models, which clamp the chain array to the parameter
     * count the library release knows — wrong whenever the on-chain cost model has
     * grown past that (ScriptIntegrityHashMismatch at submit). This recompute with
     * _languageViewCostModels (raw chain arrays) stays governance-proof, so the hash
     * is recomputed here even when the target units already match.
     */
    _stampExecUnits(tx, targets) {
        const rdmrs = tx.witnesses.redeemers ?? [];
        const unchanged = rdmrs.every((r, i) => BigInt(r.execUnits.mem) === targets[i].mem && BigInt(r.execUnits.cpu) === targets[i].cpu);
        const stamped = unchanged ? [...rdmrs] : rdmrs.map((r, i) => new cardano_ledger_ts_1.TxRedeemer({
            tag: r.tag,
            index: r.index,
            data: r.data,
            execUnits: new buildooor_1.ExBudget({ mem: targets[i].mem, cpu: targets[i].cpu })
        }));
        const newWitnesses = new cardano_ledger_ts_1.TxWitnessSet({ ...tx.witnesses, vkeyWitnesses: [], redeemers: stamped });
        const languageViews = (0, buildooor_1.costModelsToLanguageViewCbor)(this._languageViewCostModels(), this._usedLanguageViewOpts(tx));
        const newBody = new cardano_ledger_ts_1.TxBody({ ...tx.body, scriptDataHash: (0, buildooor_1.getScriptDataHash)(newWitnesses, languageViews) });
        const finalTx = new cardano_ledger_ts_1.Tx({ ...tx, body: newBody, witnesses: newWitnesses });
        if (!unchanged) {
            logger.info(`Stamped execution units into ${stamped.length} redeemer(s): ` +
                stamped.map(s => `${(0, cardano_ledger_ts_1.txRedeemerTagToString)(s.tag)}:${s.index} mem=${s.execUnits.mem} cpu=${s.execUnits.cpu}`).join('; '));
        }
        return finalTx;
    }
    /**
     * Language-view selection for scriptDataHash, mirroring Buildooor's initTxBuild
     * (which flags the languages of *executed* scripts). This builder only attaches
     * scripts inline, so the witness set carries every executed script.
     */
    _usedLanguageViewOpts(tx) {
        const w = tx.witnesses;
        const opts = {
            mustHaveV1: (w.plutusV1Scripts?.length ?? 0) > 0,
            mustHaveV2: (w.plutusV2Scripts?.length ?? 0) > 0,
            mustHaveV3: (w.plutusV3Scripts?.length ?? 0) > 0
        };
        if (!opts.mustHaveV1 && !opts.mustHaveV2 && !opts.mustHaveV3)
            opts.mustHaveV3 = true;
        return opts;
    }
    /**
     * Cost models for language-view hashing. The named-key objects the TxBuilder was
     * constructed with clamp the chain array to the parameter count this costmodels-ts
     * release knows (e.g. 297 for V3 pre-protocol-11), but the ledger hashes EVERY
     * entry the chain serves (350 on protocol-11 networks). toCostModelArrVN passes
     * array form through unclamped, so substitute the raw chain arrays where we have
     * them. (The named-key form stays in the TxBuilder — the CEK machine needs it.)
     */
    _languageViewCostModels() {
        const models = this.txBuilder.protocolParamters.costModels;
        if (Object.keys(this.rawCostModelArrays).length === 0)
            return models;
        return { ...models, ...this.rawCostModelArrays };
    }
    /**
     * Split UTxOs into forced inputs (must be consumed) and remaining candidates (free for
     * coin selection / collateral). Refs in forceInputs that are not present in utxos are
     * silently ignored — the resolver upstream has already validated existence.
     */
    _partitionForcedInputs(utxos, forceInputs) {
        if (!forceInputs || forceInputs.length === 0)
            return { forced: [], rest: utxos };
        const forcedKeys = new Set(forceInputs.map(r => `${r.txHash}#${r.outputIndex}`));
        const forced = [];
        const rest = [];
        for (const u of utxos) {
            if (forcedKeys.has(`${u.txHash}#${u.outputIndex}`))
                forced.push(u);
            else
                rest.push(u);
        }
        return { forced, rest };
    }
    /**
     * Map resolved CIP-31 reference input UTxOs to Buildooor LedgerUTxO format.
     * Returns empty array when no reference inputs are provided.
     */
    _mapReferenceInputs(referenceInputUtxos) {
        if (!referenceInputUtxos || referenceInputUtxos.length === 0)
            return [];
        return referenceInputUtxos.map(u => this._mapMultiAssetUtxoToLedgerUtxo(u));
    }
    /**
     * Funding requirement contributed by extra outputs on a mint build:
     * the summed lovelace of all entries plus, per asset unit, the demand the
     * transaction's own positive mints do NOT cover. Minted quantities are
     * aggregated per unit and subtracted from the aggregated output demand;
     * only a positive remainder is requested from the wallet (a fully covered
     * unit is not requested at all — it does not exist before this tx).
     */
    _extraOutputsFundingAfterMint(mintActions, extraOutputs) {
        const mintedByUnit = new Map();
        for (const action of mintActions) {
            const quantity = BigInt(action.quantity);
            if (quantity > 0n) {
                const unit = action.assetUnit.toLowerCase();
                mintedByUnit.set(unit, (mintedByUnit.get(unit) ?? 0n) + quantity);
            }
        }
        const demandByUnit = new Map();
        let lovelace = 0n;
        for (const extra of extraOutputs) {
            lovelace += BigInt(extra.lovelaceAmount);
            for (const asset of extra.assets ?? []) {
                const unit = asset.unit.toLowerCase();
                demandByUnit.set(unit, (demandByUnit.get(unit) ?? 0n) + BigInt(asset.quantity));
            }
        }
        const assets = [];
        for (const [unit, demand] of demandByUnit) {
            const uncovered = demand - (mintedByUnit.get(unit) ?? 0n);
            if (uncovered > 0n)
                assets.push({ unit, quantity: uncovered.toString() });
        }
        return { lovelace, ...(assets.length > 0 ? { assets } : {}) };
    }
    /**
     * The script an individual mint action executes under: its own
     * per-action policy when set (multi-policy mint FR), else the request's
     * top-level policy script.
     */
    _mintActionScript(action, defaultScript, index) {
        if (!action.mintingPolicyScript)
            return defaultScript;
        return this._parsePlutusV3Script(action.mintingPolicyScript, `mintActions[${index}].mintingPolicyScript`);
    }
    /**
     * Build the Buildooor mint-entry array shared by the mint-only flow and the
     * combined spend+mint flow (Buildooor ignores caller-supplied execution units;
     * they are stamped into the redeemers post-build by _buildScriptTx).
     *
     * Multi-policy mint FR: each action may carry its own policy script and
     * redeemer; absent fields fall back to the request-level ones. The ledger
     * carries ONE redeemer per policy, so actions resolving to the same policy
     * must agree on their redeemer, checked here.
     */
    _buildMintEntries(mintActions, mintScript, resolvedMintRedeemer, resolveCtx) {
        const redeemerByPolicy = new Map();
        return mintActions.map((action, index) => {
            const script = this._mintActionScript(action, mintScript, index);
            const actionRedeemer = action.redeemerJson !== undefined
                ? (resolveCtx ? (0, plutus_placeholders_1.resolveIndexPlaceholders)(action.redeemerJson, resolveCtx) : action.redeemerJson)
                : resolvedMintRedeemer;
            const redeemerData = actionRedeemer !== undefined
                ? (0, tx_build_helper_1.jsonToPlutusData)(actionRedeemer)
                : new plutus_data_1.DataI(action.redeemer ?? 0);
            const policyId = script.hash.toString();
            // Canonical comparison over the encoded PlutusData: JSON key order must
            // not matter, and a JSON {int:0} equals the DataI(0) fallback.
            const redeemerFingerprint = (0, plutus_data_1.dataToCbor)(redeemerData).toString();
            const seen = redeemerByPolicy.get(policyId);
            if (seen !== undefined && seen !== redeemerFingerprint) {
                throw new Error(`mint actions under policy ${policyId} carry different redeemers — the ledger allows one redeemer per policy; ` +
                    'split them into separate transactions or align the redeemers');
            }
            redeemerByPolicy.set(policyId, redeemerFingerprint);
            const { assetName } = (0, tx_build_helper_1.parseAssetUnit)(action.assetUnit);
            return {
                value: cardano_ledger_ts_1.Value.singleAsset(script.hash, Buffer.from(assetName, 'hex'), BigInt(action.quantity)),
                script: {
                    inline: script,
                    redeemer: redeemerData
                }
            };
        });
    }
    /**
     * Consumer-facing context for insufficient-funds rejections after the
     * collateral partition: the builder's own "not enough …" message counts only
     * the funding pool, and without this the reservation is invisible ("but the
     * address HAS enough ADA").
     */
    _collateralPartitionContext(collateralUtxos, fundingUtxos) {
        const collateralLovelace = collateralUtxos.reduce((s, u) => s + u.resolved.value.lovelaces, 0n);
        const fundingLovelace = fundingUtxos.reduce((s, u) => s + (0, tx_build_helper_1.getLovelace)(u), 0n);
        return `${collateralUtxos.length} UTxO(s) with ${collateralLovelace} lovelace reserved as collateral; ` +
            `${fundingUtxos.length} UTxO(s) with ${fundingLovelace} lovelace remained for coin selection`;
    }
    /**
     * Pick a collateral UTxO and return remaining funding UTxOs.
     * Throws if no ADA-only UTxO is available.
     *
     * Selection: the SMALLEST ADA-only UTxO that still covers the static
     * COLLATERAL_LOVELACE floor (5 ADA ≳ collateralPercentage × any realistic fee).
     * The previous "first ADA-only" pick failed both ways: a dust UTxO below
     * collateralPercentage × fee is rejected at submit, and a large UTxO is
     * fully forfeited on phase-2 failure (Buildooor sets no collateralReturn
     * for ADA-only collateral). Everything above the floor is therefore handed
     * back via an explicit collateralReturn when the excess satisfies min-ADA.
     */
    _setupCollateral(utxos) {
        const adaOnly = utxos.filter(u => u.amount.every(a => a.unit.toLowerCase() === 'lovelace'));
        if (adaOnly.length === 0) {
            throw new errors_1.TransactionValidationError('No ADA-only UTxO available for collateral. Plutus scripts require ADA-only collateral.');
        }
        const sorted = [...adaOnly].sort((a, b) => {
            const diff = (0, tx_build_helper_1.getLovelace)(a) - (0, tx_build_helper_1.getLovelace)(b);
            return diff < 0n ? -1 : diff > 0n ? 1 : 0;
        });
        // smallest sufficient; if none reaches the floor, the largest available is the best bet
        const chosen = sorted.find(u => (0, tx_build_helper_1.getLovelace)(u) >= const_1.COLLATERAL_LOVELACE) ?? sorted[sorted.length - 1];
        if ((0, tx_build_helper_1.getLovelace)(chosen) < const_1.COLLATERAL_LOVELACE) {
            logger.warn(`Largest ADA-only UTxO (${(0, tx_build_helper_1.getLovelace)(chosen)} lovelace) is below the ${const_1.COLLATERAL_LOVELACE} lovelace ` +
                `collateral floor — the node will reject the transaction if collateralPercentage × fee exceeds it`);
        }
        const collateralUtxos = [this._mapOdatanoUtxoToLedgerUtxo(chosen)];
        const fundingUtxos = utxos.filter(u => !(u.txHash === chosen.txHash && u.outputIndex === chosen.outputIndex));
        // Cap the at-risk amount at the floor: return the excess to the owner.
        let collateralReturn;
        const excess = (0, tx_build_helper_1.getLovelace)(chosen) - const_1.COLLATERAL_LOVELACE;
        if (excess > 0n) {
            const address = cardano_ledger_ts_1.Address.fromString(chosen.address);
            const minAda = this.txBuilder.getMinimumOutputLovelaces(new cardano_ledger_ts_1.TxOut({ address, value: cardano_ledger_ts_1.Value.lovelaces(excess) }));
            if (excess >= minAda) {
                collateralReturn = { address, value: cardano_ledger_ts_1.Value.lovelaces(excess) };
            }
            // excess below min-ADA: no return output possible — whole UTxO stays at risk,
            // but by selection it is the smallest sufficient one.
        }
        return { collateralUtxos, fundingUtxos, collateralReturn };
    }
    /** Build a Ledger Value from lovelace + optional multi-asset array */
    _buildLedgerValue(lovelace, assets) {
        let value = cardano_ledger_ts_1.Value.lovelaces(lovelace);
        if (assets) {
            for (const asset of assets) {
                if (asset.unit.toLowerCase() === 'lovelace')
                    continue;
                if (BigInt(asset.quantity) <= 0n)
                    continue;
                const { policyId, assetName } = (0, tx_build_helper_1.parseAssetUnit)(asset.unit);
                value = cardano_ledger_ts_1.Value.add(value, cardano_ledger_ts_1.Value.singleAsset(new cardano_ledger_ts_1.Hash28(policyId), Buffer.from(assetName, 'hex'), BigInt(asset.quantity)));
            }
        }
        return value;
    }
    /** Build a TxOut with optional inline datum and optional reference script (CIP-33) */
    _buildTxOut(address, value, datum, refScript) {
        const params = { address, value };
        if (datum) {
            params.datum = (0, tx_build_helper_1.jsonToPlutusData)(datum);
        }
        if (refScript) {
            params.refScript = refScript;
        }
        return new cardano_ledger_ts_1.TxOut(params);
    }
    /**
     * Parse a consumer-provided, CBOR-wrapped Plutus script and reject UPLC 1.0.0
     * code (PlutusV1/V2). `Script.fromCbor` defaults to PlutusV3, so V1/V2 bytes
     * would be hashed with the 0x03 prefix — a silently wrong script hash, i.e.
     * wrong policy IDs and unspendable script addresses with no error anywhere
     * down the line. The UPLC version is the first three flat-encoded naturals
     * of the unwrapped script: [1,0,0] (V1/V2) vs [1,1,0] (V3).
     */
    _parsePlutusV3Script(hex, field) {
        let script;
        try {
            script = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(hex, 'hex'));
        }
        catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            throw new errors_1.TransactionValidationError(`Invalid ${field} CBOR: ${msg}`);
        }
        const b = script.bytes;
        if (b.length >= 3 && b[0] === 1 && b[1] === 0 && b[2] === 0) {
            throw new errors_1.TransactionValidationError(`${field} contains UPLC 1.0.0 code (PlutusV1/V2) — ODATANO builds Plutus V3 transactions only. ` +
                `Hashing it as V3 would yield a different script hash (wrong policy ID / unspendable address).`);
        }
        return script;
    }
    /** Parse a Plutus V3 CBOR hex into a Buildooor Script for refScript attachment. */
    _parseReferenceScript(hex) {
        if (!hex)
            return undefined;
        return this._parsePlutusV3Script(hex, 'referenceScript');
    }
    /**
     * Map an input UTxO's scriptRef field to a Buildooor Script when possible.
     * UTxO.scriptRef is overloaded across backends: Blockfrost/Ogmios set it to a 28-byte
     * hash (56 hex chars), Koios sets it to the full CBOR script bytes. Only full bytes
     * are usable here — hash-only entries are preserved only on-chain, not in local eval.
     */
    _buildInputRefScript(utxo) {
        if (!utxo.scriptRef)
            return undefined;
        if (utxo.scriptRef.length <= 56) {
            logger.debug(`UTxO ${utxo.txHash}#${utxo.outputIndex} carries scriptRef hash only — local Plutus eval will not see the script`);
            return undefined;
        }
        try {
            const script = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(utxo.scriptRef, 'hex'));
            // chain data, not consumer input — warn instead of rejecting
            const b = script.bytes;
            if (b.length >= 3 && b[0] === 1 && b[1] === 0 && b[2] === 0) {
                logger.warn(`Input refScript on ${utxo.txHash}#${utxo.outputIndex} is UPLC 1.0.0 (PlutusV1/V2) — treated as V3, local eval may misbehave`);
            }
            return script;
        }
        catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            logger.warn(`Failed to parse input refScript for ${utxo.txHash}#${utxo.outputIndex}: ${msg}`);
            return undefined;
        }
    }
    /**
     * Compute the post-sort input order so __INPUT_IDX__ placeholders (FR-3) resolve to the
     * same indices Buildooor will assign during build(). Order: script-input first by convention,
     * then forced + funding sorted lexicographically on (txHash, outputIndex).
     * Buildooor sorts ALL inputs together; we mirror that exact behaviour via sortInputsLikeBuildooor.
     */
    _computeSortedInputs(scriptUtxoRef, forcedUtxos, fundingRefs) {
        const all = [
            { txHash: scriptUtxoRef.txHash, outputIndex: scriptUtxoRef.outputIndex },
            ...forcedUtxos.map(u => ({ txHash: u.txHash, outputIndex: u.outputIndex })),
            ...fundingRefs
        ];
        return (0, plutus_placeholders_1.sortInputsLikeBuildooor)(all);
    }
    /** Extract InputRef list from the Buildooor-shaped funding inputs returned by keepRelevant. */
    _extractFundingRefs(fundingInputs) {
        return fundingInputs.map(i => ({
            txHash: i.utxo.utxoRef.id.toString(),
            outputIndex: i.utxo.utxoRef.index
        }));
    }
    /**
     * Resolve __INPUT_IDX__ placeholders (FR-3) inside each extraOutput.inlineDatum.
     * Returns a new array with resolved datums; non-datum fields pass through unchanged.
     */
    _resolveExtraOutputPlaceholders(extraOutputs, resolveCtx) {
        if (!extraOutputs || extraOutputs.length === 0)
            return extraOutputs;
        return extraOutputs.map(extra => ({
            ...extra,
            inlineDatum: extra.inlineDatum
                ? (0, plutus_placeholders_1.resolveIndexPlaceholders)(extra.inlineDatum, resolveCtx)
                : undefined
        }));
    }
    /**
     * Append parsed extraOutputs (FR-2) to the outputs array, enforcing min-ADA per entry.
     * Throws TransactionValidationError with the required min-ADA in the message so consumers
     * can adjust without having to inspect Buildooor internals.
     */
    _appendExtraOutputs(outputs, extraOutputs) {
        if (!extraOutputs || extraOutputs.length === 0)
            return;
        for (let i = 0; i < extraOutputs.length; i++) {
            const extra = extraOutputs[i];
            const value = this._buildLedgerValue(BigInt(extra.lovelaceAmount), extra.assets);
            const refScript = this._parseReferenceScript(extra.referenceScript);
            const txOut = this._buildTxOut(cardano_ledger_ts_1.Address.fromString(extra.address), value, extra.inlineDatum, refScript);
            const minLovelaces = this.txBuilder.getMinimumOutputLovelaces(txOut);
            if (BigInt(extra.lovelaceAmount) < minLovelaces) {
                throw new errors_1.TransactionValidationError(`extraOutputs[${i}].lovelaceAmount (${extra.lovelaceAmount}) is below required min-ADA ${minLovelaces.toString()} for the given address/assets/datum`);
            }
            outputs.push(txOut);
        }
    }
    //---------------------------------------------------------------------------
    // UTxO Mapping & Configuration Helpers
    //---------------------------------------------------------------------------
    /**
     * Resolve the transaction's validity window (slots) from the request.
     * Falls back to `now - 2 min` / `now + 1 h` when the request omits bounds.
     * Script-validated builds must call this; plain transfers pass their own
     * explicit bounds through (no defaulting) so replay behavior is opt-in.
     */
    _resolveValiditySlots(req, mode) {
        const hasStart = req.validityStartMs !== undefined && req.validityStartMs !== null && req.validityStartMs !== '';
        const hasEnd = req.validityEndMs !== undefined && req.validityEndMs !== null && req.validityEndMs !== '';
        if (mode === 'passthrough') {
            const result = {};
            if (hasStart)
                result.invalidBefore = BigInt(this.txBuilder.posixToSlot(Number(req.validityStartMs)));
            if (hasEnd)
                result.invalidAfter = BigInt(this.txBuilder.posixToSlot(Number(req.validityEndMs)));
            return result;
        }
        const nowMs = Date.now();
        const startMs = hasStart ? Number(req.validityStartMs) : nowMs - const_1.DEFAULT_VALIDITY_START_OFFSET_MS;
        const endMs = hasEnd ? Number(req.validityEndMs) : nowMs + const_1.DEFAULT_VALIDITY_END_OFFSET_MS;
        const startSlot = this.txBuilder.posixToSlot(startMs);
        const endSlot = this.txBuilder.posixToSlot(endMs);
        return {
            invalidBefore: BigInt(startSlot),
            invalidAfter: BigInt(endSlot),
        };
    }
    /**
     * Map ODATANO LedgerProtocolParameter to Buildooor's ProtocolParameters shape.
     *
     * Every field is null-guarded: a missing/null source value keeps the library
     * default instead of degrading to 0 (`Number(null) === 0` previously set
     * utxoCostPerByte = 0, disabling min-ADA checks entirely). Cost models and
     * execution-unit prices are mapped because they feed the scriptDataHash
     * (language views) and the fee/ExUnits math — stale defaults there cause
     * PPViewHashesDontMatch or fee underestimation on-chain.
     */
    _mapLedgerParametersToBuildooorParams(protocolParameters) {
        const pp = protocolParameters;
        const d = cardano_ledger_ts_1.defaultProtocolParameters;
        const mapped = {
            ...d,
            txFeePerByte: toUInt(pp.minFeeA) ?? d.txFeePerByte,
            txFeeFixed: toUInt(pp.minFeeB) ?? d.txFeeFixed,
            utxoCostPerByte: toUInt(pp.coinsPerUtxoSize) ?? d.utxoCostPerByte,
            maxTxSize: toUInt(pp.maxTxSize) ?? d.maxTxSize,
            maxValueSize: toUInt(pp.maxValSize) ?? d.maxValueSize,
            maxBlockBodySize: toUInt(pp.maxBlockSize) ?? d.maxBlockBodySize,
            maxBlockHeaderSize: toUInt(pp.maxBlockHeaderSize) ?? d.maxBlockHeaderSize,
            stakeAddressDeposit: toUInt(pp.keyDeposit) ?? d.stakeAddressDeposit,
            stakePoolDeposit: toUInt(pp.poolDeposit) ?? d.stakePoolDeposit,
            minPoolCost: toUInt(pp.minPoolCost) ?? d.minPoolCost,
            poolRetireMaxEpoch: toUInt(pp.eMax) ?? d.poolRetireMaxEpoch,
            stakePoolTargetNum: toUInt(pp.nOpt) ?? d.stakePoolTargetNum,
            collateralPercentage: toUInt(pp.collateralPercent) ?? d.collateralPercentage,
            maxCollateralInputs: toUInt(pp.maxCollateralInputs) ?? d.maxCollateralInputs,
        };
        const maxTxExMem = toUInt(pp.maxTxExMem);
        const maxTxExSteps = toUInt(pp.maxTxExSteps);
        if (maxTxExMem !== undefined && maxTxExSteps !== undefined) {
            mapped.maxTxExecutionUnits = { memory: maxTxExMem, steps: maxTxExSteps };
        }
        const maxBlockExMem = toUInt(pp.maxBlockExMem);
        const maxBlockExSteps = toUInt(pp.maxBlockExSteps);
        if (maxBlockExMem !== undefined && maxBlockExSteps !== undefined) {
            mapped.maxBlockExecutionUnits = { memory: maxBlockExMem, steps: maxBlockExSteps };
        }
        const priceMemory = toPositiveNumber(pp.priceMem);
        const priceSteps = toPositiveNumber(pp.priceStep);
        if (priceMemory !== undefined && priceSteps !== undefined) {
            mapped.executionUnitPrices = { priceMemory, priceSteps };
        }
        const costModels = this._mapCostModels(pp.costModels);
        if (costModels) {
            mapped.costModels = costModels;
        }
        else {
            logger.warn('Protocol parameters carry no usable cost models — keeping library defaults. ' +
                'scriptDataHash of script transactions may not match the ledger (PPViewHashesDontMatch risk).');
        }
        return mapped;
    }
    /**
     * Parse the cost-models JSON blob (backend-normalized number arrays, keys
     * 'PlutusV1'/'PlutusV2'/'PlutusV3' or Ogmios 'plutus:vN') into Buildooor's
     * CostModels shape ('PlutusScriptVN' keys). Returns undefined when nothing
     * usable is found, so the caller can keep defaults and warn.
     *
     * Side effect: (re)sets this.rawCostModelArrays with the unclamped chain arrays
     * for the versions mapped here — the named-key conversion drops every entry past
     * the parameter count this costmodels-ts release knows, and the scriptDataHash
     * must cover all of them (see _languageViewCostModels).
     */
    _mapCostModels(costModelsJson) {
        this.rawCostModelArrays = {};
        if (!costModelsJson)
            return undefined;
        let raw;
        try {
            raw = JSON.parse(costModelsJson);
        }
        catch {
            logger.warn('Failed to parse protocol-parameter cost models JSON');
            return undefined;
        }
        if (!raw || typeof raw !== 'object' || Array.isArray(raw))
            return undefined;
        const KEY_MAP = {
            PlutusV1: 'PlutusScriptV1', 'plutus:v1': 'PlutusScriptV1', PlutusScriptV1: 'PlutusScriptV1',
            PlutusV2: 'PlutusScriptV2', 'plutus:v2': 'PlutusScriptV2', PlutusScriptV2: 'PlutusScriptV2',
            PlutusV3: 'PlutusScriptV3', 'plutus:v3': 'PlutusScriptV3', PlutusScriptV3: 'PlutusScriptV3',
        };
        // Buildooor's CEK Machine rejects array-form cost models — convert to named-key objects.
        const result = {};
        const rawArrays = {};
        for (const [key, value] of Object.entries(raw)) {
            const target = KEY_MAP[key];
            if (!target || !Array.isArray(value))
                continue;
            const arr = value.map(Number);
            try {
                if (target === 'PlutusScriptV1')
                    result[target] = (0, buildooor_1.toCostModelV1)(arr);
                else if (target === 'PlutusScriptV2')
                    result[target] = (0, buildooor_1.toCostModelV2)(arr);
                else
                    result[target] = (0, buildooor_1.toCostModelV3)(arr);
                // Non-finite entries would break the language-view CBOR; without a raw array
                // the hash falls back to the clamped named-key form for this version.
                if (arr.every(Number.isFinite))
                    rawArrays[target] = arr;
            }
            catch {
                logger.warn(`Cost-model array for ${key} has unexpected length (${value.length}) — skipping`);
            }
        }
        if (Object.keys(result).length === 0)
            return undefined;
        if (!(0, buildooor_1.isCostModels)(result)) {
            // Buildooor would silently substitute default cost models — surface it instead.
            logger.warn('Mapped cost models failed Buildooor validation — keeping library defaults');
            return undefined;
        }
        this.rawCostModelArrays = rawArrays;
        return result;
    }
    /**
     * Map ODATANO UTxO to Ledger UTxO (ADA-only)
     */
    _mapOdatanoUtxoToLedgerUtxo(utxos) {
        (0, tx_build_helper_1.assertAdaOnly)(utxos);
        return new cardano_ledger_ts_1.UTxO({
            utxoRef: new cardano_ledger_ts_1.TxOutRef({ id: utxos.txHash, index: utxos.outputIndex }),
            resolved: new cardano_ledger_ts_1.TxOut({
                address: cardano_ledger_ts_1.Address.fromString(utxos.address),
                value: cardano_ledger_ts_1.Value.lovelaces((0, tx_build_helper_1.getLovelace)(utxos)),
                datum: undefined,
                refScript: this._buildInputRefScript(utxos)
            })
        });
    }
    /**
     * Map ODATANO UTxO to Ledger UTxO (with multi-asset support)
     */
    _mapMultiAssetUtxoToLedgerUtxo(utxo) {
        const value = this._buildLedgerValue((0, tx_build_helper_1.getLovelace)(utxo), utxo.amount);
        // Inline datum wins; otherwise carry the datum HASH into the resolved TxOut —
        // Buildooor only includes a provided datum preimage in the witness set when the
        // spent output is marked with its Hash32 (pushWitDatum). Dropping the hash here
        // silently discards the preimage → MissingRequiredDatums on submit.
        const datumValue = utxo.inlineDatum
            ? (0, plutus_data_1.dataFromCbor)(utxo.inlineDatum)
            : utxo.datumHash
                ? new cardano_ledger_ts_1.Hash32(utxo.datumHash)
                : undefined;
        return new cardano_ledger_ts_1.UTxO({
            utxoRef: new cardano_ledger_ts_1.TxOutRef({ id: utxo.txHash, index: utxo.outputIndex }),
            resolved: new cardano_ledger_ts_1.TxOut({
                address: cardano_ledger_ts_1.Address.fromString(utxo.address),
                value,
                datum: datumValue,
                refScript: this._buildInputRefScript(utxo)
            })
        });
    }
    /**
     * Map ODATANO metadata JSON to Ledger TxMetadata
     */
    _mapOdatanoMetadataToLedgerMetadata(metadataJson) {
        if (!metadataJson) {
            return new TxMetadata_1.TxMetadata({});
        }
        const metadata = {};
        for (const [label, value] of Object.entries(metadataJson)) {
            if (!/^\d+$/.test(label)) {
                throw new errors_1.TransactionValidationError(`Invalid metadata label "${label}" — labels must be non-negative integers`);
            }
            metadata[Number(label)] = this._jsonToTxMetadatum(value, label);
        }
        return new TxMetadata_1.TxMetadata(metadata);
    }
    /**
     * Recursively convert JSON value to TxMetadatum.
     *
     * Ledger rules enforced here (instead of a node-side rejection or a raw 500):
     * - numbers must be integers (BigInt(1.5) would throw a bare RangeError)
     * - text and byte values are limited to 64 BYTES per metadatum — longer values
     *   are chunked into a list of ≤64-byte pieces (the established convention,
     *   e.g. CIP-25 long strings)
     * - strings prefixed with "0x" (even hex length) become byte metadata
     * - map keys are not auto-chunked (readers match on the literal key) — over-long
     *   keys are rejected with a clear 400
     *
     * @param path position of `value` inside the metadata JSON (label-rooted, e.g.
     *             "1155.result" or "721.files[0].src") — named in every rejection
     *             so the consumer can locate the offending value.
     */
    _jsonToTxMetadatum(value, path) {
        if (typeof value === 'number' || typeof value === 'bigint') {
            if (typeof value === 'number' && !Number.isInteger(value)) {
                throw new errors_1.TransactionValidationError(`Metadata numbers must be integers (got ${value} at ${path}) — encode decimals as strings`);
            }
            return new TxMetadatum_1.TxMetadatumInt(BigInt(value));
        }
        if (typeof value === 'string') {
            if (/^0x([0-9a-fA-F]{2})+$/.test(value)) {
                const bytes = Buffer.from(value.slice(2), 'hex');
                if (bytes.length <= METADATA_BYTE_LIMIT)
                    return new TxMetadatum_1.TxMetadatumBytes(bytes);
                const chunks = [];
                for (let i = 0; i < bytes.length; i += METADATA_BYTE_LIMIT) {
                    chunks.push(new TxMetadatum_1.TxMetadatumBytes(bytes.subarray(i, i + METADATA_BYTE_LIMIT)));
                }
                return new TxMetadatum_1.TxMetadatumList(chunks);
            }
            const chunks = chunkUtf8(value, METADATA_BYTE_LIMIT);
            if (chunks.length === 1)
                return new TxMetadatum_1.TxMetadatumText(value);
            return new TxMetadatum_1.TxMetadatumList(chunks.map(c => new TxMetadatum_1.TxMetadatumText(c)));
        }
        if (Array.isArray(value)) {
            return new TxMetadatum_1.TxMetadatumList(value.map((v, i) => this._jsonToTxMetadatum(v, `${path}[${i}]`)));
        }
        if (typeof value === 'object' && value !== null) {
            const map = [];
            for (const [k, v] of Object.entries(value)) {
                if (Buffer.byteLength(k, 'utf8') > METADATA_BYTE_LIMIT) {
                    throw new errors_1.TransactionValidationError(`Metadata map key exceeds ${METADATA_BYTE_LIMIT} bytes (UTF-8) at ${path}: "${k.slice(0, 32)}…"`);
                }
                map.push({
                    k: new TxMetadatum_1.TxMetadatumText(k),
                    v: this._jsonToTxMetadatum(v, `${path}.${k}`)
                });
            }
            return new TxMetadatum_1.TxMetadatumMap(map);
        }
        throw new errors_1.TransactionValidationError(`Unsupported metadata value type: ${value === null ? 'null' : typeof value} at ${path}` +
            (typeof value === 'boolean' ? ' — on-chain metadata has no boolean; encode as string or 0/1' : ''));
    }
}
exports.BuildooorTxBuilder = BuildooorTxBuilder;
//# sourceMappingURL=buildooor-tx.js.map