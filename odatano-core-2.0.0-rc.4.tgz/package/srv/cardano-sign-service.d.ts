export {};
//# sourceMappingURL=cardano-sign-service.d.ts.map