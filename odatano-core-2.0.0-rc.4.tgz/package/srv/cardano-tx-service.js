"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cds_1 = __importDefault(require("@sap/cds"));
const bech32_1 = require("bech32");
const backend_request_handler_1 = require("./utils/backend-request-handler");
const errors_1 = require("./utils/errors");
const validators_1 = require("./utils/validators");
const tx_build_helper_1 = require("./utils/tx-build-helper");
const cardano_ledger_ts_1 = require("@harmoniclabs/cardano-ledger-ts");
const mappers_1 = require("./utils/mappers");
const server_1 = require("./server");
const const_1 = require("./utils/const");
const tx_request_parsers_1 = require("./utils/tx-request-parsers");
const VALID_DERIVE_NETWORKS = ['mainnet', 'preview', 'preprod'];
const { SELECT, UPDATE } = cds_1.default.ql;
const logger = cds_1.default.log('CardanoTxService');
/**
 * Cardano Transaction Service Implementation
 * Handles transaction building and submission operations & some additional data queries.
 */
module.exports = (srv) => {
    logger.debug('Module loaded - registering handlers');
    const { TransactionBuilds, TransactionSubmissions, AddressTransactionBuilds } = require('#cds-models/CardanoTransactionService');
    /**
     * Build a simple ADA-only transaction
     * @param req - CDS request object (with senderAddress, recipientAddress, lovelaceAmount, changeAddress)
     * @returns {TransactionBuild} Transaction build details
     */
    srv.on('BuildSimpleAdaTransaction', async (req) => {
        const { senderAddress, recipientAddress, lovelaceAmount, outputDatumJson, assetsJson, forceInputsJson, validatorScript, scriptParamsJson, lockOnScript, referenceScriptHex, validityStartMs, validityEndMs } = req.data;
        // validate inputs
        const errors = (0, validators_1.validateTransactionInputs)({ senderAddress, recipientAddress, lovelaceAmount, referenceScriptHex, validityStartMs, validityEndMs }, ['senderAddress', 'recipientAddress', 'lovelaceAmount']);
        (0, errors_1.throwIfValidationErrors)(req, 'BuildSimpleAdaTransaction', errors);
        if (req.data.changeAddress && !(0, validators_1.isValidBech32Address)(req.data.changeAddress)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', 'Invalid changeAddress format', 'changeAddress');
        }
        // parse optional output datum
        const cleanData = { ...req.data };
        // parse optional forceInputsJson
        const forceInputsResult = (0, tx_request_parsers_1.parseUtxoRefArray)(forceInputsJson, 'forceInputsJson');
        if (forceInputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', forceInputsResult.error, 'forceInputsJson');
        cleanData.forceInputs = forceInputsResult.parsed;
        delete cleanData.forceInputsJson;
        if (outputDatumJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(outputDatumJson, 'outputDatumJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', jsonResult.error, 'outputDatumJson');
            cleanData.outputDatum = jsonResult.parsed;
            delete cleanData.outputDatumJson;
        }
        // parse optional assets JSON (for locking native assets at script addresses)
        const assetsResult = (0, tx_request_parsers_1.parseAssetsArray)(assetsJson, 'assetsJson');
        if (assetsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', assetsResult.error, 'assetsJson');
        if (assetsResult.parsed) {
            cleanData.assets = assetsResult.parsed;
            delete cleanData.assetsJson;
        }
        // parse optional scriptParamsJson (for parameterized validators)
        let scriptParams;
        if (scriptParamsJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(scriptParamsJson, 'scriptParamsJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', jsonResult.error, 'scriptParamsJson');
            scriptParams = jsonResult.parsed;
            if (!Array.isArray(scriptParams)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', 'scriptParamsJson must be a JSON array', 'scriptParamsJson');
            }
        }
        // lockOnScript requires a validatorScript to derive the target address from
        if (lockOnScript && !validatorScript) {
            return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', 'lockOnScript requires validatorScript to derive the script address', 'validatorScript');
        }
        // Pre-compute script hash + address when lockOnScript is set; override recipient before build.
        let derivedScriptHash;
        let derivedScriptAddress;
        if (lockOnScript && validatorScript) {
            try {
                const finalScript = scriptParams && scriptParams.length > 0
                    ? (0, tx_build_helper_1.applyScriptParameters)(validatorScript, scriptParams)
                    : validatorScript;
                derivedScriptHash = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(finalScript, 'hex')).hash.toString();
                derivedScriptAddress = (0, mappers_1.scriptHashToEnterpriseAddress)(derivedScriptHash, (0, server_1.getCardanoClient)().network);
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                return (0, errors_1.rejectInvalid)(req, 'BuildSimpleAdaTransaction', `Failed to derive script address: ${errMsg}`, 'validatorScript');
            }
            cleanData.recipientAddress = derivedScriptAddress;
        }
        delete cleanData.validatorScript;
        delete cleanData.scriptParamsJson;
        delete cleanData.lockOnScript;
        if (referenceScriptHex) {
            cleanData.referenceScript = referenceScriptHex;
        }
        delete cleanData.referenceScriptHex;
        // handle the request / building the transaction / indexing the build result / returning build details
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            logger.debug({ senderAddress, recipientAddress: cleanData.recipientAddress, lovelaceAmount, hasDatum: !!outputDatumJson, hasAssets: !!assetsJson, lockOnScript: !!lockOnScript }, 'Building simple ADA transaction');
            const buildResult = await (0, server_1.getCardanoIndexer)().indexSimpleBuildResult(db, cleanData);
            // Persist derived script address + hash on the build record when lockOnScript was applied
            if (lockOnScript && derivedScriptHash && derivedScriptAddress && buildResult.id) {
                buildResult.scriptHash = derivedScriptHash;
                buildResult.scriptAddress = derivedScriptAddress;
                const { TransactionBuilds } = cds_1.default.entities('CardanoTransactionService');
                await db.run(UPDATE.entity(TransactionBuilds)
                    .set({ scriptHash: derivedScriptHash, scriptAddress: derivedScriptAddress })
                    .where({ id: buildResult.id }));
            }
            return buildResult;
        });
    });
    /**
     * Build a transaction with metadata
     * @param req - CDS request object
     * @returns {TransactionBuild} Transaction build details
     */
    srv.on('BuildTransactionWithMetadata', async (req) => {
        const { senderAddress, recipientAddress, lovelaceAmount, metadataJson } = req.data;
        // validate inputs (includes JSON parsing validation)
        const errors = (0, validators_1.validateTransactionInputs)({ senderAddress, recipientAddress, lovelaceAmount, metadataJson }, ['senderAddress', 'recipientAddress', 'lovelaceAmount', 'metadataJson']);
        (0, errors_1.throwIfValidationErrors)(req, 'BuildTransactionWithMetadata', errors);
        if (req.data.changeAddress && !(0, validators_1.isValidBech32Address)(req.data.changeAddress)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildTransactionWithMetadata', 'Invalid changeAddress format', 'changeAddress');
        }
        // Parse metadataJson (already validated as valid JSON)
        const parsedMetadata = JSON.parse(metadataJson);
        // handle the request / building the transaction / indexing the build result / returning build details
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            logger.debug({ senderAddress, recipientAddress, lovelaceAmount, metadataKeyCount: Object.keys(parsedMetadata).length }, 'Building transaction with metadata');
            return await (0, server_1.getCardanoIndexer)().indexMetadataBuildResult(db, { ...req.data, metadataJson: parsedMetadata });
        });
    });
    /**
     * Build a multi-asset transaction
     * @param req CDS request object
     * @returns {TransactionBuild} Transaction build details
     */
    srv.on('BuildMultiAssetTransaction', async (req) => {
        const { senderAddress, recipientAddress, lovelaceAmount, assetsJson, outputDatumJson, referenceScriptHex, validityStartMs, validityEndMs } = req.data;
        // validate inputs (includes JSON parsing validation)
        const errors = (0, validators_1.validateTransactionInputs)({ senderAddress, recipientAddress, lovelaceAmount, assetsJson, referenceScriptHex, validityStartMs, validityEndMs }, ['senderAddress', 'recipientAddress', 'lovelaceAmount', 'assetsJson']);
        (0, errors_1.throwIfValidationErrors)(req, 'BuildMultiAssetTransaction', errors);
        if (req.data.changeAddress && !(0, validators_1.isValidBech32Address)(req.data.changeAddress)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildMultiAssetTransaction', 'Invalid changeAddress format', 'changeAddress');
        }
        // Parse and validate assetsJson entries (unit + quantity, like parseExtraOutputs)
        const assetsResult = (0, tx_request_parsers_1.parseAssetsArray)(assetsJson, 'assetsJson');
        if (assetsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildMultiAssetTransaction', assetsResult.error, 'assetsJson');
        const parsedAssets = assetsResult.parsed;
        if (!parsedAssets || parsedAssets.length === 0) {
            return (0, errors_1.rejectInvalid)(req, 'BuildMultiAssetTransaction', 'assetsJson must contain at least one asset', 'assetsJson');
        }
        // Validation BEFORE handleRequest
        const cleanData = { ...req.data };
        delete cleanData.assetsJson;
        // parse optional output datum
        if (outputDatumJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(outputDatumJson, 'outputDatumJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildMultiAssetTransaction', jsonResult.error, 'outputDatumJson');
            cleanData.outputDatum = jsonResult.parsed;
            delete cleanData.outputDatumJson;
        }
        if (referenceScriptHex) {
            cleanData.referenceScript = referenceScriptHex;
        }
        delete cleanData.referenceScriptHex;
        // handle the request / building the transaction / indexing the build result / returning build details
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            logger.debug({ senderAddress, recipientAddress, lovelaceAmount, assets: parsedAssets, hasDatum: !!outputDatumJson }, 'Building multi-asset transaction');
            const result = await (0, server_1.getCardanoIndexer)().indexMultiAssetBuildResult(db, { ...cleanData, assets: parsedAssets });
            logger.debug({ id: result.id, fee: result.fee, size: result.size }, 'Multi-asset transaction build result');
            return result;
        });
    });
    /**
     * Build a minting transaction
     * @param req CDS request object
     * @returns {TransactionBuild} Transaction build details
     */
    srv.on('BuildMintTransaction', async (req) => {
        const { senderAddress, recipientAddress, lovelaceAmount, mintActionsJson, mintingPolicyScript, requiredSignersJson, scriptParamsJson, inlineDatumJson, mintRedeemerJson, lockOnScript, forceInputsJson, referenceInputsJson, referenceScriptHex, extraOutputsJson, metadataJson, validityStartMs, validityEndMs } = req.data;
        // validate inputs (includes JSON and CBOR validation)
        const errors = (0, validators_1.validateTransactionInputs)({ senderAddress, recipientAddress, lovelaceAmount, mintActionsJson, mintingPolicyScript, referenceScriptHex, metadataJson, validityStartMs, validityEndMs }, ['senderAddress', 'recipientAddress', 'lovelaceAmount', 'mintActionsJson', 'mintingPolicyScript']);
        (0, errors_1.throwIfValidationErrors)(req, 'BuildMintTransaction', errors);
        if (req.data.changeAddress && !(0, validators_1.isValidBech32Address)(req.data.changeAddress)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'Invalid changeAddress format', 'changeAddress');
        }
        // Parse mintActionsJson and convert quantity strings to bigint
        const parsedMintActionsRaw = JSON.parse(mintActionsJson);
        if (!Array.isArray(parsedMintActionsRaw)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'mintActionsJson must be a JSON array', 'mintActionsJson');
        }
        const parsedMintActions = parsedMintActionsRaw.map((action, actionIndex) => {
            if (!action || typeof action !== 'object') {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'Each mint action must be an object with assetUnit and quantity', 'mintActionsJson');
            }
            // Multi-policy mint FR: optional per-action mintingPolicyScript + redeemerJson.
            const policyFields = (0, tx_request_parsers_1.parseMintActionPolicyFields)(action, actionIndex);
            if (policyFields.error) {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', policyFields.error, 'mintActionsJson');
            }
            let actionPolicyId;
            if (policyFields.script) {
                try {
                    actionPolicyId = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(policyFields.script, 'hex')).hash.toString();
                }
                catch (err) {
                    const errMsg = err instanceof Error ? err.message : String(err);
                    return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `mintActions[${actionIndex}].mintingPolicyScript is not a valid Plutus script: ${errMsg}`, 'mintActionsJson');
                }
            }
            const bareAssetNameForExpansion = (!!scriptParamsJson || !!actionPolicyId) &&
                typeof action.assetUnit === 'string' &&
                action.assetUnit.length < const_1.MIN_FULL_ASSET_UNIT_LENGTH &&
                action.assetUnit.length % 2 === 0 &&
                /^[0-9a-fA-F]*$/.test(action.assetUnit);
            if (typeof action.assetUnit !== 'string' || (!(0, validators_1.isAssetUnit)(action.assetUnit) && !bareAssetNameForExpansion)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `Invalid assetUnit: "${action.assetUnit}" — must be policyId+assetName hex (or a bare assetName hex when scriptParamsJson or a per-action mintingPolicyScript is set)`, 'mintActionsJson');
            }
            let assetUnit = action.assetUnit;
            if (actionPolicyId) {
                if (assetUnit.length < const_1.MIN_FULL_ASSET_UNIT_LENGTH) {
                    assetUnit = actionPolicyId + assetUnit;
                }
                else if (!assetUnit.toLowerCase().startsWith(actionPolicyId)) {
                    return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `mintActions[${actionIndex}].assetUnit "${assetUnit}" does not start with its own policy id ${actionPolicyId}`, 'mintActionsJson');
                }
            }
            if (typeof action.quantity !== 'string') {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'Each mint action must have a string quantity', 'mintActionsJson');
            }
            if (!/^-?\d+$/.test(action.quantity)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `Invalid quantity format: "${action.quantity}" — must be an integer string`, 'mintActionsJson');
            }
            try {
                return {
                    assetUnit,
                    quantity: BigInt(action.quantity),
                    ...(action.redeemer !== undefined ? { redeemer: action.redeemer } : {}),
                    ...(policyFields.script ? { mintingPolicyScript: policyFields.script } : {}),
                    ...(policyFields.redeemer !== undefined ? { redeemerJson: policyFields.redeemer } : {})
                };
            }
            catch {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `Invalid quantity: "${action.quantity}" — cannot parse as integer`, 'mintActionsJson');
            }
        });
        // Parse and validate optional requiredSignersJson
        const requiredSignersResult = (0, tx_request_parsers_1.parseRequiredSigners)(requiredSignersJson);
        if (requiredSignersResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', requiredSignersResult.error, 'requiredSignersJson');
        const requiredSigners = requiredSignersResult.parsed;
        // Parse and validate optional scriptParamsJson
        let scriptParams;
        if (scriptParamsJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(scriptParamsJson, 'scriptParamsJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', jsonResult.error, 'scriptParamsJson');
            scriptParams = jsonResult.parsed;
            if (!Array.isArray(scriptParams)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'scriptParamsJson must be a JSON array', 'scriptParamsJson');
            }
        }
        // Parse and validate optional inlineDatumJson
        let inlineDatum;
        if (inlineDatumJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(inlineDatumJson, 'inlineDatumJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', jsonResult.error, 'inlineDatumJson');
            inlineDatum = jsonResult.parsed;
        }
        // Parse and validate optional mintRedeemerJson
        let mintRedeemer;
        if (mintRedeemerJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(mintRedeemerJson, 'mintRedeemerJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', jsonResult.error, 'mintRedeemerJson');
            mintRedeemer = jsonResult.parsed;
        }
        // Validate lockOnScript requires scriptParamsJson
        if (lockOnScript && (!scriptParams || scriptParams.length === 0)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'lockOnScript requires scriptParamsJson to derive script address', 'lockOnScript');
        }
        // Parse and validate optional extraOutputsJson (FR-2 on mint: each minted
        // token can sit on its own output with its own inline datum)
        const extraOutputsResult = (0, tx_request_parsers_1.parseExtraOutputs)(extraOutputsJson);
        if (extraOutputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', extraOutputsResult.error, 'extraOutputsJson');
        const extraOutputs = extraOutputsResult.parsed;
        // Parse and validate optional forceInputsJson
        const forceInputsResult = (0, tx_request_parsers_1.parseUtxoRefArray)(forceInputsJson, 'forceInputsJson');
        if (forceInputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', forceInputsResult.error, 'forceInputsJson');
        const forceInputs = forceInputsResult.parsed;
        // Parse and validate optional referenceInputsJson (CIP-31)
        const refInputsResult = (0, tx_request_parsers_1.parseUtxoRefArray)(referenceInputsJson, 'referenceInputsJson');
        if (refInputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', refInputsResult.error, 'referenceInputsJson');
        const referenceInputs = refInputsResult.parsed;
        // Parse and validate optional metadataJson
        let parsedMetadata;
        if (metadataJson) {
            try {
                parsedMetadata = JSON.parse(metadataJson);
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `Invalid metadataJson: ${errMsg}`, 'metadataJson');
            }
            if (typeof parsedMetadata !== 'object' || parsedMetadata === null || Array.isArray(parsedMetadata)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', 'metadataJson must be an object with numeric label keys', 'metadataJson');
            }
        }
        // handle the request / building the transaction / indexing the build result / returning build details
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            logger.debug({ senderAddress, recipientAddress, lovelaceAmount, mintActions: parsedMintActions, forceInputs: forceInputs?.length ?? 0, referenceInputs: referenceInputs?.length ?? 0, hasMetadata: !!parsedMetadata }, 'Building minting transaction');
            // Create clean request object with parsed mintActions (remove mintActionsJson, add mintActions)
            const cleanData = { ...req.data };
            delete cleanData.mintActionsJson;
            delete cleanData.requiredSignersJson;
            delete cleanData.scriptParamsJson;
            delete cleanData.inlineDatumJson;
            delete cleanData.mintRedeemerJson;
            delete cleanData.lockOnScript;
            delete cleanData.forceInputsJson;
            delete cleanData.referenceInputsJson;
            delete cleanData.extraOutputsJson;
            if (parsedMetadata) {
                cleanData.metadataJson = parsedMetadata;
            }
            else {
                delete cleanData.metadataJson;
            }
            if (referenceScriptHex) {
                cleanData.referenceScript = referenceScriptHex;
            }
            delete cleanData.referenceScriptHex;
            // Apply script parameters if provided (for parameterized validators)
            let finalMintingPolicyScript = mintingPolicyScript;
            let effectivePolicyId;
            if (scriptParams && scriptParams.length > 0) {
                try {
                    finalMintingPolicyScript = (0, tx_build_helper_1.applyScriptParameters)(mintingPolicyScript, scriptParams);
                    // BUG 7 fix: expand assetName-only entries to full assetUnit using the applied script's policyId.
                    const appliedScript = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(finalMintingPolicyScript, 'hex'));
                    effectivePolicyId = appliedScript.hash.toString();
                }
                catch (err) {
                    const errMsg = err instanceof Error ? err.message : String(err);
                    return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `Failed to apply script parameters: ${errMsg}`, 'scriptParamsJson');
                }
                for (const action of parsedMintActions) {
                    if (action.assetUnit.length < const_1.MIN_FULL_ASSET_UNIT_LENGTH) {
                        action.assetUnit = effectivePolicyId + action.assetUnit;
                    }
                }
                // lockOnScript: route output to the enterprise script address derived from applied script hash
                if (lockOnScript) {
                    const scriptAddr = (0, mappers_1.scriptHashToEnterpriseAddress)(effectivePolicyId, (0, server_1.getCardanoClient)().network);
                    cleanData.recipientAddress = scriptAddr;
                    logger.debug({ scriptAddress: scriptAddr, scriptHash: effectivePolicyId }, 'lockOnScript: routing output to script address');
                }
            }
            else {
                try {
                    effectivePolicyId = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(mintingPolicyScript, 'hex')).hash.toString();
                }
                catch {
                    // invalid script CBOR — skip the prefix check; the builder rejects it with its own message
                }
            }
            if (effectivePolicyId) {
                const policyId = effectivePolicyId;
                const mismatch = parsedMintActions.find((action) => !action.mintingPolicyScript && !action.assetUnit.toLowerCase().startsWith(policyId));
                if (mismatch) {
                    return (0, errors_1.rejectInvalid)(req, 'BuildMintTransaction', `assetUnit "${mismatch.assetUnit}" does not start with the minting policy id ${policyId} — pass the full unit as policyId+assetName (asset names longer than 28 bytes cannot be passed bare)`, 'mintActionsJson');
                }
            }
            const buildResult = await (0, server_1.getCardanoIndexer)().indexMintBuildResult(db, {
                ...cleanData,
                mintActions: parsedMintActions,
                mintingPolicyScript: finalMintingPolicyScript,
                requiredSigners,
                inlineDatum,
                mintRedeemer,
                forceInputs,
                referenceInputs,
                extraOutputs
            });
            // Post-build: compute CIP-14 fingerprint and scriptAddress
            if (buildResult.scriptHash) {
                const policyId = buildResult.scriptHash;
                const updates = {};
                // CIP-14 asset fingerprint for the first minted asset. The unit is always a
                // full policyId+assetName here: bare names were expanded before the build and
                // the prefix checks rejected everything else (a 56-hex unit is an empty
                // asset name, not a bare 28-byte name). The policy id comes from the UNIT,
                // not from buildResult.scriptHash: with a per-action mintingPolicyScript the
                // first action may mint under a different policy than the top-level script.
                if (parsedMintActions.length > 0) {
                    const firstAssetUnit = parsedMintActions[0].assetUnit;
                    const firstPolicyId = firstAssetUnit.slice(0, const_1.POLICY_ID_HEX_LENGTH);
                    const assetNameHex = firstAssetUnit.slice(const_1.POLICY_ID_HEX_LENGTH);
                    buildResult.fingerprint = (0, mappers_1.computeCip14Fingerprint)(firstPolicyId, assetNameHex);
                    updates.fingerprint = buildResult.fingerprint;
                }
                // lockOnScript: persist the derived script address on the build record (only when scriptParams were applied)
                if (lockOnScript && scriptParams && scriptParams.length > 0) {
                    buildResult.scriptAddress = (0, mappers_1.scriptHashToEnterpriseAddress)(policyId, (0, server_1.getCardanoClient)().network);
                    updates.scriptAddress = buildResult.scriptAddress;
                }
                if (buildResult.id && Object.keys(updates).length > 0) {
                    const { TransactionBuilds } = cds_1.default.entities('CardanoTransactionService');
                    await db.run(UPDATE.entity(TransactionBuilds).set(updates).where({ id: buildResult.id }));
                }
            }
            return buildResult;
        });
    });
    /**
     * Build a Plutus spending transaction (consume UTxO at script address)
     * @param req - CDS request object (with senderAddress, recipientAddress, lovelaceAmount, validatorScript, scriptTxHash, scriptOutputIndex, redeemerJson, datumJson, changeAddress)
     * @returns {TransactionBuild} Transaction build details
     */
    srv.on('BuildPlutusSpendTransaction', async (req) => {
        const { senderAddress, recipientAddress, lovelaceAmount, validatorScript, scriptTxHash, scriptOutputIndex, redeemerJson, datumJson, requiredSignersJson, scriptParamsJson, inlineDatumJson, lockOnScript, forceInputsJson, extraOutputsJson, mintActionsJson, mintingPolicyScript, mintRedeemerJson, referenceInputsJson, referenceScriptHex, validityStartMs, validityEndMs } = req.data;
        // Validate inputs
        const errors = (0, validators_1.validateTransactionInputs)({ senderAddress, recipientAddress, lovelaceAmount, validatorScript, scriptTxHash, scriptOutputIndex, redeemerJson, datumJson, referenceScriptHex, validityStartMs, validityEndMs }, ['senderAddress', 'recipientAddress', 'lovelaceAmount', 'validatorScript', 'scriptTxHash', 'redeemerJson']);
        (0, errors_1.throwIfValidationErrors)(req, 'BuildPlutusSpendTransaction', errors);
        if (req.data.changeAddress && !(0, validators_1.isValidBech32Address)(req.data.changeAddress)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'Invalid changeAddress format', 'changeAddress');
        }
        // Validate scriptOutputIndex separately (it's a number, not caught by required-fields check for empty string)
        if (scriptOutputIndex === undefined || scriptOutputIndex === null) {
            return (0, errors_1.rejectMissing)(req, 'BuildPlutusSpendTransaction', 'scriptOutputIndex');
        }
        // Parse redeemer JSON
        const parsedRedeemer = JSON.parse(redeemerJson);
        // Parse optional datum JSON
        const parsedDatum = datumJson ? JSON.parse(datumJson) : undefined;
        // Parse and validate optional requiredSignersJson
        const requiredSignersResult = (0, tx_request_parsers_1.parseRequiredSigners)(requiredSignersJson);
        if (requiredSignersResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', requiredSignersResult.error, 'requiredSignersJson');
        const requiredSigners = requiredSignersResult.parsed;
        // Parse and validate optional scriptParamsJson
        let scriptParams;
        if (scriptParamsJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(scriptParamsJson, 'scriptParamsJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', jsonResult.error, 'scriptParamsJson');
            scriptParams = jsonResult.parsed;
            if (!Array.isArray(scriptParams)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'scriptParamsJson must be a JSON array', 'scriptParamsJson');
            }
        }
        // Parse and validate optional inlineDatumJson
        let inlineDatum;
        if (inlineDatumJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(inlineDatumJson, 'inlineDatumJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', jsonResult.error, 'inlineDatumJson');
            inlineDatum = jsonResult.parsed;
        }
        // Validate lockOnScript requires scriptParamsJson
        if (lockOnScript && (!scriptParams || scriptParams.length === 0)) {
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'lockOnScript requires scriptParamsJson to derive script address', 'lockOnScript');
        }
        // Parse and validate optional forceInputsJson
        const forceInputsResult = (0, tx_request_parsers_1.parseUtxoRefArray)(forceInputsJson, 'forceInputsJson');
        if (forceInputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', forceInputsResult.error, 'forceInputsJson');
        const forceInputs = forceInputsResult.parsed;
        // Parse and validate optional referenceInputsJson (CIP-31)
        const refInputsResult = (0, tx_request_parsers_1.parseUtxoRefArray)(referenceInputsJson, 'referenceInputsJson');
        if (refInputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', refInputsResult.error, 'referenceInputsJson');
        const referenceInputs = refInputsResult.parsed;
        // Parse and validate optional extraOutputsJson
        const extraOutputsResult = (0, tx_request_parsers_1.parseExtraOutputs)(extraOutputsJson);
        if (extraOutputsResult.error)
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', extraOutputsResult.error, 'extraOutputsJson');
        const extraOutputs = extraOutputsResult.parsed;
        // Optional combined spend+mint parameters
        let parsedMintActions;
        let parsedMintRedeemer;
        if (mintActionsJson) {
            if (!mintingPolicyScript) {
                return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'mintActionsJson requires mintingPolicyScript', 'mintingPolicyScript');
            }
            const mintJson = (0, validators_1.validateJsonWithLimits)(mintActionsJson, 'mintActionsJson');
            if (!mintJson.valid)
                return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', mintJson.error, 'mintActionsJson');
            if (!Array.isArray(mintJson.parsed)) {
                return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'mintActionsJson must be a JSON array', 'mintActionsJson');
            }
            parsedMintActions = mintJson.parsed.map((rawAction, actionIndex) => {
                if (!rawAction || typeof rawAction !== 'object') {
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'Each mint action must be an object with assetUnit and quantity', 'mintActionsJson');
                }
                const action = rawAction;
                if (typeof action.quantity !== 'string' || !/^-?\d+$/.test(action.quantity)) {
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `Invalid quantity: "${action.quantity}" — must be an integer string`, 'mintActionsJson');
                }
                if (typeof action.assetUnit !== 'string') {
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'Each mint action must have assetUnit string', 'mintActionsJson');
                }
                // Multi-policy mint FR: optional per-action mintingPolicyScript + redeemerJson
                // (same rules as BuildMintTransaction).
                const policyFields = (0, tx_request_parsers_1.parseMintActionPolicyFields)(action, actionIndex);
                if (policyFields.error) {
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', policyFields.error, 'mintActionsJson');
                }
                let actionPolicyId;
                if (policyFields.script) {
                    try {
                        actionPolicyId = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(policyFields.script, 'hex')).hash.toString();
                    }
                    catch (err) {
                        const errMsg = err instanceof Error ? err.message : String(err);
                        return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `mintActions[${actionIndex}].mintingPolicyScript is not a valid Plutus script: ${errMsg}`, 'mintActionsJson');
                    }
                }
                const bareAssetNameForExpansion = ((!!scriptParamsJson && mintingPolicyScript === validatorScript) || !!actionPolicyId) &&
                    action.assetUnit.length < const_1.MIN_FULL_ASSET_UNIT_LENGTH &&
                    action.assetUnit.length % 2 === 0 &&
                    /^[0-9a-fA-F]*$/.test(action.assetUnit);
                if (!(0, validators_1.isAssetUnit)(action.assetUnit) && !bareAssetNameForExpansion) {
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `Invalid assetUnit: "${action.assetUnit}" — must be policyId+assetName hex (or a bare assetName hex when a per-action mintingPolicyScript is set, or scriptParamsJson is set and the policy equals the validator)`, 'mintActionsJson');
                }
                let assetUnit = action.assetUnit;
                if (actionPolicyId) {
                    if (assetUnit.length < const_1.MIN_FULL_ASSET_UNIT_LENGTH) {
                        assetUnit = actionPolicyId + assetUnit;
                    }
                    else if (!assetUnit.toLowerCase().startsWith(actionPolicyId)) {
                        return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `mintActions[${actionIndex}].assetUnit "${assetUnit}" does not start with its own policy id ${actionPolicyId}`, 'mintActionsJson');
                    }
                }
                return {
                    assetUnit,
                    quantity: BigInt(action.quantity),
                    ...(typeof action.redeemer === 'number' ? { redeemer: action.redeemer } : {}),
                    ...(policyFields.script ? { mintingPolicyScript: policyFields.script } : {}),
                    ...(policyFields.redeemer !== undefined ? { redeemerJson: policyFields.redeemer } : {})
                };
            });
            if (mintRedeemerJson) {
                const mrJson = (0, validators_1.validateJsonWithLimits)(mintRedeemerJson, 'mintRedeemerJson');
                if (!mrJson.valid)
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', mrJson.error, 'mintRedeemerJson');
                parsedMintRedeemer = mrJson.parsed;
            }
        }
        else if (mintingPolicyScript || mintRedeemerJson) {
            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', 'mintingPolicyScript / mintRedeemerJson require mintActionsJson', 'mintActionsJson');
        }
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            logger.debug({ senderAddress, recipientAddress, lovelaceAmount, scriptTxHash, scriptOutputIndex }, 'Building Plutus spending transaction');
            // Apply script parameters if provided (for parameterized validators)
            let finalValidatorScript = validatorScript;
            if (scriptParams && scriptParams.length > 0) {
                try {
                    finalValidatorScript = (0, tx_build_helper_1.applyScriptParameters)(validatorScript, scriptParams);
                }
                catch (err) {
                    const errMsg = err instanceof Error ? err.message : String(err);
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `Failed to apply script parameters: ${errMsg}`, 'scriptParamsJson');
                }
            }
            // FR-1: when the mint policy is byte-equal to the validator (multi-purpose script),
            // re-use the script-params-applied validator hex. Otherwise pass the policy through unchanged.
            let finalMintingPolicyScript;
            if (parsedMintActions) {
                finalMintingPolicyScript = (mintingPolicyScript === validatorScript)
                    ? finalValidatorScript
                    : mintingPolicyScript;
                if (finalMintingPolicyScript && scriptParams && scriptParams.length > 0 && mintingPolicyScript === validatorScript) {
                    let appliedPolicyId;
                    try {
                        appliedPolicyId = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(finalMintingPolicyScript, 'hex')).hash.toString();
                    }
                    catch (err) {
                        const errMsg = err instanceof Error ? err.message : String(err);
                        return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `Failed to hash applied script: ${errMsg}`, 'mintingPolicyScript');
                    }
                    for (const action of parsedMintActions) {
                        if (action.assetUnit.length < const_1.MIN_FULL_ASSET_UNIT_LENGTH) {
                            action.assetUnit = appliedPolicyId + action.assetUnit;
                        }
                    }
                }
                // BUG 9 fix: same policyId-prefix check as BuildMintTransaction — the builder
                // mints every action under the mint script's hash and parseAssetUnit silently
                // discards the unit's first 56 hex chars, so a mismatched prefix would mint a
                // truncated asset name.
                if (finalMintingPolicyScript) {
                    let mintPolicyId;
                    try {
                        mintPolicyId = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(finalMintingPolicyScript, 'hex')).hash.toString();
                    }
                    catch {
                        // invalid script CBOR — skip the prefix check; the builder rejects it with its own message
                    }
                    if (mintPolicyId) {
                        const policyId = mintPolicyId;
                        // Actions with their own per-action script were already checked
                        // against THAT script's policy id during parsing.
                        const mismatch = parsedMintActions.find((action) => !action.mintingPolicyScript && !action.assetUnit.toLowerCase().startsWith(policyId));
                        if (mismatch) {
                            return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `assetUnit "${mismatch.assetUnit}" does not start with the minting policy id ${policyId} — pass the full unit as policyId+assetName (asset names longer than 28 bytes cannot be passed bare)`, 'mintActionsJson');
                        }
                    }
                }
            }
            const cleanData = {
                ...req.data,
                plutusScriptExecution: {
                    validatorScript: finalValidatorScript,
                    scriptUtxo: {
                        txHash: scriptTxHash,
                        outputIndex: scriptOutputIndex,
                    },
                    redeemer: parsedRedeemer,
                    datum: parsedDatum,
                },
                requiredSigners,
                inlineDatum,
                forceInputs,
                referenceInputs,
                extraOutputs,
                mintActions: parsedMintActions,
                mintingPolicyScript: finalMintingPolicyScript,
                mintRedeemer: parsedMintRedeemer
            };
            if (referenceScriptHex) {
                cleanData.referenceScript = referenceScriptHex;
            }
            delete cleanData.requiredSignersJson;
            delete cleanData.scriptParamsJson;
            delete cleanData.inlineDatumJson;
            delete cleanData.lockOnScript;
            delete cleanData.forceInputsJson;
            delete cleanData.referenceInputsJson;
            delete cleanData.extraOutputsJson;
            delete cleanData.mintActionsJson;
            delete cleanData.mintRedeemerJson;
            delete cleanData.referenceScriptHex;
            // lockOnScript: route continuing output to enterprise script address
            if (lockOnScript && scriptParams && scriptParams.length > 0) {
                try {
                    const appliedScript = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(finalValidatorScript, 'hex'));
                    const derivedScriptHash = appliedScript.hash.toString();
                    const scriptAddr = (0, mappers_1.scriptHashToEnterpriseAddress)(derivedScriptHash, (0, server_1.getCardanoClient)().network);
                    cleanData.recipientAddress = scriptAddr;
                    logger.debug({ scriptAddress: scriptAddr, scriptHash: derivedScriptHash }, 'lockOnScript: routing continuing output to script address');
                }
                catch (err) {
                    const errMsg = err instanceof Error ? err.message : String(err);
                    return (0, errors_1.rejectInvalid)(req, 'BuildPlutusSpendTransaction', `Failed to derive script address: ${errMsg}`, 'validatorScript');
                }
            }
            const buildResult = await (0, server_1.getCardanoIndexer)().indexPlutusSpendBuildResult(db, cleanData);
            // lockOnScript: persist the derived script address on the build record (only when scriptParams were applied)
            if (lockOnScript && scriptParams && scriptParams.length > 0 && buildResult.scriptHash && buildResult.id) {
                const scriptAddr = (0, mappers_1.scriptHashToEnterpriseAddress)(buildResult.scriptHash, (0, server_1.getCardanoClient)().network);
                buildResult.scriptAddress = scriptAddr;
                const { TransactionBuilds } = cds_1.default.entities('CardanoTransactionService');
                await db.run(UPDATE.entity(TransactionBuilds).set({ scriptAddress: scriptAddr }).where({ id: buildResult.id }));
            }
            return buildResult;
        });
    });
    /**
     * Get build details for previously built transaction
     * @param req - CDS request object (with buildId)
     * @returns {TransactionBuild} Transaction build details
     */
    srv.on('GetBuildDetails', async (req) => {
        const { buildId } = req.data;
        // Validate inputs
        const errors = (0, validators_1.validateTransactionInputs)({ buildId }, ['buildId']);
        (0, errors_1.throwIfValidationErrors)(req, 'GetBuildDetails', errors);
        // handle the request / fetching the build details
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const existing = await db.run(SELECT.one.from(TransactionBuilds).where({ id: buildId }));
            if (!existing)
                throw new errors_1.NotFoundError(`Build '${buildId}'`);
            return existing;
        });
    });
    /**
     * Set up a collateral UTxO for Plutus transactions.
     * Checks if the address already has >= 2 UTxOs with >= 5 ADA each.
     * If not, builds a self-send transaction to create a 5 ADA collateral UTxO.
     * @param req - CDS request object (with address)
     * @returns {TransactionBuild} Transaction build details for the collateral setup
     */
    srv.on('SetCollateral', async (req) => {
        const { address } = req.data;
        if (!address)
            return (0, errors_1.rejectMissing)(req, 'SetCollateral', 'address');
        if (!(0, validators_1.isValidBech32Address)(address)) {
            return (0, errors_1.rejectInvalid)(req, 'SetCollateral', 'Invalid Bech32 address format', 'address');
        }
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            // Inside handleRequest: getCardanoClient() throwing (e.g. uninitialized after
            // a failed bootstrap → ProviderUnavailableError) and backend errors from
            // getAddressUtxos both get caught and properly mapped via mapError.
            // Use rejectInvalid (throws BackendError 400) instead of req.reject so
            // mapError sees a typed BackendError and preserves the 400 status.
            const utxos = await (0, server_1.getCardanoClient)().getAddressUtxos(address);
            if (utxos.length === 0) {
                return (0, errors_1.rejectInvalid)(req, 'SetCollateral', 'No UTxOs found at address', 'address');
            }
            const qualifyingUtxos = utxos.filter(u => (0, tx_build_helper_1.getLovelace)(u) >= const_1.COLLATERAL_LOVELACE);
            if (qualifyingUtxos.length >= 2) {
                return {
                    id: cds_1.default.utils.uuid(),
                    network: (0, server_1.getCardanoClient)().network,
                    senderAddress: address,
                    collateralAvailable: true,
                };
            }
            const totalLovelace = utxos.reduce((sum, u) => sum + (0, tx_build_helper_1.getLovelace)(u), 0n);
            if (totalLovelace < const_1.COLLATERAL_LOVELACE + const_1.FEE_BUFFER_LOVELACE) {
                return (0, errors_1.rejectInvalid)(req, 'SetCollateral', `Insufficient funds — need at least ${Number(const_1.COLLATERAL_LOVELACE + const_1.FEE_BUFFER_LOVELACE) / 1_000_000} ADA, have ${Number(totalLovelace) / 1_000_000} ADA`, 'address');
            }
            logger.debug({ address, existingQualifying: qualifyingUtxos.length }, 'Building collateral setup transaction');
            const result = await (0, server_1.getCardanoIndexer)().indexSimpleBuildResult(db, {
                network: (0, server_1.getCardanoClient)().network,
                senderAddress: address,
                recipientAddress: address,
                lovelaceAmount: const_1.COLLATERAL_LOVELACE.toString(),
                changeAddress: address,
            });
            return { ...result, collateralAvailable: false };
        });
    });
    /**
     * Submit signed transaction built previously
     * Handler validates, checks build exists, submits to blockchain, delegates persistence to indexer
     * @param req - CDS request object (with buildId, signedTxCbor)
     * @returns {TransactionSubmission} Transaction submission details
     */
    srv.on('SubmitTransaction', async (req) => {
        logger.debug('SubmitTransaction Action handler called');
        const { buildId, signedTxCbor } = req.data;
        // Validate inputs (includes CBOR format validation)
        const errors = (0, validators_1.validateTransactionInputs)({ buildId, signedTxCbor }, ['buildId', 'signedTxCbor']);
        (0, errors_1.throwIfValidationErrors)(req, 'SubmitTransaction', errors);
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            logger.debug({ buildId }, 'Submitting signed transaction');
            // Validate build exists
            const existing = await db.run(SELECT.one.from(TransactionBuilds).where({ id: buildId }));
            if (!existing)
                throw new errors_1.NotFoundError(`Build '${buildId}'`);
            // Verify the signed CBOR is for this build (audit-trail integrity)
            const signedTxHash = (0, tx_build_helper_1.getTxHashFromCbor)(signedTxCbor);
            if (signedTxHash !== existing.txBodyHash) {
                return (0, errors_1.rejectInvalid)(req, 'SubmitTransaction', `signedTxCbor hash '${signedTxHash}' does not match build txBodyHash '${existing.txBodyHash}'`, 'signedTxCbor');
            }
            // Use txBodyHash from build
            const txHash = existing.txBodyHash;
            // Two-phase submit: persist with 'pending', then submit to blockchain
            const submissionRecord = await (0, server_1.getCardanoIndexer)().persistTransactionSubmission(db, {
                signedTxCbor,
                txHash,
                buildId,
            });
            try {
                await (0, server_1.getCardanoClient)().submitTransaction(signedTxCbor);
                logger.info({ txHash }, 'Transaction submitted to blockchain');
                await (0, server_1.getCardanoIndexer)().updateSubmissionStatus(db, submissionRecord.id, 'submitted');
                submissionRecord.status = 'submitted';
                // Invalidate stale UTxO cache: spent input refs + output addresses from
                // the signed CBOR, plus the build's sender address. Best-effort — a
                // failure here must not fail the already-successful submit.
                try {
                    const addrBuild = await db.run(SELECT.one.from(AddressTransactionBuilds).where({ txBuild_id: buildId }));
                    await (0, server_1.getCardanoIndexer)().invalidateUtxoCacheForTx(db, (0, tx_build_helper_1.extractTxCacheTargets)(signedTxCbor), addrBuild?.address_address ? [addrBuild.address_address] : []);
                }
                catch (invalidateErr) {
                    logger.warn(`UTxO cache invalidation failed (submit unaffected): ${invalidateErr instanceof Error ? invalidateErr.message : String(invalidateErr)}`);
                }
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                logger.error({ txHash, error: errMsg }, 'Transaction submission failed');
                await (0, server_1.getCardanoIndexer)().updateSubmissionStatus(db, submissionRecord.id, 'failed', errMsg);
                throw err;
            }
            return submissionRecord;
        });
    });
    /**
     * Submit signed transaction without prior build
     * Handler validates, submits to blockchain, delegates persistence to indexer
     * Two-phase: persist with 'pending' first, then update to 'submitted' or 'failed'
     * @param req - CDS request object (with signedTxCbor, network)
     * @returns {TransactionSubmission} Transaction submission details
     */
    srv.on('SubmitSignedTransaction', async (req) => {
        logger.debug('SubmitSignedTransaction Action handler called');
        const { signedTxCbor, network } = req.data;
        // Validate inputs (includes CBOR format validation)
        const errors = (0, validators_1.validateTransactionInputs)({ signedTxCbor }, ['signedTxCbor']);
        (0, errors_1.throwIfValidationErrors)(req, 'SubmitSignedTransaction', errors);
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            // The declared network param was previously ignored — verify it against the
            // configured network so a caller targeting the wrong deployment gets a clear 400.
            const configuredNetwork = (0, server_1.getCardanoClient)().network;
            if (network && network !== configuredNetwork) {
                return (0, errors_1.rejectInvalid)(req, 'SubmitSignedTransaction', `network '${network}' does not match this deployment's network '${configuredNetwork}'`, 'network');
            }
            // Extract txHash from signed CBOR
            const txHash = (0, tx_build_helper_1.getTxHashFromCbor)(signedTxCbor);
            // Two-phase submit: persist with 'pending', then submit to blockchain
            const submissionRecord = await (0, server_1.getCardanoIndexer)().persistTransactionSubmission(db, {
                signedTxCbor,
                txHash,
                buildId: null,
            });
            try {
                await (0, server_1.getCardanoClient)().submitTransaction(signedTxCbor);
                logger.info({ txHash }, 'External transaction submitted');
                await (0, server_1.getCardanoIndexer)().updateSubmissionStatus(db, submissionRecord.id, 'submitted');
                submissionRecord.status = 'submitted';
                // Invalidate stale UTxO cache (spent inputs + output addresses) — best-effort
                try {
                    await (0, server_1.getCardanoIndexer)().invalidateUtxoCacheForTx(db, (0, tx_build_helper_1.extractTxCacheTargets)(signedTxCbor));
                }
                catch (invalidateErr) {
                    logger.warn(`UTxO cache invalidation failed (submit unaffected): ${invalidateErr instanceof Error ? invalidateErr.message : String(invalidateErr)}`);
                }
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                logger.error({ txHash, error: errMsg }, 'External transaction submission failed');
                await (0, server_1.getCardanoIndexer)().updateSubmissionStatus(db, submissionRecord.id, 'failed', errMsg);
                throw err;
            }
            return submissionRecord;
        });
    });
    /**
     * Check submission status (bound action on TransactionSubmissions)
     * @flow.status validates @from: [#submitted] automatically (409 if wrong state)
     * Queries blockchain for transaction confirmation and updates status accordingly
     * @param req - CDS request with entity key in params
     * @returns {TransactionSubmission} The updated transaction submission status
     */
    srv.on('CheckSubmissionStatus', async (req) => {
        logger.debug('CheckSubmissionStatus Action handler called');
        const { id: submissionId } = req.params[0];
        // @from: [#submitted] validated by framework — no manual status check needed
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            const submission = await db.run(SELECT.one.from(TransactionSubmissions).where({ id: submissionId }));
            if (!submission)
                throw new errors_1.NotFoundError(`Submission '${submissionId}'`);
            // Query blockchain for confirmation
            try {
                const txDetails = await (0, server_1.getCardanoClient)().getTransaction(submission.txHash);
                if (txDetails) {
                    await db.run(UPDATE.entity(TransactionSubmissions)
                        .set({ status: 'confirmed' })
                        .where({ id: submissionId }));
                    submission.status = 'confirmed';
                    logger.info({ submissionId, txHash: submission.txHash }, 'Transaction confirmed on chain');
                }
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                if (err instanceof errors_1.NotFoundError || err?.statusCode === 404) {
                    // Transaction genuinely not yet confirmed on chain
                    logger.debug({ submissionId, txHash: submission.txHash }, 'Transaction not yet confirmed on chain');
                }
                else {
                    // Provider error — don't mask as "pending", let caller know
                    logger.warn({ submissionId, txHash: submission.txHash, error: errMsg }, 'Failed to check transaction confirmation status');
                    throw err;
                }
            }
            return submission;
        });
    });
    /**
     * Get all existing transaction builds by address
     * @param req - CDS request object (with address)
     * @returns {AddressTransactionBuilds} Address transaction build associations
     */
    srv.on('GetTransactionBuildsByAddress', async (req) => {
        logger.debug('GetTransactionBuildsByAddress Action handler called');
        const { address } = req.data;
        // Validate inputs
        if (!address)
            return (0, errors_1.rejectMissing)(req, 'GetTransactionBuildsByAddress', 'address');
        if (!(0, validators_1.isValidBech32Address)(address))
            return (0, errors_1.rejectInvalid)(req, 'GetTransactionBuildsByAddress', 'Invalid bech32 address format', 'address');
        // Fetch the address-build associations
        return (0, backend_request_handler_1.handleRequest)(req, async (db) => {
            return db.run(SELECT.from(AddressTransactionBuilds).where({ address_address: address }));
        });
    });
    /**
     * Derive the enterprise script address + script hash for a validator script,
     * optionally after applying PlutusData parameters. No transaction is built.
     */
    srv.on('DeriveScriptAddress', async (req) => {
        const { validatorScript, scriptParamsJson, network } = req.data;
        if (!validatorScript)
            return (0, errors_1.rejectMissing)(req, 'DeriveScriptAddress', 'validatorScript');
        if (typeof validatorScript !== 'string' || !/^[0-9a-fA-F]+$/.test(validatorScript) || validatorScript.length % 2 !== 0) {
            return (0, errors_1.rejectInvalid)(req, 'DeriveScriptAddress', 'validatorScript must be an even-length hex string', 'validatorScript');
        }
        let scriptParams;
        if (scriptParamsJson) {
            const jsonResult = (0, validators_1.validateJsonWithLimits)(scriptParamsJson, 'scriptParamsJson');
            if (!jsonResult.valid)
                return (0, errors_1.rejectInvalid)(req, 'DeriveScriptAddress', jsonResult.error, 'scriptParamsJson');
            if (!Array.isArray(jsonResult.parsed)) {
                return (0, errors_1.rejectInvalid)(req, 'DeriveScriptAddress', 'scriptParamsJson must be a JSON array', 'scriptParamsJson');
            }
            scriptParams = jsonResult.parsed;
        }
        if (network && !VALID_DERIVE_NETWORKS.includes(network)) {
            return (0, errors_1.rejectInvalid)(req, 'DeriveScriptAddress', `Invalid network "${network}". Must be one of: ${VALID_DERIVE_NETWORKS.join(', ')}`, 'network');
        }
        return (0, backend_request_handler_1.handleRequest)(req, async () => {
            // getCardanoClient() throws ProviderUnavailableError (503) when the app context
            // is uninitialized. Resolving the network outside the inner CBOR try/catch
            // keeps that 503 distinct from the 400 used for malformed validatorScript bytes.
            const targetNetwork = network
                ? network
                : (0, server_1.getCardanoClient)().network;
            try {
                const finalScript = scriptParams && scriptParams.length > 0
                    ? (0, tx_build_helper_1.applyScriptParameters)(validatorScript, scriptParams)
                    : validatorScript;
                const scriptHash = cardano_ledger_ts_1.Script.fromCbor(Buffer.from(finalScript, 'hex')).hash.toString();
                const scriptAddress = (0, mappers_1.scriptHashToEnterpriseAddress)(scriptHash, targetNetwork);
                return { scriptAddress, scriptHash };
            }
            catch (err) {
                const errMsg = err instanceof Error ? err.message : String(err);
                return (0, errors_1.rejectInvalid)(req, 'DeriveScriptAddress', `Failed to derive script address: ${errMsg}`, 'validatorScript');
            }
        });
    });
    /**
     * Extract the 28-byte payment credential (key hash or script hash) from a Bech32
     * Cardano address. Pure local decoding — no blockchain call.
     */
    srv.on('ExtractPaymentKeyHash', async (req) => {
        const { address } = req.data;
        if (!address)
            return (0, errors_1.rejectMissing)(req, 'ExtractPaymentKeyHash', 'address');
        if (!(0, validators_1.isValidBech32Address)(address)) {
            return (0, errors_1.rejectInvalid)(req, 'ExtractPaymentKeyHash', 'Invalid bech32 address format', 'address');
        }
        try {
            const decoded = bech32_1.bech32.decode(address, const_1.BECH32_MAX_LENGTH);
            const bytes = Buffer.from(bech32_1.bech32.fromWords(decoded.words));
            // Cardano address: 1 header byte + 28-byte payment credential + (optional 28-byte stake credential)
            if (bytes.length < 29) {
                return (0, errors_1.rejectInvalid)(req, 'ExtractPaymentKeyHash', 'Address is too short to contain a payment credential', 'address');
            }
            const paymentKeyHash = bytes.slice(1, 29).toString('hex');
            return { paymentKeyHash };
        }
        catch (err) {
            const errMsg = err instanceof Error ? err.message : String(err);
            return (0, errors_1.rejectInvalid)(req, 'ExtractPaymentKeyHash', `Failed to decode address: ${errMsg}`, 'address');
        }
    });
};
//# sourceMappingURL=cardano-tx-service.js.map