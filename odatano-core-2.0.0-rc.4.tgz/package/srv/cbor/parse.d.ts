export interface ParsedInput {
    txHash: string;
    outputIndex: number;
}
export interface ParsedAsset {
    /** `"policyIdHex" + "assetNameHex"` (concatenated, no separator). */
    unit: string;
    /** Signed decimal string — negative for burns in `mint`, always non-negative in outputs. */
    quantity: string;
}
export interface ParsedOutput {
    address: string;
    lovelace: string;
    assets: ParsedAsset[];
    datumHash: string | null;
    inlineDatumHex: string | null;
    referenceScriptHex: string | null;
}
export interface ParsedWitnesses {
    vkeyCount: number;
    nativeScripts: number;
    plutusScripts: number;
    plutusData: number;
    redeemers: number;
}
export interface ParsedTransaction {
    /**
     * Blake2b-256 hash of the transaction body. Stable across signed/unsigned
     * CBOR — signing adds witnesses without changing the body hash.
     */
    txHash: string;
    /**
     * `"mainnet"` or `"testnet"` when the body carries a network ID byte, else
     * `null`. Preview vs preprod cannot be distinguished from CBOR alone; a
     * consumer needing that split must compare against the service network.
     */
    network: 'mainnet' | 'testnet' | null;
    inputs: ParsedInput[];
    outputs: ParsedOutput[];
    /** Validity-interval start slot (decimal string) or `null` if absent. */
    validityStart: string | null;
    /** TTL slot (decimal string) or `null` if absent. */
    validityEnd: string | null;
    /** Fee in lovelace (decimal string). */
    fee: string;
    /** Native-asset mint/burn entries; quantities are signed. */
    mint: ParsedAsset[];
    /** Metadata labels present (uint64 → decimal string); full payload via GetMetadataByTxHash for submitted txs. */
    metadataLabels: string[];
    collateral: ParsedInput[];
    /** 28-byte Ed25519 key hashes listed in the tx body's required_signers field. */
    requiredSigners: string[];
    scriptDataHash: string | null;
    witnesses: ParsedWitnesses;
}
/**
 * Parse hex-encoded Cardano transaction CBOR (signed or unsigned) into structured
 * fields. Pure function — no network call, no DB write. Callers are responsible
 * for upstream size/format validation via `isValidTxCborHex`.
 *
 * @throws TransactionValidationError with code `TX_PARSE_FAILED` on malformed CBOR.
 */
export declare function parseTransaction(cborHex: string): ParsedTransaction;
//# sourceMappingURL=parse.d.ts.map