"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTransaction = parseTransaction;
const buildooor_1 = require("@harmoniclabs/buildooor");
const errors_1 = require("../utils/errors");
const error_codes_1 = require("../utils/error-codes");
/**
 * Parse hex-encoded Cardano transaction CBOR (signed or unsigned) into structured
 * fields. Pure function — no network call, no DB write. Callers are responsible
 * for upstream size/format validation via `isValidTxCborHex`.
 *
 * @throws TransactionValidationError with code `TX_PARSE_FAILED` on malformed CBOR.
 */
function parseTransaction(cborHex) {
    let tx;
    try {
        tx = buildooor_1.Tx.fromCbor(Buffer.from(cborHex, 'hex'));
    }
    catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        throw new errors_1.TransactionValidationError(`failed to parse transaction CBOR: ${msg}`, e, error_codes_1.ERROR_CODES.TX_PARSE_FAILED);
    }
    const body = tx.body;
    return {
        txHash: body.hash.toString(),
        network: normalizeNetwork(body.network),
        inputs: body.inputs.map(mapInput),
        outputs: body.outputs.map(mapOutput),
        validityStart: body.validityIntervalStart != null ? body.validityIntervalStart.toString() : null,
        validityEnd: body.ttl != null ? body.ttl.toString() : null,
        fee: body.fee.toString(),
        mint: mapMint(body.mint),
        metadataLabels: extractMetadataLabels(tx.auxiliaryData),
        collateral: (body.collateralInputs ?? []).map(mapInput),
        requiredSigners: (body.requiredSigners ?? []).map((s) => s.toString()),
        scriptDataHash: body.scriptDataHash ? body.scriptDataHash.toString() : null,
        witnesses: countWitnesses(tx.witnesses),
    };
}
function normalizeNetwork(n) {
    return n === 'mainnet' || n === 'testnet' ? n : null;
}
function mapInput(utxo) {
    return {
        txHash: utxo.utxoRef.id.toString(),
        outputIndex: utxo.utxoRef.index,
    };
}
function mapOutput(out) {
    const units = out.value.toUnits();
    let lovelace = '0';
    const assets = [];
    for (const u of units) {
        if (u.unit === 'lovelace' || u.unit === '') {
            lovelace = u.quantity.toString();
        }
        else {
            assets.push({ unit: u.unit, quantity: u.quantity.toString() });
        }
    }
    let datumHash = null;
    let inlineDatumHex = null;
    if (out.datum != null) {
        if (out.datum instanceof buildooor_1.Hash32) {
            datumHash = out.datum.toString();
        }
        else {
            // anything not a Hash32 is an inline `Data` (PlutusData) payload
            inlineDatumHex = Buffer.from((0, buildooor_1.dataToCbor)(out.datum)).toString('hex');
        }
    }
    const referenceScriptHex = out.refScript
        ? Buffer.from(out.refScript.toCborBytes()).toString('hex')
        : null;
    return {
        address: out.address.toString(),
        lovelace,
        assets,
        datumHash,
        inlineDatumHex,
        referenceScriptHex,
    };
}
function mapMint(mint) {
    if (!mint)
        return [];
    return mint
        .toUnits()
        .filter((u) => u.unit !== 'lovelace' && u.unit !== '')
        .map((u) => ({ unit: u.unit, quantity: u.quantity.toString() }));
}
function extractMetadataLabels(aux) {
    const inner = aux?.metadata?.metadata;
    return inner ? Object.keys(inner) : [];
}
function countWitnesses(ws) {
    return {
        vkeyCount: (ws.vkeyWitnesses ?? []).length,
        nativeScripts: (ws.nativeScripts ?? []).length,
        plutusScripts: (ws.plutusV1Scripts ?? []).length +
            (ws.plutusV2Scripts ?? []).length +
            (ws.plutusV3Scripts ?? []).length,
        plutusData: (ws.datums ?? []).length,
        redeemers: (ws.redeemers ?? []).length,
    };
}
//# sourceMappingURL=parse.js.map