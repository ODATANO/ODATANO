"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SigningStatus = exports.ExternalSignerType = void 0;
/**
 * Supported external signer types
 */
var ExternalSignerType;
(function (ExternalSignerType) {
    /** Cardano CLI - Reference implementation for signing */
    ExternalSignerType["CARDANO_CLI"] = "cardano-cli";
    /** Browser wallets (Nami, Eternl, Flint, etc.) */
    ExternalSignerType["BROWSER_WALLET"] = "browser-wallet";
    /** Hardware wallets (Ledger, Trezor) */
    ExternalSignerType["HARDWARE_WALLET"] = "hardware-wallet";
    /** Custom/Unknown signer */
    ExternalSignerType["CUSTOM"] = "custom";
    /** Hardware Security Module (server-side PKCS#11) */
    ExternalSignerType["HSM"] = "hsm";
})(ExternalSignerType || (exports.ExternalSignerType = ExternalSignerType = {}));
/**
 * Signing request status
 */
var SigningStatus;
(function (SigningStatus) {
    /** Request created, awaiting signing */
    SigningStatus["PENDING"] = "pending";
    /** Transaction has been signed */
    SigningStatus["SIGNED"] = "signed";
    /** Signature verified, ready for submission */
    SigningStatus["VERIFIED"] = "verified";
    /** Transaction submitted to network */
    SigningStatus["SUBMITTED"] = "submitted";
    /** Signing or verification failed */
    SigningStatus["FAILED"] = "failed";
    /** Request expired (not signed within TTL) */
    SigningStatus["EXPIRED"] = "expired";
})(SigningStatus || (exports.SigningStatus = SigningStatus = {}));
//# sourceMappingURL=types.js.map