"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapTransaction = mapTransaction;
exports.mapTransactionInputs = mapTransactionInputs;
exports.mapTransactionInputAssets = mapTransactionInputAssets;
exports.mapTransactionOutputs = mapTransactionOutputs;
exports.mapTransactionOutputAssets = mapTransactionOutputAssets;
exports.mapAddress = mapAddress;
exports.mapAddressTransactions = mapAddressTransactions;
exports.mapAddressUtxos = mapAddressUtxos;
exports.mapAddressAssets = mapAddressAssets;
exports.mapAddressUtxoAssets = mapAddressUtxoAssets;
exports.mapNetworkInfo = mapNetworkInfo;
exports.mapBlock = mapBlock;
exports.mapEpoch = mapEpoch;
exports.mapTransactionMetadata = mapTransactionMetadata;
exports.mapPool = mapPool;
exports.mapAsset = mapAsset;
exports.mapAssetHistory = mapAssetHistory;
exports.mapDrep = mapDrep;
exports.mapAccount = mapAccount;
exports.mapError = mapError;
exports.mapBuildResult = mapBuildResult;
exports.mapBuildInputs = mapBuildInputs;
exports.mapBuildOutputs = mapBuildOutputs;
exports.mapProtocolParameters = mapProtocolParameters;
exports.mapTransactionSubmission = mapTransactionSubmission;
exports.mapAddressSigningRequest = mapAddressSigningRequest;
exports.mapAddressTransactionBuild = mapAddressTransactionBuild;
exports.normalizeCostModels = normalizeCostModels;
exports.computeCip14Fingerprint = computeCip14Fingerprint;
exports.scriptHashToEnterpriseAddress = scriptHashToEnterpriseAddress;
const cds_1 = __importDefault(require("@sap/cds"));
const blake2b_1 = __importDefault(require("blake2b"));
const bech32_1 = require("bech32");
const client_1 = require("@cardano-ogmios/client");
const cardano_costmodels_ts_1 = require("@harmoniclabs/cardano-costmodels-ts");
const logger = cds_1.default.log('mappers');
const errors_1 = require("./errors");
/**
 * Maximum age for cached/indexed data in milliseconds
 */
/**
 * Map Transaction Data
 * Converts provider transaction data into TransactionRow format
 * @param providerTx
 * @returns {TransactionRow} mapped transaction row
 */
function mapTransaction(providerTx) {
    // determine presence of optional data
    // length check matters: the Ogmios chain-sync mapper produced `[]` for metadata-less
    // txs, which the old `Array.isArray` test counted as "has metadata"
    const hasMetadata = Array.isArray(providerTx.metadata) && providerTx.metadata.length > 0;
    const hasInputs = Array.isArray(providerTx.inputs) && providerTx.inputs.length > 0;
    const hasOutputs = Array.isArray(providerTx.outputs) && providerTx.outputs.length > 0;
    return {
        hash: providerTx.hash,
        blockHash: providerTx.blockHash,
        blockHeight: providerTx.blockHeight ?? null,
        blockTime: providerTx.blockTime ?? null,
        slot: providerTx.slot ?? null,
        txIndex: providerTx.index ?? null,
        fee: providerTx.fee != null ? providerTx.fee : '0',
        deposit: providerTx.deposit != null ? providerTx.deposit : '0',
        size: providerTx.size ?? null,
        hasInputs: hasInputs,
        hasOutputs: hasOutputs,
        hasMetadata: hasMetadata,
    };
}
/**
 * Map Transaction Inputs
 * Converts provider transaction input data into TransactionInputRow format
 * @param txHash transaction hash
 * @param txInputs transaction inputs from provider
 * @returns {TransactionInputRow[]} mapped transaction input rows
 */
function mapTransactionInputs(txHash, txInputs) {
    return txInputs.map((input, idx) => {
        // Use array index as the input index (position in this transaction's inputs)
        // Note: input.outputIndex is the output index from the ORIGINAL UTxO being spent, not for keying here
        const inputIndex = idx;
        // check presence of address and amount arrays
        const hasAddress = !!input.address?.length;
        const hasAssets = Array.isArray(input.amount) && input.amount.length > 0;
        return {
            tx_hash: txHash,
            inputIndex: inputIndex,
            // `|| null`: unresolved chain-sync inputs carry '' — persist a null FK, not a
            // dangling empty-string Addresses association (lazy-path inputs are never empty)
            address_address: input.address || null,
            utxoData_dataHash: input.dataHash || null,
            utxoData_inlineDatum: input.inlineDatum || null,
            utxoData_referenceScriptHash: input.referenceScriptHash || null,
            isCollateral: Boolean(input.isCollateral),
            isReference: Boolean(input.isReference),
            hasAddresses: hasAddress,
            hasAssets: hasAssets,
        };
    });
}
/**
 * Map Transaction Input Assets
 * Converts provider transaction input asset data into TransactionInputAssetRow format
 * @param txHash transaction hash
 * @param inputs transaction inputs from provider
 * @returns {TransactionInputAssetRow[]} mapped transaction input asset rows
 */
function mapTransactionInputAssets(txHash, inputs) {
    return inputs.flatMap((input, idx) => {
        // Use array index as the input index (must match mapTransactionInputs)
        const inputIndex = idx;
        if (!Array.isArray(input.amount))
            return [];
        return input.amount.map(a => {
            const { policyId, assetName } = parseAssetUnit(a.unit);
            return {
                input_tx_hash: txHash,
                input_inputIndex: inputIndex,
                unit: a.unit,
                asset_quantity: a.quantity,
                asset_policyId: policyId,
                asset_assetName: assetName,
            };
        });
    });
}
/**
 * Map Transaction Outputs
 * Converts provider transaction output data into TransactionOutputRow format
 * @param txHash transaction hash
 * @param txOutputs transaction outputs from provider
 * @returns {TransactionOutputRow[]} mapped transaction output rows
 */
function mapTransactionOutputs(txHash, txOutputs) {
    return txOutputs.map((output) => {
        const outputIndex = output.outputIndex;
        const hasAddresses = !!output.address?.length;
        const hasAssets = Array.isArray(output.amount) && output.amount.length > 0;
        return {
            tx_hash: txHash,
            outputIndex: outputIndex,
            address_address: output.address,
            utxo_dataHash: output.dataHash || null,
            utxo_inlineDatum: output.inlineDatum || null,
            utxo_referenceScriptHash: output.referenceScriptHash || null,
            hasAddresses: hasAddresses,
            hasAssets: hasAssets,
        };
    });
}
/**
 * Map Transaction Output Assets
 * Converts provider transaction output asset data into TransactionOutputAssetRow format
 * @param txHash transaction hash
 * @param outputs transaction outputs from provider
 * @returns {TransactionOutputAssetRow[]} mapped transaction output asset rows
 */
function mapTransactionOutputAssets(txHash, outputs) {
    return outputs.flatMap((output) => {
        const outputIndex = output.outputIndex;
        if (!Array.isArray(output.amount))
            return [];
        return output.amount.map(a => {
            const { policyId, assetName } = parseAssetUnit(a.unit);
            return {
                output_tx_hash: txHash,
                output_outputIndex: outputIndex,
                unit: a.unit,
                asset_quantity: a.quantity,
                asset_policyId: policyId,
                asset_assetName: assetName,
            };
        });
    });
}
/**
 * Map Address Data
 * Converts provider address data into AddressRow format
 * @param address address string
 * @param addressData address data from provider
 * @returns {AddressRow} mapped address row
 */
function mapAddress(address, addressData, maxAge) {
    const now = Date.now();
    const nowIso = new Date(now).toISOString();
    const validToIso = new Date(now + maxAge).toISOString();
    const totalLovelace = Array.isArray(addressData.amount)
        ? (addressData.amount.find((a) => a.unit === 'lovelace')?.quantity ?? '0')
        : '0';
    const utxoCount = Array.isArray(addressData.utxos) ? addressData.utxos.length : 0;
    const hasUtxos = utxoCount > 0;
    const hasAssets = Array.isArray(addressData.amount) && addressData.amount.some((a) => a.unit !== 'lovelace');
    // Transactions are indexed separately in indexAddress() — updated to true after indexing
    const hasTransactions = false;
    return {
        address,
        stakeAddress: addressData.stakeAddress || null,
        type: addressData.type ?? 'base',
        isScript: addressData.isScript ?? false,
        totalLovelace: totalLovelace,
        utxoCount: utxoCount,
        validFrom: nowIso,
        validTo: validToIso,
        hasAssets: hasAssets,
        hasUTxOs: hasUtxos,
        hasTransactions: hasTransactions,
    };
}
/**
 * Map Address Transactions
 * Converts provider address transaction data into AddressTransactionRow format
 * @param addr address string
 * @param addressTxsData address transactions data from provider
 * @returns {AddressTransactionRow[]} mapped address transaction rows
 *  */
// AddressTransactions is keyed by (address, tx) and the per-tx net amounts are
// immutable once confirmed — no temporal validity. The entity has no
// validFrom/validTo columns, so the previous TTL plumbing was silently dropped.
function mapAddressTransactions(addr, addressTxsData) {
    return addressTxsData.map((tx) => {
        // Calculate net amounts for this address in this transaction
        const { netLovelace, netAssets } = calculateNetAmounts(addr, tx);
        return {
            address_address: addr,
            tx_hash: tx.hash,
            netAmount: netLovelace,
            blockTime: tx.blockTime,
            netAssets: netAssets.length > 0 ? JSON.stringify(netAssets) : null,
            hasAssets: netAssets.length > 0,
        };
    });
}
/**
 * Calculate net lovelace and asset changes for an address in a transaction
 * @param addr the address to calculate for
 * @param tx the transaction data
 * @returns object with netLovelace and netAssets array
 */
function calculateNetAmounts(addr, tx) {
    let inputLovelace = 0n;
    let outputLovelace = 0n;
    const assetBalances = new Map(); // unit -> net quantity
    // Process inputs belonging to this address (subtract)
    for (const input of tx.inputs ?? []) {
        if (input.address === addr) {
            for (const amount of input.amount ?? []) {
                if (amount.unit === 'lovelace') {
                    inputLovelace += BigInt(amount.quantity || '0');
                }
                else {
                    // Native asset
                    const current = assetBalances.get(amount.unit) || 0n;
                    assetBalances.set(amount.unit, current - BigInt(amount.quantity || '0'));
                }
            }
        }
    }
    // Process outputs going to this address (add)
    for (const output of tx.outputs ?? []) {
        if (output.address === addr) {
            for (const amount of output.amount ?? []) {
                if (amount.unit === 'lovelace') {
                    outputLovelace += BigInt(amount.quantity || '0');
                }
                else {
                    // Native asset
                    const current = assetBalances.get(amount.unit) || 0n;
                    assetBalances.set(amount.unit, current + BigInt(amount.quantity || '0'));
                }
            }
        }
    }
    // Convert asset map to array, filtering out zero balances
    const netAssets = [];
    for (const [unit, quantity] of assetBalances) {
        if (quantity !== 0n) {
            // Parse unit into policyId and assetName
            // Format: policyId (56 chars) + assetNameHex
            const policyId = unit.substring(0, 56);
            const assetNameHex = unit.substring(56);
            const assetName = hexToUtf8(assetNameHex);
            netAssets.push({
                unit,
                policyId,
                assetName,
                assetNameHex,
                quantity: quantity.toString()
            });
        }
    }
    return {
        netLovelace: (outputLovelace - inputLovelace).toString(),
        netAssets
    };
}
/**
 * Map Address UTxOs
 * @param addr address string
 * @param validFrom validFrom
 * @param validTo validTo
 * @param addressUtxosData address UTxOs data from provider
 * @returns {AddressUTxORow[]} mapped address UTxO rows
 */
function mapAddressUtxos(addr, validFrom, validTo, addressUtxosData) {
    return addressUtxosData.map((utxo) => {
        const amounts = Array.isArray(utxo.amount) ? utxo.amount : [];
        const lovelace = amounts.find((a) => a.unit === 'lovelace')?.quantity ?? '0';
        const hasAssets = amounts.some((a) => a.unit !== 'lovelace');
        return {
            address_address: addr,
            hash: utxo.txHash,
            index: utxo.outputIndex,
            blockHash: utxo.blockHash,
            utxodata_dataHash: utxo.datumHash,
            utxodata_inlineDatum: utxo.inlineDatum || null,
            // This column is a script HASH (Blake2b256). UTxO.scriptRef is overloaded:
            // Blockfrost/Ogmios give a 56-hex hash (stored as-is); Koios gives the full
            // script CBOR (used by the tx-builder, but it would truncate this hash
            // column) — only persist hash-length values here.
            utxodata_referenceScriptHash: utxo.scriptRef && utxo.scriptRef.length <= 64 ? utxo.scriptRef : null,
            lovelace: lovelace,
            validFrom: validFrom,
            validTo: validTo,
            hasAssets: hasAssets,
        };
    });
}
/**
 * Map Address Assets
 * Converts provider address asset data into AddressAssetRow format
 * @param addr address string
 * @param validFrom validFrom
 * @param validTo validTo
 * @param AssetAssets address assets from provider
 * @returns {AddressAssetRow[]} mapped address asset rows
 */
function mapAddressAssets(addr, validFrom, validTo, AssetAssets) {
    return AssetAssets
        .filter((asset) => asset.unit !== 'lovelace')
        .map((asset) => {
        const { policyId, assetName } = parseAssetUnit(asset.unit);
        return {
            address_address: addr,
            unit: asset.unit,
            validFrom: validFrom,
            validTo: validTo,
            asset_quantity: asset.quantity,
            asset_policyId: policyId,
            asset_assetName: assetName,
        };
    });
}
/**
 * Map UTxO Assets
 * Converts provider address UTxO asset data into UTxOAssetRow format
 * @param addressUtxosData address UTxOs data from provider
 * @param validFrom validFrom
 * @param validTo validTo
 * @returns {UTxOAssetRow[]} mapped UTxO asset rows
 */
function mapAddressUtxoAssets(addressUtxosData, validFrom, validTo) {
    const assets = [];
    addressUtxosData.forEach((utxo) => {
        const amounts = Array.isArray(utxo.amount) ? utxo.amount : [];
        for (const asset of amounts) {
            if (!asset || !asset.unit || asset.unit === 'lovelace')
                continue;
            const { policyId, assetName } = parseAssetUnit(asset.unit);
            assets.push({
                utxo_address_address: utxo.address,
                utxo_hash: utxo.txHash,
                utxo_index: utxo.outputIndex,
                unit: asset.unit,
                validFrom: validFrom,
                validTo: validTo,
                asset_quantity: asset.quantity,
                asset_policyId: policyId,
                asset_assetName: assetName,
            });
        }
    });
    return assets;
}
/**
 * Map Network Information
 * Converts provider network information data into NetworkInfoRow format
 * @param providerNetworkData
 * @returns {NetworkInfoRow} mapped network information row
 */
function mapNetworkInfo(providerNetworkData, max_age, network) {
    const now = Date.now();
    const nowIso = new Date(now).toISOString();
    const validToIso = new Date(now + max_age).toISOString();
    return {
        network: network,
        validFrom: nowIso,
        validTo: validToIso,
        maxSupply: providerNetworkData.supply.max,
        circulatingSupply: providerNetworkData.supply.circulating,
        totalSupply: providerNetworkData.supply.total,
        lockedSupply: providerNetworkData.supply.locked,
        treasurySupply: providerNetworkData.supply.treasury,
        reservesSupply: providerNetworkData.supply.reserves,
        liveStake: providerNetworkData.stake.live,
        activeStake: providerNetworkData.stake.active,
    };
}
/**
 * Map Block Data
 * Converts provider block data into BlockRow format
 * @param providerBlockData block data from provider
 * @param epochData epoch data for the block's epoch
 * @returns {BlockRow} mapped block row
 */
function mapBlock(providerBlockData, epochData) {
    return {
        time: new Date(providerBlockData.time * 1000).toISOString(),
        height: providerBlockData.height,
        hash: providerBlockData.hash,
        // was `String(x ?? null)` → persisted the literal string "null" when absent
        slotLeader: providerBlockData.slotLeader ?? null,
        epochNumber: epochData?.epoch ?? providerBlockData.epoch,
        epoch: epochData,
        // absolute slot — the crawler's reorg cut axis (same axis as Transactions.slot)
        slot: providerBlockData.slot ?? null,
        epochSlot: providerBlockData.epochSlot,
        size: providerBlockData.size,
        txCount: providerBlockData.txCount,
        fees: providerBlockData.fees ?? '0',
    };
}
/**
 * Map Epoch Data
 * Converts provider epoch data into EpochRow format
 * @param providerEpochData epoch data from provider
 * @returns {EpochRow} mapped epoch row
 */
function mapEpoch(providerEpochData) {
    return {
        epoch: providerEpochData.epoch,
        startTime: providerEpochData.start_time,
        endTime: providerEpochData.end_time,
        firstBlockTime: providerEpochData.first_block_time,
        lastBlockTime: providerEpochData.last_block_time,
        blockCount: providerEpochData.block_count,
        txCount: providerEpochData.tx_count,
        output: providerEpochData.output,
        fees: providerEpochData.fees,
        activeStake: providerEpochData.active_stake,
    };
}
/**
 * Map Transaction Metadata
 * Converts provider transaction metadata labels into TransactionMetadataRow format
 * @param providerLabels array of metadata label data from provider
 * @returns {TransactionMetadataRow[]} mapped transaction metadata rows
 */
function mapTransactionMetadata(providerLabels) {
    const rows = [];
    for (const lbl of providerLabels) {
        const numericId = Number(lbl.label);
        // Metadata labels are uint64; the exact value is kept in the `label` string.
        // The numeric `id` key (now Integer64) is exact up to 2^53 — warn beyond that.
        if (!Number.isSafeInteger(numericId)) {
            logger.warn(`Metadata label ${lbl.label} exceeds safe-integer range — numeric id key may lose precision (string label is exact)`);
        }
        rows.push({
            id: numericId,
            tx_hash: lbl.txHash,
            label: lbl.label.toString(),
            // Ogmios' parser deliberately exposes numeric metadata as native bigint.
            // Its matching serializer writes those values as exact JSON number tokens;
            // native JSON.stringify would throw, while Number coercion would truncate.
            payload: lbl.json !== undefined ? client_1.safeJSON.stringify(lbl.json) : null,
        });
    }
    return rows;
}
/**
 * Map Pool Data
 * Converts provider pool data into PoolRow format
 * @param providerPoolData pool data from provider
 * @returns {PoolRow} mapped pool row
 */
function mapPool(providerPoolData, max_age) {
    // temporal stamping: live fields (liveStake/liveSaturation/retired…) change every
    // epoch, so a slice expires after max_age and the index-on-miss read re-fetches.
    // Read the clock ONCE — separate Date.now() calls for validFrom/validTo let the
    // millisecond tick over between them, making the span max_age+1.
    const now = Date.now();
    const validFrom = new Date(now).toISOString();
    const validTo = new Date(now + max_age).toISOString();
    return {
        poolId: providerPoolData.poolId,
        vrfKeyHash: providerPoolData.vrfKeyHash,
        blocksMinted: providerPoolData.blocksMinted,
        blocksEpoch: providerPoolData.blocksEpoch,
        liveStake: providerPoolData.liveStake,
        liveSize: providerPoolData.liveSize,
        liveDelegators: providerPoolData.liveDelegators,
        liveSaturation: providerPoolData.liveSaturation,
        activeStake: providerPoolData.activeStake,
        activeSize: providerPoolData.activeSize,
        pledge: providerPoolData.pledge,
        margin: Number(providerPoolData.margin),
        fixedCost: providerPoolData.fixedCost,
        rewardAccount: providerPoolData.rewardAccount,
        validFrom,
        validTo,
    };
}
/**
 * Map Asset Info Data
 * Converts provider asset info into AssetRow format. Provider data is already
 * normalized by the backend mapper into the canonical AssetInfo shape, so this
 * function just stamps temporal validity and JSON-stringifies the on-chain metadata.
 * @param providerAssetInfo canonical asset info from backend
 * @param max_age TTL window in ms for the temporal validity
 * @returns {AssetRow} mapped asset row
 */
function mapAsset(providerAssetInfo, max_age) {
    // Read the clock once so validTo - validFrom is exactly max_age (see mapPool).
    const now = Date.now();
    const validFrom = new Date(now).toISOString();
    const validTo = new Date(now + max_age).toISOString();
    return {
        unit: providerAssetInfo.unit,
        policyId: providerAssetInfo.policyId,
        assetNameHex: providerAssetInfo.assetNameHex,
        assetName: providerAssetInfo.assetName,
        fingerprint: providerAssetInfo.fingerprint,
        totalSupply: providerAssetInfo.totalSupply,
        mintOrBurnCount: providerAssetInfo.mintOrBurnCount,
        initialMintTxHash: providerAssetInfo.initialMintTxHash,
        initialMintTime: providerAssetInfo.initialMintTime,
        onchainMetadata: providerAssetInfo.onchainMetadata
            ? JSON.stringify(providerAssetInfo.onchainMetadata)
            : null,
        registryName: providerAssetInfo.registryName,
        registryTicker: providerAssetInfo.registryTicker,
        registryDecimals: providerAssetInfo.registryDecimals,
        registryDescription: providerAssetInfo.registryDescription,
        registryUrl: providerAssetInfo.registryUrl,
        registryLogo: providerAssetInfo.registryLogo,
        validFrom,
        validTo,
    };
}
/**
 * Map Asset History entries to row format. No temporal stamping — mint/burn
 * events are immutable; UPSERT keyed on (unit, txHash) is idempotent.
 * @param entries asset history events from backend (already canonical)
 * @returns {AssetHistoryRow[]} mapped rows
 */
function mapAssetHistory(entries) {
    return entries.map((e) => ({
        unit: e.unit,
        txHash: e.txHash,
        action: e.action,
        quantity: e.quantity,
        blockTime: e.blockTime,
        blockHeight: e.blockHeight,
    }));
}
/**
 * Map Drep Data
 * Converts provider drep data into DrepRow format
 * @param providerDrepData drep data from provider
 * @returns {DrepRow} mapped drep row
 */
function mapDrep(providerDrepData, max_age) {
    // temporal stamping: amount/retired/expired drift over time → slice expires
    // after max_age so the index-on-miss read re-fetches fresh state.
    // Read the clock once so the span is exactly max_age (see mapPool).
    const now = Date.now();
    const validFrom = new Date(now).toISOString();
    const validTo = new Date(now + max_age).toISOString();
    return {
        drepId: providerDrepData.drepId,
        hex: providerDrepData.hex,
        amount: providerDrepData.amount,
        hasScript: Boolean(providerDrepData.hasScript),
        lastActiveEpoch: providerDrepData.lastActiveEpoch,
        retired: Boolean(providerDrepData.retired),
        expired: Boolean(providerDrepData.expired),
        validFrom,
        validTo,
    };
}
/**
 * Map Account Data
 * Converts provider account data into AccountRow format
 * @param providerAccountData account data from provider
 * @returns {AccountRow} mapped account row
 */
function mapAccount(providerAccountData, max_age) {
    // Read the clock once so validTo - validFrom is exactly max_age (see mapPool).
    const now = Date.now();
    const validFrom = new Date(now).toISOString();
    const validTo = new Date(now + max_age).toISOString();
    return {
        validFrom: validFrom,
        validTo: validTo,
        stakeAddress: providerAccountData.stakeaddress,
        active: providerAccountData.active,
        activeEpoch: providerAccountData.activeEpoch,
        controlledAmount: providerAccountData.controlledAmount,
        rewardsSum: providerAccountData.rewardsSum,
        withdrawalsSum: providerAccountData.withdrawalsSum,
        reservesSum: providerAccountData.reservesSum,
        treasurySum: providerAccountData.treasurySum,
        withdrawableAmount: providerAccountData.withdrawableAmount,
        hasAddresses: providerAccountData.addresses.length > 0,
    };
}
/**
 * Map Backend Error
 * Converts BackendError or unknown error into OData request rejection
 * @param req OData request
 * @param err error object (BackendError or unknown)
 * @param ctx context string for error message
 */
function mapError(req, err, ctx) {
    if (err instanceof errors_1.BackendError) {
        return req.reject(err.statusCode, fmt(err.code, ctx, err.message), err.target);
    }
    // Handle non-BackendError (plain Error, string, etc.)
    // Log full error server-side, but return sanitized message to client
    const internalMsg = err instanceof Error ? err.message : String(err);
    logger.error({ error: internalMsg }, `Unexpected error in ${ctx}`);
    return req.reject(500, fmt('INTERNAL_ERROR', ctx, 'An internal error occurred'));
}
/**
 * Map Transaction Build Result
 * Converts provider transaction build result into TransactionBuildRow format
 * @param txbuildResult transaction build result from provider
 * @returns {TransactionBuildRow} mapped transaction build row
 */
function mapBuildResult(txbuildResult, max_age) {
    const buildId = cds_1.default.utils.uuid();
    // Read the clock once so validTo - validFrom is exactly max_age (see mapPool).
    const nowMs = Date.now();
    const now = Math.floor(nowMs / 1000);
    const validFrom = new Date(nowMs).toISOString();
    const validTo = new Date(nowMs + max_age).toISOString();
    const hasInputs = Array.isArray(txbuildResult.inputs) && txbuildResult.inputs.length > 0;
    const hasOutputs = Array.isArray(txbuildResult.outputs) && txbuildResult.outputs.length > 0;
    return {
        id: buildId,
        validFrom: validFrom,
        validTo: validTo,
        builderEngine: txbuildResult.builderEngine,
        network: txbuildResult.network,
        senderAddress: txbuildResult.senderAddress,
        changeAddress: txbuildResult.changeOutput?.address ?? txbuildResult.senderAddress,
        unsignedTxCbor: txbuildResult.unsignedTxCbor,
        txBodyHash: txbuildResult.txBodyHash,
        fee: txbuildResult.feeLovelace,
        size: txbuildResult.sizeBytes, // size in bytes
        createdAt: now, // epoch seconds
        submission: null,
        hasInputs: hasInputs, // indicates if build has inputs
        hasOutputs: hasOutputs, // indicates if build has outputs
        wasSubmitted: false, // indicates if this build was submitted
        scriptHash: txbuildResult.scriptHash ?? null,
        mintScriptHash: txbuildResult.mintScriptHash ?? null,
        forcedInputsUsed: txbuildResult.forcedInputsUsed ?? 0,
        referenceInputsUsed: txbuildResult.referenceInputsUsed ?? 0,
    };
}
/**
 * Map Transaction Build Inputs
 * Converts transaction build result inputs into TransactionBuildInputRow format
 * @param buildId the transaction build ID
 * @param inputs transaction build result inputs
 * @returns {TransactionBuildInputRow[]} mapped transaction build input rows
 */
function mapBuildInputs(buildId, inputs) {
    return inputs.map((input, idx) => ({
        build_id: buildId,
        inputIndex: idx,
        txHash: input.txHash,
        outputIndex: input.index,
        address: input.address || null,
        lovelace: input.lovelace,
        hasAssets: false, // simple ADA transfers don't have assets
    }));
}
/**
 * Map Transaction Build Outputs
 * Converts transaction build result outputs into TransactionBuildOutputRow format
 * @param buildId the transaction build ID
 * @param outputs transaction build result outputs
 * @param changeAddress the change address to identify change outputs
 * @returns {TransactionBuildOutputRow[]} mapped transaction build output rows
 */
function mapBuildOutputs(buildId, outputs, changeAddress) {
    return outputs.map((output, idx) => ({
        build_id: buildId,
        outputIndex: idx,
        address: output.address,
        lovelace: output.lovelace,
        isChange: changeAddress ? output.address === changeAddress : false,
        hasAssets: false, // simple ADA transfers don't have assets
    }));
}
/**
 * Map Protocol Parameters
 * Converts provider protocol parameters into ProtocolParameterRow format
 * @param providerParams protocol parameters from provider
 * @returns {ProtocolParameterRow} mapped protocol parameter row
 */
function mapProtocolParameters(providerParams) {
    return {
        network: providerParams.network,
        epoch: providerParams.epoch,
        minFeeA: providerParams.minFeeA,
        minFeeB: providerParams.minFeeB,
        maxBlockSize: providerParams.maxBlockSize,
        maxTxSize: providerParams.maxTxSize,
        maxBlockHeaderSize: providerParams.maxBlockHeaderSize,
        keyDeposit: providerParams.keyDeposit,
        poolDeposit: providerParams.poolDeposit,
        eMax: providerParams.eMax,
        nOpt: providerParams.nOpt,
        a0: providerParams.a0,
        rho: providerParams.rho,
        tau: providerParams.tau,
        minPoolCost: providerParams.minPoolCost,
        decentralisationParam: providerParams.decentralisationParam,
        extraEntropy: providerParams.extraEntropy,
        protocolMajorVer: providerParams.protocolMajorVer,
        protocolMinorVer: providerParams.protocolMinorVer,
        minUtxo: providerParams.minUtxo,
        nonce: providerParams.nonce,
        costModels: providerParams.costModels,
        priceMem: providerParams.priceMem,
        priceStep: providerParams.priceStep,
        maxTxExMem: providerParams.maxTxExMem,
        maxTxExSteps: providerParams.maxTxExSteps,
        maxBlockExMem: providerParams.maxBlockExMem,
        maxBlockExSteps: providerParams.maxBlockExSteps,
        maxValSize: providerParams.maxValSize,
        collateralPercent: providerParams.collateralPercent,
        maxCollateralInputs: providerParams.maxCollateralInputs,
        coinsPerUtxoSize: providerParams.coinsPerUtxoSize,
        fetchedAt: providerParams.fetchedAt,
        source: providerParams.source,
    };
}
/**
 * Map Transaction Submission
 * Converts signed transaction CBOR and hash into TransactionSubmissionRow format
 * @param signedTxCbor signed transaction in CBOR hex format
 * @param txHash transaction hash
 * @returns {TransactionSubmissionRow} mapped transaction submission row
 */
function mapTransactionSubmission(signedTxCbor, txHash) {
    const now = Math.floor(Date.now() / 1000);
    return {
        signedTxCbor: signedTxCbor,
        txHash: txHash,
        submittedAt: now,
    };
}
/**
 * Map Address Signing Requests
 * Creates AddressSigningRequest row for address-signing request association
 * @param addr bech32 address
 * @param signingRequestId signing request UUID
 * @returns {AddressSigningRequestRow} mapped address signing request row
 */
function mapAddressSigningRequest(addr, signingRequestId) {
    return {
        address_address: addr,
        signingRequest_id: signingRequestId,
    };
}
/**
 * Map Address Transaction Builds
 * Creates AddressTransactionBuild row for address-build association
 * @param addr bech32 address
 * @param buildId transaction build UUID
 * @returns {AddressTransactionBuildRow} mapped address transaction build row
 */
function mapAddressTransactionBuild(addr, buildId) {
    return {
        address_address: addr,
        txBuild_id: buildId,
    };
}
//-----------------------------------------------------------------------
// Helper Functions
//-----------------------------------------------------------------------
/**
 * Normalize cost models to array format in canonical Plutus parameter order.
 *
 * Blockfrost's cost_models (named keys) has known key-value mapping bugs for
 * PlutusV3 (shifted values in the quotientInteger/remainderInteger region).
 * The Blockfrost backend now prefers cost_models_raw (canonical arrays from the
 * node) which bypasses this issue entirely.
 *
 * For V3 arrays: already in canonical order, just pad to 297 via toCostModelArrV3.
 * For V3 objects (Ogmios named format): toCostModelArrV3(obj) maps via canonical keys.
 * For V1/V2: alphabetical order IS the canonical order (no reordering needed).
 *
 * @param raw - Raw cost models from any backend (Blockfrost, Ogmios, Koios)
 * @returns Object with all cost model values as number arrays in canonical order
 */
function normalizeCostModels(raw) {
    const result = {};
    for (const [key, value] of Object.entries(raw)) {
        const isV3 = key === 'PlutusV3' || key === 'plutus:v3';
        if (Array.isArray(value)) {
            if (isV3) {
                // V3 arrays (from cost_models_raw or Ogmios) are already in canonical Plutus V3 order.
                // toCostModelArrV3 pads to 297 (Chang 2) with defaults if the array is shorter.
                result[key] = Array.from((0, cardano_costmodels_ts_1.toCostModelArrV3)(value)).map(Number);
            }
            else {
                // V1/V2: pass through (already in canonical order)
                result[key] = value;
            }
        }
        else if (value && typeof value === 'object') {
            const obj = value;
            if (isV3) {
                result[key] = Array.from((0, cardano_costmodels_ts_1.toCostModelArrV3)(obj)).map(Number);
            }
            else {
                // V1/V2: alphabetical sort IS correct for those versions
                result[key] = Object.keys(obj).sort()
                    .map(k => obj[k]);
            }
        }
    }
    return result;
}
/**
 * Convert hex string to UTF-8 string, falling back to hex if conversion fails.
 * This helper reduces code duplication and improves performance by centralizing
 * the conversion logic.
 *
 * @param hex - Hexadecimal string to convert
 * @returns {string} UTF-8 string or original hex if conversion fails
 */
function hexToUtf8(hex) {
    if (!hex)
        return hex;
    return Buffer.from(hex, 'hex').toString('utf8');
}
/**
 * Parse asset unit (policyId + assetNameHex) into components.
 * Optimizes repeated parsing logic across multiple mapper functions.
 * @param unit - Asset unit string (56 char policyId + asset name hex)
 * @returns { policyId: string | null; assetName: string | null } Object with policyId and assetName
 */
function parseAssetUnit(unit) {
    if (unit === 'lovelace') {
        return { policyId: null, assetName: 'lovelace' };
    }
    if (unit.length < 56 || !/^[a-f0-9]+$/i.test(unit)) {
        return { policyId: null, assetName: unit };
    }
    const policyId = unit.slice(0, 56);
    const assetNameHex = unit.slice(56);
    const assetName = assetNameHex.length > 0 ? hexToUtf8(assetNameHex) : '';
    return { policyId, assetName };
}
/**
 * Compute CIP-14 asset fingerprint from policyId and assetName.
 * Algorithm: bech32_encode("asset", blake2b_160(policyId_bytes + assetName_bytes))
 * @param policyIdHex - Policy ID as hex string (56 chars / 28 bytes)
 * @param assetNameHex - Asset name as hex string (variable length)
 * @returns CIP-14 fingerprint string (e.g. "asset1...")
 */
function computeCip14Fingerprint(policyIdHex, assetNameHex) {
    const input = Buffer.from(policyIdHex + assetNameHex, 'hex');
    const out = Buffer.alloc(20);
    (0, blake2b_1.default)(20).update(input).digest(out);
    const words = bech32_1.bech32.toWords(out);
    return bech32_1.bech32.encode('asset', words);
}
/**
 * Derive an enterprise script address from a script hash and network.
 * Enterprise address = header_byte + 28-byte script hash, bech32-encoded.
 * Header: 0x71 (mainnet, type 7 network 1) or 0x70 (testnet, type 7 network 0).
 */
function scriptHashToEnterpriseAddress(scriptHashHex, network) {
    const headerByte = network === 'mainnet' ? 0x71 : 0x70;
    const payload = Buffer.alloc(29);
    payload[0] = headerByte;
    Buffer.from(scriptHashHex, 'hex').copy(payload, 1);
    const words = bech32_1.bech32.toWords(payload);
    const hrp = network === 'mainnet' ? 'addr' : 'addr_test';
    return bech32_1.bech32.encode(hrp, words, 120);
}
/**
 * Format error message
 * @param code error code
 * @param ctx context string
 * @param msg error message
 * @returns {string} formatted error message
 */
function fmt(code, ctx, msg) {
    return `[${code}] ${ctx}: ${msg}`;
}
//# sourceMappingURL=mappers.js.map