"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DREP_ID_REGEX = exports.POOL_ID_REGEX = exports.ASSET_UNIT_REGEX = exports.TX_HASH_REGEX = exports.HEX_56_REGEX = exports.HEX_64_REGEX = exports.MAX_POSIX_MS_DIGITS = exports.DEFAULT_VALIDITY_END_OFFSET_MS = exports.DEFAULT_VALIDITY_START_OFFSET_MS = exports.GENESIS_INFOS_BY_NETWORK = exports.MIN_CHANGE_LOVELACE = exports.ED25519_KEY_HASH_REGEX = exports.ED25519_KEY_HASH_HEX_LENGTH = exports.MIN_FULL_ASSET_UNIT_LENGTH = exports.POLICY_ID_HEX_LENGTH = exports.DREP_ID_BYTES = exports.POOL_ID_BYTES = exports.MAX_EPOCH = exports.MAX_TX_CBOR_HEX_LENGTH = exports.BECH32_MAX_LENGTH = exports.MAX_STRING_LENGTH = exports.MAX_ARRAY_LENGTH = exports.MAX_KEYS = exports.MAX_DEPTH = exports.MAX_JSON_SIZE = exports.HRP = exports.FEE_BUFFER_LOVELACE = exports.COLLATERAL_LOVELACE = exports.ABS_MEM_BUFFER = exports.ABS_CPU_BUFFER = exports.EXECUTION_UNIT_BUFFER = exports.HIGH_EXECUTION_UNITS = exports.DEFAULT_EXECUTION_UNITS = exports.EPOCH_CONFIG_BY_NETWORK = exports.CARDANO_DEFAULTS = void 0;
/**
 * Cardano protocol constants
 */
exports.CARDANO_DEFAULTS = {
    /** Maximum ADA supply in lovelace (45 billion ADA) */
    MAX_LOVELACE_SUPPLY: '45000000000000000',
    /** Milliseconds per slot */
    MS_PER_SLOT: 1000,
};
/**
 * Network-specific epoch geometry, anchored at the Shelley transition:
 * `epochStartSlot(epoch) = shelleyStartSlot + (epoch - shelleyStartEpoch) * slotsPerEpoch`.
 * A single global SLOTS_PER_EPOCH is wrong twice over — preview uses 86 400 (1 day),
 * and mainnet/preprod epochs are offset by their Byron era.
 */
exports.EPOCH_CONFIG_BY_NETWORK = {
    mainnet: { shelleyStartEpoch: 208, shelleyStartSlot: 4_492_800, slotsPerEpoch: 432_000 },
    preprod: { shelleyStartEpoch: 4, shelleyStartSlot: 86_400, slotsPerEpoch: 432_000 },
    preview: { shelleyStartEpoch: 0, shelleyStartSlot: 0, slotsPerEpoch: 86_400 },
};
/**
 * Default execution units for Plutus scripts
 * Used when dynamic evaluation is not available
 */
exports.DEFAULT_EXECUTION_UNITS = {
    /** Memory units for script execution */
    mem: 14_000_000,
    /** CPU steps for script execution */
    cpu: 10_000_000_000,
};
/**
 * High execution units for initial transaction build (before evaluation)
 * Set higher than DEFAULT to ensure fee estimation is sufficient before actual evaluation
 */
exports.HIGH_EXECUTION_UNITS = {
    /** Memory units - high for evaluation pass */
    mem: 28_000_000,
    /** CPU steps - high for evaluation pass */
    cpu: 20_000_000_000,
};
/**
 * Execution unit buffer — relative multiplier applied to evaluator output.
 * Combined with ABS_* floors below so small validators also get a meaningful cushion.
 */
exports.EXECUTION_UNIT_BUFFER = 1.1;
/**
 * Absolute ExUnits floor added on top of the relative multiplier.
 *
 * Rationale: validators that iterate reference inputs and decode inline CBOR
 * datums (e.g. oracle-consuming mint policies) show a larger ScriptContext →
 * ledger drift than the documented ~10k–30k CPU / ~50–100 mem band — real-world
 * cases overshot a 50k/1k floor by ~27k CPU / ~56 mem, burning the submit fee.
 * The floor is sized to cover reference-input + CBOR-decoding drift on top of
 * the 10% relative multiplier; `max_tx_ex_units` still caps build-time totals,
 * so oversizing here cannot push a tx past network limits — it only trades a
 * few extra lovelace of fee for avoiding an opaque PlutusFailure on submit.
 */
exports.ABS_CPU_BUFFER = 200_000;
exports.ABS_MEM_BUFFER = 5_000;
/**
 * Transaction building constants
 */
/** Collateral amount in lovelace (5 ADA) */
exports.COLLATERAL_LOVELACE = 5000000n;
/** Fee buffer in lovelace (1 ADA) */
exports.FEE_BUFFER_LOVELACE = 1000000n;
exports.HRP = {
    mainnet: { addr: /^addr1[0-9a-z]{50,100}$/, stake: /^stake1[0-9a-z]{53,}$/ },
    preview: { addr: /^addr_test1[0-9a-z]{50,100}$/, stake: /^stake_test1[0-9a-z]{53,}$/ },
    preprod: { addr: /^addr_test1[0-9a-z]{50,100}$/, stake: /^stake_test1[0-9a-z]{53,}$/ },
};
/**
 * Input validation limits to prevent DoS attacks
 */
/** Maximum JSON string length in bytes (1MB) */
exports.MAX_JSON_SIZE = 1_048_576;
/** Maximum nesting depth for JSON objects/arrays */
exports.MAX_DEPTH = 10;
/** Maximum number of keys in a JSON object */
exports.MAX_KEYS = 100;
/** Maximum number of elements in a JSON array */
exports.MAX_ARRAY_LENGTH = 1000;
/** Maximum length of a single string value */
exports.MAX_STRING_LENGTH = 65536;
/** Maximum ech32 string length to prevent DoS */
exports.BECH32_MAX_LENGTH = 2000;
/**
 * Maximum hex length of transaction CBOR accepted by ParseTransactionCbor.
 * Mainnet `maxTxSize` is currently 16 KiB; 64 KiB raw (= 128 KiB hex) leaves
 * generous headroom for future protocol bumps and reference-script outputs
 * while keeping the parser from being a memory-exhaustion vector.
 */
exports.MAX_TX_CBOR_HEX_LENGTH = 65536 * 2;
/** Maximum reasonable epoch number */
exports.MAX_EPOCH = 100_000;
/** Standard pool ID payload length */
exports.POOL_ID_BYTES = 28;
/** Standard DRep ID payload length (1 byte type prefix + 28 byte key hash) */
exports.DREP_ID_BYTES = 29;
/** Length of a hex-encoded Cardano policy ID (28 bytes = 56 hex chars) */
exports.POLICY_ID_HEX_LENGTH = 56;
/** Minimum length of a full asset unit (policyId + at least 1 char assetName) */
exports.MIN_FULL_ASSET_UNIT_LENGTH = exports.POLICY_ID_HEX_LENGTH + 1; // 57
/** Length of a hex-encoded Ed25519 key hash (28 bytes = 56 hex chars) */
exports.ED25519_KEY_HASH_HEX_LENGTH = 56;
/** Regex for validating Ed25519 key hash hex strings */
exports.ED25519_KEY_HASH_REGEX = /^[a-f0-9]{56}$/i;
/** Minimum lovelace for a change output carrying native assets (2 ADA) */
exports.MIN_CHANGE_LOVELACE = 2_000_000;
/**
 * Shelley-era genesis parameters per network, used to construct Buildooor's
 * GenesisInfos so `TxBuilder.posixToSlot()` can convert validity-window
 * Posix ms into ledger slots. `slotLengthMs` is 1000 ms on all current networks.
 */
exports.GENESIS_INFOS_BY_NETWORK = {
    mainnet: { systemStartPosixMs: 1596491091000, slotLengthMs: 1000, startSlotNo: 4492800 },
    preprod: { systemStartPosixMs: 1655683200000, slotLengthMs: 1000, startSlotNo: 0 },
    preview: { systemStartPosixMs: 1666656000000, slotLengthMs: 1000, startSlotNo: 0 },
};
/** Default validity-window start offset: `now - 2 min` to absorb clock skew. */
exports.DEFAULT_VALIDITY_START_OFFSET_MS = 120_000;
/** Default validity-window end offset: `now + 1 h` — generous enough for human-latency sign+submit flows. */
exports.DEFAULT_VALIDITY_END_OFFSET_MS = 60 * 60 * 1000;
/** Max accepted digits in a Posix-ms string (13 digits covers Unix ms timestamps through ~Nov 2286). */
exports.MAX_POSIX_MS_DIGITS = 13;
/**
 * Generic 64-character hex string (used for block hashes and other 32-byte hex identifiers)
 */
exports.HEX_64_REGEX = /^[a-f0-9]{64}$/;
/**
 * Generic 56-character hex string — 28-byte hashes (Blake2b-224 / payment credential / script hash / pool key hash).
 */
exports.HEX_56_REGEX = /^[a-f0-9]{56}$/;
/**
 * Transaction hash Regex - 64-character hexadecimal string
 */
exports.TX_HASH_REGEX = /^[a-f0-9]{64}$/;
/**
 * Asset unit Regex - policy ID (56 hex chars) + asset name (0-128 hex chars)
 */
exports.ASSET_UNIT_REGEX = /^[a-f0-9]{56}([a-f0-9]{2}){0,32}$/; // policy ID (56) + asset name (0-32 bytes per ledger rules -> 0-64 hex chars, even length; total ≤ 120 = String(120) key column)
/**
 *  Pool ID Regex - bech32 with HRP "pool" and 28 bytes payload
 */
exports.POOL_ID_REGEX = /^pool1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{51}$/;
/**
 * DRep ID Regex - bech32 with HRP "drep" and 50-60 chars payload
 */
exports.DREP_ID_REGEX = /^drep1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{50,60}$/;
//# sourceMappingURL=const.js.map