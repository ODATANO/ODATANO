import { type ErrorCode } from './error-codes';
import { Request } from '@sap/cds';
/**
 * Backend Errors Implementation
 * Defines typed errors for backend communication issues
 */
/**
 * BackendError Base class for all backend-related errors
 */
export declare class BackendError extends Error {
    readonly statusCode: number;
    readonly code: ErrorCode;
    readonly backendName?: string | undefined;
    readonly originalError?: unknown | undefined;
    readonly target?: string | undefined;
    /** Constructor
     * @param message error message string
     * @param statusCode error status code
     * @param code error code
     * @param backendName name of the backend where the error originated
     * @param originalError original error object
     * @param target target resource (if applicable)
     */
    constructor(message: string, statusCode?: number, code?: ErrorCode, backendName?: string | undefined, originalError?: unknown | undefined, target?: string | undefined);
}
/**
 * NotFoundError - Resource not found in backend (404)
 * This is NOT a provider error - it's a valid response indicating the resource doesn't exist
 * Examples: transaction hash not found, address has no UTxOs
 */
export declare class NotFoundError extends BackendError {
    /** Constructor
     * @param resource name of the resource that was not found
     * @param backendName name of the backend where the error originated
     * @param originalError original error object
     */
    constructor(resource: string, backendName?: string, originalError?: unknown);
}
/**
 * TransactionValidationError - Transaction failed validation (400)
 * Indicates that the transaction failed validation checks
 * Examples: wrong signature, tampered CBOR, invalid witnesses
 */
export declare class TransactionValidationError extends BackendError {
    /** Constructor
     * @param message detailed validation failure message
     * @param originalError original error object
     * @param code optional override (e.g. `TX_PARSE_FAILED` for CBOR decode failures);
     *             defaults to `TX_VALIDATION_FAILED`.
     */
    constructor(message: string, originalError?: unknown, code?: ErrorCode);
}
/**
 * ScriptValidationError - Plutus script validation failed on the ledger (400)
 * Distinguishes a clean ledger rejection (PlutusFailure, CekError, overspent
 * budget, script hash mismatch) from provider outages (503). The transaction
 * was well-formed enough to reach phase-2 validation — retrying against a
 * different provider will not help; the tx shape itself is the problem.
 */
export declare class ScriptValidationError extends BackendError {
    /** Constructor
     * @param message detailed script failure message (typically from ledger)
     * @param originalError original error object
     */
    constructor(message: string, originalError?: unknown);
}
/**
 * TransactionAlreadySubmittedError - Transaction already exists (409)
 * Indicates that the transaction has already been submitted (duplicate/replay)
 * Examples: same txHash already in mempool or on chain
 */
export declare class TransactionAlreadySubmittedError extends BackendError {
    readonly txHash: string;
    /** Constructor
     * @param txHash the transaction hash that was already submitted
     * @param originalError original error object
     */
    constructor(txHash: string, originalError?: unknown);
}
/**
 * InsufficientFundsError - Not enough funds or assets available (400)
 * Indicates that the address does not have enough of a specific asset to complete the transaction
 * Examples: trying to send more ADA than available, not enough native tokens
 */
export declare class InsufficientFundsError extends BackendError {
    readonly assetUnit: string;
    readonly required: bigint;
    readonly available: bigint;
    /** Constructor
     * @param assetUnit the asset unit that is insufficient (e.g., "lovelace" or "policyId.assetName")
     * @param required the required amount (0n when unknown)
     * @param available the available amount (0n when unknown)
     * @param originalError original error object
     * @param detail human-readable cause shown INSTEAD of the amounts — use when
     *               the amounts are unknown; "required 0, available 0" reads as
     *               nonsense from the consumer's perspective
     */
    constructor(assetUnit: string, required: bigint, available: bigint, originalError?: unknown, detail?: string);
}
/**
 * MixedAssetsError - UTxO contains mixed assets when pure ADA is required (400)
 * Indicates that a UTxO contains native assets in addition to ADA, but the operation requires ADA-only UTxOs
 */
export declare class MixedAssetsError extends BackendError {
    readonly utxoRef: string;
    readonly assets: string[];
    /** Constructor
     * @param utxoRef UTxO reference (txHash#outputIndex)
     * @param assets list of non-ADA assets found in the UTxO
     * @param originalError original error object
     */
    constructor(utxoRef: string, assets: string[], originalError?: unknown);
}
/**
 * ProviderUnavailableError - Provider unavailable or timeout (503)
 * Indicates a temporary issue - retrying may help
 * Examples: network timeout, 5xx errors, service down
 */
export declare class ProviderUnavailableError extends BackendError {
    /** Constructor
     * @param message error message string
     * @param backendName name of the backend where the error originated
     * @param timeoutMs optional timeout duration in milliseconds
     * @param originalError original error object
     */
    constructor(message: string, backendName?: string, timeoutMs?: number, originalError?: unknown);
}
/**
 * RateLimitError - Provider rate limit exceeded (429)
 * Indicates too many requests - client should back off and retry later
 * Examples: Blockfrost 10 req/sec limit, Koios tier limits
 */
export declare class RateLimitError extends BackendError {
    /** Constructor
     * @param message error message string
     * @param backendName name of the backend where the error originated
     * @param retryAfter optional retry-after duration in seconds
     * @param originalError original error object
     */
    constructor(message: string, backendName?: string, retryAfter?: number, originalError?: unknown);
}
/**
 * AllBackendsFailedError - All backends failed
 * Aggregates multiple backend errors and returns the most relevant status
 */
export declare class AllBackendsFailedError extends BackendError {
    readonly errors: BackendError[];
    /** Constructor
     * @param errors array of backend errors
     * @param originalError original error object
     */
    constructor(errors: BackendError[], originalError?: unknown);
}
/**
 * True when the error proves the resource is absent on EVERY backend that was
 * consulted: either a direct NotFoundError, or an AllBackendsFailedError whose
 * collected per-backend errors are all 404s. CardanoClient's failover wraps
 * per-backend errors (including 404s) into AllBackendsFailedError, so callers
 * that need "definitively not found" (e.g. the wallet-worker's dropped-tx
 * detection) must use this instead of `instanceof NotFoundError`. A mixed
 * result (one backend 404, another 500) is NOT proof of absence.
 */
export declare function isNotFoundOnAllBackends(err: unknown): boolean;
/**
 *  HttpErrorLike - Simplified interface for HTTP errors from various libraries
 */
export interface HttpErrorLike {
    message?: string;
    code?: string;
    status?: number;
    response?: {
        status?: number;
        headers?: Record<string, unknown>;
        data?: {
            error?: string;
            message?: string;
            [k: string]: unknown;
        };
    };
    [k: string]: unknown;
}
/** True when a PostgREST error body's `code` denotes a provider-side SQL fault. */
export declare function isPostgrestServerErrorCode(code: unknown): boolean;
/**
 * Utility functions to extract status and message from HttpErrorLike
 * @param err error object
 * @returns {number} status code
 */
export declare function getErrorStatus(err: HttpErrorLike | unknown): number;
/**
 * Utility functions to extract status and message from HttpErrorLike
 * @param err error object
 * @returns {string} error message
 */
export declare function getErrorMessage(err: HttpErrorLike | unknown): string;
/**
 * Normalizes any backend error into a typed BackendError
 *
 * Priority (checked in order):
 * 1. TX Submission — Already submitted/duplicate → 409
 * 2. TX Submission — Plutus script validation failure → 400 (ScriptValidationError)
 * 3. TX Submission — Validation/Signature errors → 400
 * 4. Message indicates "not found" → 404 (even if provider returns 5xx)
 * 5. Rate limiting (status 429 or message patterns) → 429
 * 6. Explicit 404 status → 404
 * 7. 5xx errors → 503 (Provider unavailable, retry-able)
 * 8. Other 4xx → 503
 * 9. Unknown/network errors → 503 (default fallback)
 */
export declare function normalizeBackendError(err: unknown, backendName?: string): BackendError;
/**
 * HsmError - Error related to HSM operations (signing, session, key access)
 * Indicates that the Hardware Security Module is unavailable or signing failed
 */
export declare class HsmError extends BackendError {
    constructor(message: string, statusCode?: number, code?: ErrorCode, originalError?: unknown);
}
/**
 * ConfigError - Error in configuration settings
 * Captures configuration-related issues
 */
export declare class ConfigError extends Error {
    constructor(message: string);
}
/**
 * BackendInitError - Error initializing a specific backend
 * Captures backend name and original error
 */
export declare class BackendInitError extends BackendError {
    constructor(backendName: string, originalError: unknown);
}
/**
 * AllBackendsInitFailedError - All backends failed to initialize
 * Aggregates multiple backend initialization errors
 */
export declare class AllBackendsInitFailedError extends Error {
    readonly errors: BackendInitError[];
    constructor(errors: BackendInitError[]);
}
/**
 * Function to reject requests with standardized error messages
 * @param req - The incoming request
 * @param ctx - Context string for the error
 * @param message - Detailed error message
 * @param target - Optional target resource
 * @throws {BackendError} BackendError with 400 status code
 */
export declare function rejectInvalid(req: Request, ctx: string, message: string, target?: string): never;
/**
 * Function to reject requests for missing required fields
 * @param req - The incoming request
 * @param ctx - Context string for the error
 * @param field - Name of the missing field
 * @throws {BackendError} BackendError with 400 status code
*/
export declare function rejectMissing(req: Request, ctx: string, field: string): never;
/**
 * Validation error from validators.ts
 */
interface ValidationError {
    type: 'missing' | 'invalid';
    field: string;
    message: string;
}
/**
 * Throw BackendError for the first validation error in the list
 * @param req - The incoming request
 * @param ctx - Context string for the error
 * @param errors - Array of validation errors from validateTransactionInputs
 * @throws {BackendError} if errors array is not empty
 */
export declare function throwIfValidationErrors(req: Request, ctx: string, errors: ValidationError[]): void;
export {};
//# sourceMappingURL=errors.d.ts.map