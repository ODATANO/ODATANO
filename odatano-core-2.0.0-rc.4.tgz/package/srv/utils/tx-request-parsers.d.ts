import type { JSONValue } from './types';
/**
 * Shared parsers for the Build*-action JSON payload fields. Used by the
 * synchronous CardanoTransactionService handlers AND the wallet-worker's
 * request transformation (srv/blockchain/wallet-worker/build-request.ts) so
 * both paths accept exactly the same payload shape.
 *
 * Result contract: { parsed } on success (undefined for absent/empty input →
 * no-op) or { error } with a caller-presentable message.
 */
export declare function parseUtxoRefArray(json: string | undefined, fieldName: 'forceInputsJson' | 'referenceInputsJson'): {
    parsed?: Array<{
        txHash: string;
        outputIndex: number;
    }>;
    error?: string;
};
/**
 * Parse and validate requiredSignersJson (array of 56-hex Ed25519 key hashes).
 * Same result contract as the other parse* helpers.
 */
export declare function parseRequiredSigners(requiredSignersJson: string | undefined): {
    parsed?: string[];
    error?: string;
};
/**
 * Parse and validate an assetsJson array ({unit, quantity} entries) with the same
 * per-entry strictness as parseExtraOutputs — unchecked entries previously flowed
 * into the builder and surfaced as 500s.
 */
export declare function parseAssetsArray(assetsJson: string | undefined, fieldName: string): {
    parsed?: Array<{
        unit: string;
        quantity: string;
    }>;
    error?: string;
};
/** Upper bound on extra outputs per transaction (defence against tx-size blow-up). */
export declare const MAX_EXTRA_OUTPUTS = 32;
export interface ParsedExtraOutput {
    address: string;
    lovelaceAmount: string;
    assets?: Array<{
        unit: string;
        quantity: string;
    }>;
    inlineDatum?: JSONValue;
    referenceScript?: string;
}
/**
 * Parse and validate extraOutputsJson. Returns { parsed } on success (possibly undefined
 * for empty array → no-op) or { error } on validation failure.
 */
export declare function parseExtraOutputs(extraOutputsJson: string | undefined): {
    parsed?: ParsedExtraOutput[];
    error?: string;
};
/**
 * Parse the optional PER-ACTION policy fields of a mintActionsJson entry
 * (multi-policy mint FR): `mintingPolicyScript` (CBOR hex, applied as-is; a
 * parameterized per-action script must be pre-applied by the caller) and
 * `redeemerJson` (a JSON-encoded string, same convention as extraOutputs'
 * inlineDatumJson). Absent fields fall back to the action's top-level
 * script/redeemer at build time.
 */
export declare function parseMintActionPolicyFields(entry: Record<string, unknown>, i: number): {
    script?: string;
    redeemer?: JSONValue;
    error?: string;
};
//# sourceMappingURL=tx-request-parsers.d.ts.map