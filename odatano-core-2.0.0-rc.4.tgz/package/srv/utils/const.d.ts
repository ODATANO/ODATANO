/**
 * Cardano protocol constants
 */
export declare const CARDANO_DEFAULTS: {
    /** Maximum ADA supply in lovelace (45 billion ADA) */
    MAX_LOVELACE_SUPPLY: string;
    /** Milliseconds per slot */
    MS_PER_SLOT: number;
};
/**
 * Network-specific epoch geometry, anchored at the Shelley transition:
 * `epochStartSlot(epoch) = shelleyStartSlot + (epoch - shelleyStartEpoch) * slotsPerEpoch`.
 * A single global SLOTS_PER_EPOCH is wrong twice over — preview uses 86 400 (1 day),
 * and mainnet/preprod epochs are offset by their Byron era.
 */
export declare const EPOCH_CONFIG_BY_NETWORK: {
    readonly mainnet: {
        readonly shelleyStartEpoch: 208;
        readonly shelleyStartSlot: 4492800;
        readonly slotsPerEpoch: 432000;
    };
    readonly preprod: {
        readonly shelleyStartEpoch: 4;
        readonly shelleyStartSlot: 86400;
        readonly slotsPerEpoch: 432000;
    };
    readonly preview: {
        readonly shelleyStartEpoch: 0;
        readonly shelleyStartSlot: 0;
        readonly slotsPerEpoch: 86400;
    };
};
/**
 * Default execution units for Plutus scripts
 * Used when dynamic evaluation is not available
 */
export declare const DEFAULT_EXECUTION_UNITS: {
    /** Memory units for script execution */
    mem: number;
    /** CPU steps for script execution */
    cpu: number;
};
/**
 * High execution units for initial transaction build (before evaluation)
 * Set higher than DEFAULT to ensure fee estimation is sufficient before actual evaluation
 */
export declare const HIGH_EXECUTION_UNITS: {
    /** Memory units - high for evaluation pass */
    mem: number;
    /** CPU steps - high for evaluation pass */
    cpu: number;
};
/**
 * Execution unit buffer — relative multiplier applied to evaluator output.
 * Combined with ABS_* floors below so small validators also get a meaningful cushion.
 */
export declare const EXECUTION_UNIT_BUFFER = 1.1;
/**
 * Absolute ExUnits floor added on top of the relative multiplier.
 *
 * Rationale: validators that iterate reference inputs and decode inline CBOR
 * datums (e.g. oracle-consuming mint policies) show a larger ScriptContext →
 * ledger drift than the documented ~10k–30k CPU / ~50–100 mem band — real-world
 * cases overshot a 50k/1k floor by ~27k CPU / ~56 mem, burning the submit fee.
 * The floor is sized to cover reference-input + CBOR-decoding drift on top of
 * the 10% relative multiplier; `max_tx_ex_units` still caps build-time totals,
 * so oversizing here cannot push a tx past network limits — it only trades a
 * few extra lovelace of fee for avoiding an opaque PlutusFailure on submit.
 */
export declare const ABS_CPU_BUFFER = 200000;
export declare const ABS_MEM_BUFFER = 5000;
/**
 * Transaction building constants
 */
/** Collateral amount in lovelace (5 ADA) */
export declare const COLLATERAL_LOVELACE = 5000000n;
/** Fee buffer in lovelace (1 ADA) */
export declare const FEE_BUFFER_LOVELACE = 1000000n;
export declare const HRP: {
    mainnet: {
        addr: RegExp;
        stake: RegExp;
    };
    preview: {
        addr: RegExp;
        stake: RegExp;
    };
    preprod: {
        addr: RegExp;
        stake: RegExp;
    };
};
/**
 * Input validation limits to prevent DoS attacks
 */
/** Maximum JSON string length in bytes (1MB) */
export declare const MAX_JSON_SIZE = 1048576;
/** Maximum nesting depth for JSON objects/arrays */
export declare const MAX_DEPTH = 10;
/** Maximum number of keys in a JSON object */
export declare const MAX_KEYS = 100;
/** Maximum number of elements in a JSON array */
export declare const MAX_ARRAY_LENGTH = 1000;
/** Maximum length of a single string value */
export declare const MAX_STRING_LENGTH = 65536;
/** Maximum ech32 string length to prevent DoS */
export declare const BECH32_MAX_LENGTH = 2000;
/**
 * Maximum hex length of transaction CBOR accepted by ParseTransactionCbor.
 * Mainnet `maxTxSize` is currently 16 KiB; 64 KiB raw (= 128 KiB hex) leaves
 * generous headroom for future protocol bumps and reference-script outputs
 * while keeping the parser from being a memory-exhaustion vector.
 */
export declare const MAX_TX_CBOR_HEX_LENGTH: number;
/** Maximum reasonable epoch number */
export declare const MAX_EPOCH = 100000;
/** Standard pool ID payload length */
export declare const POOL_ID_BYTES = 28;
/** Standard DRep ID payload length (1 byte type prefix + 28 byte key hash) */
export declare const DREP_ID_BYTES = 29;
/** Length of a hex-encoded Cardano policy ID (28 bytes = 56 hex chars) */
export declare const POLICY_ID_HEX_LENGTH = 56;
/** Minimum length of a full asset unit (policyId + at least 1 char assetName) */
export declare const MIN_FULL_ASSET_UNIT_LENGTH: number;
/** Length of a hex-encoded Ed25519 key hash (28 bytes = 56 hex chars) */
export declare const ED25519_KEY_HASH_HEX_LENGTH = 56;
/** Regex for validating Ed25519 key hash hex strings */
export declare const ED25519_KEY_HASH_REGEX: RegExp;
/** Minimum lovelace for a change output carrying native assets (2 ADA) */
export declare const MIN_CHANGE_LOVELACE = 2000000;
/**
 * Shelley-era genesis parameters per network, used to construct Buildooor's
 * GenesisInfos so `TxBuilder.posixToSlot()` can convert validity-window
 * Posix ms into ledger slots. `slotLengthMs` is 1000 ms on all current networks.
 */
export declare const GENESIS_INFOS_BY_NETWORK: {
    readonly mainnet: {
        readonly systemStartPosixMs: 1596491091000;
        readonly slotLengthMs: 1000;
        readonly startSlotNo: 4492800;
    };
    readonly preprod: {
        readonly systemStartPosixMs: 1655683200000;
        readonly slotLengthMs: 1000;
        readonly startSlotNo: 0;
    };
    readonly preview: {
        readonly systemStartPosixMs: 1666656000000;
        readonly slotLengthMs: 1000;
        readonly startSlotNo: 0;
    };
};
/** Default validity-window start offset: `now - 2 min` to absorb clock skew. */
export declare const DEFAULT_VALIDITY_START_OFFSET_MS = 120000;
/** Default validity-window end offset: `now + 1 h` — generous enough for human-latency sign+submit flows. */
export declare const DEFAULT_VALIDITY_END_OFFSET_MS: number;
/** Max accepted digits in a Posix-ms string (13 digits covers Unix ms timestamps through ~Nov 2286). */
export declare const MAX_POSIX_MS_DIGITS = 13;
/**
 * Generic 64-character hex string (used for block hashes and other 32-byte hex identifiers)
 */
export declare const HEX_64_REGEX: RegExp;
/**
 * Generic 56-character hex string — 28-byte hashes (Blake2b-224 / payment credential / script hash / pool key hash).
 */
export declare const HEX_56_REGEX: RegExp;
/**
 * Transaction hash Regex - 64-character hexadecimal string
 */
export declare const TX_HASH_REGEX: RegExp;
/**
 * Asset unit Regex - policy ID (56 hex chars) + asset name (0-128 hex chars)
 */
export declare const ASSET_UNIT_REGEX: RegExp;
/**
 *  Pool ID Regex - bech32 with HRP "pool" and 28 bytes payload
 */
export declare const POOL_ID_REGEX: RegExp;
/**
 * DRep ID Regex - bech32 with HRP "drep" and 50-60 chars payload
 */
export declare const DREP_ID_REGEX: RegExp;
//# sourceMappingURL=const.d.ts.map