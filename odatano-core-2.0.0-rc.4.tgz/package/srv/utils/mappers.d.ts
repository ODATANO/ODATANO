import { Transaction as TransactionProviderData, Address as AddressProviderData, UTxO as UtxosProviderData, TxInputLine as TxInputProviderData, TxOutputLine as TxOutputProviderData, Amount as AmountProviderData, NetworkInformation as NetworkInfoProviderData, BlockData as BlockProviderData, EpochData as EpochProviderData, MetadataLabelTx as MetadataLabelTxProviderData, PoolData as PoolProviderData, DrepData as DrepProviderData, AccountData as AccountProviderData, AssetInfo as AssetInfoProviderData, AssetHistoryEntry as AssetHistoryEntryProviderData, TxBuildResult as TransactionBuildResult, LedgerProtocolParameters as ProtocolParameters } from './types';
import { Address as AddressRow, AddressAsset as AddressAssetRow, AddressUTxO as AddressUTxORow, UTxOAsset as UTxOAssetRow, Transaction as TransactionRow, TransactionInput as TransactionInputRow, TransactionInputAsset as TransactionInputAssetRow, TransactionOutput as TransactionOutputRow, TransactionOutputAsset as TransactionOutputAssetRow, NetworkInformation as NetworkInfoRow, TransactionMetadata as TransactionMetadataRow, Block as BlockRow, Epoch as EpochRow, Pool as PoolRow, Drep as DrepRow, Asset as AssetRow, AssetHistory as AssetHistoryRow, Account as AccountRow, LedgerProtocolParameter as ProtocolParameterRow, AddressTransaction as AddressTransactionRow } from '#cds-models/CardanoODataService';
import type { TransactionBuild as TransactionBuildRow, TransactionBuildInput as TransactionBuildInputRow, TransactionBuildOutput as TransactionBuildOutputRow, TransactionSubmission as TransactionSubmissionRow, AddressTransactionBuild as AddressTransactionBuildRow } from '#cds-models/CardanoTransactionService';
import type { AddressSigningRequest as AddressSigningRequestRow } from '#cds-models/CardanoSignService';
import type { Request } from '@sap/cds';
/**
 * Maximum age for cached/indexed data in milliseconds
 */
/**
 * Map Transaction Data
 * Converts provider transaction data into TransactionRow format
 * @param providerTx
 * @returns {TransactionRow} mapped transaction row
 */
export declare function mapTransaction(providerTx: TransactionProviderData): TransactionRow;
/**
 * Map Transaction Inputs
 * Converts provider transaction input data into TransactionInputRow format
 * @param txHash transaction hash
 * @param txInputs transaction inputs from provider
 * @returns {TransactionInputRow[]} mapped transaction input rows
 */
export declare function mapTransactionInputs(txHash: string, txInputs: TxInputProviderData[]): TransactionInputRow[];
/**
 * Map Transaction Input Assets
 * Converts provider transaction input asset data into TransactionInputAssetRow format
 * @param txHash transaction hash
 * @param inputs transaction inputs from provider
 * @returns {TransactionInputAssetRow[]} mapped transaction input asset rows
 */
export declare function mapTransactionInputAssets(txHash: string, inputs: TxInputProviderData[]): TransactionInputAssetRow[];
/**
 * Map Transaction Outputs
 * Converts provider transaction output data into TransactionOutputRow format
 * @param txHash transaction hash
 * @param txOutputs transaction outputs from provider
 * @returns {TransactionOutputRow[]} mapped transaction output rows
 */
export declare function mapTransactionOutputs(txHash: string, txOutputs: TxOutputProviderData[]): TransactionOutputRow[];
/**
 * Map Transaction Output Assets
 * Converts provider transaction output asset data into TransactionOutputAssetRow format
 * @param txHash transaction hash
 * @param outputs transaction outputs from provider
 * @returns {TransactionOutputAssetRow[]} mapped transaction output asset rows
 */
export declare function mapTransactionOutputAssets(txHash: string, outputs: TxOutputProviderData[]): TransactionOutputAssetRow[];
/**
 * Map Address Data
 * Converts provider address data into AddressRow format
 * @param address address string
 * @param addressData address data from provider
 * @returns {AddressRow} mapped address row
 */
export declare function mapAddress(address: string, addressData: AddressProviderData, maxAge: number): AddressRow;
/**
 * Map Address Transactions
 * Converts provider address transaction data into AddressTransactionRow format
 * @param addr address string
 * @param addressTxsData address transactions data from provider
 * @returns {AddressTransactionRow[]} mapped address transaction rows
 *  */
export declare function mapAddressTransactions(addr: string, addressTxsData: TransactionProviderData[]): AddressTransactionRow[];
/**
 * Map Address UTxOs
 * @param addr address string
 * @param validFrom validFrom
 * @param validTo validTo
 * @param addressUtxosData address UTxOs data from provider
 * @returns {AddressUTxORow[]} mapped address UTxO rows
 */
export declare function mapAddressUtxos(addr: string, validFrom: string, validTo: string, addressUtxosData: UtxosProviderData[]): AddressUTxORow[];
/**
 * Map Address Assets
 * Converts provider address asset data into AddressAssetRow format
 * @param addr address string
 * @param validFrom validFrom
 * @param validTo validTo
 * @param AssetAssets address assets from provider
 * @returns {AddressAssetRow[]} mapped address asset rows
 */
export declare function mapAddressAssets(addr: string, validFrom: string, validTo: string, AssetAssets: AmountProviderData[]): AddressAssetRow[];
/**
 * Map UTxO Assets
 * Converts provider address UTxO asset data into UTxOAssetRow format
 * @param addressUtxosData address UTxOs data from provider
 * @param validFrom validFrom
 * @param validTo validTo
 * @returns {UTxOAssetRow[]} mapped UTxO asset rows
 */
export declare function mapAddressUtxoAssets(addressUtxosData: UtxosProviderData[], validFrom: string, validTo: string): UTxOAssetRow[];
/**
 * Map Network Information
 * Converts provider network information data into NetworkInfoRow format
 * @param providerNetworkData
 * @returns {NetworkInfoRow} mapped network information row
 */
export declare function mapNetworkInfo(providerNetworkData: NetworkInfoProviderData, max_age: number, network: string): NetworkInfoRow;
/**
 * Map Block Data
 * Converts provider block data into BlockRow format
 * @param providerBlockData block data from provider
 * @param epochData epoch data for the block's epoch
 * @returns {BlockRow} mapped block row
 */
export declare function mapBlock(providerBlockData: BlockProviderData, epochData?: EpochRow): BlockRow;
/**
 * Map Epoch Data
 * Converts provider epoch data into EpochRow format
 * @param providerEpochData epoch data from provider
 * @returns {EpochRow} mapped epoch row
 */
export declare function mapEpoch(providerEpochData: EpochProviderData): EpochRow;
/**
 * Map Transaction Metadata
 * Converts provider transaction metadata labels into TransactionMetadataRow format
 * @param providerLabels array of metadata label data from provider
 * @returns {TransactionMetadataRow[]} mapped transaction metadata rows
 */
export declare function mapTransactionMetadata(providerLabels: MetadataLabelTxProviderData[]): TransactionMetadataRow[];
/**
 * Map Pool Data
 * Converts provider pool data into PoolRow format
 * @param providerPoolData pool data from provider
 * @returns {PoolRow} mapped pool row
 */
export declare function mapPool(providerPoolData: PoolProviderData, max_age: number): PoolRow;
/**
 * Map Asset Info Data
 * Converts provider asset info into AssetRow format. Provider data is already
 * normalized by the backend mapper into the canonical AssetInfo shape, so this
 * function just stamps temporal validity and JSON-stringifies the on-chain metadata.
 * @param providerAssetInfo canonical asset info from backend
 * @param max_age TTL window in ms for the temporal validity
 * @returns {AssetRow} mapped asset row
 */
export declare function mapAsset(providerAssetInfo: AssetInfoProviderData, max_age: number): AssetRow;
/**
 * Map Asset History entries to row format. No temporal stamping — mint/burn
 * events are immutable; UPSERT keyed on (unit, txHash) is idempotent.
 * @param entries asset history events from backend (already canonical)
 * @returns {AssetHistoryRow[]} mapped rows
 */
export declare function mapAssetHistory(entries: AssetHistoryEntryProviderData[]): AssetHistoryRow[];
/**
 * Map Drep Data
 * Converts provider drep data into DrepRow format
 * @param providerDrepData drep data from provider
 * @returns {DrepRow} mapped drep row
 */
export declare function mapDrep(providerDrepData: DrepProviderData, max_age: number): DrepRow;
/**
 * Map Account Data
 * Converts provider account data into AccountRow format
 * @param providerAccountData account data from provider
 * @returns {AccountRow} mapped account row
 */
export declare function mapAccount(providerAccountData: AccountProviderData, max_age: number): AccountRow;
/**
 * Map Backend Error
 * Converts BackendError or unknown error into OData request rejection
 * @param req OData request
 * @param err error object (BackendError or unknown)
 * @param ctx context string for error message
 */
export declare function mapError(req: Request, err: unknown, ctx: string): never;
/**
 * Map Transaction Build Result
 * Converts provider transaction build result into TransactionBuildRow format
 * @param txbuildResult transaction build result from provider
 * @returns {TransactionBuildRow} mapped transaction build row
 */
export declare function mapBuildResult(txbuildResult: TransactionBuildResult, max_age: number): TransactionBuildRow;
/**
 * Map Transaction Build Inputs
 * Converts transaction build result inputs into TransactionBuildInputRow format
 * @param buildId the transaction build ID
 * @param inputs transaction build result inputs
 * @returns {TransactionBuildInputRow[]} mapped transaction build input rows
 */
export declare function mapBuildInputs(buildId: string, inputs: Array<{
    txHash: string;
    index: number;
    lovelace: string;
    address?: string;
}>): TransactionBuildInputRow[];
/**
 * Map Transaction Build Outputs
 * Converts transaction build result outputs into TransactionBuildOutputRow format
 * @param buildId the transaction build ID
 * @param outputs transaction build result outputs
 * @param changeAddress the change address to identify change outputs
 * @returns {TransactionBuildOutputRow[]} mapped transaction build output rows
 */
export declare function mapBuildOutputs(buildId: string, outputs: Array<{
    address: string;
    lovelace: string;
}>, changeAddress?: string): TransactionBuildOutputRow[];
/**
 * Map Protocol Parameters
 * Converts provider protocol parameters into ProtocolParameterRow format
 * @param providerParams protocol parameters from provider
 * @returns {ProtocolParameterRow} mapped protocol parameter row
 */
export declare function mapProtocolParameters(providerParams: ProtocolParameters): ProtocolParameterRow;
/**
 * Map Transaction Submission
 * Converts signed transaction CBOR and hash into TransactionSubmissionRow format
 * @param signedTxCbor signed transaction in CBOR hex format
 * @param txHash transaction hash
 * @returns {TransactionSubmissionRow} mapped transaction submission row
 */
export declare function mapTransactionSubmission(signedTxCbor: string, txHash: string): TransactionSubmissionRow;
/**
 * Map Address Signing Requests
 * Creates AddressSigningRequest row for address-signing request association
 * @param addr bech32 address
 * @param signingRequestId signing request UUID
 * @returns {AddressSigningRequestRow} mapped address signing request row
 */
export declare function mapAddressSigningRequest(addr: string, signingRequestId: string): AddressSigningRequestRow;
/**
 * Map Address Transaction Builds
 * Creates AddressTransactionBuild row for address-build association
 * @param addr bech32 address
 * @param buildId transaction build UUID
 * @returns {AddressTransactionBuildRow} mapped address transaction build row
 */
export declare function mapAddressTransactionBuild(addr: string, buildId: string): AddressTransactionBuildRow;
/**
 * Normalize cost models to array format in canonical Plutus parameter order.
 *
 * Blockfrost's cost_models (named keys) has known key-value mapping bugs for
 * PlutusV3 (shifted values in the quotientInteger/remainderInteger region).
 * The Blockfrost backend now prefers cost_models_raw (canonical arrays from the
 * node) which bypasses this issue entirely.
 *
 * For V3 arrays: already in canonical order, just pad to 297 via toCostModelArrV3.
 * For V3 objects (Ogmios named format): toCostModelArrV3(obj) maps via canonical keys.
 * For V1/V2: alphabetical order IS the canonical order (no reordering needed).
 *
 * @param raw - Raw cost models from any backend (Blockfrost, Ogmios, Koios)
 * @returns Object with all cost model values as number arrays in canonical order
 */
export declare function normalizeCostModels(raw: Record<string, unknown>): Record<string, number[]>;
/**
 * Compute CIP-14 asset fingerprint from policyId and assetName.
 * Algorithm: bech32_encode("asset", blake2b_160(policyId_bytes + assetName_bytes))
 * @param policyIdHex - Policy ID as hex string (56 chars / 28 bytes)
 * @param assetNameHex - Asset name as hex string (variable length)
 * @returns CIP-14 fingerprint string (e.g. "asset1...")
 */
export declare function computeCip14Fingerprint(policyIdHex: string, assetNameHex: string): string;
/**
 * Derive an enterprise script address from a script hash and network.
 * Enterprise address = header_byte + 28-byte script hash, bech32-encoded.
 * Header: 0x71 (mainnet, type 7 network 1) or 0x70 (testnet, type 7 network 0).
 */
export declare function scriptHashToEnterpriseAddress(scriptHashHex: string, network: 'mainnet' | 'preprod' | 'preview'): string;
//# sourceMappingURL=mappers.d.ts.map