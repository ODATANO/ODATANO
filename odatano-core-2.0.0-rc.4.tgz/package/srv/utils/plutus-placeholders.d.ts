import type { JSONValue } from './types';
/**
 * PlutusData-JSON input-index placeholder.
 * Matches the full string form `__INPUT_IDX:<64-hex txHash>#<outputIndex>__`.
 * The placeholder must be the entire `int` field value — partial matches are ignored.
 */
export declare const INPUT_IDX_REGEX: RegExp;
/** Minimal UTxO reference shape used by the placeholder resolver. */
export interface InputRef {
    txHash: string;
    outputIndex: number;
}
export interface ResolveContext {
    /** Inputs in their final, post-sort order — index of `ref` in this array == resolved placeholder value. */
    sortedInputs: InputRef[];
}
/**
 * Replicates Buildooor's input sort: lexicographic on the txHash bytes, tie-break by outputIndex asc.
 * This mirrors the Cardano ledger CBOR-set ordering used by Buildooor.
 * Verified against node_modules/@harmoniclabs/buildooor/dist/TxBuilder/TxBuilder.js:772.
 */
export declare function sortInputsLikeBuildooor<T extends InputRef>(refs: T[]): T[];
/**
 * Walk a PlutusData JSON tree and replace any `{int: "__INPUT_IDX:<hash>#<idx>__"}` leaves
 * with `{int: <resolvedIndex>}` according to the sorted input order in `ctx`.
 *
 * Placeholders are only recognised inside an `int` field. Strings elsewhere (e.g. `bytes`)
 * are left untouched — hex payloads may legitimately contain `__` sequences.
 *
 * Throws TransactionValidationError if a placeholder references a UTxO ref that is not present
 * in `ctx.sortedInputs`. The exact placeholder string is included in the message so consumers
 * can diagnose missing forceInputs / script UTxOs.
 */
export declare function resolveIndexPlaceholders(node: JSONValue, ctx: ResolveContext): JSONValue;
//# sourceMappingURL=plutus-placeholders.d.ts.map