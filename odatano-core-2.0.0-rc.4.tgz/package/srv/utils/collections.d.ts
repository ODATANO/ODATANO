/**
 * Small collection helpers shared across the blockchain layer.
 */
/**
 * Split an array into fixed-size chunks. Used to keep CQL IN-lists below DB driver
 * bind-variable limits (SQLite caps at 999 on older builds / 32766 on node:sqlite).
 * @param arr  source array (not mutated)
 * @param size chunk size (must be > 0; guarded to avoid an infinite loop)
 */
export declare function chunk<T>(arr: T[], size: number): T[][];
/** Max bind variables per IN-list — well below every supported driver's cap. */
export declare const IN_CHUNK = 500;
//# sourceMappingURL=collections.d.ts.map