import cds from '@sap/cds';
/** Default acquire budget for detached bookkeeping transactions. */
export declare const DETACHED_TX_TIMEOUT_MS = 10000;
/**
 * Run `fn` with `cds.context` cleared, so any `db.run(...)` inside it gets a
 * fresh short-lived transaction instead of joining a long-lived ambient one.
 * Under @cap-js/sqlite (pool.max=1) this is what keeps the single pooled
 * connection free during long awaits (NIGHTGATE lesson 2; used by the
 * wallet-worker job loops).
 */
export declare function runWithoutAmbientTx<T>(fn: () => Promise<T>): Promise<T>;
/**
 * `cds.tx(fn)` with a deadlock guard: a NEW ROOT transaction that fails fast
 * instead of hanging forever when no pooled connection becomes available.
 *
 * Why: the sign-service must commit its submit bookkeeping (claim, finalize,
 * failure marker) independently of the caller's request transaction. When an
 * in-process consumer awaits the action while its own request transaction
 * holds the single pooled sqlite connection, the acquire can never succeed —
 * without this guard that is a silent, zero-CPU, infinite hang.
 *
 * Guarantees:
 * - On timeout, throws `BackendError` 503 `ODATANO_NESTED_TX_TIMEOUT` with a
 *   diagnosis pointing at KNOWN_ISSUES #11.
 * - A late connection grant (after the timeout already fired) performs NO
 *   work: the callback forces the acquire via an explicit `begin()` and
 *   checks the abort flag right after it, so it rolls back immediately and
 *   the caller never observes an error for work that then silently happened
 *   anyway. (A flag check at callback ENTRY would run long before the lazy
 *   acquire and miss the timeout.)
 */
export declare function detachedTx<T>(label: string, fn: (db: cds.Transaction) => Promise<T>, timeoutMs?: number): Promise<T>;
//# sourceMappingURL=tx-utils.d.ts.map