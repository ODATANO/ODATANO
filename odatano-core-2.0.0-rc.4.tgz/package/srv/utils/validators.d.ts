/**
 * Result of JSON validation with limits
 */
interface JsonValidationResult {
    valid: boolean;
    error?: string;
    parsed?: unknown;
}
/**
 * Validate JSON string with size and complexity limits to prevent DoS
 * @param jsonString - The JSON string to validate
 * @param fieldName - Name of the field (for error messages)
 * @returns JsonValidationResult with parsed value or error message
 */
export declare function validateJsonWithLimits(jsonString: string, fieldName: string): JsonValidationResult;
/**
 * Transaction hash: 64-character hexadecimal string
 * @param s - The raw value to validate against transaction hash format
 * @returns { boolean } true if s is a valid transaction hash false otherwise
 */
export declare function isTxHash(s: unknown): s is string;
/**
 * Asset unit: concatenation of policy ID (56 hex chars) + asset name (0-128 hex chars)
 * @param s - The raw value to validate against asset unit format
 * @returns { boolean } true if v is a valid asset unit false otherwise
 */
export declare function isAssetUnit(s: unknown): s is string;
/**
 * Block hash: 64-character hexadecimal string
 * @param s - The raw value to validate against block hash format
 * @returns { boolean } true if s is a valid block hash false otherwise
 */
export declare function isBlockHash(s: unknown): s is string;
/**
 * Payment credential: 28-byte hash (key hash or script hash) as 56-char lowercase hex.
 * Used for credential-based UTxO queries (Indigo CDPs, Liqwid positions, etc.).
 * @param s - The raw value to validate against credential format
 * @returns { boolean } true if s is a valid 56-char lowercase hex string
 */
export declare function isValidCredential(s: unknown): s is string;
/**
 * Pool ID: must be bech32-decodable, HRP=pool, payload length 28 bytes.
 * @param poolIdRaw - The raw value to validate against pool ID format
 * @returns { boolean } true if valid pool ID false otherwise
 */
export declare function isValidPoolId(poolIdRaw: unknown): poolIdRaw is string;
/**
 * DRep ID: must be bech32-decodable, HRP=drep.
 * @param drepRaw - The raw value to validate against drep ID format
 * @returns { boolean } true if valid drep ID false otherwise
 */
export declare function isValidDrepId(drepRaw: unknown): drepRaw is string;
/**
 * Validate Bech32 address: must be bech32-decodable, HRP based on network config.
 * @param addrRaw - The raw value to validate against bech32 address format
 * @returns { boolean } true if valid bech32 address false otherwise
 */
export declare function isValidBech32Address(addrRaw: unknown): addrRaw is string;
/**
 * Validate Bech32 stake address: must be bech32-decodable, HRP based on network config.
 * @param stakeRaw - The raw value to validate against stake address format
 * @returns { boolean } true if valid bech32 stake address false otherwise
 */
export declare function isValidBech32StakeAddress(stakeRaw: unknown): stakeRaw is string;
/**
 * Epoch number: non-negative integer within reasonable bounds
 * @param s - The parameter value to validate as epoch number
 * @returns { boolean } true if s is a valid epoch number false otherwise
 */
export declare function isEpochNumber(s: unknown): s is number;
/**
 * Validate CBOR string: must be a non-empty even-length hexadecimal string
 * @param cborRaw - The raw value to validate against CBOR format
 * @returns { boolean } true if valid CBOR false otherwise
 */
export declare function isValidCbor(cborRaw: unknown): cborRaw is string;
/**
 * Validate a transaction CBOR hex string for the ParseTransactionCbor action.
 * Combines `isValidCbor` with a hard length limit to block memory-exhaustion
 * attacks on the server-side CBOR parser.
 * @param cborRaw - The raw value to validate
 * @returns { boolean } true if valid hex AND within MAX_TX_CBOR_HEX_LENGTH
 */
export declare function isValidTxCborHex(cborRaw: unknown): cborRaw is string;
/**
 * Extract the payment credential from a Shelley bech32 address.
 * Returns the 28-byte credential hash (hex) plus whether it is a SCRIPT
 * credential (address type bit 0 of the header high nibble), or null when the
 * address cannot be decoded / carries no payment part (stake addresses).
 */
export declare function extractPaymentCredential(address: string): {
    hash: string;
    isScript: boolean;
} | null;
/**
 * Validate an array of Ed25519 key hashes (hex, 28 bytes / 56 hex chars each).
 * @param signers - The parsed JSON array to validate
 * @returns validated string array
 * @throws Error if any signer is invalid
 */
export declare function validateRequiredSigners(signers: unknown): string[];
/**
 * Validation error details for transaction input validation
 */
export interface ValidationError {
    type: 'missing' | 'invalid';
    field: string;
    message: string;
}
/**
 * Transaction input fields for validation
 */
export interface TransactionInputs {
    senderAddress?: string;
    recipientAddress?: string;
    changeAddress?: string;
    lovelaceAmount?: string | number | bigint;
    signedTxCbor?: string;
    metadataJson?: string;
    assetsJson?: string;
    mintActionsJson?: string;
    mintingPolicyScript?: string;
    buildId?: string;
    submissionId?: string;
    signingRequestId?: string;
    signerType?: string;
    signerInfo?: string;
    validatorScript?: string;
    scriptTxHash?: string;
    scriptOutputIndex?: number;
    redeemerJson?: string;
    datumJson?: string;
    referenceScriptHex?: string;
    validityStartMs?: string;
    validityEndMs?: string;
}
/**
 * Validate transaction build inputs and return validation errors if any
 * @param inputs - Transaction input fields to validate
 * @param requiredFields - List of required field names
 * @returns Array of validation errors, empty if all valid
 */
export declare function validateTransactionInputs(inputs: TransactionInputs, requiredFields: (keyof TransactionInputs)[]): ValidationError[];
export {};
//# sourceMappingURL=validators.d.ts.map