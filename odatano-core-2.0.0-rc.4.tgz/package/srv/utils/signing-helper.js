"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.combineTransactionWithWitnesses = combineTransactionWithWitnesses;
exports.isWitnessSetCbor = isWitnessSetCbor;
const cds_1 = __importDefault(require("@sap/cds"));
const cbor_1 = require("@harmoniclabs/cbor");
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const errors_1 = require("./errors");
const logger = cds_1.default.log('SigningHelper');
/**
 * Combine an unsigned transaction with a witness set from CIP-30 wallet signing
 *
 * CIP-30 signTx() returns only the witness set, not a complete signed transaction.
 * This function combines the original unsigned transaction with the witness set
 * to create a complete signed transaction that can be submitted to the network.
 *
 * @param unsignedTxCbor - The unsigned transaction CBOR (hex)
 * @param witnessSetCbor - The witness set CBOR from CIP-30 signTx() (hex)
 * @returns Complete signed transaction CBOR (hex)
 */
function combineTransactionWithWitnesses(unsignedTxCbor, witnessSetCbor) {
    try {
        // Parse at raw CBOR level — no Cardano type validation, preserves all encoding metadata
        const txObj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(unsignedTxCbor));
        if (!(txObj instanceof cbor_1.CborArray) || txObj.array.length < 2) {
            throw new errors_1.TransactionValidationError('Invalid transaction CBOR structure');
        }
        const walletWsObj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(witnessSetCbor));
        // txObj.array[0] = body, [1] = witness_set, [2] = is_valid, [3] = auxiliary_data
        const origWs = txObj.array[1];
        let witnessCount = 0;
        if (origWs instanceof cbor_1.CborMap && walletWsObj instanceof cbor_1.CborMap) {
            // Find wallet's VKey witnesses (map key 0)
            const walletVkeyEntry = walletWsObj.map.find(e => e.k instanceof cbor_1.CborUInt && Number(e.k.num) === 0);
            if (walletVkeyEntry) {
                // Merge: keep all original entries (redeemers, datums, scripts at keys 3-7),
                // remove any existing key 0, then add wallet's key 0 (VKey witnesses)
                const mergedEntries = origWs.map
                    .filter(e => !(e.k instanceof cbor_1.CborUInt && Number(e.k.num) === 0))
                    .concat([walletVkeyEntry]);
                // Construct new witness set CborMap preserving the original's encoding style
                txObj.array[1] = new cbor_1.CborMap(mergedEntries, {
                    indefinite: origWs.indefinite,
                });
                // Count VKey witnesses — value may be CborArray or CborTag(258, CborArray) in Conway era
                const vkeyValue = walletVkeyEntry.v;
                if (vkeyValue instanceof cbor_1.CborArray) {
                    witnessCount = vkeyValue.array.length;
                }
                else if (vkeyValue instanceof cbor_1.CborTag && vkeyValue.data instanceof cbor_1.CborArray) {
                    witnessCount = vkeyValue.data.array.length;
                }
                else {
                    throw new errors_1.TransactionValidationError('Unexpected VKey witness format in witness set');
                }
            }
        }
        else {
            throw new errors_1.TransactionValidationError('Witness set must be CBOR map per Cardano spec');
        }
        // Re-encode the tx as a NEW outer CborArray so the encoder cannot short-circuit
        // to the original full-tx bytes via the outer value's subCborRef (which no longer
        // matches now that the witness set changed). The INNER element subCborRefs are
        // deliberately kept: that byte-preserves the body (array[0]), so the tx body hash
        // the witnesses signed stays identical.
        const signedTxCbor = (0, uint8array_utils_1.toHex)(cbor_1.Cbor.encode(new cbor_1.CborArray(txObj.array, { indefinite: txObj.indefinite })));
        logger.info({
            unsignedTxLength: unsignedTxCbor.length,
            witnessSetLength: witnessSetCbor.length,
            signedTxLength: signedTxCbor.length,
            witnessCount,
        }, 'Combined transaction with witness set (harmoniclabs CBOR)');
        return signedTxCbor;
    }
    catch (error) {
        const msg = error instanceof Error ? error.message : String(error);
        logger.error({ error: msg }, 'Failed to combine transaction with witnesses');
        throw new errors_1.TransactionValidationError(`Failed to combine transaction with witnesses: ${msg}`);
    }
}
/**
 * Check if a CBOR string is a witness set (vs a full transaction)
 *
 * CIP-30 returns witness sets, not full transactions.
 * This helps detect when we need to call combineTransactionWithWitnesses.
 *
 * @param cborHex - CBOR hex string
 * @returns true if it's a witness set, false if it's a full transaction
 */
function isWitnessSetCbor(cborHex) {
    try {
        const obj = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(cborHex));
        // A full transaction is a CBOR array ([body, witness_set, is_valid, aux_data]);
        // a CIP-30 witness set is a CBOR map. The two shapes are unambiguous.
        if (obj instanceof cbor_1.CborArray)
            return false;
        return obj instanceof cbor_1.CborMap;
    }
    catch {
        // Invalid / unparseable CBOR
        return false;
    }
}
//# sourceMappingURL=signing-helper.js.map