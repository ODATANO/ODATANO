/**
 * Derive the 32-byte encryption key from the environment.
 * Production: ENCRYPTION_KEY is required. Development: process-scoped fallback.
 */
export declare function getEncryptionKey(): Buffer;
/**
 * Encrypt plaintext with AES-256-GCM.
 * Returns the combined format `base64(iv):base64(authTag):base64(ciphertext)`.
 */
export declare function encrypt(plaintext: string, key: Buffer): string;
/**
 * Decrypt a combined `iv:authTag:ciphertext` string back to plaintext.
 * Throws on authentication failure (tampered ciphertext or wrong key).
 */
export declare function decrypt(combined: string, key: Buffer): string;
//# sourceMappingURL=crypto.d.ts.map