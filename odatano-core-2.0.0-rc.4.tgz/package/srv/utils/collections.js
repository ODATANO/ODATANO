"use strict";
/**
 * Small collection helpers shared across the blockchain layer.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.IN_CHUNK = void 0;
exports.chunk = chunk;
/**
 * Split an array into fixed-size chunks. Used to keep CQL IN-lists below DB driver
 * bind-variable limits (SQLite caps at 999 on older builds / 32766 on node:sqlite).
 * @param arr  source array (not mutated)
 * @param size chunk size (must be > 0; guarded to avoid an infinite loop)
 */
function chunk(arr, size) {
    if (size <= 0)
        throw new RangeError(`chunk size must be > 0, got ${size}`);
    const out = [];
    for (let i = 0; i < arr.length; i += size)
        out.push(arr.slice(i, i + size));
    return out;
}
/** Max bind variables per IN-list — well below every supported driver's cap. */
exports.IN_CHUNK = 500;
//# sourceMappingURL=collections.js.map