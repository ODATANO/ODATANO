import type { Network } from '../blockchain/cardano-client';
/** Record the active network. Pass `null` to clear (shutdown/reset). */
export declare function setActiveNetwork(n: Network | null): void;
/** The active network, or `null` if the app context has not been initialized. */
export declare function getActiveNetwork(): Network | null;
//# sourceMappingURL=network-context.d.ts.map