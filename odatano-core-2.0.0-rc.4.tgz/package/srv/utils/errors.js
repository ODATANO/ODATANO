"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AllBackendsInitFailedError = exports.BackendInitError = exports.ConfigError = exports.HsmError = exports.AllBackendsFailedError = exports.RateLimitError = exports.ProviderUnavailableError = exports.MixedAssetsError = exports.InsufficientFundsError = exports.TransactionAlreadySubmittedError = exports.ScriptValidationError = exports.TransactionValidationError = exports.NotFoundError = exports.BackendError = void 0;
exports.isNotFoundOnAllBackends = isNotFoundOnAllBackends;
exports.isPostgrestServerErrorCode = isPostgrestServerErrorCode;
exports.getErrorStatus = getErrorStatus;
exports.getErrorMessage = getErrorMessage;
exports.normalizeBackendError = normalizeBackendError;
exports.rejectInvalid = rejectInvalid;
exports.rejectMissing = rejectMissing;
exports.throwIfValidationErrors = throwIfValidationErrors;
const error_codes_1 = require("./error-codes");
/**
 * Backend Errors Implementation
 * Defines typed errors for backend communication issues
 */
/**
 * BackendError Base class for all backend-related errors
 */
class BackendError extends Error {
    statusCode;
    code;
    backendName;
    originalError;
    target;
    /** Constructor
     * @param message error message string
     * @param statusCode error status code
     * @param code error code
     * @param backendName name of the backend where the error originated
     * @param originalError original error object
     * @param target target resource (if applicable)
     */
    constructor(message, statusCode = 500, code = error_codes_1.ERROR_CODES.INTERNAL_ERROR, backendName, originalError, target) {
        super(message);
        this.statusCode = statusCode;
        this.code = code;
        this.backendName = backendName;
        this.originalError = originalError;
        this.target = target;
        this.name = this.constructor.name;
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.BackendError = BackendError;
/**
 * NotFoundError - Resource not found in backend (404)
 * This is NOT a provider error - it's a valid response indicating the resource doesn't exist
 * Examples: transaction hash not found, address has no UTxOs
 */
class NotFoundError extends BackendError {
    /** Constructor
     * @param resource name of the resource that was not found
     * @param backendName name of the backend where the error originated
     * @param originalError original error object
     */
    constructor(resource, backendName, originalError) {
        super(`${resource} not found`, 404, error_codes_1.ERROR_CODES.NOT_FOUND, backendName, originalError);
    }
}
exports.NotFoundError = NotFoundError;
/**
 * TransactionValidationError - Transaction failed validation (400)
 * Indicates that the transaction failed validation checks
 * Examples: wrong signature, tampered CBOR, invalid witnesses
 */
class TransactionValidationError extends BackendError {
    /** Constructor
     * @param message detailed validation failure message
     * @param originalError original error object
     * @param code optional override (e.g. `TX_PARSE_FAILED` for CBOR decode failures);
     *             defaults to `TX_VALIDATION_FAILED`.
     */
    constructor(message, originalError, code = error_codes_1.ERROR_CODES.TX_VALIDATION_FAILED) {
        super(message, 400, code, undefined, originalError);
    }
}
exports.TransactionValidationError = TransactionValidationError;
/**
 * ScriptValidationError - Plutus script validation failed on the ledger (400)
 * Distinguishes a clean ledger rejection (PlutusFailure, CekError, overspent
 * budget, script hash mismatch) from provider outages (503). The transaction
 * was well-formed enough to reach phase-2 validation — retrying against a
 * different provider will not help; the tx shape itself is the problem.
 */
class ScriptValidationError extends BackendError {
    /** Constructor
     * @param message detailed script failure message (typically from ledger)
     * @param originalError original error object
     */
    constructor(message, originalError) {
        super(message, 400, error_codes_1.ERROR_CODES.SCRIPT_VALIDATION_FAILURE, undefined, originalError);
    }
}
exports.ScriptValidationError = ScriptValidationError;
/**
 * TransactionAlreadySubmittedError - Transaction already exists (409)
 * Indicates that the transaction has already been submitted (duplicate/replay)
 * Examples: same txHash already in mempool or on chain
 */
class TransactionAlreadySubmittedError extends BackendError {
    txHash;
    /** Constructor
     * @param txHash the transaction hash that was already submitted
     * @param originalError original error object
     */
    constructor(txHash, originalError) {
        super(`Transaction ${txHash} already exists in mempool or on chain`, 409, error_codes_1.ERROR_CODES.TX_ALREADY_SUBMITTED, undefined, originalError);
        this.txHash = txHash;
    }
}
exports.TransactionAlreadySubmittedError = TransactionAlreadySubmittedError;
/**
 * InsufficientFundsError - Not enough funds or assets available (400)
 * Indicates that the address does not have enough of a specific asset to complete the transaction
 * Examples: trying to send more ADA than available, not enough native tokens
 */
class InsufficientFundsError extends BackendError {
    assetUnit;
    required;
    available;
    /** Constructor
     * @param assetUnit the asset unit that is insufficient (e.g., "lovelace" or "policyId.assetName")
     * @param required the required amount (0n when unknown)
     * @param available the available amount (0n when unknown)
     * @param originalError original error object
     * @param detail human-readable cause shown INSTEAD of the amounts — use when
     *               the amounts are unknown; "required 0, available 0" reads as
     *               nonsense from the consumer's perspective
     */
    constructor(assetUnit, required, available, originalError, detail) {
        super(detail
            ? `Insufficient ${assetUnit}: ${detail}`
            : `Insufficient ${assetUnit}: required ${required}, available ${available}`, 400, error_codes_1.ERROR_CODES.INSUFFICIENT_FUNDS, undefined, originalError, assetUnit);
        this.assetUnit = assetUnit;
        this.required = required;
        this.available = available;
    }
}
exports.InsufficientFundsError = InsufficientFundsError;
/**
 * MixedAssetsError - UTxO contains mixed assets when pure ADA is required (400)
 * Indicates that a UTxO contains native assets in addition to ADA, but the operation requires ADA-only UTxOs
 */
class MixedAssetsError extends BackendError {
    utxoRef;
    assets;
    /** Constructor
     * @param utxoRef UTxO reference (txHash#outputIndex)
     * @param assets list of non-ADA assets found in the UTxO
     * @param originalError original error object
     */
    constructor(utxoRef, assets, originalError) {
        super(`UTxO ${utxoRef} contains non-ADA assets: ${assets.join(', ')}`, 400, error_codes_1.ERROR_CODES.INVALID_INPUT, undefined, originalError, utxoRef);
        this.utxoRef = utxoRef;
        this.assets = assets;
    }
}
exports.MixedAssetsError = MixedAssetsError;
/**
 * ProviderUnavailableError - Provider unavailable or timeout (503)
 * Indicates a temporary issue - retrying may help
 * Examples: network timeout, 5xx errors, service down
 */
class ProviderUnavailableError extends BackendError {
    /** Constructor
     * @param message error message string
     * @param backendName name of the backend where the error originated
     * @param timeoutMs optional timeout duration in milliseconds
     * @param originalError original error object
     */
    constructor(message, backendName, timeoutMs, originalError) {
        const msg = timeoutMs
            ? `${message} (timeout after ${timeoutMs}ms)`
            : message;
        super(msg, 503, error_codes_1.ERROR_CODES.PROVIDER_UNAVAILABLE, backendName, originalError);
    }
}
exports.ProviderUnavailableError = ProviderUnavailableError;
/**
 * RateLimitError - Provider rate limit exceeded (429)
 * Indicates too many requests - client should back off and retry later
 * Examples: Blockfrost 10 req/sec limit, Koios tier limits
 */
class RateLimitError extends BackendError {
    /** Constructor
     * @param message error message string
     * @param backendName name of the backend where the error originated
     * @param retryAfter optional retry-after duration in seconds
     * @param originalError original error object
     */
    constructor(message, backendName, retryAfter, originalError) {
        const msg = retryAfter
            ? `${message} (retry after ${retryAfter}s)`
            : message;
        super(msg, 429, error_codes_1.ERROR_CODES.PROVIDER_RATE_LIMITED, backendName, originalError);
    }
}
exports.RateLimitError = RateLimitError;
/**
 * AllBackendsFailedError - All backends failed
 * Aggregates multiple backend errors and returns the most relevant status
 */
class AllBackendsFailedError extends BackendError {
    errors;
    /** Constructor
     * @param errors array of backend errors
     * @param originalError original error object
     */
    constructor(errors, originalError) {
        const lastError = errors[errors.length - 1];
        super(
        // Empty errors == every backend was *skipped* (e.g. all declared the method
        // unsupported), so nothing actually failed/connected: surface 503 (no provider
        // available) rather than 502 (which implies an upstream backend returned a bad
        // response). A real backend failure carries its own statusCode via lastError.
        `All backends failed: ${lastError?.message ?? 'unknown error'}`, lastError?.statusCode ?? 503, lastError?.code ?? error_codes_1.ERROR_CODES.PROVIDER_UNAVAILABLE, undefined, originalError);
        this.errors = errors;
    }
}
exports.AllBackendsFailedError = AllBackendsFailedError;
/**
 * True when the error proves the resource is absent on EVERY backend that was
 * consulted: either a direct NotFoundError, or an AllBackendsFailedError whose
 * collected per-backend errors are all 404s. CardanoClient's failover wraps
 * per-backend errors (including 404s) into AllBackendsFailedError, so callers
 * that need "definitively not found" (e.g. the wallet-worker's dropped-tx
 * detection) must use this instead of `instanceof NotFoundError`. A mixed
 * result (one backend 404, another 500) is NOT proof of absence.
 */
function isNotFoundOnAllBackends(err) {
    if (err instanceof NotFoundError)
        return true;
    return err instanceof AllBackendsFailedError
        && err.errors.length > 0
        && err.errors.every((e) => e instanceof NotFoundError || e.statusCode === 404);
}
/**
 * PostgreSQL error-code classes that indicate a fault in the provider's own
 * database/deployment rather than in our request. Koios (PostgREST) surfaces
 * these as HTTP 400 — e.g. code '42703' ("column … does not exist") from a
 * half-migrated SQL function on one load-balanced instance, or '57014'
 * (statement timeout) under load. Client-input errors (class 22, invalid text
 * representation etc.) are deliberately NOT listed — those remain 4xx.
 * Classes: 08 connection, 42 syntax/undefined object, 53 insufficient
 * resources, 57 operator intervention (incl. query_canceled), 58 system
 * error, XX internal error.
 */
const PG_SERVER_ERROR_CODE_CLASSES = ['08', '42', '53', '57', '58', 'XX'];
/** True when a PostgREST error body's `code` denotes a provider-side SQL fault. */
function isPostgrestServerErrorCode(code) {
    return typeof code === 'string' && PG_SERVER_ERROR_CODE_CLASSES.some(c => code.startsWith(c));
}
/**
 * Utility functions to extract status and message from HttpErrorLike
 * @param err error object
 * @returns {number} status code
 */
function getErrorStatus(err) {
    const e = (err ?? {});
    return e.status ?? e.response?.status ?? 500;
}
/**
 * Utility functions to extract status and message from HttpErrorLike
 * @param err error object
 * @returns {string} error message
 */
function getErrorMessage(err) {
    const e = (err ?? {});
    // Check Axios response.data.error (Koios format)
    if (e.response?.data?.error)
        return e.response.data.error;
    // Check direct message property
    if (e.message)
        return e.message;
    return 'Unknown error';
}
/**
 * Normalizes any backend error into a typed BackendError
 *
 * Priority (checked in order):
 * 1. TX Submission — Already submitted/duplicate → 409
 * 2. TX Submission — Plutus script validation failure → 400 (ScriptValidationError)
 * 3. TX Submission — Validation/Signature errors → 400
 * 4. Message indicates "not found" → 404 (even if provider returns 5xx)
 * 5. Rate limiting (status 429 or message patterns) → 429
 * 6. Explicit 404 status → 404
 * 7. 5xx errors → 503 (Provider unavailable, retry-able)
 * 8. Other 4xx → 503
 * 9. Unknown/network errors → 503 (default fallback)
 */
function normalizeBackendError(err, backendName) {
    // Already normalized
    if (err instanceof BackendError)
        return err;
    // Check for uninitialized backend client (TypeError from calling methods on null/undefined client)
    if (err instanceof TypeError &&
        (err.message.includes('Cannot read properties of null') ||
            err.message.includes('Cannot read properties of undefined') ||
            err.message.includes('null is not an object') ||
            err.message.includes('undefined is not an object'))) {
        return new BackendInitError(backendName || 'unknown', new Error('Backend client not initialized - call init() first'));
    }
    const message = getErrorMessage(err);
    const status = getErrorStatus(err);
    const messageLower = message.toLowerCase();
    // Priority 1: TX Submission - Already submitted/duplicate → 409
    const alreadySubmittedHints = [
        'already exists',
        'already submitted',
        'already known',
        'known transaction',
        'duplicate',
        'in mempool',
    ];
    if (alreadySubmittedHints.some(h => messageLower.includes(h))) {
        // Try to extract txHash from message
        const txHashMatch = message.match(/([a-f0-9]{64})/i);
        return new TransactionAlreadySubmittedError(txHashMatch?.[1] || 'unknown', err);
    }
    // Priority 2: TX Submission - Plutus script validation → 400 (ScriptValidationError)
    // Must precede the generic validation block: these are ledger phase-2 rejections
    // (tx was well-formed), not provider outages and not generic witness/CBOR issues.
    const scriptValidationHints = [
        'plutusfailure',
        'plutus failure',
        'cekerror',
        'cek error',
        'overspending the budget',
        'overspent',
        'script failure',
        'script failed',
        'script evaluation',
        'ppviewhashesdontmatch',
        'scriptsnotpaidforall',
    ];
    if (scriptValidationHints.some(h => messageLower.includes(h))) {
        return new ScriptValidationError(`Script validation failed: ${message}`, err);
    }
    // Priority 3a: Address-shaped lookup errors → 404. MUST precede the generic
    // validation hints — 'malformed' there used to shadow 'malformed address',
    // turning a Blockfrost 400 on a read into a TransactionValidationError.
    const addressNotFoundHints = [
        'invalid address',
        'malformed address',
    ];
    if (addressNotFoundHints.some(h => messageLower.includes(h))) {
        return new NotFoundError('Resource', backendName, err);
    }
    // Priority 3: TX Submission - Validation/Signature errors → 400
    const validationErrorHints = [
        'signature',
        'witness',
        'verification failed',
        'deserialize',
        'malformed',
        'invalid cbor',
        'invalid transaction',
    ];
    if (validationErrorHints.some(h => messageLower.includes(h))) {
        return new TransactionValidationError(`Transaction validation failed: ${message}`, err);
    }
    // Priority 3b: PostgREST server-side SQL faults surfaced as HTTP 400 (Koios).
    // Body shape: { code: '42703', message: 'column … does not exist' } (broken
    // SQL function on one LB instance) or { code: '57014' } (statement timeout).
    // These are provider faults, not request validation — classify as retry-able
    // 503 so multi-backend failover and the circuit breaker treat them like any
    // other provider outage. Checked before Priority 4: the PostgREST message
    // ("column … does not exist") would otherwise be misread as a resource 404.
    const pgErrorBody = err?.response?.data;
    if ((status === 400 || status === 422) && isPostgrestServerErrorCode(pgErrorBody?.code)) {
        return new ProviderUnavailableError(`Provider database error (${pgErrorBody?.code}): ${pgErrorBody?.message ?? message}`, backendName, undefined, err);
    }
    // Priority 4: Message indicates "not found" or equivalent → always 404.
    // This also handles providers returning wrong status codes for missing
    // resources. Deliberately NOT here: 'not available' / bare 'no data' — those
    // also appear in provider OUTAGE messages, and classifying an outage as 404
    // would make it circuit-breaker-exempt (4xx) on top of hiding the 503.
    const notFoundHints = [
        'not found',
        'has not been found',
        'does not exist',
        'no data found',
        'no records',
        'empty result',
        'no metadata',
    ];
    if (notFoundHints.some(h => messageLower.includes(h))) {
        return new NotFoundError('Resource', backendName, err);
    }
    // Priority 5: Rate limiting detection (status 429 or message patterns)
    if (status === 429 ||
        messageLower.includes('rate limit') ||
        messageLower.includes('too many requests') ||
        messageLower.includes('quota exceeded')) {
        // Try to extract retry-after header
        const headers = err.response?.headers;
        const retryAfter = headers?.["retry-after"] ||
            headers?.["x-ratelimit-reset"];
        return new RateLimitError(message || 'Rate limit exceeded', backendName, retryAfter ? parseInt(retryAfter, 10) : undefined, err);
    }
    // Priority 6: Explicit 404 status
    if (status === 404) {
        return new NotFoundError('Resource', backendName, err);
    }
    // Priority 7: 5xx errors → Provider unavailable (retry-able)
    if (status >= 500) {
        return new ProviderUnavailableError(message || 'Provider returned server error', backendName, undefined, err);
    }
    // Priority 8: Other 4xx → differentiate by status code
    if (status === 400 || status === 422) {
        return new TransactionValidationError(message || `Provider returned ${status}: invalid request`, err);
    }
    if (status === 401 || status === 403) {
        return new BackendError(`Provider authentication failed (${status}): ${message}`, status, error_codes_1.ERROR_CODES.PROVIDER_UNAVAILABLE, backendName, err);
    }
    if (status >= 400) {
        return new ProviderUnavailableError(message || 'Provider request failed', backendName, undefined, err);
    }
    // Priority 9: Unknown/network errors → treat as unavailable (default fallback)
    return new ProviderUnavailableError(message || 'Unknown backend error', backendName, undefined, err);
}
/**
 * HsmError - Error related to HSM operations (signing, session, key access)
 * Indicates that the Hardware Security Module is unavailable or signing failed
 */
class HsmError extends BackendError {
    constructor(message, statusCode = 503, code = error_codes_1.ERROR_CODES.HSM_UNAVAILABLE, originalError) {
        super(message, statusCode, code, 'hsm', originalError);
        this.name = 'HsmError';
    }
}
exports.HsmError = HsmError;
/**
 * ConfigError - Error in configuration settings
 * Captures configuration-related issues
 */
class ConfigError extends Error {
    constructor(message) {
        super(message);
        this.name = 'ConfigError';
    }
}
exports.ConfigError = ConfigError;
/**
 * BackendInitError - Error initializing a specific backend
 * Captures backend name and original error
 */
class BackendInitError extends BackendError {
    constructor(backendName, originalError) {
        super(`Failed to initialize backend: ${backendName}`, 500, error_codes_1.ERROR_CODES.INTERNAL_ERROR, backendName, originalError);
        this.name = 'BackendInitError';
    }
}
exports.BackendInitError = BackendInitError;
/**
 * AllBackendsInitFailedError - All backends failed to initialize
 * Aggregates multiple backend initialization errors
 */
class AllBackendsInitFailedError extends Error {
    errors;
    constructor(errors) {
        const summary = errors
            .map(e => `${e.backendName}: ${e.originalError instanceof Error ? e.originalError.message : String(e.originalError)}`)
            .join(' | ');
        super(`CardanoClient startup failed: all backends failed to initialize. ${summary}`);
        this.errors = errors;
        this.name = 'AllBackendsInitFailedError';
    }
}
exports.AllBackendsInitFailedError = AllBackendsInitFailedError;
/**
 * Function to reject requests with standardized error messages
 * @param req - The incoming request
 * @param ctx - Context string for the error
 * @param message - Detailed error message
 * @param target - Optional target resource
 * @throws {BackendError} BackendError with 400 status code
 */
function rejectInvalid(req, ctx, message, target) {
    throw new BackendError(`${ctx}: ${message}`, 400, error_codes_1.ERROR_CODES.INVALID_INPUT, undefined, undefined, target);
}
/**
 * Function to reject requests for missing required fields
 * @param req - The incoming request
 * @param ctx - Context string for the error
 * @param field - Name of the missing field
 * @throws {BackendError} BackendError with 400 status code
*/
function rejectMissing(req, ctx, field) {
    throw new BackendError(`${ctx}: ${field} is required`, 400, error_codes_1.ERROR_CODES.INVALID_INPUT, undefined, undefined, field);
}
/**
 * Throw BackendError for the first validation error in the list
 * @param req - The incoming request
 * @param ctx - Context string for the error
 * @param errors - Array of validation errors from validateTransactionInputs
 * @throws {BackendError} if errors array is not empty
 */
function throwIfValidationErrors(req, ctx, errors) {
    if (errors.length === 0)
        return;
    const firstError = errors[0];
    if (firstError.type === 'missing') {
        rejectMissing(req, ctx, firstError.field);
    }
    else {
        rejectInvalid(req, ctx, firstError.message, firstError.field);
    }
}
//# sourceMappingURL=errors.js.map