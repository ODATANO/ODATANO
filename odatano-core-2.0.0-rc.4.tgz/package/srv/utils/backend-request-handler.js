"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleBackendRequest = handleBackendRequest;
exports.handleRequest = handleRequest;
const errors_1 = require("./errors");
const cds_1 = __importDefault(require("@sap/cds"));
const mappers_1 = require("./mappers");
const logger = cds_1.default.log('BackendRequestHandler');
/**
 * BackendRequestHandler - Provides standardized handling for backend requests
 */
/**
 * BackendRequestHandler - Wraps a backend method call with standardized error handling
 * @param fn - The async function to execute
 * @param backendName - Name of the backend (for error context)
 * @param resourceName - Name of the resource being accessed (e.g., "Transaction", "Address")
 * @returns {Promise<T>} The result of the backend call or a normalized error
 */
async function handleBackendRequest(fn, backendName) {
    try {
        return await fn();
    }
    catch (err) {
        throw (0, errors_1.normalizeBackendError)(err, backendName);
    }
}
/**
 * General request handler for CardanoService
 * @param req - The incoming request
 * @param handler - The async function containing business logic
 * @returns {Promise<unknown>} The result of the handler or a mapped error response
 */
async function handleRequest(req, handler) {
    const context = req.target?.name || req.event;
    // cds.tx(req) returns the request's managed transaction — CAP auto-rolls back
    // on req.reject()/req.error() (called by mapError). No explicit rollback needed.
    const db = cds_1.default.tx(req);
    try {
        return await handler(db);
    }
    catch (e) {
        logger.error({ err: e }, `${context} error`);
        return (0, mappers_1.mapError)(req, e, context);
    }
}
//# sourceMappingURL=backend-request-handler.js.map