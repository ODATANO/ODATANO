"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateJsonWithLimits = validateJsonWithLimits;
exports.isTxHash = isTxHash;
exports.isAssetUnit = isAssetUnit;
exports.isBlockHash = isBlockHash;
exports.isValidCredential = isValidCredential;
exports.isValidPoolId = isValidPoolId;
exports.isValidDrepId = isValidDrepId;
exports.isValidBech32Address = isValidBech32Address;
exports.isValidBech32StakeAddress = isValidBech32StakeAddress;
exports.isEpochNumber = isEpochNumber;
exports.isValidCbor = isValidCbor;
exports.isValidTxCborHex = isValidTxCborHex;
exports.extractPaymentCredential = extractPaymentCredential;
exports.validateRequiredSigners = validateRequiredSigners;
exports.validateTransactionInputs = validateTransactionInputs;
const bech32_1 = require("bech32");
const const_1 = require("./const");
// Read the active network from a tiny leaf module rather than from `../server`:
// importing server here would pull the whole server → indexer graph (which
// accesses cds.ql at module load) into every consumer of a validator.
const network_context_1 = require("./network-context");
/**
 * Safely trim a string value
 * @param s - The value to trim
 * @returns { string | null } trimmed string or null if input is not a string or empty after trim
 */
function safeTrimString(s) {
    if (typeof s !== "string")
        return null;
    const t = s.trim();
    return t.length > 0 ? t : null;
}
/**
 * Strict bech32 decode with HRP allowlist.
 * @param value - bech32 encoded string
 * @param allowedHrp - list of allowed HRP prefixes
 * @returns { prefix: string; words: number[] } decoded bech32 parts or null if invalid
 */
function tryDecodeBech32WithHrp(value, allowedHrp) {
    try {
        const decoded = bech32_1.bech32.decode(value, const_1.BECH32_MAX_LENGTH);
        if (allowedHrp.includes(decoded.prefix)) {
            return { prefix: decoded.prefix, words: decoded.words };
        }
        return null;
    }
    catch {
        return null;
    }
}
/**
 * Convert bech32 words to byte length
 * @param words - bech32 decoded words
 * @returns { number } byte length of decoded words
 */
function wordsToBytesLen(words) {
    // bech32.fromWords validates word range and converts 5-bit words -> bytes
    return Buffer.from(bech32_1.bech32.fromWords(words)).length;
}
/**
 * Validate JSON string with size and complexity limits to prevent DoS
 * @param jsonString - The JSON string to validate
 * @param fieldName - Name of the field (for error messages)
 * @returns JsonValidationResult with parsed value or error message
 */
function validateJsonWithLimits(jsonString, fieldName) {
    // Check size limit first (before parsing)
    if (jsonString.length > const_1.MAX_JSON_SIZE) {
        return { valid: false, error: `${fieldName} exceeds maximum size of ${const_1.MAX_JSON_SIZE} bytes` };
    }
    // Parse JSON
    let parsed;
    try {
        parsed = JSON.parse(jsonString);
    }
    catch {
        return { valid: false, error: `Invalid JSON in ${fieldName}` };
    }
    // Validate complexity recursively
    const complexityError = checkJsonComplexity(parsed, 0);
    if (complexityError) {
        return { valid: false, error: `${fieldName}: ${complexityError}` };
    }
    return { valid: true, parsed };
}
/**
 * Recursively check JSON complexity (depth, keys, array length, string length)
 * @param value - The parsed JSON value
 * @param depth - Current nesting depth
 * @returns Error message if limits exceeded, null otherwise
 */
function checkJsonComplexity(value, depth) {
    // Check depth limit
    if (depth > const_1.MAX_DEPTH) {
        return `Maximum nesting depth of ${const_1.MAX_DEPTH} exceeded`;
    }
    if (value === null || typeof value !== 'object') {
        // Check string length for primitive strings
        if (typeof value === 'string' && value.length > const_1.MAX_STRING_LENGTH) {
            return `String value exceeds maximum length of ${const_1.MAX_STRING_LENGTH}`;
        }
        return null;
    }
    if (Array.isArray(value)) {
        // Check array length
        if (value.length > const_1.MAX_ARRAY_LENGTH) {
            return `Array exceeds maximum length of ${const_1.MAX_ARRAY_LENGTH}`;
        }
        // Recursively check array elements
        for (const item of value) {
            const error = checkJsonComplexity(item, depth + 1);
            if (error)
                return error;
        }
    }
    else {
        // Check object key count
        const keys = Object.keys(value);
        if (keys.length > const_1.MAX_KEYS) {
            return `Object exceeds maximum key count of ${const_1.MAX_KEYS}`;
        }
        // Recursively check object values
        for (const key of keys) {
            const error = checkJsonComplexity(value[key], depth + 1);
            if (error)
                return error;
        }
    }
    return null;
}
/**
 * Transaction hash: 64-character hexadecimal string
 * @param s - The raw value to validate against transaction hash format
 * @returns { boolean } true if s is a valid transaction hash false otherwise
 */
function isTxHash(s) {
    return typeof s === "string" && const_1.TX_HASH_REGEX.test(s);
}
/**
 * Asset unit: concatenation of policy ID (56 hex chars) + asset name (0-128 hex chars)
 * @param s - The raw value to validate against asset unit format
 * @returns { boolean } true if v is a valid asset unit false otherwise
 */
function isAssetUnit(s) {
    if (typeof s !== "string")
        return false;
    const t = s.trim();
    // Regex ensures: 56-192 hex chars, even length, valid hex
    return const_1.ASSET_UNIT_REGEX.test(t);
}
/**
 * Block hash: 64-character hexadecimal string
 * @param s - The raw value to validate against block hash format
 * @returns { boolean } true if s is a valid block hash false otherwise
 */
function isBlockHash(s) {
    return typeof s === "string" && const_1.HEX_64_REGEX.test(s);
}
/**
 * Payment credential: 28-byte hash (key hash or script hash) as 56-char lowercase hex.
 * Used for credential-based UTxO queries (Indigo CDPs, Liqwid positions, etc.).
 * @param s - The raw value to validate against credential format
 * @returns { boolean } true if s is a valid 56-char lowercase hex string
 */
function isValidCredential(s) {
    return typeof s === "string" && const_1.HEX_56_REGEX.test(s);
}
/**
 * Pool ID: must be bech32-decodable, HRP=pool, payload length 28 bytes.
 * @param poolIdRaw - The raw value to validate against pool ID format
 * @returns { boolean } true if valid pool ID false otherwise
 */
function isValidPoolId(poolIdRaw) {
    const poolId = safeTrimString(poolIdRaw);
    if (!poolId)
        return false;
    // optional: cheap prefilter (keeps performance high)
    if (!const_1.POOL_ID_REGEX.test(poolId))
        return false;
    const decoded = tryDecodeBech32WithHrp(poolId, ["pool"]);
    if (decoded)
        return wordsToBytesLen(decoded.words) === const_1.POOL_ID_BYTES;
    return false;
}
/**
 * DRep ID: must be bech32-decodable, HRP=drep.
 * @param drepRaw - The raw value to validate against drep ID format
 * @returns { boolean } true if valid drep ID false otherwise
 */
function isValidDrepId(drepRaw) {
    const drepId = safeTrimString(drepRaw);
    if (!drepId)
        return false;
    // optional cheap prefilter
    if (!const_1.DREP_ID_REGEX.test(drepId))
        return false;
    const decoded = tryDecodeBech32WithHrp(drepId, ["drep"]);
    if (decoded)
        return wordsToBytesLen(decoded.words) === const_1.DREP_ID_BYTES;
    return false;
}
/**
 * Validate Bech32 address: must be bech32-decodable, HRP based on network config.
 * @param addrRaw - The raw value to validate against bech32 address format
 * @returns { boolean } true if valid bech32 address false otherwise
 */
function isValidBech32Address(addrRaw) {
    const addr = safeTrimString(addrRaw);
    if (!addr)
        return false;
    // get the active network to check the right HRP. If the app context isn't
    // ready yet (e.g., a backend init failure left it uninitialized) the network
    // is null — return false so the handler responds with a clean 400 "Invalid
    // bech32 address format" instead of leaking an init error to the client. The
    // actual init failure is surfaced via stderr in server.ts.
    const network = (0, network_context_1.getActiveNetwork)();
    if (!network)
        return false;
    // prefilter from config to make sure it is the right network
    if (!const_1.HRP[network].addr.test(addr))
        return false;
    const allowed = ["addr", "addr_test"];
    const decoded = tryDecodeBech32WithHrp(addr, allowed);
    if (decoded) {
        // Cardano addresses: 29 bytes (enterprise/reward) to 57 bytes (base address)
        const len = wordsToBytesLen(decoded.words);
        return len >= 29 && len <= 57;
    }
    return false;
}
/**
 * Validate Bech32 stake address: must be bech32-decodable, HRP based on network config.
 * @param stakeRaw - The raw value to validate against stake address format
 * @returns { boolean } true if valid bech32 stake address false otherwise
 */
function isValidBech32StakeAddress(stakeRaw) {
    const stake = safeTrimString(stakeRaw);
    if (!stake)
        return false;
    // Defensive against unset app context — same rationale as isValidBech32Address.
    const network = (0, network_context_1.getActiveNetwork)();
    if (!network)
        return false;
    // prefilter from config to make sure it is the right network
    if (!const_1.HRP[network].stake.test(stake))
        return false;
    const allowed = ["stake", "stake_test"];
    const decoded = tryDecodeBech32WithHrp(stake, allowed);
    if (!decoded)
        return false;
    const len = wordsToBytesLen(decoded.words);
    return len >= 1 && len <= 64;
}
/**
 * Epoch number: non-negative integer within reasonable bounds
 * @param s - The parameter value to validate as epoch number
 * @returns { boolean } true if s is a valid epoch number false otherwise
 */
function isEpochNumber(s) {
    return typeof s === "number" && s >= 0 && s <= const_1.MAX_EPOCH && Number.isInteger(s);
}
/**
 * Validate CBOR string: must be a non-empty even-length hexadecimal string
 * @param cborRaw - The raw value to validate against CBOR format
 * @returns { boolean } true if valid CBOR false otherwise
 */
function isValidCbor(cborRaw) {
    const cbor = safeTrimString(cborRaw);
    if (!cbor)
        return false;
    // basic validation: must be even-length hex string
    return /^[a-f0-9]+$/i.test(cbor) && cbor.length % 2 === 0;
}
/**
 * Validate a transaction CBOR hex string for the ParseTransactionCbor action.
 * Combines `isValidCbor` with a hard length limit to block memory-exhaustion
 * attacks on the server-side CBOR parser.
 * @param cborRaw - The raw value to validate
 * @returns { boolean } true if valid hex AND within MAX_TX_CBOR_HEX_LENGTH
 */
function isValidTxCborHex(cborRaw) {
    if (!isValidCbor(cborRaw))
        return false;
    return cborRaw.trim().length <= const_1.MAX_TX_CBOR_HEX_LENGTH;
}
/**
 * Extract the payment credential from a Shelley bech32 address.
 * Returns the 28-byte credential hash (hex) plus whether it is a SCRIPT
 * credential (address type bit 0 of the header high nibble), or null when the
 * address cannot be decoded / carries no payment part (stake addresses).
 */
function extractPaymentCredential(address) {
    try {
        const decoded = bech32_1.bech32.decode(address, const_1.BECH32_MAX_LENGTH);
        const bytes = Buffer.from(bech32_1.bech32.fromWords(decoded.words));
        // 1 header byte + 28-byte payment credential (+ optional 28-byte stake part)
        if (bytes.length < 29)
            return null;
        const addrType = bytes[0] >> 4;
        // types 0-7 are payment addresses; 14/15 are stake addresses (no payment part)
        if (addrType > 7)
            return null;
        return {
            hash: bytes.subarray(1, 29).toString('hex'),
            isScript: (addrType & 0x1) === 1,
        };
    }
    catch {
        return null;
    }
}
/**
 * Validate an array of Ed25519 key hashes (hex, 28 bytes / 56 hex chars each).
 * @param signers - The parsed JSON array to validate
 * @returns validated string array
 * @throws Error if any signer is invalid
 */
function validateRequiredSigners(signers) {
    if (!Array.isArray(signers)) {
        throw new Error('requiredSignersJson must be a JSON array');
    }
    for (const signer of signers) {
        if (typeof signer !== 'string' || !const_1.ED25519_KEY_HASH_REGEX.test(signer)) {
            throw new Error('Invalid Ed25519 key hash: must be 56 hex chars');
        }
    }
    return signers;
}
/**
 * Validate transaction build inputs and return validation errors if any
 * @param inputs - Transaction input fields to validate
 * @param requiredFields - List of required field names
 * @returns Array of validation errors, empty if all valid
 */
function validateTransactionInputs(inputs, requiredFields) {
    const errors = [];
    // Check required fields
    for (const field of requiredFields) {
        if (inputs[field] === undefined || inputs[field] === null || inputs[field] === '') {
            errors.push({
                type: 'missing',
                field,
                message: `${field} is required`
            });
        }
    }
    // If required fields are missing, return early
    if (errors.length > 0)
        return errors;
    // Validate address formats
    if (inputs.senderAddress && !isValidBech32Address(inputs.senderAddress)) {
        errors.push({
            type: 'invalid',
            field: 'senderAddress',
            message: 'Invalid sender address format'
        });
    }
    if (inputs.recipientAddress && !isValidBech32Address(inputs.recipientAddress)) {
        errors.push({
            type: 'invalid',
            field: 'recipientAddress',
            message: 'Invalid recipient address format'
        });
    }
    if (inputs.changeAddress && !isValidBech32Address(inputs.changeAddress)) {
        errors.push({
            type: 'invalid',
            field: 'changeAddress',
            message: 'Invalid change address format'
        });
    }
    // Validate lovelaceAmount is a positive integer (string-based to avoid precision loss for large values)
    if (inputs.lovelaceAmount !== undefined && inputs.lovelaceAmount !== null) {
        const s = String(inputs.lovelaceAmount);
        if (!/^\d+$/.test(s) || s === '0') {
            errors.push({
                type: 'invalid',
                field: 'lovelaceAmount',
                message: 'lovelaceAmount must be a positive integer'
            });
        }
    }
    // Validate CBOR format and size (max 65536 hex chars = 32 KB binary)
    const MAX_CBOR_HEX_LENGTH = 65536;
    if (inputs.signedTxCbor && !isValidCbor(inputs.signedTxCbor)) {
        errors.push({
            type: 'invalid',
            field: 'signedTxCbor',
            message: 'Invalid signedTxCbor format'
        });
    }
    else if (inputs.signedTxCbor && typeof inputs.signedTxCbor === 'string' && inputs.signedTxCbor.length > MAX_CBOR_HEX_LENGTH) {
        errors.push({
            type: 'invalid',
            field: 'signedTxCbor',
            message: `signedTxCbor exceeds maximum size of ${MAX_CBOR_HEX_LENGTH} hex characters`
        });
    }
    if (inputs.mintingPolicyScript && !isValidCbor(inputs.mintingPolicyScript)) {
        errors.push({
            type: 'invalid',
            field: 'mintingPolicyScript',
            message: 'Invalid mintingPolicyScript format'
        });
    }
    if (inputs.validatorScript && !isValidCbor(inputs.validatorScript)) {
        errors.push({
            type: 'invalid',
            field: 'validatorScript',
            message: 'Invalid validatorScript format'
        });
    }
    if (inputs.referenceScriptHex && !isValidCbor(inputs.referenceScriptHex)) {
        errors.push({
            type: 'invalid',
            field: 'referenceScriptHex',
            message: 'Invalid referenceScriptHex format (must be even-length hex)'
        });
    }
    if (inputs.scriptTxHash && !isTxHash(inputs.scriptTxHash)) {
        errors.push({
            type: 'invalid',
            field: 'scriptTxHash',
            message: 'Invalid scriptTxHash format'
        });
    }
    if (inputs.scriptOutputIndex !== undefined && inputs.scriptOutputIndex !== null) {
        if (!Number.isInteger(inputs.scriptOutputIndex) || inputs.scriptOutputIndex < 0) {
            errors.push({
                type: 'invalid',
                field: 'scriptOutputIndex',
                message: 'scriptOutputIndex must be a non-negative integer'
            });
        }
    }
    // Validate JSON fields with size and complexity limits
    if (inputs.metadataJson) {
        const result = validateJsonWithLimits(inputs.metadataJson, 'metadataJson');
        if (!result.valid) {
            errors.push({
                type: 'invalid',
                field: 'metadataJson',
                message: result.error
            });
        }
    }
    if (inputs.assetsJson) {
        const result = validateJsonWithLimits(inputs.assetsJson, 'assetsJson');
        if (!result.valid) {
            errors.push({
                type: 'invalid',
                field: 'assetsJson',
                message: result.error
            });
        }
    }
    if (inputs.mintActionsJson) {
        const result = validateJsonWithLimits(inputs.mintActionsJson, 'mintActionsJson');
        if (!result.valid) {
            errors.push({
                type: 'invalid',
                field: 'mintActionsJson',
                message: result.error
            });
        }
    }
    if (inputs.redeemerJson) {
        const result = validateJsonWithLimits(inputs.redeemerJson, 'redeemerJson');
        if (!result.valid) {
            errors.push({
                type: 'invalid',
                field: 'redeemerJson',
                message: result.error
            });
        }
    }
    if (inputs.datumJson) {
        const result = validateJsonWithLimits(inputs.datumJson, 'datumJson');
        if (!result.valid) {
            errors.push({
                type: 'invalid',
                field: 'datumJson',
                message: result.error
            });
        }
    }
    const validityStartErr = validatePosixMsField(inputs.validityStartMs, 'validityStartMs');
    if (validityStartErr)
        errors.push(validityStartErr);
    const validityEndErr = validatePosixMsField(inputs.validityEndMs, 'validityEndMs');
    if (validityEndErr)
        errors.push(validityEndErr);
    if (!validityStartErr && !validityEndErr && inputs.validityStartMs && inputs.validityEndMs) {
        if (BigInt(inputs.validityStartMs) >= BigInt(inputs.validityEndMs)) {
            errors.push({
                type: 'invalid',
                field: 'validityEndMs',
                message: 'validityEndMs must be greater than validityStartMs'
            });
        }
    }
    return errors;
}
/**
 * Validate a Posix-ms string field: must be a non-negative integer with at most
 * MAX_POSIX_MS_DIGITS digits. Returns null if valid or absent.
 */
function validatePosixMsField(value, field) {
    if (value === undefined || value === null || value === '')
        return null;
    if (typeof value !== 'string' || !/^\d+$/.test(value) || value.length > const_1.MAX_POSIX_MS_DIGITS) {
        return {
            type: 'invalid',
            field,
            message: `${field} must be a non-negative integer string in milliseconds (max ${const_1.MAX_POSIX_MS_DIGITS} digits)`
        };
    }
    return null;
}
//# sourceMappingURL=validators.js.map