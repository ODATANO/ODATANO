import type { UTxO as OdatanoUtxo, JSONValue } from '../utils/types';
import { type Data } from '@harmoniclabs/plutus-data';
import { UPLCConst } from '@harmoniclabs/uplc';
/**
 * Extract lovelace amount from UTxO
 * @param u UTxO to extract from
 * @returns {bigint} lovelace amount
 */
export declare function getLovelace(u: OdatanoUtxo): bigint;
/**
 * Assert that UTxO contains only ADA (lovelace)
 * @param u UTxO to check
 * @throws {MixedAssetsError} if UTxO contains non-ADA assets
 */
export declare function assertAdaOnly(u: OdatanoUtxo): void;
/**
 * Extract transaction hash from a transaction CBOR (signed or unsigned).
 * Hash is computed over the body, so witness presence does not affect it.
 * @param txCbor transaction in CBOR hex format
 * @returns {string} transaction hash (64 character hex string)
 * @throws {Error} if CBOR is invalid or transaction hash cannot be extracted
 */
export declare function getTxHashFromCbor(txCbor: string): string;
/** Cache-invalidation targets of a submitted transaction (see extractTxCacheTargets). */
export interface TxCacheTargets {
    /** UTxO refs consumed by the transaction (now spent). */
    inputs: Array<{
        txHash: string;
        outputIndex: number;
    }>;
    /** Distinct bech32 addresses receiving outputs (sender change + recipients). */
    outputAddresses: string[];
}
/**
 * Extract the consumed input refs and the output addresses from a transaction
 * CBOR (signed or unsigned) — the rows a successful submit makes stale in the
 * UTxO cache. Works at the raw-CBOR level for the same reason as
 * getTxHashFromCbor (byte-exact, no high-level Tx round-trip).
 *
 * Outputs whose address bytes cannot be decoded (e.g. Byron bootstrap
 * addresses) are skipped — invalidation is best-effort per address.
 *
 * @param txCbor transaction in CBOR hex format
 * @throws {TransactionValidationError} if the CBOR is not a transaction
 */
export declare function extractTxCacheTargets(txCbor: string): TxCacheTargets;
/**
 * Maps builder errors to typed BackendErrors
 * Used by the Buildooor transaction builder.
 * When no assetUnit is provided, extracts it from the error message if possible
 * (e.g. "not enough <policyId.assetName>"), falling back to 'lovelace'.
 * @param err Error from builder
 * @param assetUnit Optional asset unit override (auto-extracted from error message if omitted)
 * @param context Optional build-flow context (e.g. the collateral/funding partition)
 *                appended to the consumer-facing message — the builder's own message
 *                has no way of knowing it
 * @throws {InsufficientFundsError} if error is related to insufficient funds
 * @throws {Error} original error if not mappable
 */
export declare function mapBuilderError(err: unknown, assetUnit?: string, context?: string): never;
/**
 * Parse asset unit string into policyId and assetName
 * Format: policyId (56 hex chars) + assetName (remaining hex)
 * Used by the Buildooor transaction builder
 */
export declare function parseAssetUnit(assetUnit: string): {
    policyId: string;
    assetName: string;
};
/**
 * Convert JSON value to Buildooor PlutusData (Data type).
 * Accepts both cardano-cli format ("constructor") and Buildooor format ("constr").
 * - { "int": 42 } → DataI(42)
 * - { "bytes": "deadbeef" } → DataB("deadbeef")
 * - { "list": [...] } → DataList([...])
 * - { "map": [{ "k": ..., "v": ... }] } → DataMap([...])
 * - { "constructor": 0, "fields": [...] } or { "constr": 0, "fields": [...] } → DataConstr(0, [...])
 * @param json JSON value representing PlutusData
 * @returns Buildooor Data object
 */
export declare function jsonToPlutusData(json: JSONValue): Data;
/**
 * Normalize a backend-provided inline datum to canonical CBOR hex.
 *
 * Backends report inline datums in different shapes:
 * - Blockfrost: hex CBOR string (e.g. "19a6aa")
 * - Koios (_extended): wrapper { bytes: "<hex>", value: { ...PlutusData JSON... } }
 * - Koios (sometimes empty): { bytes: null, value: null }
 * - Some endpoints: raw PlutusData JSON ({ "int": 42 } / { "constructor": 0, "fields": [] })
 *
 * Returns hex CBOR (lowercase) or null. Defensive: returns null on unknown
 * shapes rather than throwing — backend mappers must not crash on malformed data.
 */
export declare function inlineDatumToHex(datum: unknown): string | null;
/** UPLC type tag for a typed script parameter (see {@link encodeScriptParam}). */
export type ScriptParamUplcType = 'data' | 'bytes' | 'int' | 'bool' | 'unit';
/**
 * Encode a single script parameter into the UPLC constant the parameterized
 * script expects.
 *
 * A script parameter is applied as a UPLC constant whose TYPE must match what
 * the compiled validator expects for that parameter. Two input shapes are
 * accepted:
 *
 *  1. Typed — `{ "uplc": "<type>", "value": <...> }`:
 *       - `"data"`  → `UPLCConst.data(...)`        value: PlutusData JSON ("constr"/cardano-cli form)
 *       - `"bytes"` → `UPLCConst.byteString(...)`  value: even-length hex string
 *       - `"int"`   → `UPLCConst.int(...)`         value: number | numeric string
 *       - `"bool"`  → `UPLCConst.bool(...)`        value: boolean
 *       - `"unit"`  → `UPLCConst.unit`             value: omitted
 *     Required for compilers whose scalar params are NATIVE-typed rather than
 *     Data-wrapped (e.g. Pebble: `param x: PubKeyHash` expects a native
 *     `bytestring`, not a `Data` bytestring).
 *
 *  2. Bare PlutusData object (e.g. `{ "bytes": "ab.." }`, `{ "constructor": 0, ... }`)
 *     — shorthand for `{ "uplc": "data", "value": <object> }`. This is the
 *     Aiken / CIP-57 blueprint convention, where every parameter is Data.
 */
export declare function encodeScriptParam(param: JSONValue): UPLCConst;
/**
 * Apply parameters to a parameterized PlutusV3 script (CBOR-wrapped flat UPLC).
 * Each parameter becomes a successive UPLC Application wrapping the program body.
 *
 * Parameters are applied in their declared UPLC type via {@link encodeScriptParam}:
 * pass `{ uplc, value }` entries for native-typed params (e.g. Pebble scalars),
 * or bare PlutusData objects for the Data convention (Aiken / CIP-57 blueprints).
 *
 * @param scriptHex CBOR hex of the unapplied Plutus script (as output by Aiken/Pebble/Plutus compilers)
 * @param params Array of script parameters (typed `{uplc,value}` and/or bare PlutusData JSON) to apply in order
 * @returns CBOR hex of the applied script (ready for transaction building)
 */
export declare function applyScriptParameters(scriptHex: string, params: JSONValue[]): string;
//# sourceMappingURL=tx-build-helper.d.ts.map