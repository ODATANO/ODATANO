import cds, { Request } from '@sap/cds';
/**
 * BackendRequestHandler - Provides standardized handling for backend requests
 */
/**
 * BackendRequestHandler - Wraps a backend method call with standardized error handling
 * @param fn - The async function to execute
 * @param backendName - Name of the backend (for error context)
 * @param resourceName - Name of the resource being accessed (e.g., "Transaction", "Address")
 * @returns {Promise<T>} The result of the backend call or a normalized error
 */
export declare function handleBackendRequest<T>(fn: () => Promise<T>, backendName: string): Promise<T>;
/**
 * General request handler for CardanoService
 * @param req - The incoming request
 * @param handler - The async function containing business logic
 * @returns {Promise<unknown>} The result of the handler or a mapped error response
 */
export declare function handleRequest(req: Request, handler: (db: cds.Transaction) => Promise<unknown>): Promise<unknown>;
//# sourceMappingURL=backend-request-handler.d.ts.map