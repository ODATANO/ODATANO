"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLovelace = getLovelace;
exports.assertAdaOnly = assertAdaOnly;
exports.getTxHashFromCbor = getTxHashFromCbor;
exports.extractTxCacheTargets = extractTxCacheTargets;
exports.mapBuilderError = mapBuilderError;
exports.parseAssetUnit = parseAssetUnit;
exports.jsonToPlutusData = jsonToPlutusData;
exports.inlineDatumToHex = inlineDatumToHex;
exports.encodeScriptParam = encodeScriptParam;
exports.applyScriptParameters = applyScriptParameters;
const uint8array_utils_1 = require("@harmoniclabs/uint8array-utils");
const crypto_1 = require("@harmoniclabs/crypto");
const errors_1 = require("./errors");
const error_codes_1 = require("./error-codes");
const plutus_data_1 = require("@harmoniclabs/plutus-data");
const uplc_1 = require("@harmoniclabs/uplc");
const cbor_1 = require("@harmoniclabs/cbor");
const cardano_ledger_ts_1 = require("@harmoniclabs/cardano-ledger-ts");
/**
 * Extract lovelace amount from UTxO
 * @param u UTxO to extract from
 * @returns {bigint} lovelace amount
 */
function getLovelace(u) {
    const entry = u.amount.find(a => (a.unit).toLowerCase() === "lovelace");
    return BigInt(entry?.quantity ?? "0");
}
/**
 * Assert that UTxO contains only ADA (lovelace)
 * @param u UTxO to check
 * @throws {MixedAssetsError} if UTxO contains non-ADA assets
 */
function assertAdaOnly(u) {
    const nonAda = u.amount.filter(a => (a.unit).toLowerCase() !== "lovelace" && BigInt(a.quantity) !== 0n);
    if (nonAda.length > 0) {
        throw new errors_1.MixedAssetsError(`${u.txHash}#${u.outputIndex}`, nonAda.map(a => a.unit));
    }
}
/**
 * Extract transaction hash from a transaction CBOR (signed or unsigned).
 * Hash is computed over the body, so witness presence does not affect it.
 * @param txCbor transaction in CBOR hex format
 * @returns {string} transaction hash (64 character hex string)
 * @throws {Error} if CBOR is invalid or transaction hash cannot be extracted
 */
function getTxHashFromCbor(txCbor) {
    if (!txCbor || typeof txCbor !== 'string') {
        throw new Error('Invalid input: txCbor must be a non-empty string');
    }
    // Validate hex format. Require even length — a hex byte string encodes whole bytes,
    // so an odd-length string is malformed and would otherwise surface as a confusing
    // "Failed to parse transaction CBOR" from fromHex/Cbor.parse rather than a clear
    // input-validation error.
    if (!/^[a-fA-F0-9]+$/.test(txCbor) || txCbor.length % 2 !== 0) {
        throw new Error('Invalid input: txCbor must be a valid hex string');
    }
    // Compute blake2b-256 over the ORIGINAL transaction-body bytes (CBOR array index 0).
    // subCborRef.toBuffer() returns the exact bytes as received — no re-serialization, so
    // the hash matches what was signed. We stay at the raw-CBOR level (never instantiate
    // the high-level Tx type) for that byte-exactness.
    try {
        const tx = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(txCbor));
        if (!(tx instanceof cbor_1.CborArray) || tx.array.length < 1 || !tx.array[0].subCborRef) {
            throw new Error('not a transaction');
        }
        const bodyBytes = tx.array[0].subCborRef.toBuffer();
        return (0, uint8array_utils_1.toHex)((0, crypto_1.blake2b_256)(bodyBytes));
    }
    catch (err) {
        // typed 400 — a plain Error here surfaced as a 500 to the consumer
        throw new errors_1.TransactionValidationError('Failed to parse transaction CBOR', err, error_codes_1.ERROR_CODES.TX_PARSE_FAILED);
    }
}
/**
 * Extract the consumed input refs and the output addresses from a transaction
 * CBOR (signed or unsigned) — the rows a successful submit makes stale in the
 * UTxO cache. Works at the raw-CBOR level for the same reason as
 * getTxHashFromCbor (byte-exact, no high-level Tx round-trip).
 *
 * Outputs whose address bytes cannot be decoded (e.g. Byron bootstrap
 * addresses) are skipped — invalidation is best-effort per address.
 *
 * @param txCbor transaction in CBOR hex format
 * @throws {TransactionValidationError} if the CBOR is not a transaction
 */
function extractTxCacheTargets(txCbor) {
    let body;
    try {
        const tx = cbor_1.Cbor.parse((0, uint8array_utils_1.fromHex)(txCbor));
        if (!(tx instanceof cbor_1.CborArray) || !(tx.array[0] instanceof cbor_1.CborMap)) {
            throw new Error('not a transaction');
        }
        body = tx.array[0];
    }
    catch (err) {
        throw new errors_1.TransactionValidationError('Failed to parse transaction CBOR', err, error_codes_1.ERROR_CODES.TX_PARSE_FAILED);
    }
    const bodyValue = (key) => body.map.find(e => e.k instanceof cbor_1.CborUInt && e.k.num === BigInt(key))?.v;
    // key 0: inputs — plain array or a CBOR tag-258 set (Conway)
    const inputs = [];
    let inputsObj = bodyValue(0);
    if (inputsObj instanceof cbor_1.CborTag)
        inputsObj = inputsObj.data;
    if (inputsObj instanceof cbor_1.CborArray) {
        for (const entry of inputsObj.array) {
            if (entry instanceof cbor_1.CborArray &&
                entry.array[0] instanceof cbor_1.CborBytes &&
                entry.array[1] instanceof cbor_1.CborUInt) {
                inputs.push({ txHash: (0, uint8array_utils_1.toHex)(entry.array[0].bytes), outputIndex: Number(entry.array[1].num) });
            }
        }
    }
    // key 1: outputs — post-alonzo map form ({0: address, ...}) or legacy array form ([address, amount, ...])
    const outputAddresses = new Set();
    const outputsObj = bodyValue(1);
    if (outputsObj instanceof cbor_1.CborArray) {
        for (const output of outputsObj.array) {
            const addrObj = output instanceof cbor_1.CborMap
                ? output.map.find(e => e.k instanceof cbor_1.CborUInt && e.k.num === 0n)?.v
                : output instanceof cbor_1.CborArray ? output.array[0] : undefined;
            if (!(addrObj instanceof cbor_1.CborBytes))
                continue;
            try {
                outputAddresses.add(cardano_ledger_ts_1.Address.fromBuffer(addrObj.bytes).toString());
            }
            catch {
                // non-Shelley address bytes — nothing cached under a bech32 key for it
            }
        }
    }
    return { inputs, outputAddresses: [...outputAddresses] };
}
/**
 * Maps builder errors to typed BackendErrors
 * Used by the Buildooor transaction builder.
 * When no assetUnit is provided, extracts it from the error message if possible
 * (e.g. "not enough <policyId.assetName>"), falling back to 'lovelace'.
 * @param err Error from builder
 * @param assetUnit Optional asset unit override (auto-extracted from error message if omitted)
 * @param context Optional build-flow context (e.g. the collateral/funding partition)
 *                appended to the consumer-facing message — the builder's own message
 *                has no way of knowing it
 * @throws {InsufficientFundsError} if error is related to insufficient funds
 * @throws {Error} original error if not mappable
 */
function mapBuilderError(err, assetUnit, context) {
    // Already-typed errors carry their own status + payload (amounts, asset units,
    // validation details) — re-wrapping them into a generic InsufficientFundsError
    // because their MESSAGE happens to contain "balance"/"insufficient" destroys that.
    if (err instanceof errors_1.BackendError) {
        throw err;
    }
    const errObj = err;
    const rawMsg = errObj?.message || errObj?.toString?.() || String(err);
    const msg = rawMsg.toLowerCase();
    if (msg.includes('not enough') ||
        msg.includes('insufficient') ||
        msg.includes('balance')) {
        const effectiveUnit = assetUnit ?? (() => {
            const match = msg.match(/not enough\s+([a-f0-9.]+)/i);
            return match?.[1] || 'lovelace';
        })();
        // The builder knows no amounts here — surface its own message (plus the build
        // context) instead of a meaningless "required 0, available 0".
        throw new errors_1.InsufficientFundsError(effectiveUnit, 0n, 0n, err, context ? `${rawMsg} (${context})` : rawMsg);
    }
    throw err;
}
/**
 * Parse asset unit string into policyId and assetName
 * Format: policyId (56 hex chars) + assetName (remaining hex)
 * Used by the Buildooor transaction builder
 */
function parseAssetUnit(assetUnit) {
    return {
        policyId: assetUnit.substring(0, 56),
        assetName: assetUnit.substring(56)
    };
}
/** Allowed keys in PlutusData JSON — strip anything else for defense-in-depth */
const PLUTUS_DATA_ALLOWED_KEYS = new Set([
    'constructor', 'constr', 'fields', 'int', 'bytes', 'list', 'map', 'k', 'v'
]);
/** Strip keys not in the PlutusData whitelist */
function sanitizePlutusKeys(obj) {
    const clean = {};
    for (const key of Object.keys(obj)) {
        if (PLUTUS_DATA_ALLOWED_KEYS.has(key)) {
            clean[key] = obj[key];
        }
    }
    return clean;
}
/**
 * Normalize PlutusData JSON from cardano-cli format ("constructor") to
 * Buildooor format ("constr"), recursively through fields/list/map.
 * Also strips unrecognized keys for safety.
 */
function normalizeConstructorKey(obj) {
    const safe = sanitizePlutusKeys(obj);
    const isObj = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
    if (Object.hasOwn(safe, 'constructor') && !Object.hasOwn(safe, 'constr')) {
        const result = { constr: safe.constructor };
        if (Array.isArray(safe.fields)) {
            result.fields = safe.fields.map((f) => isObj(f) ? normalizeConstructorKey(f) : f);
        }
        return result;
    }
    if ('list' in safe && Array.isArray(safe.list)) {
        return { list: safe.list.map((item) => isObj(item) ? normalizeConstructorKey(item) : item) };
    }
    if ('map' in safe && Array.isArray(safe.map)) {
        return { map: safe.map.map((entry) => ({
                k: isObj(entry.k) ? normalizeConstructorKey(entry.k) : entry.k,
                v: isObj(entry.v) ? normalizeConstructorKey(entry.v) : entry.v,
            })) };
    }
    if ('constr' in safe && Array.isArray(safe.fields)) {
        return { constr: safe.constr, fields: safe.fields.map((f) => isObj(f) ? normalizeConstructorKey(f) : f) };
    }
    return safe;
}
/**
 * Convert JSON value to Buildooor PlutusData (Data type).
 * Accepts both cardano-cli format ("constructor") and Buildooor format ("constr").
 * - { "int": 42 } → DataI(42)
 * - { "bytes": "deadbeef" } → DataB("deadbeef")
 * - { "list": [...] } → DataList([...])
 * - { "map": [{ "k": ..., "v": ... }] } → DataMap([...])
 * - { "constructor": 0, "fields": [...] } or { "constr": 0, "fields": [...] } → DataConstr(0, [...])
 * @param json JSON value representing PlutusData
 * @returns Buildooor Data object
 */
function jsonToPlutusData(json) {
    if (json === null || json === undefined) {
        throw new Error('PlutusData JSON cannot be null or undefined');
    }
    if (typeof json === 'object' && !Array.isArray(json)) {
        const normalized = normalizeConstructorKey(json);
        return (0, plutus_data_1.dataFromJson)(normalized);
    }
    throw new Error(`Unsupported PlutusData JSON format: expected an object with "int", "bytes", "list", "map", or "constructor" key`);
}
/**
 * Normalize a backend-provided inline datum to canonical CBOR hex.
 *
 * Backends report inline datums in different shapes:
 * - Blockfrost: hex CBOR string (e.g. "19a6aa")
 * - Koios (_extended): wrapper { bytes: "<hex>", value: { ...PlutusData JSON... } }
 * - Koios (sometimes empty): { bytes: null, value: null }
 * - Some endpoints: raw PlutusData JSON ({ "int": 42 } / { "constructor": 0, "fields": [] })
 *
 * Returns hex CBOR (lowercase) or null. Defensive: returns null on unknown
 * shapes rather than throwing — backend mappers must not crash on malformed data.
 */
function inlineDatumToHex(datum) {
    if (datum === null || datum === undefined)
        return null;
    // Already hex CBOR (Blockfrost path, or pre-normalized)
    if (typeof datum === 'string') {
        const s = datum.trim();
        if (!s)
            return null;
        return /^[0-9a-fA-F]+$/.test(s) && s.length % 2 === 0 ? s.toLowerCase() : null;
    }
    if (typeof datum !== 'object' || Array.isArray(datum))
        return null;
    const obj = datum;
    // Koios wrapper: { bytes: "<hex>", value: <PlutusData JSON> }.
    // Distinguished from raw PlutusData {bytes:"deadbeef"} by the presence of `value`.
    if ('value' in obj && typeof obj.bytes === 'string' && obj.bytes.length > 0) {
        const hex = obj.bytes.trim();
        return /^[0-9a-fA-F]+$/.test(hex) && hex.length % 2 === 0 ? hex.toLowerCase() : null;
    }
    // Koios empty wrapper: all top-level values null
    if ('value' in obj || ('bytes' in obj && obj.bytes === null)) {
        const vals = Object.values(obj);
        if (vals.length > 0 && vals.every(v => v === null))
            return null;
    }
    // Raw PlutusData JSON (DetailedSchema or Buildooor "constr" form)
    try {
        const data = jsonToPlutusData(datum);
        return Buffer.from((0, plutus_data_1.dataToCbor)(data)).toString('hex');
    }
    catch {
        return null;
    }
}
/**
 * Encode a single script parameter into the UPLC constant the parameterized
 * script expects.
 *
 * A script parameter is applied as a UPLC constant whose TYPE must match what
 * the compiled validator expects for that parameter. Two input shapes are
 * accepted:
 *
 *  1. Typed — `{ "uplc": "<type>", "value": <...> }`:
 *       - `"data"`  → `UPLCConst.data(...)`        value: PlutusData JSON ("constr"/cardano-cli form)
 *       - `"bytes"` → `UPLCConst.byteString(...)`  value: even-length hex string
 *       - `"int"`   → `UPLCConst.int(...)`         value: number | numeric string
 *       - `"bool"`  → `UPLCConst.bool(...)`        value: boolean
 *       - `"unit"`  → `UPLCConst.unit`             value: omitted
 *     Required for compilers whose scalar params are NATIVE-typed rather than
 *     Data-wrapped (e.g. Pebble: `param x: PubKeyHash` expects a native
 *     `bytestring`, not a `Data` bytestring).
 *
 *  2. Bare PlutusData object (e.g. `{ "bytes": "ab.." }`, `{ "constructor": 0, ... }`)
 *     — shorthand for `{ "uplc": "data", "value": <object> }`. This is the
 *     Aiken / CIP-57 blueprint convention, where every parameter is Data.
 */
function encodeScriptParam(param) {
    if (param !== null &&
        typeof param === 'object' &&
        !Array.isArray(param) &&
        'uplc' in param) {
        const { uplc, value } = param;
        switch (uplc) {
            case 'data':
                return uplc_1.UPLCConst.data(jsonToPlutusData(value));
            case 'bytes': {
                if (typeof value !== 'string' || !/^([0-9a-fA-F]{2})*$/.test(value)) {
                    throw new Error('Script param of uplc type "bytes" requires an even-length hex string "value"');
                }
                return uplc_1.UPLCConst.byteString((0, uint8array_utils_1.fromHex)(value));
            }
            case 'int': {
                if (typeof value !== 'number' && typeof value !== 'string') {
                    throw new Error('Script param of uplc type "int" requires a number or numeric-string "value"');
                }
                let n;
                try {
                    n = BigInt(value);
                }
                catch {
                    throw new Error(`Script param of uplc type "int" has a non-integer "value": ${String(value)}`);
                }
                return uplc_1.UPLCConst.int(n);
            }
            case 'bool': {
                if (typeof value !== 'boolean') {
                    throw new Error('Script param of uplc type "bool" requires a boolean "value"');
                }
                return uplc_1.UPLCConst.bool(value);
            }
            case 'unit':
                return uplc_1.UPLCConst.unit;
            default:
                throw new Error(`Unknown script param uplc type "${String(uplc)}"; expected one of: data, bytes, int, bool, unit`);
        }
    }
    // Bare PlutusData → apply as Data (Aiken / blueprint convention)
    return uplc_1.UPLCConst.data(jsonToPlutusData(param));
}
/**
 * Apply parameters to a parameterized PlutusV3 script (CBOR-wrapped flat UPLC).
 * Each parameter becomes a successive UPLC Application wrapping the program body.
 *
 * Parameters are applied in their declared UPLC type via {@link encodeScriptParam}:
 * pass `{ uplc, value }` entries for native-typed params (e.g. Pebble scalars),
 * or bare PlutusData objects for the Data convention (Aiken / CIP-57 blueprints).
 *
 * @param scriptHex CBOR hex of the unapplied Plutus script (as output by Aiken/Pebble/Plutus compilers)
 * @param params Array of script parameters (typed `{uplc,value}` and/or bare PlutusData JSON) to apply in order
 * @returns CBOR hex of the applied script (ready for transaction building)
 */
function applyScriptParameters(scriptHex, params) {
    if (!Array.isArray(params) || params.length === 0) {
        throw new Error('Script parameters must be a non-empty array');
    }
    // 1. CBOR-decode script hex → get inner flat UPLC bytes
    const cborObj = cbor_1.Cbor.parse(scriptHex);
    const flatBytes = cborObj.bytes;
    // 2. Flat-decode → UPLCProgram
    const program = uplc_1.UPLCDecoder.parse(flatBytes, 'flat');
    // 3. Apply each parameter as Application(body, <typed UPLC constant>)
    let body = program.body;
    for (const param of params) {
        body = new uplc_1.Application(body, encodeScriptParam(param));
    }
    // 4. Create new program with applied body, flat-encode, CBOR-wrap
    const applied = new uplc_1.UPLCProgram(program.version, body);
    const appliedFlatBytes = (0, uplc_1.compileUPLC)(applied);
    const cborEncoded = cbor_1.Cbor.encode(new cbor_1.CborBytes(appliedFlatBytes));
    return (0, uint8array_utils_1.toHex)(cborEncoded);
}
//# sourceMappingURL=tx-build-helper.js.map