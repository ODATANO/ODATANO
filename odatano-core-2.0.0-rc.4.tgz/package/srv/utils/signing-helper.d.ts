/**
 * Combine an unsigned transaction with a witness set from CIP-30 wallet signing
 *
 * CIP-30 signTx() returns only the witness set, not a complete signed transaction.
 * This function combines the original unsigned transaction with the witness set
 * to create a complete signed transaction that can be submitted to the network.
 *
 * @param unsignedTxCbor - The unsigned transaction CBOR (hex)
 * @param witnessSetCbor - The witness set CBOR from CIP-30 signTx() (hex)
 * @returns Complete signed transaction CBOR (hex)
 */
export declare function combineTransactionWithWitnesses(unsignedTxCbor: string, witnessSetCbor: string): string;
/**
 * Check if a CBOR string is a witness set (vs a full transaction)
 *
 * CIP-30 returns witness sets, not full transactions.
 * This helps detect when we need to call combineTransactionWithWitnesses.
 *
 * @param cborHex - CBOR hex string
 * @returns true if it's a witness set, false if it's a full transaction
 */
export declare function isWitnessSetCbor(cborHex: string): boolean;
//# sourceMappingURL=signing-helper.d.ts.map