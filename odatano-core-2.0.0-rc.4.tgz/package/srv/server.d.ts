import { CardanoClient, CardanoClientConfig, BackendName, TransactionBuilderName } from './blockchain/cardano-client';
import { CardanoIndexer } from './blockchain/cardano-indexer';
import { CardanoTransactionBuilder } from './blockchain/cardano-tx-builder';
import type { LedgerProtocolParameters, HsmConfig } from './utils/types';
import type { CrawlerConfig } from './blockchain/crawler/crawler';
import type { WalletWorkerConfig } from './blockchain/wallet-worker';
/**
 * Application context holding initialized blockchain components
 * These are created once during CAP bootstrap and shared across services
 */
interface AppContext {
    cardanoClient: CardanoClient;
    cardanoIndexer: CardanoIndexer;
    cardanoTxBuilder: CardanoTransactionBuilder;
}
/**
 * Get the application context (must be called after bootstrap)
 * @throws {ProviderUnavailableError} 503 when uninitialized — request handlers using
 *   handleRequest/mapError translate this into a clean 503 response instead of a raw 500.
 *   If bootstrap actively failed, the cause is appended to the message.
 */
export declare function getAppContext(): AppContext;
/**
 * Get the CardanoIndexer instance
 * Convenience function for services
 */
export declare function getCardanoIndexer(): CardanoIndexer;
/**
 * Get the CardanoClient instance
 * Convenience function for services
 */
export declare function getCardanoClient(): CardanoClient;
/**
 * Get the CardanoTransactionBuilder instance
 * Convenience function for services and plugin consumers
 */
export declare function getCardanoTxBuilder(): CardanoTransactionBuilder;
/**
 * Get the HSM configuration (if HSM is enabled).
 * Used by sign service to check requiresRole.
 */
export declare function getHsmConfig(): HsmConfig | undefined;
/**
 * Initialize from a pre-built config (used by plugin's src/index.ts)
 * @param config - validated CardanoClientConfig
 * @param protocolParams - Optional protocol parameters (for tests)
 */
export declare function initializeFromConfig(config: CardanoClientConfig, protocolParams?: LedgerProtocolParameters, hsmConfig?: HsmConfig): Promise<void>;
/**
 * Reset the application context (for testing only)
 * Allows tests to inject their own instances
 */
export declare function resetAppContext(context: AppContext | null): void;
/**
 * Create a test context with specific backends and transaction builder
 * Used by integration tests to create isolated test instances
 * @param backends Array of backend names to use (e.g., ['koios'], ['blockfrost'])
 * @param _txBuilderName Deprecated/ignored — Buildooor is the sole transaction builder (kept for signature compatibility)
 * @param protocolParams Optional protocol parameters (to skip backend call during init)
 * @returns Promise<AppContext> The created application context
 */
export declare function createTestContext(backends: BackendName[], _txBuilderName?: TransactionBuilderName, // kept for signature compat; Buildooor is the only builder
protocolParams?: LedgerProtocolParameters): Promise<AppContext>;
/**
 * Shutdown the application context (for cleanup in tests)
 * Closes all backend connections to allow process to exit cleanly
 */
export declare function shutdownAppContext(): Promise<void>;
/**
 * Load and validate CardanoClientConfig from CDS config or environment variables.
 *
 * When used as a plugin, consumers configure via package.json:
 *   { "cds": { "requires": { "odatano-core": { "network": "preview", "backends": ["blockfrost"], ... }}}}
 *
 * Priority: cds.env.requires["odatano-core"].X > process.env.X > default
 *
 * @returns validated CardanoClientConfig
 * @throws {Error} if any config value is invalid
 */
export declare function loadConfigFromEnv(): CardanoClientConfig;
/**
 * Load HSM configuration from CDS config or environment variables.
 * Returns undefined if HSM is not enabled.
 *
 * Plugin mode: cds.requires.odatano-core.hsm.enabled = true
 * Env mode:    HSM_ENABLED=true
 *
 * @returns HsmConfig or undefined
 */
export declare function loadHsmConfigFromEnv(): HsmConfig | undefined;
/**
 * Load the chain-crawler configuration from CDS config or environment variables.
 * Returns { enabled:false } when the crawler is not switched on (the default), so
 * existing deployments are unaffected.
 *
 * Plugin mode: cds.requires.odatano-core.crawler.{enabled,startSlot,startBlockHash,...}
 * Env mode:    CRAWLER_ENABLED / CRAWLER_START_SLOT / CRAWLER_START_HASH / ...
 */
export declare function loadCrawlerConfigFromEnv(): CrawlerConfig;
/**
 * Start the chain crawler if it is enabled and the app context is ready. Never throws
 * (crawler failure must not affect request serving) — errors are logged. Idempotent:
 * startCrawler() is a no-op when one is already running.
 */
export declare function startCrawlerIfConfigured(): Promise<void>;
/**
 * Load the wallet-worker configuration from CDS config or environment variables.
 * Returns { enabled:false } when the worker is not switched on (the default).
 *
 * Plugin mode: cds.requires.odatano-core.walletWorker.{enabled,wallets,...}
 * Env mode:    WALLET_WORKER_ENABLED / WALLET_WORKER_WALLETS (JSON) / ...
 */
export declare function loadWalletWorkerConfigFromEnv(): WalletWorkerConfig;
/**
 * Start the wallet worker if it is enabled and the app context is ready. Never
 * throws (worker failure must not affect request serving) — errors are logged.
 * Idempotent: startWalletWorker() is a no-op when one is already running.
 */
export declare function startWalletWorkerIfConfigured(): Promise<void>;
/**
 * Re-drive deferred submissions that were claimed (status 'submitting' with
 * persisted signedTxCbor) but whose detached submit never ran because the
 * process died first (KNOWN_ISSUES #11, Layer 2). Idempotent — an already
 * submitted tx finalizes via the TransactionAlreadySubmittedError path.
 * Non-fatal, mirrors startCrawlerIfConfigured/startWalletWorkerIfConfigured.
 */
export declare function redriveInterruptedSubmissionsIfConfigured(): Promise<void>;
export {};
//# sourceMappingURL=server.d.ts.map