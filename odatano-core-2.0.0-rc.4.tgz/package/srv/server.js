"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAppContext = getAppContext;
exports.getCardanoIndexer = getCardanoIndexer;
exports.getCardanoClient = getCardanoClient;
exports.getCardanoTxBuilder = getCardanoTxBuilder;
exports.getHsmConfig = getHsmConfig;
exports.initializeFromConfig = initializeFromConfig;
exports.resetAppContext = resetAppContext;
exports.createTestContext = createTestContext;
exports.shutdownAppContext = shutdownAppContext;
exports.loadConfigFromEnv = loadConfigFromEnv;
exports.loadHsmConfigFromEnv = loadHsmConfigFromEnv;
exports.loadCrawlerConfigFromEnv = loadCrawlerConfigFromEnv;
exports.startCrawlerIfConfigured = startCrawlerIfConfigured;
exports.loadWalletWorkerConfigFromEnv = loadWalletWorkerConfigFromEnv;
exports.startWalletWorkerIfConfigured = startWalletWorkerIfConfigured;
exports.redriveInterruptedSubmissionsIfConfigured = redriveInterruptedSubmissionsIfConfigured;
const cds_1 = __importDefault(require("@sap/cds"));
const cardano_client_1 = require("./blockchain/cardano-client");
const cardano_indexer_1 = require("./blockchain/cardano-indexer");
const cardano_tx_builder_1 = require("./blockchain/cardano-tx-builder");
const hsm_signer_1 = require("./blockchain/signing/hsm-signer");
const errors_1 = require("./utils/errors");
const network_context_1 = require("./utils/network-context");
const crawler_1 = require("./blockchain/crawler");
const wallet_worker_1 = require("./blockchain/wallet-worker");
const process_1 = require("process");
const logger = cds_1.default.log('ODATANO');
const VALID_NETWORKS = ['mainnet', 'preview', 'preprod'];
const VALID_BACKENDS = ['blockfrost', 'koios', 'ogmios'];
const CRAWLER_LIMITS = {
    batchSize: { min: 1, max: 100 },
    confirmationDepth: { min: 0, max: 2160 },
    pollIntervalMs: { min: 1000, max: 3_600_000 },
};
/** Parse an integer without allowing JavaScript's lossy/implicit coercions. */
function crawlerInteger(raw, name, min, max, defaultValue) {
    if (raw == null)
        return defaultValue;
    if ((typeof raw !== 'number' && typeof raw !== 'string')
        || (typeof raw === 'string' && raw.trim() === '')) {
        throw new errors_1.ConfigError(`Invalid ${name} "${String(raw)}". Must be an integer between ${min} and ${max}.`);
    }
    const parsed = typeof raw === 'number' ? raw : Number(raw);
    if (!Number.isSafeInteger(parsed) || parsed < min || parsed > max) {
        throw new errors_1.ConfigError(`Invalid ${name} "${String(raw)}". Must be an integer between ${min} and ${max}.`);
    }
    return parsed;
}
let appContext = null;
let bootstrapError = null;
/**
 * Initialize the application context with blockchain components
 * Called once during CAP server startup via cds.on('served')
 * @param config - CardanoClientConfig
 * @param protocolParams - Optional protocol parameters (for tests to skip backend call)
 */
async function initializeAppContext(config, protocolParams, hsmConfig) {
    logger.debug('Initializing blockchain components...');
    // Create CardanoClient from configuration
    const cardanoClient = new cardano_client_1.CardanoClient(config);
    // Publish the active network for leaf utilities (e.g. network-aware validators)
    // without forcing them to import this module / the full server graph.
    (0, network_context_1.setActiveNetwork)(config.network);
    // Create CardanoTransactionBuilder with the client
    const cardanoTxBuilder = new cardano_tx_builder_1.CardanoTransactionBuilder(cardanoClient);
    await cardanoTxBuilder.init(protocolParams);
    // Create CardanoIndexer with client and transaction builder
    const cardanoIndexer = new cardano_indexer_1.CardanoIndexer(cardanoClient, cardanoTxBuilder);
    // Initialize HSM signer if configured (failure is non-fatal — won't crash the app)
    if (hsmConfig?.enabled) {
        try {
            const hsmSigner = new hsm_signer_1.HsmSigner(hsmConfig);
            await hsmSigner.init(config.network);
            (0, hsm_signer_1.setHsmSigner)(hsmSigner);
            logger.debug('HSM signer initialized');
        }
        catch (err) {
            logger.error('Failed to initialize HSM signer:', err);
            (0, hsm_signer_1.setHsmSigner)(null);
        }
    }
    logger.info('Blockchain components initialized successfully');
    return {
        cardanoClient,
        cardanoIndexer,
        cardanoTxBuilder,
    };
}
/**
 * Get the application context (must be called after bootstrap)
 * @throws {ProviderUnavailableError} 503 when uninitialized — request handlers using
 *   handleRequest/mapError translate this into a clean 503 response instead of a raw 500.
 *   If bootstrap actively failed, the cause is appended to the message.
 */
function getAppContext() {
    if (!appContext) {
        const base = 'Application not initialized. This should be called after cds.served event.';
        const msg = bootstrapError
            ? `${base} Bootstrap failed: ${bootstrapError.message}`
            : base;
        throw new errors_1.ProviderUnavailableError(msg, 'odatano-bootstrap', undefined, bootstrapError ?? undefined);
    }
    return appContext;
}
/**
 * Get the CardanoIndexer instance
 * Convenience function for services
 */
function getCardanoIndexer() {
    return getAppContext().cardanoIndexer;
}
/**
 * Get the CardanoClient instance
 * Convenience function for services
 */
function getCardanoClient() {
    return getAppContext().cardanoClient;
}
/**
 * Get the CardanoTransactionBuilder instance
 * Convenience function for services and plugin consumers
 */
function getCardanoTxBuilder() {
    return getAppContext().cardanoTxBuilder;
}
let hsmConfigInstance;
/**
 * Get the HSM configuration (if HSM is enabled).
 * Used by sign service to check requiresRole.
 */
function getHsmConfig() {
    return hsmConfigInstance;
}
/**
 * Initialize from a pre-built config (used by plugin's src/index.ts)
 * @param config - validated CardanoClientConfig
 * @param protocolParams - Optional protocol parameters (for tests)
 */
async function initializeFromConfig(config, protocolParams, hsmConfig) {
    // Idempotent: a previous call (plugin's cds.on('served'), server.ts's served hook,
    // or an earlier programmatic initialize()) already built the context. Direct callers
    // such as @odatano/x402's bridge must not produce a duplicate CardanoClient.
    // Tests that need to reinitialize should use resetAppContext() / createTestContext().
    if (appContext) {
        logger.debug('initializeFromConfig: appContext already initialized, skipping');
        return;
    }
    hsmConfigInstance = hsmConfig;
    try {
        appContext = await initializeAppContext(config, protocolParams, hsmConfig);
        bootstrapError = null;
    }
    catch (err) {
        // Capture the cause so getAppContext() surfaces a structured 503 with diagnostics
        // even in PLUGIN mode (src/plugin.ts only logs the error) — previously bootstrapError
        // stayed null there and the failure showed up as a causeless "not initialized".
        bootstrapError = err instanceof Error ? err : new Error(String(err));
        throw err; // still propagate so the plugin/programmatic caller sees it
    }
}
/**
 * Reset the application context (for testing only)
 * Allows tests to inject their own instances
 */
function resetAppContext(context) {
    if (process.env.NODE_ENV === 'production') {
        throw new Error('resetAppContext() is not available in production');
    }
    appContext = context;
    bootstrapError = null;
    // Keep the published network in sync with the injected context (or clear it).
    (0, network_context_1.setActiveNetwork)(context?.cardanoClient.network ?? null);
    logger.debug('Application context reset');
}
/**
 * Create a test context with specific backends and transaction builder
 * Used by integration tests to create isolated test instances
 * @param backends Array of backend names to use (e.g., ['koios'], ['blockfrost'])
 * @param _txBuilderName Deprecated/ignored — Buildooor is the sole transaction builder (kept for signature compatibility)
 * @param protocolParams Optional protocol parameters (to skip backend call during init)
 * @returns Promise<AppContext> The created application context
 */
async function createTestContext(backends, _txBuilderName = 'buildooor', // kept for signature compat; Buildooor is the only builder
protocolParams) {
    const config = {
        network: process_1.env.NETWORK || 'preview',
        backends,
        blockfrostApiKey: process_1.env.BLOCKFROST_API_KEY || '',
        blockfrostCustomBackend: process_1.env.BLOCKFROST_CUSTOM_BACKEND || undefined,
        koiosApiKey: process_1.env.KOIOS_API_KEY || '',
        ogmiosUrl: process_1.env.OGMIOS_URL || '',
        transactionBuilders: ['buildooor'],
        primaryTimeoutMs: Number(process_1.env.PRIMARY_TIMEOUT_MS) || 30000, // || intentional: NaN (missing env var) falls back to default
        fallbackTimeoutMs: Number(process_1.env.FALLBACK_TIMEOUT_MS) || 60000,
        indexTtlMs: Number(process_1.env.INDEX_TTL_MS) || 3600000,
    };
    return await initializeAppContext(config, protocolParams);
}
/**
 * Shutdown the application context (for cleanup in tests)
 * Closes all backend connections to allow process to exit cleanly
 */
async function shutdownAppContext() {
    // Stop the wallet worker first — its in-flight submit must not hit a torn-down client.
    try {
        await (0, wallet_worker_1.stopWalletWorker)();
    }
    catch (err) {
        logger.warn('Wallet worker shutdown failed (continuing):', err);
    }
    // Stop the crawler so its in-flight block writes don't hit a torn-down client.
    try {
        await (0, crawler_1.stopCrawler)();
    }
    catch (err) {
        logger.warn('Crawler shutdown failed (continuing):', err);
    }
    if (appContext) {
        logger.info('Shutting down application context...');
        // Shutdown HSM signer if active
        const hsm = (0, hsm_signer_1.getHsmSigner)();
        if (hsm) {
            hsm.shutdown();
            (0, hsm_signer_1.setHsmSigner)(null);
            logger.debug('HSM signer shutdown');
        }
        await appContext.cardanoClient.shutdown();
        appContext = null;
        (0, network_context_1.setActiveNetwork)(null);
    }
}
/**
 * Load and validate CardanoClientConfig from CDS config or environment variables.
 *
 * When used as a plugin, consumers configure via package.json:
 *   { "cds": { "requires": { "odatano-core": { "network": "preview", "backends": ["blockfrost"], ... }}}}
 *
 * Priority: cds.env.requires["odatano-core"].X > process.env.X > default
 *
 * @returns validated CardanoClientConfig
 * @throws {Error} if any config value is invalid
 */
function loadConfigFromEnv() {
    // Check CDS plugin config first, fall back to env vars
    const cdsConfig = cds_1.default.env?.requires?.['odatano-core'] ?? {};
    const network = (cdsConfig.network || process_1.env.NETWORK || 'preview');
    if (!VALID_NETWORKS.includes(network)) {
        throw new errors_1.ConfigError(`Invalid NETWORK "${cdsConfig.network || process_1.env.NETWORK}". Must be one of: ${VALID_NETWORKS.join(', ')}`);
    }
    const backendStrings = cdsConfig.backends
        || (process_1.env.BACKENDS ? process_1.env.BACKENDS.split(',').map(b => b.trim()) : ['koios']);
    const invalidBackends = backendStrings.filter(b => !VALID_BACKENDS.includes(b));
    if (invalidBackends.length > 0) {
        throw new errors_1.ConfigError(`Invalid BACKENDS: "${invalidBackends.join(', ')}". Must be one of: ${VALID_BACKENDS.join(', ')}`);
    }
    const backends = backendStrings;
    // Buildooor is the sole transaction builder; any legacy txBuilders/TX_BUILDERS config is ignored.
    const txBuilders = ['buildooor'];
    const primaryTimeout = cdsConfig.primaryTimeoutMs ?? process_1.env.PRIMARY_TIMEOUT_MS;
    const fallbackTimeout = cdsConfig.fallbackTimeoutMs ?? process_1.env.FALLBACK_TIMEOUT_MS;
    // `!= null` not truthiness: a CDS-config numeric 0 is falsy, so `timeout && …`
    // skipped the <=0 check and 0 then silently became the default via `Number(0)||default`.
    if (primaryTimeout != null && isNaN(Number(primaryTimeout))) {
        throw new errors_1.ConfigError(`Invalid PRIMARY_TIMEOUT_MS "${primaryTimeout}". Must be a number.`);
    }
    if (primaryTimeout != null && Number(primaryTimeout) <= 0) {
        throw new errors_1.ConfigError(`Invalid PRIMARY_TIMEOUT_MS "${primaryTimeout}". Must be a positive number.`);
    }
    if (fallbackTimeout != null && isNaN(Number(fallbackTimeout))) {
        throw new errors_1.ConfigError(`Invalid FALLBACK_TIMEOUT_MS "${fallbackTimeout}". Must be a number.`);
    }
    if (fallbackTimeout != null && Number(fallbackTimeout) <= 0) {
        throw new errors_1.ConfigError(`Invalid FALLBACK_TIMEOUT_MS "${fallbackTimeout}". Must be a positive number.`);
    }
    const blockfrostApiKey = cdsConfig.blockfrostApiKey || process_1.env.BLOCKFROST_API_KEY || '';
    const blockfrostCustomBackend = cdsConfig.blockfrostCustomBackend || process_1.env.BLOCKFROST_CUSTOM_BACKEND || '';
    if (blockfrostCustomBackend && !/^https?:\/\//i.test(blockfrostCustomBackend)) {
        throw new errors_1.ConfigError(`Invalid BLOCKFROST_CUSTOM_BACKEND "${blockfrostCustomBackend}". Must be an http(s) URL ` +
            `(e.g. http://localhost:3010/api/v0).`);
    }
    const koiosApiKey = cdsConfig.koiosApiKey || process_1.env.KOIOS_API_KEY || '';
    const ogmiosUrl = cdsConfig.ogmiosUrl || process_1.env.OGMIOS_URL || '';
    // Warn about missing API keys for selected backends
    if (backends.includes('blockfrost') && !blockfrostApiKey && !blockfrostCustomBackend) {
        logger.warn('Neither BLOCKFROST_API_KEY nor BLOCKFROST_CUSTOM_BACKEND is set but blockfrost is listed in BACKENDS');
    }
    else if (backends.includes('blockfrost') && blockfrostCustomBackend) {
        logger.info(`Blockfrost will use customBackend: ${blockfrostCustomBackend}`);
    }
    if (backends.includes('ogmios') && !ogmiosUrl) {
        logger.warn('OGMIOS_URL is not set but ogmios is listed in BACKENDS');
    }
    return {
        network,
        backends,
        blockfrostApiKey,
        blockfrostCustomBackend: blockfrostCustomBackend || undefined,
        koiosApiKey,
        ogmiosUrl,
        transactionBuilders: txBuilders,
        primaryTimeoutMs: Number(primaryTimeout) || 30000, // || intentional: NaN (missing config) falls back to default
        fallbackTimeoutMs: Number(fallbackTimeout) || 60000,
        indexTtlMs: Number(cdsConfig.indexTtlMs ?? process_1.env.INDEX_TTL_MS) || 3600000,
    };
}
/**
 * Load HSM configuration from CDS config or environment variables.
 * Returns undefined if HSM is not enabled.
 *
 * Plugin mode: cds.requires.odatano-core.hsm.enabled = true
 * Env mode:    HSM_ENABLED=true
 *
 * @returns HsmConfig or undefined
 */
function loadHsmConfigFromEnv() {
    const cdsConfig = cds_1.default.env?.requires?.['odatano-core'] ?? {};
    const hsmCds = cdsConfig.hsm ?? {};
    const hsmEnabled = hsmCds.enabled === true || process_1.env.HSM_ENABLED === 'true';
    if (!hsmEnabled)
        return undefined;
    const pkcs11Module = hsmCds.pkcs11Module || process_1.env.HSM_PKCS11_MODULE || '';
    if (!pkcs11Module) {
        throw new errors_1.ConfigError('HSM_PKCS11_MODULE is required when HSM is enabled');
    }
    const pin = hsmCds.pin || process_1.env.HSM_PIN || '';
    if (!pin) {
        throw new errors_1.ConfigError('HSM_PIN is required when HSM is enabled');
    }
    const slot = Number(hsmCds.slot ?? process_1.env.HSM_SLOT ?? 0);
    if (!Number.isInteger(slot) || slot < 0) {
        throw new errors_1.ConfigError(`Invalid HSM slot: "${hsmCds.slot ?? process_1.env.HSM_SLOT}" — must be a non-negative integer`);
    }
    // Fail-closed: HSM controls a real signing key. Require an explicit role gate so
    // that an authenticated user cannot drain the HSM-controlled wallet by default.
    const requiresRole = hsmCds.requiresRole || process_1.env.HSM_REQUIRES_ROLE || '';
    if (!requiresRole) {
        throw new errors_1.ConfigError('HSM_REQUIRES_ROLE (or cds.requires.odatano-core.hsm.requiresRole) is required when HSM is enabled — set it to the XSUAA scope name allowed to invoke HSM signing actions');
    }
    return {
        enabled: true,
        pkcs11Module,
        slot,
        pin,
        keyId: hsmCds.keyId || process_1.env.HSM_KEY_ID,
        keyLabel: hsmCds.keyLabel || process_1.env.HSM_KEY_LABEL,
        requiresRole,
    };
}
/**
 * Load the chain-crawler configuration from CDS config or environment variables.
 * Returns { enabled:false } when the crawler is not switched on (the default), so
 * existing deployments are unaffected.
 *
 * Plugin mode: cds.requires.odatano-core.crawler.{enabled,startSlot,startBlockHash,...}
 * Env mode:    CRAWLER_ENABLED / CRAWLER_START_SLOT / CRAWLER_START_HASH / ...
 */
function loadCrawlerConfigFromEnv() {
    const cdsConfig = cds_1.default.env?.requires?.['odatano-core'] ?? {};
    const c = cdsConfig.crawler ?? {};
    // A CDS value, including explicit `false`, wins over the environment.
    const enabledRaw = c.enabled !== undefined ? c.enabled : process_1.env.CRAWLER_ENABLED;
    let enabled = false;
    if (enabledRaw === true || enabledRaw === 'true') {
        enabled = true;
    }
    else if (enabledRaw !== undefined && enabledRaw !== false && enabledRaw !== 'false') {
        throw new errors_1.ConfigError(`Invalid CRAWLER_ENABLED "${String(enabledRaw)}". Must be true or false.`);
    }
    const startSlot = crawlerInteger(c.startSlot ?? process_1.env.CRAWLER_START_SLOT, 'CRAWLER_START_SLOT', 0, Number.MAX_SAFE_INTEGER);
    const startHeight = crawlerInteger(c.startHeight ?? process_1.env.CRAWLER_START_HEIGHT, 'CRAWLER_START_HEIGHT', 0, Number.MAX_SAFE_INTEGER);
    const startBlockHashRaw = c.startBlockHash ?? process_1.env.CRAWLER_START_HASH;
    if (startBlockHashRaw != null && (typeof startBlockHashRaw !== 'string' || !/^[0-9a-f]{64}$/i.test(startBlockHashRaw.trim()))) {
        throw new errors_1.ConfigError('Invalid CRAWLER_START_HASH. Must be exactly 64 hexadecimal characters.');
    }
    const startBlockHash = startBlockHashRaw?.trim() || undefined;
    const source = (c.source ?? process_1.env.CRAWLER_SOURCE ?? 'auto');
    const batchSize = crawlerInteger(c.batchSize ?? process_1.env.CRAWLER_BATCH_SIZE, 'CRAWLER_BATCH_SIZE', CRAWLER_LIMITS.batchSize.min, CRAWLER_LIMITS.batchSize.max, 20);
    const confirmationDepth = crawlerInteger(c.confirmationDepth ?? process_1.env.CRAWLER_CONFIRMATION_DEPTH, 'CRAWLER_CONFIRMATION_DEPTH', CRAWLER_LIMITS.confirmationDepth.min, CRAWLER_LIMITS.confirmationDepth.max, 3);
    const pollIntervalMs = crawlerInteger(c.pollIntervalMs ?? process_1.env.CRAWLER_POLL_INTERVAL_MS, 'CRAWLER_POLL_INTERVAL_MS', CRAWLER_LIMITS.pollIntervalMs.min, CRAWLER_LIMITS.pollIntervalMs.max, 20_000);
    if (enabled && (startSlot == null || Number.isNaN(startSlot) || !startBlockHash)) {
        throw new errors_1.ConfigError('Crawler is enabled but no start block is configured — set crawler.startSlot + crawler.startBlockHash ' +
            '(or CRAWLER_START_SLOT + CRAWLER_START_HASH).');
    }
    if (!['ogmios', 'pagination', 'auto'].includes(source)) {
        throw new errors_1.ConfigError(`Invalid CRAWLER_SOURCE "${source}". Must be one of: ogmios, pagination, auto.`);
    }
    return { enabled, startSlot, startBlockHash, startHeight, source, batchSize, confirmationDepth, pollIntervalMs };
}
/**
 * Start the chain crawler if it is enabled and the app context is ready. Never throws
 * (crawler failure must not affect request serving) — errors are logged. Idempotent:
 * startCrawler() is a no-op when one is already running.
 */
async function startCrawlerIfConfigured() {
    if (process_1.env.SKIP_AUTO_INIT === 'true' || !appContext)
        return;
    let config;
    try {
        config = loadCrawlerConfigFromEnv();
    }
    catch (err) {
        logger.error('Invalid crawler configuration — crawler not started:', err);
        return;
    }
    if (!config.enabled)
        return;
    try {
        await (0, crawler_1.startCrawler)({
            client: appContext.cardanoClient,
            indexer: appContext.cardanoIndexer,
            network: appContext.cardanoClient.network,
            config,
        });
        logger.info(`Chain crawler started (source=${config.source}, start=${config.startBlockHash})`);
    }
    catch (err) {
        logger.error('Failed to start chain crawler (non-fatal):', err);
    }
}
const WALLET_WORKER_LIMITS = {
    maxConcurrentWallets: { min: 1, max: 64 },
    confirmationDepth: { min: 1, max: 2160 },
    confirmationTimeoutMs: { min: 30_000, max: 86_400_000 },
    pollIntervalMs: { min: 500, max: 3_600_000 },
    maxAttempts: { min: 1, max: 10 },
};
/**
 * Load the wallet-worker configuration from CDS config or environment variables.
 * Returns { enabled:false } when the worker is not switched on (the default).
 *
 * Plugin mode: cds.requires.odatano-core.walletWorker.{enabled,wallets,...}
 * Env mode:    WALLET_WORKER_ENABLED / WALLET_WORKER_WALLETS (JSON) / ...
 */
function loadWalletWorkerConfigFromEnv() {
    const cdsConfig = cds_1.default.env?.requires?.['odatano-core'] ?? {};
    const w = cdsConfig.walletWorker ?? {};
    const enabledRaw = w.enabled !== undefined ? w.enabled : process_1.env.WALLET_WORKER_ENABLED;
    let enabled = false;
    if (enabledRaw === true || enabledRaw === 'true') {
        enabled = true;
    }
    else if (enabledRaw !== undefined && enabledRaw !== false && enabledRaw !== 'false') {
        throw new errors_1.ConfigError(`Invalid WALLET_WORKER_ENABLED "${String(enabledRaw)}". Must be true or false.`);
    }
    let walletsRaw = w.wallets ?? undefined;
    if (walletsRaw === undefined && process_1.env.WALLET_WORKER_WALLETS) {
        try {
            walletsRaw = JSON.parse(process_1.env.WALLET_WORKER_WALLETS);
        }
        catch {
            throw new errors_1.ConfigError('Invalid WALLET_WORKER_WALLETS — must be a JSON array of { walletId, signerType, keyEnv? }.');
        }
    }
    const wallets = [];
    if (walletsRaw !== undefined) {
        if (!Array.isArray(walletsRaw)) {
            throw new errors_1.ConfigError('Invalid walletWorker.wallets — must be an array of { walletId, signerType, keyEnv? }.');
        }
        for (const entry of walletsRaw) {
            const walletId = typeof entry?.walletId === 'string' ? entry.walletId.trim() : '';
            const signerType = entry?.signerType;
            if (!walletId || (signerType !== 'hsm' && signerType !== 'software')) {
                throw new errors_1.ConfigError(`Invalid wallet entry ${JSON.stringify(entry)} — walletId and signerType (hsm|software) are required.`);
            }
            if (signerType === 'software' && (typeof entry.keyEnv !== 'string' || !entry.keyEnv.trim())) {
                throw new errors_1.ConfigError(`Wallet "${walletId}" is signerType=software but has no keyEnv (name of the env var holding the signing key).`);
            }
            if (wallets.some((existing) => existing.walletId === walletId)) {
                throw new errors_1.ConfigError(`Duplicate walletId "${walletId}" in walletWorker.wallets.`);
            }
            wallets.push({ walletId, signerType, keyEnv: entry.keyEnv });
        }
    }
    const maxConcurrentWallets = crawlerInteger(w.maxConcurrentWallets ?? process_1.env.WALLET_WORKER_MAX_CONCURRENT, 'WALLET_WORKER_MAX_CONCURRENT', WALLET_WORKER_LIMITS.maxConcurrentWallets.min, WALLET_WORKER_LIMITS.maxConcurrentWallets.max, 4);
    const confirmationDepth = crawlerInteger(w.confirmationDepth ?? process_1.env.WALLET_WORKER_CONFIRMATION_DEPTH, 'WALLET_WORKER_CONFIRMATION_DEPTH', WALLET_WORKER_LIMITS.confirmationDepth.min, WALLET_WORKER_LIMITS.confirmationDepth.max, 3);
    const confirmationTimeoutMs = crawlerInteger(w.confirmationTimeoutMs ?? process_1.env.WALLET_WORKER_CONFIRMATION_TIMEOUT_MS, 'WALLET_WORKER_CONFIRMATION_TIMEOUT_MS', WALLET_WORKER_LIMITS.confirmationTimeoutMs.min, WALLET_WORKER_LIMITS.confirmationTimeoutMs.max, 600_000);
    const pollIntervalMs = crawlerInteger(w.pollIntervalMs ?? process_1.env.WALLET_WORKER_POLL_INTERVAL_MS, 'WALLET_WORKER_POLL_INTERVAL_MS', WALLET_WORKER_LIMITS.pollIntervalMs.min, WALLET_WORKER_LIMITS.pollIntervalMs.max, 2_000);
    const defaultMaxAttempts = crawlerInteger(w.defaultMaxAttempts ?? process_1.env.WALLET_WORKER_MAX_ATTEMPTS, 'WALLET_WORKER_MAX_ATTEMPTS', WALLET_WORKER_LIMITS.maxAttempts.min, WALLET_WORKER_LIMITS.maxAttempts.max, 3);
    const resubmitRaw = w.resubmitOnRollback !== undefined ? w.resubmitOnRollback : process_1.env.WALLET_WORKER_RESUBMIT_ON_ROLLBACK;
    let resubmitOnRollback = true;
    if (resubmitRaw === false || resubmitRaw === 'false') {
        resubmitOnRollback = false;
    }
    else if (resubmitRaw !== undefined && resubmitRaw !== true && resubmitRaw !== 'true') {
        throw new errors_1.ConfigError(`Invalid WALLET_WORKER_RESUBMIT_ON_ROLLBACK "${String(resubmitRaw)}". Must be true or false.`);
    }
    if (enabled && wallets.length === 0) {
        throw new errors_1.ConfigError('Wallet worker is enabled but no wallets are configured — set walletWorker.wallets (or WALLET_WORKER_WALLETS).');
    }
    return {
        enabled,
        wallets,
        maxConcurrentWallets,
        confirmationDepth,
        confirmationTimeoutMs,
        pollIntervalMs,
        defaultMaxAttempts,
        resubmitOnRollback,
    };
}
/**
 * Start the wallet worker if it is enabled and the app context is ready. Never
 * throws (worker failure must not affect request serving) — errors are logged.
 * Idempotent: startWalletWorker() is a no-op when one is already running.
 */
async function startWalletWorkerIfConfigured() {
    if (process_1.env.SKIP_AUTO_INIT === 'true' || !appContext)
        return;
    let config;
    try {
        config = loadWalletWorkerConfigFromEnv();
    }
    catch (err) {
        logger.error('Invalid wallet-worker configuration — worker not started:', err);
        return;
    }
    if (!config.enabled)
        return;
    try {
        await (0, wallet_worker_1.startWalletWorker)({
            client: appContext.cardanoClient,
            indexer: appContext.cardanoIndexer,
            network: appContext.cardanoClient.network,
            config,
        });
        logger.info(`Wallet worker started (wallets=${config.wallets.map((w2) => w2.walletId).join(',')})`);
    }
    catch (err) {
        logger.error('Failed to start wallet worker (non-fatal):', err);
    }
}
/**
 * Re-drive deferred submissions that were claimed (status 'submitting' with
 * persisted signedTxCbor) but whose detached submit never ran because the
 * process died first (KNOWN_ISSUES #11, Layer 2). Idempotent — an already
 * submitted tx finalizes via the TransactionAlreadySubmittedError path.
 * Non-fatal, mirrors startCrawlerIfConfigured/startWalletWorkerIfConfigured.
 */
async function redriveInterruptedSubmissionsIfConfigured() {
    if (process_1.env.SKIP_AUTO_INIT === 'true' || !appContext)
        return;
    try {
        const { redriveInterruptedSubmissions } = require('./blockchain/signing/submission-finalizer');
        const attempted = await redriveInterruptedSubmissions();
        if (attempted > 0)
            logger.info(`Re-drove ${attempted} interrupted deferred submission(s)`);
    }
    catch (err) {
        logger.error('Failed to re-drive interrupted submissions (non-fatal):', err);
    }
}
// Bootstrap hook - runs when CAP server has loaded all services
cds_1.default.on('served', async () => {
    // Skip if already initialized by plugin (src/plugin.ts runs first)
    if (appContext)
        return;
    // Skip auto-initialization when SKIP_AUTO_INIT is set (e.g., for tests with mocked backends)
    if (process_1.env.SKIP_AUTO_INIT === 'true') {
        logger.info('Skipping auto-initialization (SKIP_AUTO_INIT=true)');
        return;
    }
    // NOTE: config loading is INSIDE the try — loadConfigFromEnv/loadHsmConfigFromEnv
    // throw ConfigError synchronously (missing HSM_PIN, bad slot, no requiresRole…).
    // Outside the try that would crash the host app's bootstrap in plugin mode,
    // violating the plugin contract ("never throw on failure").
    let config;
    try {
        config = loadConfigFromEnv();
        const hsmConfig = loadHsmConfigFromEnv();
        hsmConfigInstance = hsmConfig;
        appContext = await initializeAppContext(config, undefined, hsmConfig);
        bootstrapError = null;
        logger.info('CAP server bootstrap complete');
    }
    catch (err) {
        // Don't throw - initialization failure shouldn't crash the host app (plugin contract).
        // Capture the cause so getAppContext() can surface a structured 503 with diagnostics
        // instead of the raw "Application not initialized" Error landing as a generic 500.
        bootstrapError = err instanceof Error ? err : new Error(String(err));
        // Write to stderr directly so the cause stays visible even when test runners
        // suppress console.error (vitest.setup.ts in this repo silences it).
        const where = config ? `backends={${config.backends.join(',')}} network=${config.network}` : 'config load';
        const msg = err instanceof Error ? `${err.name}: ${err.message}\n${err.stack ?? ''}` : String(err);
        process.stderr.write(`[ODATANO] Failed to initialize blockchain components — ${where}\n${msg}\n`);
        logger.error('Failed to initialize blockchain components:', err);
    }
    // Start the pre-sync crawler if configured (standalone mode). Non-fatal.
    await startCrawlerIfConfigured();
    // Start the wallet worker if configured (standalone mode). Non-fatal.
    await startWalletWorkerIfConfigured();
    // Re-drive deferred submissions interrupted by a restart (standalone mode). Non-fatal.
    await redriveInterruptedSubmissionsIfConfigured();
});
// Shutdown hook - runs when CAP server is shutting down (e.g., cds.shutdown() in tests)
cds_1.default.on('shutdown', async () => {
    await shutdownAppContext();
});
//# sourceMappingURL=server.js.map