// This is an automatically generated file. Please do not change its contents manually!
import * as __ from './../_';
import * as _ from './..';
import * as _odatano_cardano from './../odatano/cardano';

/**
* Cardano Sign Service
* 
* Handles the external signing workflow for Cardano transactions, including:
* - Creating signing requests with transaction details and signing instructions
* - Verifying signatures of signed transactions and storing verification results
* - Submitting verified transactions to the blockchain and tracking submission status
* - Providing actions for signing with a Hardware Security Module (HSM) and retrieving HSM status
* 
* Security note: see CardanoODataService (cardano-service.cds) for the rationale
* on service-level auth without per-resource ownership enforcement.
*/
export default class {
  static readonly VerifySignature: typeof VerifySignature;
  static readonly SubmitVerifiedTransaction: typeof SubmitVerifiedTransaction;
  static readonly VerifyDataSignature: typeof VerifyDataSignature;
  static readonly CreateSigningRequest: typeof CreateSigningRequest;
  static readonly GetSigningRequest: typeof GetSigningRequest;
  static readonly GetSigningRequestsByAddress: typeof GetSigningRequestsByAddress;
  static readonly SignWithHsm: typeof SignWithHsm;
  static readonly SignAndSubmitWithHsm: typeof SignAndSubmitWithHsm;
  static readonly GetHsmStatus: typeof GetHsmStatus;
}

// entity 'SignatureVerification'
export declare function _SignatureVerificationAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    signingRequest?: __.Association.to<SigningRequest> | null
    signingRequest_id?: string | null
    signedTxCbor?: string | null
    isValid?: boolean | null
    txBodyHash?: _.Blake2b256 | null
    witnessCount?: number | null
    signerKeyHashes?: string | null
    errorMessage?: string | null
    warnings?: string | null
    verifiedAt?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<SignatureVerification>;
    readonly elements: __.ElementsOf<SignatureVerification>;
    readonly actions: globalThis.Record<never, never>;
};
export class SignatureVerification extends _SignatureVerificationAspect(__.Entity) {
}
export class SignatureVerifications extends Array<SignatureVerification> {
  $count?: number
}

// entity 'AddressSigningRequest'
export declare function _AddressSigningRequestAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    signingRequest?: __.Key<__.Association.to<SigningRequest>>
    signingRequest_id?: __.Key<string>
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressSigningRequest>;
    readonly elements: __.ElementsOf<AddressSigningRequest>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressSigningRequest extends _AddressSigningRequestAspect(__.Entity) {
}
export class AddressSigningRequests extends Array<AddressSigningRequest> {
  $count?: number
}

// entity 'TransactionBuild'
export declare function _TransactionBuildAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    id?: __.Key<string>
    network?: string | null
    builderEngine?: string | null
    senderAddress?: _.Bech32 | null
    changeAddress?: _.Bech32 | null
    unsignedTxCbor?: string | null
    txBodyHash?: _.Blake2b256 | null
    fee?: _.Lovelace | null
    size?: number | null
    createdAt?: number | null
    inputs?: __.Composition.of.many<TransactionBuildInputs>
    outputs?: __.Composition.of.many<TransactionBuildOutputs>
    submission?: __.Association.to<TransactionSubmission> | null
    hasInputs?: boolean | null
    hasOutputs?: boolean | null
    wasSubmitted?: boolean | null
    scriptHash?: string | null
    mintScriptHash?: string | null
    fingerprint?: string | null
    scriptAddress?: string | null
    forcedInputsUsed?: number | null
    referenceInputsUsed?: number | null
    collateralAvailable?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuild>;
    readonly elements: __.ElementsOf<TransactionBuild>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuild extends _TransactionBuildAspect(__.Entity) {
}
export class TransactionBuilds extends Array<TransactionBuild> {
  $count?: number
}

// entity 'TransactionSubmission'
export declare function _TransactionSubmissionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    build?: __.Association.to<TransactionBuild> | null
    build_id?: string | null
    signedTxCbor?: string | null
    txHash?: _.Blake2b256 | null
    submittedAt?: number | null
    status?: _.SubmissionStatus | null
    errorCode?: string | null
    errorMessage?: string | null
    retryCount?: number | null
    errors?: __.Composition.of.many<TransactionSubmissionErrors>
    hasErrors?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionSubmission>;
    readonly elements: __.ElementsOf<TransactionSubmission>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionSubmission extends _TransactionSubmissionAspect(__.Entity) {
}
export class TransactionSubmissions extends Array<TransactionSubmission> {
  $count?: number
}

// entity 'SigningRequest'
export declare function _SigningRequestAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    build?: __.Association.to<TransactionBuild> | null
    build_id?: string | null
    txBodyHash?: _.Blake2b256 | null
    unsignedTxCbor?: string | null
    network?: string | null
    status?: _.SigningStatus | null
    createdAt?: __.CdsTimestamp | null
    expiresAt?: __.CdsTimestamp | null
    signedAt?: __.CdsTimestamp | null
    submittedAt?: __.CdsTimestamp | null
    cardanoCliCommand?: string | null
    cip30TxCbor?: string | null
    signedTxCbor?: string | null
    signerType?: string | null
    signerInfo?: string | null
    hsmKeyId?: string | null
    verifications?: __.Composition.of.many<SignatureVerifications>
    submission?: __.Association.to<TransactionSubmission> | null
    submission_id?: string | null
    errorMessage?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<SigningRequest>;
    readonly elements: __.ElementsOf<SigningRequest>;
    readonly actions: globalThis.Record<never, never>;
};
export class SigningRequest extends _SigningRequestAspect(__.Entity) {
}
export class SigningRequests extends Array<SigningRequest> {
  $count?: number
}

// entity 'Address'
export declare function _AddressAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<_.Bech32>
    stakeAddress?: _.Bech32 | null
    type?: string | null
    isScript?: boolean | null
    totalLovelace?: _.Lovelace | null
    utxoCount?: number | null
    transactions?: __.Composition.of.many<AddressTransactions>
    assets?: __.Composition.of.many<AddressAssets>
    utxos?: __.Composition.of.many<AddressUTxOs>
    hasTransactions?: boolean | null
    hasAssets?: boolean | null
    hasUTxOs?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Address>;
    readonly elements: __.ElementsOf<Address>;
    readonly actions: globalThis.Record<never, never>;
};
export class Address extends _AddressAspect(__.Entity) {
}
export class Addresses extends Array<Address> {
  $count?: number
}

// entity 'TransactionBuildInput'
export declare function _TransactionBuildInputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    build?: __.Key<__.Association.to<TransactionBuild>>
    build_id?: __.Key<string>
    inputIndex?: __.Key<number>
    txHash?: _.Blake2b256 | null
    outputIndex?: number | null
    address?: _.Bech32 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<TransactionBuildInputAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildInput>;
    readonly elements: __.ElementsOf<TransactionBuildInput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildInput extends _TransactionBuildInputAspect(__.Entity) {
}
export class TransactionBuildInputs extends Array<TransactionBuildInput> {
  $count?: number
}

// entity 'TransactionBuildOutput'
export declare function _TransactionBuildOutputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    build?: __.Key<__.Association.to<TransactionBuild>>
    build_id?: __.Key<string>
    outputIndex?: __.Key<number>
    address?: _.Bech32 | null
    lovelace?: _.Lovelace | null
    isChange?: boolean | null
    assets?: __.Composition.of.many<TransactionBuildOutputAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildOutput>;
    readonly elements: __.ElementsOf<TransactionBuildOutput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildOutput extends _TransactionBuildOutputAspect(__.Entity) {
}
export class TransactionBuildOutputs extends Array<TransactionBuildOutput> {
  $count?: number
}

// entity 'TransactionSubmissionError'
export declare function _TransactionSubmissionErrorAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    submission?: __.Association.to<TransactionSubmission> | null
    submission_id?: string | null
    occurredAt?: number | null
    errorType?: string | null
    errorCode?: string | null
    errorMessage?: string | null
    errorDetails?: string | null
    isRecoverable?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionSubmissionError>;
    readonly elements: __.ElementsOf<TransactionSubmissionError>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionSubmissionError extends _TransactionSubmissionErrorAspect(__.Entity) {
}
export class TransactionSubmissionErrors extends Array<TransactionSubmissionError> {
  $count?: number
}

// entity 'AddressTransaction'
export declare function _AddressTransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    tx?: __.Key<__.Association.to<_odatano_cardano.Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    netAmount?: (number | string) | null
    blockTime?: number | null
    netAssets?: string | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressTransaction>;
    readonly elements: __.ElementsOf<AddressTransaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressTransaction extends _AddressTransactionAspect(__.Entity) {
}
export class AddressTransactions extends Array<AddressTransaction> {
  $count?: number
}

// entity 'AddressAsset'
export declare function _AddressAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressAsset>;
    readonly elements: __.ElementsOf<AddressAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressAsset extends _AddressAssetAspect(__.Entity) {
}
export class AddressAssets extends Array<AddressAsset> {
  $count?: number
}

// entity 'AddressUTxO'
export declare function _AddressUTxOAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    hash?: __.Key<_.Blake2b256>
    index?: __.Key<number>
    blockHash?: _.Blake2b256 | null
    utxodata_dataHash?: _.Blake2b256 | null
    utxodata_inlineDatum?: string | null
    utxodata_referenceScriptHash?: _.Blake2b256 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<UTxOAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressUTxO>;
    readonly elements: __.ElementsOf<AddressUTxO>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressUTxO extends _AddressUTxOAspect(__.Entity) {
}
export class AddressUTxOs extends Array<AddressUTxO> {
  $count?: number
}

// entity 'TransactionBuildInputAsset'
export declare function _TransactionBuildInputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    input?: __.Key<__.Association.to<TransactionBuildInput>>
    input_inputIndex?: __.Key<number>
    input_build_id?: __.Key<string>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildInputAsset>;
    readonly elements: __.ElementsOf<TransactionBuildInputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildInputAsset extends _TransactionBuildInputAssetAspect(__.Entity) {
}
export class TransactionBuildInputAssets extends Array<TransactionBuildInputAsset> {
  $count?: number
}

// entity 'TransactionBuildOutputAsset'
export declare function _TransactionBuildOutputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    output?: __.Key<__.Association.to<TransactionBuildOutput>>
    output_outputIndex?: __.Key<number>
    output_build_id?: __.Key<string>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildOutputAsset>;
    readonly elements: __.ElementsOf<TransactionBuildOutputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildOutputAsset extends _TransactionBuildOutputAssetAspect(__.Entity) {
}
export class TransactionBuildOutputAssets extends Array<TransactionBuildOutputAsset> {
  $count?: number
}

// entity 'UTxOAsset'
export declare function _UTxOAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    utxo?: __.Key<__.Association.to<AddressUTxO>>
    utxo_hash?: __.Key<_.Blake2b256>
    utxo_index?: __.Key<number>
    utxo_address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<UTxOAsset>;
    readonly elements: __.ElementsOf<UTxOAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class UTxOAsset extends _UTxOAssetAspect(__.Entity) {
}
export class UTxOAssets extends Array<UTxOAsset> {
  $count?: number
}


export declare const VerifySignature:  {
  // positional
  (signingRequestId: string | null, signedTxCbor: string | null, signerType: string | null, signerInfo: string | null, address: _.Bech32 | null): globalThis.Promise<SignatureVerification | null> | SignatureVerification | null
  // named
  ({signingRequestId, signedTxCbor, signerType, signerInfo, address}: {signingRequestId?: string | null, signedTxCbor?: string | null, signerType?: string | null, signerInfo?: string | null, address?: _.Bech32 | null}): globalThis.Promise<SignatureVerification | null> | SignatureVerification | null
  // metadata (do not use)
  __parameters: {signingRequestId?: string | null, signedTxCbor?: string | null, signerType?: string | null, signerInfo?: string | null, address?: _.Bech32 | null}, __returns: globalThis.Promise<SignatureVerification | null> | SignatureVerification | null, __self: never
  kind: 'action'
}

export declare const SubmitVerifiedTransaction:  {
  // positional
  (signingRequestId: string | null, signedTxCbor: string | null, signerType: string | null, signerInfo: string | null, address: _.Bech32 | null, deferSubmit: boolean | null): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // named
  ({signingRequestId, signedTxCbor, signerType, signerInfo, address, deferSubmit}: {signingRequestId?: string | null, signedTxCbor?: string | null, signerType?: string | null, signerInfo?: string | null, address?: _.Bech32 | null, deferSubmit?: boolean | null}): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // metadata (do not use)
  __parameters: {signingRequestId?: string | null, signedTxCbor?: string | null, signerType?: string | null, signerInfo?: string | null, address?: _.Bech32 | null, deferSubmit?: boolean | null}, __returns: globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null, __self: never
  kind: 'action'
}

export declare const VerifyDataSignature:  {
  // positional
  (address: _.Bech32 | null, coseSignature: string | null, coseKey: string | null, expectedPayload: string | null): globalThis.Promise<{   valid?: boolean | null,   reason?: string | null,   signedPayload?: string | null,   signerVkh?: string | null, } | null> | {   valid?: boolean | null,   reason?: string | null,   signedPayload?: string | null,   signerVkh?: string | null, } | null
  // named
  ({address, coseSignature, coseKey, expectedPayload}: {address?: _.Bech32 | null, coseSignature?: string | null, coseKey?: string | null, expectedPayload?: string | null}): globalThis.Promise<{   valid?: boolean | null,   reason?: string | null,   signedPayload?: string | null,   signerVkh?: string | null, } | null> | {   valid?: boolean | null,   reason?: string | null,   signedPayload?: string | null,   signerVkh?: string | null, } | null
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null, coseSignature?: string | null, coseKey?: string | null, expectedPayload?: string | null}, __returns: globalThis.Promise<{   valid?: boolean | null,   reason?: string | null,   signedPayload?: string | null,   signerVkh?: string | null, } | null> | {   valid?: boolean | null,   reason?: string | null,   signedPayload?: string | null,   signerVkh?: string | null, } | null, __self: never
  kind: 'action'
}

export declare const CreateSigningRequest:  {
  // positional
  (buildId: string | null, message: string | null): globalThis.Promise<SigningRequest | null> | SigningRequest | null
  // named
  ({buildId, message}: {buildId?: string | null, message?: string | null}): globalThis.Promise<SigningRequest | null> | SigningRequest | null
  // metadata (do not use)
  __parameters: {buildId?: string | null, message?: string | null}, __returns: globalThis.Promise<SigningRequest | null> | SigningRequest | null, __self: never
  kind: 'action'
}

export declare const GetSigningRequest:  {
  // positional
  (signingRequestId: string | null): globalThis.Promise<SigningRequest | null> | SigningRequest | null
  // named
  ({signingRequestId}: {signingRequestId?: string | null}): globalThis.Promise<SigningRequest | null> | SigningRequest | null
  // metadata (do not use)
  __parameters: {signingRequestId?: string | null}, __returns: globalThis.Promise<SigningRequest | null> | SigningRequest | null, __self: never
  kind: 'action'
}

export declare const GetSigningRequestsByAddress:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<Array<AddressSigningRequest>> | Array<AddressSigningRequest>
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<Array<AddressSigningRequest>> | Array<AddressSigningRequest>
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<Array<AddressSigningRequest>> | Array<AddressSigningRequest>, __self: never
  kind: 'action'
}

export declare const SignWithHsm:  {
  // positional
  (buildId: string | null, address: _.Bech32 | null): globalThis.Promise<SigningRequest | null> | SigningRequest | null
  // named
  ({buildId, address}: {buildId?: string | null, address?: _.Bech32 | null}): globalThis.Promise<SigningRequest | null> | SigningRequest | null
  // metadata (do not use)
  __parameters: {buildId?: string | null, address?: _.Bech32 | null}, __returns: globalThis.Promise<SigningRequest | null> | SigningRequest | null, __self: never
  kind: 'action'
}

export declare const SignAndSubmitWithHsm:  {
  // positional
  (buildId: string | null, address: _.Bech32 | null, deferSubmit: boolean | null): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // named
  ({buildId, address, deferSubmit}: {buildId?: string | null, address?: _.Bech32 | null, deferSubmit?: boolean | null}): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // metadata (do not use)
  __parameters: {buildId?: string | null, address?: _.Bech32 | null, deferSubmit?: boolean | null}, __returns: globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null, __self: never
  kind: 'action'
}

export declare const GetHsmStatus:  {
  // positional
  (): globalThis.Promise<{   connected?: boolean | null,   keyId?: string | null,   keyLabel?: string | null,   publicKeyHash?: string | null,   cardanoAddress?: string | null, } | null> | {   connected?: boolean | null,   keyId?: string | null,   keyLabel?: string | null,   publicKeyHash?: string | null,   cardanoAddress?: string | null, } | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<{   connected?: boolean | null,   keyId?: string | null,   keyLabel?: string | null,   publicKeyHash?: string | null,   cardanoAddress?: string | null, } | null> | {   connected?: boolean | null,   keyId?: string | null,   keyLabel?: string | null,   publicKeyHash?: string | null,   cardanoAddress?: string | null, } | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<{   connected?: boolean | null,   keyId?: string | null,   keyLabel?: string | null,   publicKeyHash?: string | null,   cardanoAddress?: string | null, } | null> | {   connected?: boolean | null,   keyId?: string | null,   keyLabel?: string | null,   publicKeyHash?: string | null,   cardanoAddress?: string | null, } | null, __self: never
  kind: 'action'
}