// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./../_')
// service
const CardanoSignService = { name: 'CardanoSignService' }
module.exports = CardanoSignService
module.exports.CardanoSignService = CardanoSignService
// SignatureVerifications
module.exports.SignatureVerification = createEntityProxy(['CardanoSignService', 'SignatureVerifications'], { target: { is_singular: true } })
module.exports.SignatureVerifications = createEntityProxy(['CardanoSignService', 'SignatureVerifications'], { target: { is_singular: false }})
// AddressSigningRequests
module.exports.AddressSigningRequest = createEntityProxy(['CardanoSignService', 'AddressSigningRequests'], { target: { is_singular: true } })
module.exports.AddressSigningRequests = createEntityProxy(['CardanoSignService', 'AddressSigningRequests'], { target: { is_singular: false }})
// TransactionBuilds
module.exports.TransactionBuild = createEntityProxy(['CardanoSignService', 'TransactionBuilds'], { target: { is_singular: true } })
module.exports.TransactionBuilds = createEntityProxy(['CardanoSignService', 'TransactionBuilds'], { target: { is_singular: false }})
// TransactionSubmissions
module.exports.TransactionSubmission = createEntityProxy(['CardanoSignService', 'TransactionSubmissions'], { target: { is_singular: true } })
module.exports.TransactionSubmissions = createEntityProxy(['CardanoSignService', 'TransactionSubmissions'], { target: { is_singular: false }})
// SigningRequests
module.exports.SigningRequest = createEntityProxy(['CardanoSignService', 'SigningRequests'], { target: { is_singular: true } })
module.exports.SigningRequests = createEntityProxy(['CardanoSignService', 'SigningRequests'], { target: { is_singular: false }})
// Addresses
module.exports.Address = createEntityProxy(['CardanoSignService', 'Addresses'], { target: { is_singular: true } })
module.exports.Addresses = createEntityProxy(['CardanoSignService', 'Addresses'], { target: { is_singular: false }})
// TransactionBuildInputs
module.exports.TransactionBuildInput = createEntityProxy(['CardanoSignService', 'TransactionBuildInputs'], { target: { is_singular: true } })
module.exports.TransactionBuildInputs = createEntityProxy(['CardanoSignService', 'TransactionBuildInputs'], { target: { is_singular: false }})
// TransactionBuildOutputs
module.exports.TransactionBuildOutput = createEntityProxy(['CardanoSignService', 'TransactionBuildOutputs'], { target: { is_singular: true } })
module.exports.TransactionBuildOutputs = createEntityProxy(['CardanoSignService', 'TransactionBuildOutputs'], { target: { is_singular: false }})
// TransactionSubmissionErrors
module.exports.TransactionSubmissionError = createEntityProxy(['CardanoSignService', 'TransactionSubmissionErrors'], { target: { is_singular: true } })
module.exports.TransactionSubmissionErrors = createEntityProxy(['CardanoSignService', 'TransactionSubmissionErrors'], { target: { is_singular: false }})
// AddressTransactions
module.exports.AddressTransaction = createEntityProxy(['CardanoSignService', 'AddressTransactions'], { target: { is_singular: true } })
module.exports.AddressTransactions = createEntityProxy(['CardanoSignService', 'AddressTransactions'], { target: { is_singular: false }})
// AddressAssets
module.exports.AddressAsset = createEntityProxy(['CardanoSignService', 'AddressAssets'], { target: { is_singular: true } })
module.exports.AddressAssets = createEntityProxy(['CardanoSignService', 'AddressAssets'], { target: { is_singular: false }})
// AddressUTxOs
module.exports.AddressUTxO = createEntityProxy(['CardanoSignService', 'AddressUTxOs'], { target: { is_singular: true } })
module.exports.AddressUTxOs = createEntityProxy(['CardanoSignService', 'AddressUTxOs'], { target: { is_singular: false }})
// TransactionBuildInputAssets
module.exports.TransactionBuildInputAsset = createEntityProxy(['CardanoSignService', 'TransactionBuildInputAssets'], { target: { is_singular: true } })
module.exports.TransactionBuildInputAssets = createEntityProxy(['CardanoSignService', 'TransactionBuildInputAssets'], { target: { is_singular: false }})
// TransactionBuildOutputAssets
module.exports.TransactionBuildOutputAsset = createEntityProxy(['CardanoSignService', 'TransactionBuildOutputAssets'], { target: { is_singular: true } })
module.exports.TransactionBuildOutputAssets = createEntityProxy(['CardanoSignService', 'TransactionBuildOutputAssets'], { target: { is_singular: false }})
// UTxOAssets
module.exports.UTxOAsset = createEntityProxy(['CardanoSignService', 'UTxOAssets'], { target: { is_singular: true } })
module.exports.UTxOAssets = createEntityProxy(['CardanoSignService', 'UTxOAssets'], { target: { is_singular: false }})
// events
// actions
module.exports.VerifySignature = 'VerifySignature'
module.exports.SubmitVerifiedTransaction = 'SubmitVerifiedTransaction'
module.exports.VerifyDataSignature = 'VerifyDataSignature'
module.exports.CreateSigningRequest = 'CreateSigningRequest'
module.exports.GetSigningRequest = 'GetSigningRequest'
module.exports.GetSigningRequestsByAddress = 'GetSigningRequestsByAddress'
module.exports.SignWithHsm = 'SignWithHsm'
module.exports.SignAndSubmitWithHsm = 'SignAndSubmitWithHsm'
module.exports.GetHsmStatus = 'GetHsmStatus'
// enums
