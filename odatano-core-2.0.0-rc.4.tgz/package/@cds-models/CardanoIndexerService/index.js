// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./../_')
// service
const CardanoIndexerService = { name: 'CardanoIndexerService' }
module.exports = CardanoIndexerService
module.exports.CardanoIndexerService = CardanoIndexerService
// SyncState
module.exports.SyncState = createEntityProxy(['CardanoIndexerService', 'SyncState'], { target: { is_singular: true } })
module.exports.SyncState_ = createEntityProxy(['CardanoIndexerService', 'SyncState'], { target: { is_singular: false }})
// ReorgLog
module.exports.ReorgLog = createEntityProxy(['CardanoIndexerService', 'ReorgLog'], { target: { is_singular: true } })
module.exports.ReorgLog_ = createEntityProxy(['CardanoIndexerService', 'ReorgLog'], { target: { is_singular: false }})
// CrawlerStatus
module.exports.CrawlerStatus = createEntityProxy(['CardanoIndexerService', 'CrawlerStatus'], { target: { is_singular: true } })
module.exports.__Array_CrawlerStatus_ = createEntityProxy(['CardanoIndexerService', 'CrawlerStatus'], { target: { is_singular: false }})
// events
module.exports.blockIndexed = 'CardanoIndexerService.blockIndexed'
module.exports.reorg = 'CardanoIndexerService.reorg'
// actions
module.exports.getStatus = 'getStatus'
module.exports.pauseCrawler = 'pauseCrawler'
module.exports.resumeCrawler = 'resumeCrawler'
// enums
