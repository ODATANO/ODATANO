// This is an automatically generated file. Please do not change its contents manually!
import * as _ from './..';
import * as __ from './../_';

/**
* Cardano Indexer Service (v2.0)
* 
* Control + observability surface for the chain crawler / pre-sync engine:
* - read-only projections of the sync cursor and reorg audit log
* - status function + pause/resume actions delegating to the crawler singleton
* 
* Security note: see CardanoODataService (cardano-service.cds) for the rationale on
* service-level auth. pause/resume are operational actions — gate behind a dedicated
* Admin scope. Read-only status and audit data remain available to authenticated users.
*/
export default class {
  static readonly getStatus: typeof getStatus;
  static readonly pauseCrawler: typeof pauseCrawler;
  static readonly resumeCrawler: typeof resumeCrawler;
}

// entity 'SyncState'
export declare function _SyncStateAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
    network?: string | null
    startSlot?: number | null
    startBlockHash?: _.Blake2b256 | null
    lastSlot?: number | null
    lastBlockHash?: _.Blake2b256 | null
    lastHeight?: number | null
    lastIndexedAt?: __.CdsTimestamp | null
    tipSlot?: number | null
    tipHeight?: number | null
    syncStatus?: _.CrawlSyncStatus | null
    lastError?: string | null
    lastErrorAt?: __.CdsTimestamp | null
    consecutiveErrors?: number | null
    desiredRunning?: boolean | null
    leaseOwner?: string | null
    leaseUntil?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<SyncState>;
    readonly elements: __.ElementsOf<SyncState>;
    readonly actions: globalThis.Record<never, never>;
};
export class SyncState extends _SyncStateAspect(__.Entity) {
}
export class SyncState_ extends Array<SyncState> {
  $count?: number
}

// entity 'ReorgLog'
export declare function _ReorgLogAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
    detectedAt?: __.CdsTimestamp | null
    forkSlot?: number | null
    forkHeight?: number | null
    oldTipHash?: _.Blake2b256 | null
    newTipHash?: _.Blake2b256 | null
    blocksRolledBack?: number | null
    status?: _.ReorgStatus | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<ReorgLog>;
    readonly elements: __.ElementsOf<ReorgLog>;
    readonly actions: globalThis.Record<never, never>;
};
export class ReorgLog extends _ReorgLogAspect(__.Entity) {
}
export class ReorgLog_ extends Array<ReorgLog> {
  $count?: number
}

// entity 'CrawlerStatus'
export declare function _CrawlerStatusAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    running?: boolean | null
    syncStatus?: string | null
    lastSlot?: string | null
    lastHeight?: string | null
    tipHeight?: string | null
    syncProgress?: string | null
    consecutiveErrors?: number | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<CrawlerStatus>;
    readonly elements: __.ElementsOf<CrawlerStatus>;
    readonly actions: globalThis.Record<never, never>;
};
export class CrawlerStatus extends _CrawlerStatusAspect(__.Entity) {
}

// event
export declare class blockIndexed {
  readonly kind: 'event';
  hash: string | null
  slot: number | null
  height: number | null
  txHashes: Array<string>
  tipSlot: number | null
  tipHeight: number | null
}
// event
export declare class reorg {
  readonly kind: 'event';
  forkSlot: number | null
  forkHeight: number | null
  blocksRolledBack: number | null
}

export declare const getStatus:  {
  // positional
  (): globalThis.Promise<CrawlerStatus | null> | CrawlerStatus | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<CrawlerStatus | null> | CrawlerStatus | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<CrawlerStatus | null> | CrawlerStatus | null, __self: never
  kind: 'function'
}

export declare const pauseCrawler:  {
  // positional
  (): globalThis.Promise<boolean | null> | boolean | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<boolean | null> | boolean | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<boolean | null> | boolean | null, __self: never
  kind: 'action'
}

export declare const resumeCrawler:  {
  // positional
  (): globalThis.Promise<boolean | null> | boolean | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<boolean | null> | boolean | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<boolean | null> | boolean | null, __self: never
  kind: 'action'
}