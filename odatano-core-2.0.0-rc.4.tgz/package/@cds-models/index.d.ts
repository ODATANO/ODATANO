// This is an automatically generated file. Please do not change its contents manually!
import * as __ from './_';
import * as _sap_common from './sap/common';

export type Blake2b224 = string;
export type Blake2b256 = string;
export type HexBytes = string;
export type Lovelace = (number | string);
export type AssetUnit = string;
export type MetadataLabel = string;
export type Bech32 = string;
export type Language = __.Association.to<_sap_common.Language>;
export type Currency = __.Association.to<_sap_common.Currency>;
export type Country = __.Association.to<_sap_common.Country>;
export type Timezone = __.Association.to<_sap_common.Timezone>;
export type User = string;
// enum
export const SubmissionStatus: {
  pending: "pending",
  submitted: "submitted",
  confirmed: "confirmed",
  failed: "failed",
}
export type SubmissionStatus = "pending" | "submitted" | "confirmed" | "failed"

// enum
export const SigningStatus: {
  pending: "pending",
  signed: "signed",
  verified: "verified",
  submitting: "submitting",
  submitted: "submitted",
  expired: "expired",
  failed: "failed",
}
export type SigningStatus = "pending" | "signed" | "verified" | "submitting" | "submitted" | "expired" | "failed"

// enum
export const CrawlSyncStatus: {
  stopped: "stopped",
  syncing: "syncing",
  synced: "synced",
  error: "error",
}
export type CrawlSyncStatus = "stopped" | "syncing" | "synced" | "error"

// enum
export const ReorgStatus: {
  detected: "detected",
  rolling_back: "rolling_back",
  reindexing: "reindexing",
  completed: "completed",
}
export type ReorgStatus = "detected" | "rolling_back" | "reindexing" | "completed"

// enum
export const WalletJobStatus: {
  pending: "pending",
  building: "building",
  submitting: "submitting",
  submitted: "submitted",
  confirmed: "confirmed",
  failed: "failed",
  cancelled: "cancelled",
}
export type WalletJobStatus = "pending" | "building" | "submitting" | "submitted" | "confirmed" | "failed" | "cancelled"

// enum
export const WalletJobKind: {
  simpleAda: "simpleAda",
  metadata: "metadata",
  multiAsset: "multiAsset",
  mint: "mint",
  plutusSpend: "plutusSpend",
  submitSigned: "submitSigned",
}
export type WalletJobKind = "simpleAda" | "metadata" | "multiAsset" | "mint" | "plutusSpend" | "submitSigned"

// enum
export const WorkerSignerType: {
  hsm: "hsm",
  software: "software",
}
export type WorkerSignerType = "hsm" | "software"

// the following represents the CDS aspect 'cuid'
export declare function _cuidAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
  } & InstanceType<TBase>
    readonly kind: 'aspect';
    readonly keys: __.KeysOf<cuid>;
    readonly elements: __.ElementsOf<cuid>;
    readonly actions: globalThis.Record<never, never>;
};
/**
* Aspect for entities with canonical universal IDs
* 
* See https://cap.cloud.sap/docs/cds/common#aspect-cuid
*/
export class cuid extends _cuidAspect(__.Entity) {
}
/**
* Aspect for entities with canonical universal IDs
* 
* See https://cap.cloud.sap/docs/cds/common#aspect-cuid
*/
export class cuid_ extends Array<cuid> {
  $count?: number
}
// the following represents the CDS aspect 'managed'
export declare function _managedAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    createdAt?: __.CdsTimestamp | null
    /** Canonical user ID */
    createdBy?: User | null
    modifiedAt?: __.CdsTimestamp | null
    /** Canonical user ID */
    modifiedBy?: User | null
  } & InstanceType<TBase>
    readonly kind: 'aspect';
    readonly keys: __.KeysOf<managed>;
    readonly elements: __.ElementsOf<managed>;
    readonly actions: globalThis.Record<never, never>;
};
/**
* Aspect to capture changes by user and name
* 
* See https://cap.cloud.sap/docs/cds/common#aspect-managed
*/
export class managed extends _managedAspect(__.Entity) {
}
/**
* Aspect to capture changes by user and name
* 
* See https://cap.cloud.sap/docs/cds/common#aspect-managed
*/
export class managed_ extends Array<managed> {
  $count?: number
}
// the following represents the CDS aspect 'temporal'
export declare function _temporalAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'aspect';
    readonly keys: __.KeysOf<temporal>;
    readonly elements: __.ElementsOf<temporal>;
    readonly actions: globalThis.Record<never, never>;
};
/**
* Aspect for entities with temporal data
* 
* See https://cap.cloud.sap/docs/cds/common#aspect-temporal
*/
export class temporal extends _temporalAspect(__.Entity) {
}
/**
* Aspect for entities with temporal data
* 
* See https://cap.cloud.sap/docs/cds/common#aspect-temporal
*/
export class temporal_ extends Array<temporal> {
  $count?: number
}
// entity 'AssetSlice'
export declare function _AssetSliceAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    quantity?: Lovelace | null
    policyId?: Blake2b224 | null
    assetNameHex?: HexBytes | null
    assetName?: string | null
    fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<AssetSlice>;
    readonly elements: __.ElementsOf<AssetSlice>;
    readonly actions: globalThis.Record<never, never>;
};
export class AssetSlice extends _AssetSliceAspect(__.Entity) {
}

// entity 'MetadataSlice'
export declare function _MetadataSliceAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    label?: MetadataLabel | null
    payload?: string | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<MetadataSlice>;
    readonly elements: __.ElementsOf<MetadataSlice>;
    readonly actions: globalThis.Record<never, never>;
};
export class MetadataSlice extends _MetadataSliceAspect(__.Entity) {
}

// entity 'UTxODataSlice'
export declare function _UTxODataSliceAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    dataHash?: Blake2b256 | null
    inlineDatum?: string | null
    referenceScriptHash?: Blake2b256 | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<UTxODataSlice>;
    readonly elements: __.ElementsOf<UTxODataSlice>;
    readonly actions: globalThis.Record<never, never>;
};
export class UTxODataSlice extends _UTxODataSliceAspect(__.Entity) {
}

// entity 'ParsedInput'
export declare function _ParsedInputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    txHash?: Blake2b256 | null
    outputIndex?: number | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<ParsedInput>;
    readonly elements: __.ElementsOf<ParsedInput>;
    readonly actions: globalThis.Record<never, never>;
};
export class ParsedInput extends _ParsedInputAspect(__.Entity) {
}

// entity 'ParsedAsset'
export declare function _ParsedAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    unit?: AssetUnit | null
    quantity?: string | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<ParsedAsset>;
    readonly elements: __.ElementsOf<ParsedAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class ParsedAsset extends _ParsedAssetAspect(__.Entity) {
}

// entity 'ParsedOutput'
export declare function _ParsedOutputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: Bech32 | null
    lovelace?: Lovelace | null
    assets?: Array<ParsedAsset>
    datumHash?: Blake2b256 | null
    inlineDatumHex?: string | null
    referenceScriptHex?: string | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<ParsedOutput>;
    readonly elements: __.ElementsOf<ParsedOutput>;
    readonly actions: globalThis.Record<never, never>;
};
export class ParsedOutput extends _ParsedOutputAspect(__.Entity) {
}

// entity 'ParsedWitnesses'
export declare function _ParsedWitnessesAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    vkeyCount?: number | null
    nativeScripts?: number | null
    plutusScripts?: number | null
    plutusData?: number | null
    redeemers?: number | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<ParsedWitnesses>;
    readonly elements: __.ElementsOf<ParsedWitnesses>;
    readonly actions: globalThis.Record<never, never>;
};
export class ParsedWitnesses extends _ParsedWitnessesAspect(__.Entity) {
}

// entity 'ParsedTransaction'
export declare function _ParsedTransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    txHash?: Blake2b256 | null
    network?: string | null
    inputs?: Array<ParsedInput>
    outputs?: Array<ParsedOutput>
    validityStart?: string | null
    validityEnd?: string | null
    fee?: Lovelace | null
    mint?: Array<ParsedAsset>
    metadataLabels?: Array<string>
    collateral?: Array<ParsedInput>
    requiredSigners?: Array<Blake2b224>
    scriptDataHash?: Blake2b256 | null
    witnesses?: ParsedWitnesses | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<ParsedTransaction>;
    readonly elements: __.ElementsOf<ParsedTransaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class ParsedTransaction extends _ParsedTransactionAspect(__.Entity) {
}
