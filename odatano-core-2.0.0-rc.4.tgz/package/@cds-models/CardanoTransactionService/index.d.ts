// This is an automatically generated file. Please do not change its contents manually!
import * as _ from './..';
import * as __ from './../_';
import * as _odatano_cardano from './../odatano/cardano';

/**
* Cardano Transaction Service
* 
* Handles transaction building and submission operations.
* Separate from the read-only CardanoODataService to provide
* clear separation between general query and command operations.
* 
* Security note: see CardanoODataService (cardano-service.cds) for the rationale
* on service-level auth without per-resource ownership enforcement.
*/
export default class {
  static readonly BuildSimpleAdaTransaction: typeof BuildSimpleAdaTransaction;
  static readonly BuildTransactionWithMetadata: typeof BuildTransactionWithMetadata;
  static readonly BuildMultiAssetTransaction: typeof BuildMultiAssetTransaction;
  static readonly BuildMintTransaction: typeof BuildMintTransaction;
  static readonly GetBuildDetails: typeof GetBuildDetails;
  static readonly SubmitTransaction: typeof SubmitTransaction;
  static readonly SubmitSignedTransaction: typeof SubmitSignedTransaction;
  static readonly BuildPlutusSpendTransaction: typeof BuildPlutusSpendTransaction;
  static readonly SetCollateral: typeof SetCollateral;
  static readonly GetTransactionBuildsByAddress: typeof GetTransactionBuildsByAddress;
  static readonly DeriveScriptAddress: typeof DeriveScriptAddress;
  static readonly ExtractPaymentKeyHash: typeof ExtractPaymentKeyHash;
}

// entity 'TransactionBuild'
export declare function _TransactionBuildAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    id?: __.Key<string>
    network?: string | null
    builderEngine?: string | null
    senderAddress?: _.Bech32 | null
    changeAddress?: _.Bech32 | null
    unsignedTxCbor?: string | null
    txBodyHash?: _.Blake2b256 | null
    fee?: _.Lovelace | null
    size?: number | null
    createdAt?: number | null
    inputs?: __.Composition.of.many<TransactionBuildInputs>
    outputs?: __.Composition.of.many<TransactionBuildOutputs>
    submission?: __.Association.to<TransactionSubmission> | null
    hasInputs?: boolean | null
    hasOutputs?: boolean | null
    wasSubmitted?: boolean | null
    scriptHash?: string | null
    mintScriptHash?: string | null
    fingerprint?: string | null
    scriptAddress?: string | null
    forcedInputsUsed?: number | null
    referenceInputsUsed?: number | null
    collateralAvailable?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuild>;
    readonly elements: __.ElementsOf<TransactionBuild>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuild extends _TransactionBuildAspect(__.Entity) {
}
export class TransactionBuilds extends Array<TransactionBuild> {
  $count?: number
}

// entity 'TransactionBuildInput'
export declare function _TransactionBuildInputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    build?: __.Key<__.Association.to<TransactionBuild>>
    build_id?: __.Key<string>
    inputIndex?: __.Key<number>
    txHash?: _.Blake2b256 | null
    outputIndex?: number | null
    address?: _.Bech32 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<TransactionBuildInputAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildInput>;
    readonly elements: __.ElementsOf<TransactionBuildInput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildInput extends _TransactionBuildInputAspect(__.Entity) {
}
export class TransactionBuildInputs extends Array<TransactionBuildInput> {
  $count?: number
}

// entity 'TransactionBuildOutput'
export declare function _TransactionBuildOutputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    build?: __.Key<__.Association.to<TransactionBuild>>
    build_id?: __.Key<string>
    outputIndex?: __.Key<number>
    address?: _.Bech32 | null
    lovelace?: _.Lovelace | null
    isChange?: boolean | null
    assets?: __.Composition.of.many<TransactionBuildOutputAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildOutput>;
    readonly elements: __.ElementsOf<TransactionBuildOutput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildOutput extends _TransactionBuildOutputAspect(__.Entity) {
}
export class TransactionBuildOutputs extends Array<TransactionBuildOutput> {
  $count?: number
}

// entity 'TransactionBuildInputAsset'
export declare function _TransactionBuildInputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    input?: __.Key<__.Association.to<TransactionBuildInput>>
    input_inputIndex?: __.Key<number>
    input_build_id?: __.Key<string>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildInputAsset>;
    readonly elements: __.ElementsOf<TransactionBuildInputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildInputAsset extends _TransactionBuildInputAssetAspect(__.Entity) {
}
export class TransactionBuildInputAssets extends Array<TransactionBuildInputAsset> {
  $count?: number
}

// entity 'TransactionBuildOutputAsset'
export declare function _TransactionBuildOutputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    output?: __.Key<__.Association.to<TransactionBuildOutput>>
    output_outputIndex?: __.Key<number>
    output_build_id?: __.Key<string>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildOutputAsset>;
    readonly elements: __.ElementsOf<TransactionBuildOutputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildOutputAsset extends _TransactionBuildOutputAssetAspect(__.Entity) {
}
export class TransactionBuildOutputAssets extends Array<TransactionBuildOutputAsset> {
  $count?: number
}

// entity 'TransactionSubmission'
export declare function _TransactionSubmissionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    build?: __.Association.to<TransactionBuild> | null
    build_id?: string | null
    signedTxCbor?: string | null
    txHash?: _.Blake2b256 | null
    submittedAt?: number | null
    status?: _.SubmissionStatus | null
    errorCode?: string | null
    errorMessage?: string | null
    retryCount?: number | null
    errors?: __.Composition.of.many<TransactionSubmissionErrors>
    hasErrors?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionSubmission>;
    readonly elements: __.ElementsOf<TransactionSubmission>;
    readonly actions: {
      CheckSubmissionStatus:  {
        // positional
        (): TransactionSubmission
        // named
        ({}: globalThis.Record<never, never>): TransactionSubmission
        // metadata (do not use)
        __parameters: globalThis.Record<never, never>, __returns: TransactionSubmission, __self: TransactionSubmission
        kind: 'action'
      }
    };
};
/**
* TransactionSubmissions status flow:
* pending -> [submit to chain] -> submitted  (internal, in SubmitTransaction handler)
* submitted -> [CheckSubmissionStatus] confirmed | stays submitted  (conditional)
* pending | submitted -> failed  (blockchain error)
*/
export class TransactionSubmission extends _TransactionSubmissionAspect(__.Entity) {
}
/**
* TransactionSubmissions status flow:
* pending -> [submit to chain] -> submitted  (internal, in SubmitTransaction handler)
* submitted -> [CheckSubmissionStatus] confirmed | stays submitted  (conditional)
* pending | submitted -> failed  (blockchain error)
*/
export class TransactionSubmissions extends Array<TransactionSubmission> {
  $count?: number
}

// entity 'TransactionSubmissionError'
export declare function _TransactionSubmissionErrorAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    submission?: __.Association.to<TransactionSubmission> | null
    submission_id?: string | null
    occurredAt?: number | null
    errorType?: string | null
    errorCode?: string | null
    errorMessage?: string | null
    errorDetails?: string | null
    isRecoverable?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionSubmissionError>;
    readonly elements: __.ElementsOf<TransactionSubmissionError>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionSubmissionError extends _TransactionSubmissionErrorAspect(__.Entity) {
}
export class TransactionSubmissionErrors extends Array<TransactionSubmissionError> {
  $count?: number
}

// entity 'AddressTransactionBuild'
export declare function _AddressTransactionBuildAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    txBuild?: __.Key<__.Association.to<TransactionBuild>>
    txBuild_id?: __.Key<string>
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressTransactionBuild>;
    readonly elements: __.ElementsOf<AddressTransactionBuild>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressTransactionBuild extends _AddressTransactionBuildAspect(__.Entity) {
}
export class AddressTransactionBuilds extends Array<AddressTransactionBuild> {
  $count?: number
}

// entity 'Address'
export declare function _AddressAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<_.Bech32>
    stakeAddress?: _.Bech32 | null
    type?: string | null
    isScript?: boolean | null
    totalLovelace?: _.Lovelace | null
    utxoCount?: number | null
    transactions?: __.Composition.of.many<AddressTransactions>
    assets?: __.Composition.of.many<AddressAssets>
    utxos?: __.Composition.of.many<AddressUTxOs>
    hasTransactions?: boolean | null
    hasAssets?: boolean | null
    hasUTxOs?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Address>;
    readonly elements: __.ElementsOf<Address>;
    readonly actions: globalThis.Record<never, never>;
};
export class Address extends _AddressAspect(__.Entity) {
}
export class Addresses extends Array<Address> {
  $count?: number
}

// entity 'AddressTransaction'
export declare function _AddressTransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    tx?: __.Key<__.Association.to<_odatano_cardano.Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    netAmount?: (number | string) | null
    blockTime?: number | null
    netAssets?: string | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressTransaction>;
    readonly elements: __.ElementsOf<AddressTransaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressTransaction extends _AddressTransactionAspect(__.Entity) {
}
export class AddressTransactions extends Array<AddressTransaction> {
  $count?: number
}

// entity 'AddressAsset'
export declare function _AddressAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressAsset>;
    readonly elements: __.ElementsOf<AddressAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressAsset extends _AddressAssetAspect(__.Entity) {
}
export class AddressAssets extends Array<AddressAsset> {
  $count?: number
}

// entity 'AddressUTxO'
export declare function _AddressUTxOAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    hash?: __.Key<_.Blake2b256>
    index?: __.Key<number>
    blockHash?: _.Blake2b256 | null
    utxodata_dataHash?: _.Blake2b256 | null
    utxodata_inlineDatum?: string | null
    utxodata_referenceScriptHash?: _.Blake2b256 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<UTxOAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressUTxO>;
    readonly elements: __.ElementsOf<AddressUTxO>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressUTxO extends _AddressUTxOAspect(__.Entity) {
}
export class AddressUTxOs extends Array<AddressUTxO> {
  $count?: number
}

// entity 'UTxOAsset'
export declare function _UTxOAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    utxo?: __.Key<__.Association.to<AddressUTxO>>
    utxo_hash?: __.Key<_.Blake2b256>
    utxo_index?: __.Key<number>
    utxo_address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<UTxOAsset>;
    readonly elements: __.ElementsOf<UTxOAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class UTxOAsset extends _UTxOAssetAspect(__.Entity) {
}
export class UTxOAssets extends Array<UTxOAsset> {
  $count?: number
}


export declare const BuildSimpleAdaTransaction:  {
  // positional
  (senderAddress: _.Bech32 | null, recipientAddress: _.Bech32 | null, lovelaceAmount: _.Lovelace | null, changeAddress: _.Bech32 | null, outputDatumJson: string | null, assetsJson: string | null, forceInputsJson: string | null, validatorScript: string | null, scriptParamsJson: string | null, lockOnScript: boolean | null, referenceScriptHex: string | null, validityStartMs: string | null, validityEndMs: string | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({senderAddress, recipientAddress, lovelaceAmount, changeAddress, outputDatumJson, assetsJson, forceInputsJson, validatorScript, scriptParamsJson, lockOnScript, referenceScriptHex, validityStartMs, validityEndMs}: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, changeAddress?: _.Bech32 | null, outputDatumJson?: string | null, assetsJson?: string | null, forceInputsJson?: string | null, validatorScript?: string | null, scriptParamsJson?: string | null, lockOnScript?: boolean | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, changeAddress?: _.Bech32 | null, outputDatumJson?: string | null, assetsJson?: string | null, forceInputsJson?: string | null, validatorScript?: string | null, scriptParamsJson?: string | null, lockOnScript?: boolean | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const BuildTransactionWithMetadata:  {
  // positional
  (senderAddress: _.Bech32 | null, recipientAddress: _.Bech32 | null, lovelaceAmount: _.Lovelace | null, changeAddress: _.Bech32 | null, metadataJson: string | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({senderAddress, recipientAddress, lovelaceAmount, changeAddress, metadataJson}: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, changeAddress?: _.Bech32 | null, metadataJson?: string | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, changeAddress?: _.Bech32 | null, metadataJson?: string | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const BuildMultiAssetTransaction:  {
  // positional
  (senderAddress: _.Bech32 | null, recipientAddress: _.Bech32 | null, lovelaceAmount: _.Lovelace | null, assetsJson: string | null, changeAddress: _.Bech32 | null, outputDatumJson: string | null, referenceScriptHex: string | null, validityStartMs: string | null, validityEndMs: string | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({senderAddress, recipientAddress, lovelaceAmount, assetsJson, changeAddress, outputDatumJson, referenceScriptHex, validityStartMs, validityEndMs}: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, assetsJson?: string | null, changeAddress?: _.Bech32 | null, outputDatumJson?: string | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, assetsJson?: string | null, changeAddress?: _.Bech32 | null, outputDatumJson?: string | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const BuildMintTransaction:  {
  // positional
  (senderAddress: _.Bech32 | null, recipientAddress: _.Bech32 | null, lovelaceAmount: _.Lovelace | null, mintActionsJson: string | null, mintingPolicyScript: string | null, changeAddress: _.Bech32 | null, requiredSignersJson: string | null, scriptParamsJson: string | null, inlineDatumJson: string | null, mintRedeemerJson: string | null, lockOnScript: boolean | null, forceInputsJson: string | null, referenceInputsJson: string | null, extraOutputsJson: string | null, metadataJson: string | null, referenceScriptHex: string | null, validityStartMs: string | null, validityEndMs: string | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({senderAddress, recipientAddress, lovelaceAmount, mintActionsJson, mintingPolicyScript, changeAddress, requiredSignersJson, scriptParamsJson, inlineDatumJson, mintRedeemerJson, lockOnScript, forceInputsJson, referenceInputsJson, extraOutputsJson, metadataJson, referenceScriptHex, validityStartMs, validityEndMs}: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, mintActionsJson?: string | null, mintingPolicyScript?: string | null, changeAddress?: _.Bech32 | null, requiredSignersJson?: string | null, scriptParamsJson?: string | null, inlineDatumJson?: string | null, mintRedeemerJson?: string | null, lockOnScript?: boolean | null, forceInputsJson?: string | null, referenceInputsJson?: string | null, extraOutputsJson?: string | null, metadataJson?: string | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, mintActionsJson?: string | null, mintingPolicyScript?: string | null, changeAddress?: _.Bech32 | null, requiredSignersJson?: string | null, scriptParamsJson?: string | null, inlineDatumJson?: string | null, mintRedeemerJson?: string | null, lockOnScript?: boolean | null, forceInputsJson?: string | null, referenceInputsJson?: string | null, extraOutputsJson?: string | null, metadataJson?: string | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const GetBuildDetails:  {
  // positional
  (buildId: string | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({buildId}: {buildId?: string | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {buildId?: string | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const SubmitTransaction:  {
  // positional
  (buildId: string | null, signedTxCbor: string | null): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // named
  ({buildId, signedTxCbor}: {buildId?: string | null, signedTxCbor?: string | null}): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // metadata (do not use)
  __parameters: {buildId?: string | null, signedTxCbor?: string | null}, __returns: globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null, __self: never
  kind: 'action'
}

export declare const SubmitSignedTransaction:  {
  // positional
  (signedTxCbor: string | null, network: string | null): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // named
  ({signedTxCbor, network}: {signedTxCbor?: string | null, network?: string | null}): globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null
  // metadata (do not use)
  __parameters: {signedTxCbor?: string | null, network?: string | null}, __returns: globalThis.Promise<TransactionSubmission | null> | TransactionSubmission | null, __self: never
  kind: 'action'
}

export declare const BuildPlutusSpendTransaction:  {
  // positional
  (senderAddress: _.Bech32 | null, recipientAddress: _.Bech32 | null, lovelaceAmount: _.Lovelace | null, validatorScript: string | null, scriptTxHash: string | null, scriptOutputIndex: number | null, redeemerJson: string | null, datumJson: string | null, changeAddress: _.Bech32 | null, requiredSignersJson: string | null, scriptParamsJson: string | null, inlineDatumJson: string | null, lockOnScript: boolean | null, forceInputsJson: string | null, extraOutputsJson: string | null, mintActionsJson: string | null, mintingPolicyScript: string | null, mintRedeemerJson: string | null, referenceInputsJson: string | null, referenceScriptHex: string | null, validityStartMs: string | null, validityEndMs: string | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({senderAddress, recipientAddress, lovelaceAmount, validatorScript, scriptTxHash, scriptOutputIndex, redeemerJson, datumJson, changeAddress, requiredSignersJson, scriptParamsJson, inlineDatumJson, lockOnScript, forceInputsJson, extraOutputsJson, mintActionsJson, mintingPolicyScript, mintRedeemerJson, referenceInputsJson, referenceScriptHex, validityStartMs, validityEndMs}: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, validatorScript?: string | null, scriptTxHash?: string | null, scriptOutputIndex?: number | null, redeemerJson?: string | null, datumJson?: string | null, changeAddress?: _.Bech32 | null, requiredSignersJson?: string | null, scriptParamsJson?: string | null, inlineDatumJson?: string | null, lockOnScript?: boolean | null, forceInputsJson?: string | null, extraOutputsJson?: string | null, mintActionsJson?: string | null, mintingPolicyScript?: string | null, mintRedeemerJson?: string | null, referenceInputsJson?: string | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {senderAddress?: _.Bech32 | null, recipientAddress?: _.Bech32 | null, lovelaceAmount?: _.Lovelace | null, validatorScript?: string | null, scriptTxHash?: string | null, scriptOutputIndex?: number | null, redeemerJson?: string | null, datumJson?: string | null, changeAddress?: _.Bech32 | null, requiredSignersJson?: string | null, scriptParamsJson?: string | null, inlineDatumJson?: string | null, lockOnScript?: boolean | null, forceInputsJson?: string | null, extraOutputsJson?: string | null, mintActionsJson?: string | null, mintingPolicyScript?: string | null, mintRedeemerJson?: string | null, referenceInputsJson?: string | null, referenceScriptHex?: string | null, validityStartMs?: string | null, validityEndMs?: string | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const SetCollateral:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<TransactionBuild | null> | TransactionBuild | null
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<TransactionBuild | null> | TransactionBuild | null, __self: never
  kind: 'action'
}

export declare const GetTransactionBuildsByAddress:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<Array<AddressTransactionBuild>> | Array<AddressTransactionBuild>
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<Array<AddressTransactionBuild>> | Array<AddressTransactionBuild>
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<Array<AddressTransactionBuild>> | Array<AddressTransactionBuild>, __self: never
  kind: 'action'
}

export declare const DeriveScriptAddress:  {
  // positional
  (validatorScript: string | null, scriptParamsJson: string | null, network: string | null): globalThis.Promise<{   scriptAddress?: string | null,   scriptHash?: string | null, } | null> | {   scriptAddress?: string | null,   scriptHash?: string | null, } | null
  // named
  ({validatorScript, scriptParamsJson, network}: {validatorScript?: string | null, scriptParamsJson?: string | null, network?: string | null}): globalThis.Promise<{   scriptAddress?: string | null,   scriptHash?: string | null, } | null> | {   scriptAddress?: string | null,   scriptHash?: string | null, } | null
  // metadata (do not use)
  __parameters: {validatorScript?: string | null, scriptParamsJson?: string | null, network?: string | null}, __returns: globalThis.Promise<{   scriptAddress?: string | null,   scriptHash?: string | null, } | null> | {   scriptAddress?: string | null,   scriptHash?: string | null, } | null, __self: never
  kind: 'action'
}

export declare const ExtractPaymentKeyHash:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<{   paymentKeyHash?: string | null, } | null> | {   paymentKeyHash?: string | null, } | null
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<{   paymentKeyHash?: string | null, } | null> | {   paymentKeyHash?: string | null, } | null
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<{   paymentKeyHash?: string | null, } | null> | {   paymentKeyHash?: string | null, } | null, __self: never
  kind: 'action'
}