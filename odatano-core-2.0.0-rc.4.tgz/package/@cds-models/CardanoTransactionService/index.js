// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./../_')
// service
const CardanoTransactionService = { name: 'CardanoTransactionService' }
module.exports = CardanoTransactionService
module.exports.CardanoTransactionService = CardanoTransactionService
// TransactionBuilds
module.exports.TransactionBuild = createEntityProxy(['CardanoTransactionService', 'TransactionBuilds'], { target: { is_singular: true } })
module.exports.TransactionBuilds = createEntityProxy(['CardanoTransactionService', 'TransactionBuilds'], { target: { is_singular: false }})
// TransactionBuildInputs
module.exports.TransactionBuildInput = createEntityProxy(['CardanoTransactionService', 'TransactionBuildInputs'], { target: { is_singular: true } })
module.exports.TransactionBuildInputs = createEntityProxy(['CardanoTransactionService', 'TransactionBuildInputs'], { target: { is_singular: false }})
// TransactionBuildOutputs
module.exports.TransactionBuildOutput = createEntityProxy(['CardanoTransactionService', 'TransactionBuildOutputs'], { target: { is_singular: true } })
module.exports.TransactionBuildOutputs = createEntityProxy(['CardanoTransactionService', 'TransactionBuildOutputs'], { target: { is_singular: false }})
// TransactionBuildInputAssets
module.exports.TransactionBuildInputAsset = createEntityProxy(['CardanoTransactionService', 'TransactionBuildInputAssets'], { target: { is_singular: true } })
module.exports.TransactionBuildInputAssets = createEntityProxy(['CardanoTransactionService', 'TransactionBuildInputAssets'], { target: { is_singular: false }})
// TransactionBuildOutputAssets
module.exports.TransactionBuildOutputAsset = createEntityProxy(['CardanoTransactionService', 'TransactionBuildOutputAssets'], { target: { is_singular: true } })
module.exports.TransactionBuildOutputAssets = createEntityProxy(['CardanoTransactionService', 'TransactionBuildOutputAssets'], { target: { is_singular: false }})
// TransactionSubmissions
module.exports.TransactionSubmission = createEntityProxy(['CardanoTransactionService', 'TransactionSubmissions'], { target: { is_singular: true } })
module.exports.TransactionSubmissions = createEntityProxy(['CardanoTransactionService', 'TransactionSubmissions'], { target: { is_singular: false }})
// TransactionSubmissionErrors
module.exports.TransactionSubmissionError = createEntityProxy(['CardanoTransactionService', 'TransactionSubmissionErrors'], { target: { is_singular: true } })
module.exports.TransactionSubmissionErrors = createEntityProxy(['CardanoTransactionService', 'TransactionSubmissionErrors'], { target: { is_singular: false }})
// AddressTransactionBuilds
module.exports.AddressTransactionBuild = createEntityProxy(['CardanoTransactionService', 'AddressTransactionBuilds'], { target: { is_singular: true } })
module.exports.AddressTransactionBuilds = createEntityProxy(['CardanoTransactionService', 'AddressTransactionBuilds'], { target: { is_singular: false }})
// Addresses
module.exports.Address = createEntityProxy(['CardanoTransactionService', 'Addresses'], { target: { is_singular: true } })
module.exports.Addresses = createEntityProxy(['CardanoTransactionService', 'Addresses'], { target: { is_singular: false }})
// AddressTransactions
module.exports.AddressTransaction = createEntityProxy(['CardanoTransactionService', 'AddressTransactions'], { target: { is_singular: true } })
module.exports.AddressTransactions = createEntityProxy(['CardanoTransactionService', 'AddressTransactions'], { target: { is_singular: false }})
// AddressAssets
module.exports.AddressAsset = createEntityProxy(['CardanoTransactionService', 'AddressAssets'], { target: { is_singular: true } })
module.exports.AddressAssets = createEntityProxy(['CardanoTransactionService', 'AddressAssets'], { target: { is_singular: false }})
// AddressUTxOs
module.exports.AddressUTxO = createEntityProxy(['CardanoTransactionService', 'AddressUTxOs'], { target: { is_singular: true } })
module.exports.AddressUTxOs = createEntityProxy(['CardanoTransactionService', 'AddressUTxOs'], { target: { is_singular: false }})
// UTxOAssets
module.exports.UTxOAsset = createEntityProxy(['CardanoTransactionService', 'UTxOAssets'], { target: { is_singular: true } })
module.exports.UTxOAssets = createEntityProxy(['CardanoTransactionService', 'UTxOAssets'], { target: { is_singular: false }})
// events
// actions
module.exports.BuildSimpleAdaTransaction = 'BuildSimpleAdaTransaction'
module.exports.BuildTransactionWithMetadata = 'BuildTransactionWithMetadata'
module.exports.BuildMultiAssetTransaction = 'BuildMultiAssetTransaction'
module.exports.BuildMintTransaction = 'BuildMintTransaction'
module.exports.GetBuildDetails = 'GetBuildDetails'
module.exports.SubmitTransaction = 'SubmitTransaction'
module.exports.SubmitSignedTransaction = 'SubmitSignedTransaction'
module.exports.BuildPlutusSpendTransaction = 'BuildPlutusSpendTransaction'
module.exports.SetCollateral = 'SetCollateral'
module.exports.GetTransactionBuildsByAddress = 'GetTransactionBuildsByAddress'
module.exports.DeriveScriptAddress = 'DeriveScriptAddress'
module.exports.ExtractPaymentKeyHash = 'ExtractPaymentKeyHash'
// enums
