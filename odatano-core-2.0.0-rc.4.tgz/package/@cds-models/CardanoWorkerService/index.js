// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./../_')
// service
const CardanoWorkerService = { name: 'CardanoWorkerService' }
module.exports = CardanoWorkerService
module.exports.CardanoWorkerService = CardanoWorkerService
// WalletJobs
module.exports.WalletJob = createEntityProxy(['CardanoWorkerService', 'WalletJobs'], { target: { is_singular: true } })
module.exports.WalletJobs = createEntityProxy(['CardanoWorkerService', 'WalletJobs'], { target: { is_singular: false }})
// WorkerWallets
module.exports.WorkerWallet = createEntityProxy(['CardanoWorkerService', 'WorkerWallets'], { target: { is_singular: true } })
module.exports.WorkerWallets = createEntityProxy(['CardanoWorkerService', 'WorkerWallets'], { target: { is_singular: false }})
// JobSubmissionResult
module.exports.JobSubmissionResult = createEntityProxy(['CardanoWorkerService', 'JobSubmissionResult'], { target: { is_singular: true } })
module.exports.__Array_JobSubmissionResult_ = createEntityProxy(['CardanoWorkerService', 'JobSubmissionResult'], { target: { is_singular: false }})
// JobStatus
module.exports.JobStatus = createEntityProxy(['CardanoWorkerService', 'JobStatus'], { target: { is_singular: true } })
module.exports.__Array_JobStatus_ = createEntityProxy(['CardanoWorkerService', 'JobStatus'], { target: { is_singular: false }})
// WorkerStatus
module.exports.WorkerStatus = createEntityProxy(['CardanoWorkerService', 'WorkerStatus'], { target: { is_singular: true } })
module.exports.__Array_WorkerStatus_ = createEntityProxy(['CardanoWorkerService', 'WorkerStatus'], { target: { is_singular: false }})
// events
module.exports.jobConfirmed = 'CardanoWorkerService.jobConfirmed'
module.exports.jobFailed = 'CardanoWorkerService.jobFailed'
// actions
module.exports.SubmitWalletJob = 'SubmitWalletJob'
module.exports.CancelJob = 'CancelJob'
module.exports.GetJobStatus = 'GetJobStatus'
module.exports.GetWorkerStatus = 'GetWorkerStatus'
module.exports.PauseWorker = 'PauseWorker'
module.exports.ResumeWorker = 'ResumeWorker'
// enums
