// This is an automatically generated file. Please do not change its contents manually!
import * as _ from './..';
import * as __ from './../_';

/**
* Cardano Wallet Worker Service (v2.0)
* 
* Control + observability surface for the wallet worker / job engine:
* - job submission (async build → sign → submit → confirm from server-side wallets)
* - job status polling + cancellation
* - read-only projections of jobs and registered worker wallets
* - pause/resume of the local worker instance (admin)
* 
* Security note: SubmitWalletJob executes value transfers with server-held keys —
* the service requires authentication throughout; control actions and foreign-job
* visibility are gated behind the Admin role. Jobs on HSM-backed wallets addition-
* ally require the configured hsm.requiresRole (HSM_REQUIRES_ROLE), the same gate
* the synchronous SignWithHsm path enforces. Keys are NEVER accepted or exposed
* through this surface.
*/
export default class {
  static readonly SubmitWalletJob: typeof SubmitWalletJob;
  static readonly CancelJob: typeof CancelJob;
  static readonly GetJobStatus: typeof GetJobStatus;
  static readonly GetWorkerStatus: typeof GetWorkerStatus;
  static readonly PauseWorker: typeof PauseWorker;
  static readonly ResumeWorker: typeof ResumeWorker;
}

// entity 'WalletJob'
export declare function _WalletJobAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
    walletId?: string | null
    kind?: _.WalletJobKind | null
    status?: _.WalletJobStatus | null
    idempotencyKey?: string | null
    request?: string | null
    priority?: number | null
    notBefore?: __.CdsTimestamp | null
    attempt?: number | null
    maxAttempts?: number | null
    txHash?: _.Blake2b256 | null
    unsignedTxCbor?: string | null
    signedTxCbor?: string | null
    fee?: _.Lovelace | null
    submittedAt?: __.CdsTimestamp | null
    confirmedAt?: __.CdsTimestamp | null
    confirmedSlot?: number | null
    confirmedHeight?: number | null
    errorCode?: string | null
    errorMessage?: string | null
    createdAt?: __.CdsTimestamp | null
    createdBy?: string | null
    finishedAt?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<WalletJob>;
    readonly elements: __.ElementsOf<WalletJob>;
    readonly actions: globalThis.Record<never, never>;
};
export class WalletJob extends _WalletJobAspect(__.Entity) {
}
export class WalletJobs extends Array<WalletJob> {
  $count?: number
}

// entity 'WorkerWallet'
export declare function _WorkerWalletAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    walletId?: __.Key<string>
    signerType?: _.WorkerSignerType | null
    address?: _.Bech32 | null
    publicKeyHash?: _.Blake2b224 | null
    enabled?: boolean | null
    lastJobAt?: __.CdsTimestamp | null
    jobsConfirmed?: number | null
    jobsFailed?: number | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<WorkerWallet>;
    readonly elements: __.ElementsOf<WorkerWallet>;
    readonly actions: globalThis.Record<never, never>;
};
export class WorkerWallet extends _WorkerWalletAspect(__.Entity) {
}
export class WorkerWallets extends Array<WorkerWallet> {
  $count?: number
}

// entity 'JobSubmissionResult'
export declare function _JobSubmissionResultAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    jobId?: string | null
    status?: string | null
    deduplicated?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<JobSubmissionResult>;
    readonly elements: __.ElementsOf<JobSubmissionResult>;
    readonly actions: globalThis.Record<never, never>;
};
export class JobSubmissionResult extends _JobSubmissionResultAspect(__.Entity) {
}

// entity 'JobStatus'
export declare function _JobStatusAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    jobId?: string | null
    walletId?: string | null
    kind?: string | null
    status?: string | null
    attempt?: number | null
    txHash?: string | null
    fee?: string | null
    errorCode?: string | null
    errorMessage?: string | null
    submittedAt?: __.CdsTimestamp | null
    confirmedAt?: __.CdsTimestamp | null
    finishedAt?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<JobStatus>;
    readonly elements: __.ElementsOf<JobStatus>;
    readonly actions: globalThis.Record<never, never>;
};
export class JobStatus extends _JobStatusAspect(__.Entity) {
}

// entity 'WorkerStatus'
export declare function _WorkerStatusAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    running?: boolean | null
    wallets?: Array<string>
    executing?: Array<string>
    awaitingConfirmation?: number | null
    pendingJobs?: number | null
  } & InstanceType<TBase>
    readonly kind: 'type';
    readonly keys: __.KeysOf<WorkerStatus>;
    readonly elements: __.ElementsOf<WorkerStatus>;
    readonly actions: globalThis.Record<never, never>;
};
export class WorkerStatus extends _WorkerStatusAspect(__.Entity) {
}

// event
export declare class jobConfirmed {
  readonly kind: 'event';
  jobId: string | null
  walletId: string | null
  kind: string | null
  txHash: string | null
}
// event
export declare class jobFailed {
  readonly kind: 'event';
  jobId: string | null
  walletId: string | null
  kind: string | null
  txHash: string | null
  errorCode: string | null
  errorMessage: string | null
}

export declare const SubmitWalletJob:  {
  // positional
  (walletId: string | null, kind: string | null, requestJson: string | null, idempotencyKey: string | null, priority: number | null, notBefore: __.CdsTimestamp | null): globalThis.Promise<JobSubmissionResult | null> | JobSubmissionResult | null
  // named
  ({walletId, kind, requestJson, idempotencyKey, priority, notBefore}: {walletId?: string | null, kind?: string | null, requestJson?: string | null, idempotencyKey?: string | null, priority?: number | null, notBefore?: __.CdsTimestamp | null}): globalThis.Promise<JobSubmissionResult | null> | JobSubmissionResult | null
  // metadata (do not use)
  __parameters: {walletId?: string | null, kind?: string | null, requestJson?: string | null, idempotencyKey?: string | null, priority?: number | null, notBefore?: __.CdsTimestamp | null}, __returns: globalThis.Promise<JobSubmissionResult | null> | JobSubmissionResult | null, __self: never
  kind: 'action'
}

export declare const CancelJob:  {
  // positional
  (jobId: string | null): globalThis.Promise<boolean | null> | boolean | null
  // named
  ({jobId}: {jobId?: string | null}): globalThis.Promise<boolean | null> | boolean | null
  // metadata (do not use)
  __parameters: {jobId?: string | null}, __returns: globalThis.Promise<boolean | null> | boolean | null, __self: never
  kind: 'action'
}

export declare const GetJobStatus:  {
  // positional
  (jobId: string | null): globalThis.Promise<JobStatus | null> | JobStatus | null
  // named
  ({jobId}: {jobId?: string | null}): globalThis.Promise<JobStatus | null> | JobStatus | null
  // metadata (do not use)
  __parameters: {jobId?: string | null}, __returns: globalThis.Promise<JobStatus | null> | JobStatus | null, __self: never
  kind: 'function'
}

export declare const GetWorkerStatus:  {
  // positional
  (): globalThis.Promise<WorkerStatus | null> | WorkerStatus | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<WorkerStatus | null> | WorkerStatus | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<WorkerStatus | null> | WorkerStatus | null, __self: never
  kind: 'function'
}

export declare const PauseWorker:  {
  // positional
  (): globalThis.Promise<boolean | null> | boolean | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<boolean | null> | boolean | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<boolean | null> | boolean | null, __self: never
  kind: 'action'
}

export declare const ResumeWorker:  {
  // positional
  (): globalThis.Promise<boolean | null> | boolean | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<boolean | null> | boolean | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<boolean | null> | boolean | null, __self: never
  kind: 'action'
}