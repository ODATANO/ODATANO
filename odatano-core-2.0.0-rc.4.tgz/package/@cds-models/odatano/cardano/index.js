// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./../../_')
// NetworkInformation
module.exports.NetworkInformation = createEntityProxy(['odatano.cardano', 'NetworkInformation'], { target: { is_singular: true } })
module.exports.NetworkInformation_ = createEntityProxy(['odatano.cardano', 'NetworkInformation'], { target: { is_singular: false }})
// Blocks
module.exports.Block = createEntityProxy(['odatano.cardano', 'Blocks'], { target: { is_singular: true } })
module.exports.Blocks = createEntityProxy(['odatano.cardano', 'Blocks'], { target: { is_singular: false }})
// Epochs
module.exports.Epoch = createEntityProxy(['odatano.cardano', 'Epochs'], { target: { is_singular: true } })
module.exports.Epochs = createEntityProxy(['odatano.cardano', 'Epochs'], { target: { is_singular: false }})
// Pools
module.exports.Pool = createEntityProxy(['odatano.cardano', 'Pools'], { target: { is_singular: true } })
module.exports.Pools = createEntityProxy(['odatano.cardano', 'Pools'], { target: { is_singular: false }})
// Assets
module.exports.Asset = createEntityProxy(['odatano.cardano', 'Assets'], { target: { is_singular: true } })
module.exports.Assets = createEntityProxy(['odatano.cardano', 'Assets'], { target: { is_singular: false }})
// AssetHistory
module.exports.AssetHistory = createEntityProxy(['odatano.cardano', 'AssetHistory'], { target: { is_singular: true } })
module.exports.AssetHistory_ = createEntityProxy(['odatano.cardano', 'AssetHistory'], { target: { is_singular: false }})
// Dreps
module.exports.Drep = createEntityProxy(['odatano.cardano', 'Dreps'], { target: { is_singular: true } })
module.exports.Dreps = createEntityProxy(['odatano.cardano', 'Dreps'], { target: { is_singular: false }})
// Addresses
module.exports.Address = createEntityProxy(['odatano.cardano', 'Addresses'], { target: { is_singular: true } })
module.exports.Addresses = createEntityProxy(['odatano.cardano', 'Addresses'], { target: { is_singular: false }})
// AddressAssets
module.exports.AddressAsset = createEntityProxy(['odatano.cardano', 'AddressAssets'], { target: { is_singular: true } })
module.exports.AddressAssets = createEntityProxy(['odatano.cardano', 'AddressAssets'], { target: { is_singular: false }})
// AddressUTxOs
module.exports.AddressUTxO = createEntityProxy(['odatano.cardano', 'AddressUTxOs'], { target: { is_singular: true } })
module.exports.AddressUTxOs = createEntityProxy(['odatano.cardano', 'AddressUTxOs'], { target: { is_singular: false }})
// UTxOAssets
module.exports.UTxOAsset = createEntityProxy(['odatano.cardano', 'UTxOAssets'], { target: { is_singular: true } })
module.exports.UTxOAssets = createEntityProxy(['odatano.cardano', 'UTxOAssets'], { target: { is_singular: false }})
// Accounts
module.exports.Account = createEntityProxy(['odatano.cardano', 'Accounts'], { target: { is_singular: true } })
module.exports.Accounts = createEntityProxy(['odatano.cardano', 'Accounts'], { target: { is_singular: false }})
// Transactions
module.exports.Transaction = createEntityProxy(['odatano.cardano', 'Transactions'], { target: { is_singular: true } })
module.exports.Transactions = createEntityProxy(['odatano.cardano', 'Transactions'], { target: { is_singular: false }})
// TransactionInputs
module.exports.TransactionInput = createEntityProxy(['odatano.cardano', 'TransactionInputs'], { target: { is_singular: true } })
module.exports.TransactionInputs = createEntityProxy(['odatano.cardano', 'TransactionInputs'], { target: { is_singular: false }})
// TransactionInputAssets
module.exports.TransactionInputAsset = createEntityProxy(['odatano.cardano', 'TransactionInputAssets'], { target: { is_singular: true } })
module.exports.TransactionInputAssets = createEntityProxy(['odatano.cardano', 'TransactionInputAssets'], { target: { is_singular: false }})
// TransactionOutputs
module.exports.TransactionOutput = createEntityProxy(['odatano.cardano', 'TransactionOutputs'], { target: { is_singular: true } })
module.exports.TransactionOutputs = createEntityProxy(['odatano.cardano', 'TransactionOutputs'], { target: { is_singular: false }})
// TransactionOutputAssets
module.exports.TransactionOutputAsset = createEntityProxy(['odatano.cardano', 'TransactionOutputAssets'], { target: { is_singular: true } })
module.exports.TransactionOutputAssets = createEntityProxy(['odatano.cardano', 'TransactionOutputAssets'], { target: { is_singular: false }})
// TransactionMetadata
module.exports.TransactionMetadata = createEntityProxy(['odatano.cardano', 'TransactionMetadata'], { target: { is_singular: true } })
module.exports.TransactionMetadata_ = createEntityProxy(['odatano.cardano', 'TransactionMetadata'], { target: { is_singular: false }})
// LedgerProtocolParameters
module.exports.LedgerProtocolParameter = createEntityProxy(['odatano.cardano', 'LedgerProtocolParameters'], { target: { is_singular: true } })
module.exports.LedgerProtocolParameters = createEntityProxy(['odatano.cardano', 'LedgerProtocolParameters'], { target: { is_singular: false }})
// TransactionBuilds
module.exports.TransactionBuild = createEntityProxy(['odatano.cardano', 'TransactionBuilds'], { target: { is_singular: true } })
module.exports.TransactionBuilds = createEntityProxy(['odatano.cardano', 'TransactionBuilds'], { target: { is_singular: false }})
// TransactionBuildInputs
module.exports.TransactionBuildInput = createEntityProxy(['odatano.cardano', 'TransactionBuildInputs'], { target: { is_singular: true } })
module.exports.TransactionBuildInputs = createEntityProxy(['odatano.cardano', 'TransactionBuildInputs'], { target: { is_singular: false }})
// TransactionBuildInputAssets
module.exports.TransactionBuildInputAsset = createEntityProxy(['odatano.cardano', 'TransactionBuildInputAssets'], { target: { is_singular: true } })
module.exports.TransactionBuildInputAssets = createEntityProxy(['odatano.cardano', 'TransactionBuildInputAssets'], { target: { is_singular: false }})
// TransactionBuildOutputs
module.exports.TransactionBuildOutput = createEntityProxy(['odatano.cardano', 'TransactionBuildOutputs'], { target: { is_singular: true } })
module.exports.TransactionBuildOutputs = createEntityProxy(['odatano.cardano', 'TransactionBuildOutputs'], { target: { is_singular: false }})
// TransactionBuildOutputAssets
module.exports.TransactionBuildOutputAsset = createEntityProxy(['odatano.cardano', 'TransactionBuildOutputAssets'], { target: { is_singular: true } })
module.exports.TransactionBuildOutputAssets = createEntityProxy(['odatano.cardano', 'TransactionBuildOutputAssets'], { target: { is_singular: false }})
// TransactionSubmissions
module.exports.TransactionSubmission = createEntityProxy(['odatano.cardano', 'TransactionSubmissions'], { target: { is_singular: true } })
module.exports.TransactionSubmissions = createEntityProxy(['odatano.cardano', 'TransactionSubmissions'], { target: { is_singular: false }})
// TransactionSubmissionErrors
module.exports.TransactionSubmissionError = createEntityProxy(['odatano.cardano', 'TransactionSubmissionErrors'], { target: { is_singular: true } })
module.exports.TransactionSubmissionErrors = createEntityProxy(['odatano.cardano', 'TransactionSubmissionErrors'], { target: { is_singular: false }})
// AddressTransactions
module.exports.AddressTransaction = createEntityProxy(['odatano.cardano', 'AddressTransactions'], { target: { is_singular: true } })
module.exports.AddressTransactions = createEntityProxy(['odatano.cardano', 'AddressTransactions'], { target: { is_singular: false }})
// AddressSigningRequests
module.exports.AddressSigningRequest = createEntityProxy(['odatano.cardano', 'AddressSigningRequests'], { target: { is_singular: true } })
module.exports.AddressSigningRequests = createEntityProxy(['odatano.cardano', 'AddressSigningRequests'], { target: { is_singular: false }})
// AddressTransactionBuilds
module.exports.AddressTransactionBuild = createEntityProxy(['odatano.cardano', 'AddressTransactionBuilds'], { target: { is_singular: true } })
module.exports.AddressTransactionBuilds = createEntityProxy(['odatano.cardano', 'AddressTransactionBuilds'], { target: { is_singular: false }})
// SigningRequests
module.exports.SigningRequest = createEntityProxy(['odatano.cardano', 'SigningRequests'], { target: { is_singular: true } })
module.exports.SigningRequests = createEntityProxy(['odatano.cardano', 'SigningRequests'], { target: { is_singular: false }})
// SignatureVerifications
module.exports.SignatureVerification = createEntityProxy(['odatano.cardano', 'SignatureVerifications'], { target: { is_singular: true } })
module.exports.SignatureVerifications = createEntityProxy(['odatano.cardano', 'SignatureVerifications'], { target: { is_singular: false }})
// CardanoSyncState
module.exports.CardanoSyncState = createEntityProxy(['odatano.cardano', 'CardanoSyncState'], { target: { is_singular: true } })
module.exports.CardanoSyncState_ = createEntityProxy(['odatano.cardano', 'CardanoSyncState'], { target: { is_singular: false }})
// CardanoReorgLog
module.exports.CardanoReorgLog = createEntityProxy(['odatano.cardano', 'CardanoReorgLog'], { target: { is_singular: true } })
module.exports.CardanoReorgLog_ = createEntityProxy(['odatano.cardano', 'CardanoReorgLog'], { target: { is_singular: false }})
// CardanoWorkerWallets
module.exports.CardanoWorkerWallet = createEntityProxy(['odatano.cardano', 'CardanoWorkerWallets'], { target: { is_singular: true } })
module.exports.CardanoWorkerWallets = createEntityProxy(['odatano.cardano', 'CardanoWorkerWallets'], { target: { is_singular: false }})
// CardanoWalletJobs
module.exports.CardanoWalletJob = createEntityProxy(['odatano.cardano', 'CardanoWalletJobs'], { target: { is_singular: true } })
module.exports.CardanoWalletJobs = createEntityProxy(['odatano.cardano', 'CardanoWalletJobs'], { target: { is_singular: false }})
// events
// actions
// enums
