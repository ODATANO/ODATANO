// This is an automatically generated file. Please do not change its contents manually!
import * as _ from './../..';
import * as __ from './../../_';

// entity 'NetworkInformation'
export declare function _NetworkInformationAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    network?: __.Key<string>
    maxSupply?: _.Lovelace | null
    totalSupply?: _.Lovelace | null
    circulatingSupply?: _.Lovelace | null
    lockedSupply?: _.Lovelace | null
    treasurySupply?: _.Lovelace | null
    reservesSupply?: _.Lovelace | null
    liveStake?: _.Lovelace | null
    activeStake?: _.Lovelace | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<NetworkInformation>;
    readonly elements: __.ElementsOf<NetworkInformation>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class NetworkInformation extends _NetworkInformationAspect(__.Entity) {
}
export class NetworkInformation_ extends Array<NetworkInformation> {
  $count?: number
}

// entity 'Block'
export declare function _BlockAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    hash?: __.Key<string>
    time?: string | null
    height?: number | null
    slotLeader?: string | null
    epochNumber?: number | null
    epoch?: __.Association.to<Epoch> | null
    slot?: number | null
    epochSlot?: number | null
    size?: number | null
    txCount?: number | null
    fees?: _.Lovelace | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Block>;
    readonly elements: __.ElementsOf<Block>;
    readonly actions: globalThis.Record<never, never>;
};
export class Block extends _BlockAspect(__.Entity) {
}
export class Blocks extends Array<Block> {
  $count?: number
}

// entity 'Epoch'
export declare function _EpochAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    epoch?: __.Key<number>
    startTime?: number | null
    endTime?: number | null
    firstBlockTime?: number | null
    lastBlockTime?: number | null
    blockCount?: number | null
    txCount?: number | null
    output?: string | null
    fees?: _.Lovelace | null
    activeStake?: _.Lovelace | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Epoch>;
    readonly elements: __.ElementsOf<Epoch>;
    readonly actions: globalThis.Record<never, never>;
};
export class Epoch extends _EpochAspect(__.Entity) {
}
export class Epochs extends Array<Epoch> {
  $count?: number
}

// entity 'Pool'
export declare function _PoolAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    poolId?: __.Key<_.Bech32>
    vrfKeyHash?: string | null
    blocksMinted?: number | null
    blocksEpoch?: number | null
    liveStake?: _.Lovelace | null
    liveSize?: (number | string) | null
    liveSaturation?: (number | string) | null
    liveDelegators?: number | null
    activeStake?: _.Lovelace | null
    activeSize?: (number | string) | null
    pledge?: _.Lovelace | null
    margin?: (number | string) | null
    fixedCost?: _.Lovelace | null
    rewardAccount?: string | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Pool>;
    readonly elements: __.ElementsOf<Pool>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class Pool extends _PoolAspect(__.Entity) {
}
export class Pools extends Array<Pool> {
  $count?: number
}

// entity 'Asset'
export declare function _AssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    unit?: __.Key<_.AssetUnit>
    policyId?: _.Blake2b224 | null
    assetNameHex?: string | null
    assetName?: string | null
    fingerprint?: string | null
    totalSupply?: string | null
    mintOrBurnCount?: number | null
    initialMintTxHash?: _.Blake2b256 | null
    initialMintTime?: number | null
    onchainMetadata?: string | null
    registryName?: string | null
    registryTicker?: string | null
    registryDecimals?: number | null
    registryDescription?: string | null
    registryUrl?: string | null
    registryLogo?: string | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Asset>;
    readonly elements: __.ElementsOf<Asset>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class Asset extends _AssetAspect(__.Entity) {
}
export class Assets extends Array<Asset> {
  $count?: number
}

// entity 'AssetHistory'
export declare function _AssetHistoryAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    unit?: __.Key<_.AssetUnit>
    txHash?: __.Key<_.Blake2b256>
    action?: string | null
    quantity?: string | null
    blockTime?: number | null
    blockHeight?: number | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AssetHistory>;
    readonly elements: __.ElementsOf<AssetHistory>;
    readonly actions: globalThis.Record<never, never>;
};
export class AssetHistory extends _AssetHistoryAspect(__.Entity) {
}
export class AssetHistory_ extends Array<AssetHistory> {
  $count?: number
}

// entity 'Drep'
export declare function _DrepAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    drepId?: __.Key<_.Bech32>
    hex?: string | null
    amount?: _.Lovelace | null
    hasScript?: boolean | null
    lastActiveEpoch?: number | null
    retired?: boolean | null
    expired?: boolean | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Drep>;
    readonly elements: __.ElementsOf<Drep>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class Drep extends _DrepAspect(__.Entity) {
}
export class Dreps extends Array<Drep> {
  $count?: number
}

// entity 'Address'
export declare function _AddressAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<_.Bech32>
    stakeAddress?: _.Bech32 | null
    type?: string | null
    isScript?: boolean | null
    totalLovelace?: _.Lovelace | null
    utxoCount?: number | null
    transactions?: __.Composition.of.many<AddressTransactions>
    assets?: __.Composition.of.many<AddressAssets>
    utxos?: __.Composition.of.many<AddressUTxOs>
    hasTransactions?: boolean | null
    hasAssets?: boolean | null
    hasUTxOs?: boolean | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Address>;
    readonly elements: __.ElementsOf<Address>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class Address extends _AddressAspect(__.Entity) {
}
export class Addresses extends Array<Address> {
  $count?: number
}

// entity 'AddressAsset'
export declare function _AddressAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressAsset>;
    readonly elements: __.ElementsOf<AddressAsset>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class AddressAsset extends _AddressAssetAspect(__.Entity) {
}
export class AddressAssets extends Array<AddressAsset> {
  $count?: number
}

// entity 'AddressUTxO'
export declare function _AddressUTxOAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    hash?: __.Key<_.Blake2b256>
    index?: __.Key<number>
    blockHash?: _.Blake2b256 | null
    utxodata_dataHash?: _.Blake2b256 | null
    utxodata_inlineDatum?: string | null
    utxodata_referenceScriptHash?: _.Blake2b256 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<UTxOAssets>
    hasAssets?: boolean | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressUTxO>;
    readonly elements: __.ElementsOf<AddressUTxO>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class AddressUTxO extends _AddressUTxOAspect(__.Entity) {
}
export class AddressUTxOs extends Array<AddressUTxO> {
  $count?: number
}

// entity 'UTxOAsset'
export declare function _UTxOAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    utxo?: __.Key<__.Association.to<AddressUTxO>>
    utxo_hash?: __.Key<_.Blake2b256>
    utxo_index?: __.Key<number>
    utxo_address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<UTxOAsset>;
    readonly elements: __.ElementsOf<UTxOAsset>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class UTxOAsset extends _UTxOAssetAspect(__.Entity) {
}
export class UTxOAssets extends Array<UTxOAsset> {
  $count?: number
}

// entity 'Account'
export declare function _AccountAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    stakeAddress?: __.Key<_.Bech32>
    active?: boolean | null
    activeEpoch?: number | null
    controlledAmount?: _.Lovelace | null
    rewardsSum?: _.Lovelace | null
    withdrawalsSum?: _.Lovelace | null
    reservesSum?: _.Lovelace | null
    treasurySum?: _.Lovelace | null
    withdrawableAmount?: _.Lovelace | null
    poolId?: __.Association.to<Pool> | null
    poolId_poolId?: _.Bech32 | null
    drepId?: __.Association.to<Drep> | null
    drepId_drepId?: _.Bech32 | null
    Address?: __.Composition.of.many<Addresses>
    hasAddresses?: boolean | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Account>;
    readonly elements: __.ElementsOf<Account>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class Account extends _AccountAspect(__.Entity) {
}
export class Accounts extends Array<Account> {
  $count?: number
}

// entity 'Transaction'
export declare function _TransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    hash?: __.Key<_.Blake2b256>
    blockHash?: _.Blake2b256 | null
    blockHeight?: number | null
    blockTime?: number | null
    slot?: number | null
    txIndex?: number | null
    fee?: _.Lovelace | null
    deposit?: _.Lovelace | null
    size?: number | null
    metadata?: __.Composition.of.many<TransactionMetadata_>
    inputs?: __.Composition.of.many<TransactionInputs>
    outputs?: __.Composition.of.many<TransactionOutputs>
    hasMetadata?: boolean | null
    hasInputs?: boolean | null
    hasOutputs?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Transaction>;
    readonly elements: __.ElementsOf<Transaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class Transaction extends _TransactionAspect(__.Entity) {
}
export class Transactions extends Array<Transaction> {
  $count?: number
}

// entity 'TransactionInput'
export declare function _TransactionInputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    inputIndex?: __.Key<number>
    address?: __.Association.to<Address> | null
    address_address?: _.Bech32 | null
    utxoData_dataHash?: _.Blake2b256 | null
    utxoData_inlineDatum?: string | null
    utxoData_referenceScriptHash?: _.Blake2b256 | null
    isCollateral?: boolean | null
    isReference?: boolean | null
    assets?: __.Composition.of.many<TransactionInputAssets>
    hasAddresses?: boolean | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionInput>;
    readonly elements: __.ElementsOf<TransactionInput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionInput extends _TransactionInputAspect(__.Entity) {
}
export class TransactionInputs extends Array<TransactionInput> {
  $count?: number
}

// entity 'TransactionInputAsset'
export declare function _TransactionInputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    input?: __.Key<__.Association.to<TransactionInput>>
    input_inputIndex?: __.Key<number>
    input_tx_hash?: __.Key<_.Blake2b256>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionInputAsset>;
    readonly elements: __.ElementsOf<TransactionInputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionInputAsset extends _TransactionInputAssetAspect(__.Entity) {
}
export class TransactionInputAssets extends Array<TransactionInputAsset> {
  $count?: number
}

// entity 'TransactionOutput'
export declare function _TransactionOutputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    outputIndex?: __.Key<number>
    address?: __.Association.to<Address> | null
    address_address?: _.Bech32 | null
    utxo_dataHash?: _.Blake2b256 | null
    utxo_inlineDatum?: string | null
    utxo_referenceScriptHash?: _.Blake2b256 | null
    assets?: __.Composition.of.many<TransactionOutputAssets>
    hasAddresses?: boolean | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionOutput>;
    readonly elements: __.ElementsOf<TransactionOutput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionOutput extends _TransactionOutputAspect(__.Entity) {
}
export class TransactionOutputs extends Array<TransactionOutput> {
  $count?: number
}

// entity 'TransactionOutputAsset'
export declare function _TransactionOutputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    output?: __.Key<__.Association.to<TransactionOutput>>
    output_outputIndex?: __.Key<number>
    output_tx_hash?: __.Key<_.Blake2b256>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionOutputAsset>;
    readonly elements: __.ElementsOf<TransactionOutputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionOutputAsset extends _TransactionOutputAssetAspect(__.Entity) {
}
export class TransactionOutputAssets extends Array<TransactionOutputAsset> {
  $count?: number
}

// entity 'TransactionMetadata'
export declare function _TransactionMetadataAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<number>
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    label?: _.MetadataLabel | null
    payload?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionMetadata>;
    readonly elements: __.ElementsOf<TransactionMetadata>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionMetadata extends _TransactionMetadataAspect(__.Entity) {
}
export class TransactionMetadata_ extends Array<TransactionMetadata> {
  $count?: number
}

// entity 'LedgerProtocolParameter'
export declare function _LedgerProtocolParameterAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    network?: __.Key<string>
    epoch?: __.Key<number>
    minFeeA?: number | null
    minFeeB?: number | null
    maxBlockSize?: number | null
    maxTxSize?: number | null
    maxBlockHeaderSize?: number | null
    keyDeposit?: string | null
    poolDeposit?: string | null
    eMax?: number | null
    nOpt?: number | null
    a0?: (number | string) | null
    rho?: (number | string) | null
    tau?: (number | string) | null
    minPoolCost?: string | null
    decentralisationParam?: (number | string) | null
    extraEntropy?: string | null
    protocolMajorVer?: number | null
    protocolMinorVer?: number | null
    minUtxo?: string | null
    nonce?: string | null
    costModels?: string | null
    priceMem?: (number | string) | null
    priceStep?: (number | string) | null
    maxTxExMem?: string | null
    maxTxExSteps?: string | null
    maxBlockExMem?: string | null
    maxBlockExSteps?: string | null
    maxValSize?: string | null
    collateralPercent?: number | null
    maxCollateralInputs?: number | null
    coinsPerUtxoSize?: string | null
    coinsPerUtxoWord?: string | null
    fetchedAt?: __.CdsTimestamp | null
    source?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<LedgerProtocolParameter>;
    readonly elements: __.ElementsOf<LedgerProtocolParameter>;
    readonly actions: globalThis.Record<never, never>;
};
export class LedgerProtocolParameter extends _LedgerProtocolParameterAspect(__.Entity) {
}
export class LedgerProtocolParameters extends Array<LedgerProtocolParameter> {
  $count?: number
}

// entity 'TransactionBuild'
export declare function _TransactionBuildAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    id?: __.Key<string>
    network?: string | null
    builderEngine?: string | null
    senderAddress?: _.Bech32 | null
    changeAddress?: _.Bech32 | null
    unsignedTxCbor?: string | null
    txBodyHash?: _.Blake2b256 | null
    fee?: _.Lovelace | null
    size?: number | null
    createdAt?: number | null
    inputs?: __.Composition.of.many<TransactionBuildInputs>
    outputs?: __.Composition.of.many<TransactionBuildOutputs>
    submission?: __.Association.to<TransactionSubmission> | null
    hasInputs?: boolean | null
    hasOutputs?: boolean | null
    wasSubmitted?: boolean | null
    scriptHash?: string | null
    mintScriptHash?: string | null
    fingerprint?: string | null
    scriptAddress?: string | null
    forcedInputsUsed?: number | null
    referenceInputsUsed?: number | null
    collateralAvailable?: boolean | null
  } & InstanceType<ReturnType<typeof _._temporalAspect<TBase>>>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuild>;
    readonly elements: __.ElementsOf<TransactionBuild>;
    readonly actions: typeof _.temporal.actions & globalThis.Record<never, never>;
};
export class TransactionBuild extends _TransactionBuildAspect(__.Entity) {
}
export class TransactionBuilds extends Array<TransactionBuild> {
  $count?: number
}

// entity 'TransactionBuildInput'
export declare function _TransactionBuildInputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    build?: __.Key<__.Association.to<TransactionBuild>>
    build_id?: __.Key<string>
    inputIndex?: __.Key<number>
    txHash?: _.Blake2b256 | null
    outputIndex?: number | null
    address?: _.Bech32 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<TransactionBuildInputAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildInput>;
    readonly elements: __.ElementsOf<TransactionBuildInput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildInput extends _TransactionBuildInputAspect(__.Entity) {
}
export class TransactionBuildInputs extends Array<TransactionBuildInput> {
  $count?: number
}

// entity 'TransactionBuildInputAsset'
export declare function _TransactionBuildInputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    input?: __.Key<__.Association.to<TransactionBuildInput>>
    input_inputIndex?: __.Key<number>
    input_build_id?: __.Key<string>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildInputAsset>;
    readonly elements: __.ElementsOf<TransactionBuildInputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildInputAsset extends _TransactionBuildInputAssetAspect(__.Entity) {
}
export class TransactionBuildInputAssets extends Array<TransactionBuildInputAsset> {
  $count?: number
}

// entity 'TransactionBuildOutput'
export declare function _TransactionBuildOutputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    build?: __.Key<__.Association.to<TransactionBuild>>
    build_id?: __.Key<string>
    outputIndex?: __.Key<number>
    address?: _.Bech32 | null
    lovelace?: _.Lovelace | null
    isChange?: boolean | null
    assets?: __.Composition.of.many<TransactionBuildOutputAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildOutput>;
    readonly elements: __.ElementsOf<TransactionBuildOutput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildOutput extends _TransactionBuildOutputAspect(__.Entity) {
}
export class TransactionBuildOutputs extends Array<TransactionBuildOutput> {
  $count?: number
}

// entity 'TransactionBuildOutputAsset'
export declare function _TransactionBuildOutputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    output?: __.Key<__.Association.to<TransactionBuildOutput>>
    output_outputIndex?: __.Key<number>
    output_build_id?: __.Key<string>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionBuildOutputAsset>;
    readonly elements: __.ElementsOf<TransactionBuildOutputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionBuildOutputAsset extends _TransactionBuildOutputAssetAspect(__.Entity) {
}
export class TransactionBuildOutputAssets extends Array<TransactionBuildOutputAsset> {
  $count?: number
}

// entity 'TransactionSubmission'
export declare function _TransactionSubmissionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    build?: __.Association.to<TransactionBuild> | null
    build_id?: string | null
    signedTxCbor?: string | null
    txHash?: _.Blake2b256 | null
    submittedAt?: number | null
    status?: _.SubmissionStatus | null
    errorCode?: string | null
    errorMessage?: string | null
    retryCount?: number | null
    errors?: __.Composition.of.many<TransactionSubmissionErrors>
    hasErrors?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionSubmission>;
    readonly elements: __.ElementsOf<TransactionSubmission>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionSubmission extends _TransactionSubmissionAspect(__.Entity) {
}
export class TransactionSubmissions extends Array<TransactionSubmission> {
  $count?: number
}

// entity 'TransactionSubmissionError'
export declare function _TransactionSubmissionErrorAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    submission?: __.Association.to<TransactionSubmission> | null
    submission_id?: string | null
    occurredAt?: number | null
    errorType?: string | null
    errorCode?: string | null
    errorMessage?: string | null
    errorDetails?: string | null
    isRecoverable?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionSubmissionError>;
    readonly elements: __.ElementsOf<TransactionSubmissionError>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionSubmissionError extends _TransactionSubmissionErrorAspect(__.Entity) {
}
export class TransactionSubmissionErrors extends Array<TransactionSubmissionError> {
  $count?: number
}

// entity 'AddressTransaction'
export declare function _AddressTransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    netAmount?: (number | string) | null
    blockTime?: number | null
    netAssets?: string | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressTransaction>;
    readonly elements: __.ElementsOf<AddressTransaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressTransaction extends _AddressTransactionAspect(__.Entity) {
}
export class AddressTransactions extends Array<AddressTransaction> {
  $count?: number
}

// entity 'AddressSigningRequest'
export declare function _AddressSigningRequestAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    signingRequest?: __.Key<__.Association.to<SigningRequest>>
    signingRequest_id?: __.Key<string>
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressSigningRequest>;
    readonly elements: __.ElementsOf<AddressSigningRequest>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressSigningRequest extends _AddressSigningRequestAspect(__.Entity) {
}
export class AddressSigningRequests extends Array<AddressSigningRequest> {
  $count?: number
}

// entity 'AddressTransactionBuild'
export declare function _AddressTransactionBuildAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    txBuild?: __.Key<__.Association.to<TransactionBuild>>
    txBuild_id?: __.Key<string>
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressTransactionBuild>;
    readonly elements: __.ElementsOf<AddressTransactionBuild>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressTransactionBuild extends _AddressTransactionBuildAspect(__.Entity) {
}
export class AddressTransactionBuilds extends Array<AddressTransactionBuild> {
  $count?: number
}

// entity 'SigningRequest'
export declare function _SigningRequestAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    build?: __.Association.to<TransactionBuild> | null
    build_id?: string | null
    txBodyHash?: _.Blake2b256 | null
    unsignedTxCbor?: string | null
    network?: string | null
    status?: _.SigningStatus | null
    createdAt?: __.CdsTimestamp | null
    expiresAt?: __.CdsTimestamp | null
    signedAt?: __.CdsTimestamp | null
    submittedAt?: __.CdsTimestamp | null
    cardanoCliCommand?: string | null
    cip30TxCbor?: string | null
    signedTxCbor?: string | null
    signerType?: string | null
    signerInfo?: string | null
    hsmKeyId?: string | null
    verifications?: __.Composition.of.many<SignatureVerifications>
    submission?: __.Association.to<TransactionSubmission> | null
    submission_id?: string | null
    errorMessage?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<SigningRequest>;
    readonly elements: __.ElementsOf<SigningRequest>;
    readonly actions: globalThis.Record<never, never>;
};
export class SigningRequest extends _SigningRequestAspect(__.Entity) {
}
export class SigningRequests extends Array<SigningRequest> {
  $count?: number
}

// entity 'SignatureVerification'
export declare function _SignatureVerificationAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<string>
    signingRequest?: __.Association.to<SigningRequest> | null
    signingRequest_id?: string | null
    signedTxCbor?: string | null
    isValid?: boolean | null
    txBodyHash?: _.Blake2b256 | null
    witnessCount?: number | null
    signerKeyHashes?: string | null
    errorMessage?: string | null
    warnings?: string | null
    verifiedAt?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<SignatureVerification>;
    readonly elements: __.ElementsOf<SignatureVerification>;
    readonly actions: globalThis.Record<never, never>;
};
export class SignatureVerification extends _SignatureVerificationAspect(__.Entity) {
}
export class SignatureVerifications extends Array<SignatureVerification> {
  $count?: number
}

// entity 'CardanoSyncState'
export declare function _CardanoSyncStateAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
    network?: string | null
    startSlot?: number | null
    startBlockHash?: _.Blake2b256 | null
    lastSlot?: number | null
    lastBlockHash?: _.Blake2b256 | null
    lastHeight?: number | null
    lastIndexedAt?: __.CdsTimestamp | null
    tipSlot?: number | null
    tipHeight?: number | null
    syncStatus?: _.CrawlSyncStatus | null
    lastError?: string | null
    lastErrorAt?: __.CdsTimestamp | null
    consecutiveErrors?: number | null
    desiredRunning?: boolean | null
    leaseOwner?: string | null
    leaseUntil?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<CardanoSyncState>;
    readonly elements: __.ElementsOf<CardanoSyncState>;
    readonly actions: globalThis.Record<never, never>;
};
export class CardanoSyncState extends _CardanoSyncStateAspect(__.Entity) {
}
export class CardanoSyncState_ extends Array<CardanoSyncState> {
  $count?: number
}

// entity 'CardanoReorgLog'
export declare function _CardanoReorgLogAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
    detectedAt?: __.CdsTimestamp | null
    forkSlot?: number | null
    forkHeight?: number | null
    oldTipHash?: _.Blake2b256 | null
    newTipHash?: _.Blake2b256 | null
    blocksRolledBack?: number | null
    status?: _.ReorgStatus | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<CardanoReorgLog>;
    readonly elements: __.ElementsOf<CardanoReorgLog>;
    readonly actions: globalThis.Record<never, never>;
};
export class CardanoReorgLog extends _CardanoReorgLogAspect(__.Entity) {
}
export class CardanoReorgLog_ extends Array<CardanoReorgLog> {
  $count?: number
}

// entity 'CardanoWorkerWallet'
export declare function _CardanoWorkerWalletAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    walletId?: __.Key<string>
    signerType?: _.WorkerSignerType | null
    address?: _.Bech32 | null
    publicKeyHash?: _.Blake2b224 | null
    enabled?: boolean | null
    leaseOwner?: string | null
    leaseUntil?: __.CdsTimestamp | null
    lastJobAt?: __.CdsTimestamp | null
    jobsConfirmed?: number | null
    jobsFailed?: number | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<CardanoWorkerWallet>;
    readonly elements: __.ElementsOf<CardanoWorkerWallet>;
    readonly actions: globalThis.Record<never, never>;
};
export class CardanoWorkerWallet extends _CardanoWorkerWalletAspect(__.Entity) {
}
export class CardanoWorkerWallets extends Array<CardanoWorkerWallet> {
  $count?: number
}

// entity 'CardanoWalletJob'
export declare function _CardanoWalletJobAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    ID?: __.Key<string>
    walletId?: string | null
    kind?: _.WalletJobKind | null
    status?: _.WalletJobStatus | null
    idempotencyKey?: string | null
    dedupKey?: string | null
    request?: string | null
    priority?: number | null
    notBefore?: __.CdsTimestamp | null
    attempt?: number | null
    maxAttempts?: number | null
    txHash?: _.Blake2b256 | null
    unsignedTxCbor?: string | null
    signedTxCbor?: string | null
    fee?: _.Lovelace | null
    submittedAt?: __.CdsTimestamp | null
    confirmedAt?: __.CdsTimestamp | null
    confirmedSlot?: number | null
    confirmedHeight?: number | null
    errorCode?: string | null
    errorMessage?: string | null
    createdAt?: __.CdsTimestamp | null
    createdBy?: string | null
    finishedAt?: __.CdsTimestamp | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<CardanoWalletJob>;
    readonly elements: __.ElementsOf<CardanoWalletJob>;
    readonly actions: globalThis.Record<never, never>;
};
export class CardanoWalletJob extends _CardanoWalletJobAspect(__.Entity) {
}
export class CardanoWalletJobs extends Array<CardanoWalletJob> {
  $count?: number
}
