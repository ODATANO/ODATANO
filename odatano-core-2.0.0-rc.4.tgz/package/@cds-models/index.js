// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./_')
// AssetSlice
module.exports.AssetSlice = createEntityProxy(['', 'AssetSlice'], { target: { is_singular: true } })
module.exports.__Array_AssetSlice_ = createEntityProxy(['', 'AssetSlice'], { target: { is_singular: false }})
// MetadataSlice
module.exports.MetadataSlice = createEntityProxy(['', 'MetadataSlice'], { target: { is_singular: true } })
module.exports.__Array_MetadataSlice_ = createEntityProxy(['', 'MetadataSlice'], { target: { is_singular: false }})
// UTxODataSlice
module.exports.UTxODataSlice = createEntityProxy(['', 'UTxODataSlice'], { target: { is_singular: true } })
module.exports.__Array_UTxODataSlice_ = createEntityProxy(['', 'UTxODataSlice'], { target: { is_singular: false }})
// ParsedInput
module.exports.ParsedInput = createEntityProxy(['', 'ParsedInput'], { target: { is_singular: true } })
module.exports.__Array_ParsedInput_ = createEntityProxy(['', 'ParsedInput'], { target: { is_singular: false }})
// ParsedAsset
module.exports.ParsedAsset = createEntityProxy(['', 'ParsedAsset'], { target: { is_singular: true } })
module.exports.__Array_ParsedAsset_ = createEntityProxy(['', 'ParsedAsset'], { target: { is_singular: false }})
// ParsedOutput
module.exports.ParsedOutput = createEntityProxy(['', 'ParsedOutput'], { target: { is_singular: true } })
module.exports.__Array_ParsedOutput_ = createEntityProxy(['', 'ParsedOutput'], { target: { is_singular: false }})
// ParsedWitnesses
module.exports.ParsedWitnesses = createEntityProxy(['', 'ParsedWitnesses'], { target: { is_singular: true } })
module.exports.__Array_ParsedWitnesses_ = createEntityProxy(['', 'ParsedWitnesses'], { target: { is_singular: false }})
// ParsedTransaction
module.exports.ParsedTransaction = createEntityProxy(['', 'ParsedTransaction'], { target: { is_singular: true } })
module.exports.__Array_ParsedTransaction_ = createEntityProxy(['', 'ParsedTransaction'], { target: { is_singular: false }})
// events
// actions
// enums
module.exports.SubmissionStatus ??= { pending: "pending", submitted: "submitted", confirmed: "confirmed", failed: "failed" }
module.exports.SigningStatus ??= { pending: "pending", signed: "signed", verified: "verified", submitting: "submitting", submitted: "submitted", expired: "expired", failed: "failed" }
module.exports.CrawlSyncStatus ??= { stopped: "stopped", syncing: "syncing", synced: "synced", error: "error" }
module.exports.ReorgStatus ??= { detected: "detected", rolling_back: "rolling_back", reindexing: "reindexing", completed: "completed" }
module.exports.WalletJobStatus ??= { pending: "pending", building: "building", submitting: "submitting", submitted: "submitted", confirmed: "confirmed", failed: "failed", cancelled: "cancelled" }
module.exports.WalletJobKind ??= { simpleAda: "simpleAda", metadata: "metadata", multiAsset: "multiAsset", mint: "mint", plutusSpend: "plutusSpend", submitSigned: "submitSigned" }
module.exports.WorkerSignerType ??= { hsm: "hsm", software: "software" }
