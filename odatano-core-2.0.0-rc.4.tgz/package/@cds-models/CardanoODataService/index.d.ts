// This is an automatically generated file. Please do not change its contents manually!
import * as _ from './..';
import * as __ from './../_';

/**
* Cardano OData Service
* 
* Handles external read-only queries for Cardano blockchain data, including:
* - Retrieving network information, blocks, epochs, pools, dreps, transactions, accounts, addresses, UTxOs, assets, and metadata
* - Providing actions for fetching specific data by identifiers (hashes, addresses, etc.) and for retrieving the latest blockchain state (latest block, epoch, protocol parameters)
* 
* ## Security: Authentication & Authorization
* 
* All services use `@requires: 'authenticated-user'` (service-level gate).
* The XSUAA scopes defined in xs-security.json (Read, Transact, Sign) are available
* for consumer-level role assignment but are NOT enforced per-action in ODATANO itself.
* 
* This is intentional — ODATANO is a blockchain bridge, not a multi-tenant application.
* Per-resource ownership checks (IDOR prevention) are deliberately omitted because:
* 
* 1. **Blockchain security model**: Unsigned transaction CBOR is not exploitable without
* the corresponding private key. Viewing a build/signing request does not enable
* fund theft — only the key holder can sign and submit.
* 
* 2. **Cross-address operations are legitimate**: Smart contract interactions routinely
* require building transactions for addresses the caller does not own — e.g. script
* redemptions, multi-party Plutus workflows, or DApp backends building on behalf of users.
* Enforcing sender == authenticated user would break these use cases.
* 
* 3. **Consumer responsibility**: Consumers deploying ODATANO in multi-user environments
* should add their own authorization layer (e.g. `@restrict` annotations, custom
* middleware) that maps JWT claims to allowed wallet addresses if needed.
*/
export default class {
  static readonly GetNetworkInformation: typeof GetNetworkInformation;
  static readonly GetBlockByHash: typeof GetBlockByHash;
  static readonly GetEpochByNumber: typeof GetEpochByNumber;
  static readonly GetPoolById: typeof GetPoolById;
  static readonly GetDrepById: typeof GetDrepById;
  static readonly GetAssetInfo: typeof GetAssetInfo;
  static readonly GetAssetHistory: typeof GetAssetHistory;
  static readonly GetAccountByStakeAddress: typeof GetAccountByStakeAddress;
  static readonly GetTransactionByHash: typeof GetTransactionByHash;
  static readonly GetMetadataByTxHash: typeof GetMetadataByTxHash;
  static readonly GetAddressByBech32: typeof GetAddressByBech32;
  static readonly GetUTxOsByAddress: typeof GetUTxOsByAddress;
  static readonly GetUTxOsByCredential: typeof GetUTxOsByCredential;
  static readonly GetAssetsByAddress: typeof GetAssetsByAddress;
  static readonly GetLatestTransactionsByAddress: typeof GetLatestTransactionsByAddress;
  static readonly GetLatestBlock: typeof GetLatestBlock;
  static readonly GetLatestEpoch: typeof GetLatestEpoch;
  static readonly GetLedgerProtocolParameters: typeof GetLedgerProtocolParameters;
  static readonly ParseTransactionCbor: typeof ParseTransactionCbor;
}

// entity 'NetworkInformation'
export declare function _NetworkInformationAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    network?: __.Key<string>
    maxSupply?: _.Lovelace | null
    totalSupply?: _.Lovelace | null
    circulatingSupply?: _.Lovelace | null
    lockedSupply?: _.Lovelace | null
    treasurySupply?: _.Lovelace | null
    reservesSupply?: _.Lovelace | null
    liveStake?: _.Lovelace | null
    activeStake?: _.Lovelace | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<NetworkInformation>;
    readonly elements: __.ElementsOf<NetworkInformation>;
    readonly actions: globalThis.Record<never, never>;
};
export class NetworkInformation extends _NetworkInformationAspect(__.Entity) {
}
export class NetworkInformation_ extends Array<NetworkInformation> {
  $count?: number
}

// entity 'Block'
export declare function _BlockAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    hash?: __.Key<string>
    time?: string | null
    height?: number | null
    slotLeader?: string | null
    epochNumber?: number | null
    epoch?: __.Association.to<Epoch> | null
    slot?: number | null
    epochSlot?: number | null
    size?: number | null
    txCount?: number | null
    fees?: _.Lovelace | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Block>;
    readonly elements: __.ElementsOf<Block>;
    readonly actions: globalThis.Record<never, never>;
};
export class Block extends _BlockAspect(__.Entity) {
}
export class Blocks extends Array<Block> {
  $count?: number
}

// entity 'Epoch'
export declare function _EpochAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    epoch?: __.Key<number>
    startTime?: number | null
    endTime?: number | null
    firstBlockTime?: number | null
    lastBlockTime?: number | null
    blockCount?: number | null
    txCount?: number | null
    output?: string | null
    fees?: _.Lovelace | null
    activeStake?: _.Lovelace | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Epoch>;
    readonly elements: __.ElementsOf<Epoch>;
    readonly actions: globalThis.Record<never, never>;
};
export class Epoch extends _EpochAspect(__.Entity) {
}
export class Epochs extends Array<Epoch> {
  $count?: number
}

// entity 'Pool'
export declare function _PoolAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    poolId?: __.Key<_.Bech32>
    vrfKeyHash?: string | null
    blocksMinted?: number | null
    blocksEpoch?: number | null
    liveStake?: _.Lovelace | null
    liveSize?: (number | string) | null
    liveSaturation?: (number | string) | null
    liveDelegators?: number | null
    activeStake?: _.Lovelace | null
    activeSize?: (number | string) | null
    pledge?: _.Lovelace | null
    margin?: (number | string) | null
    fixedCost?: _.Lovelace | null
    rewardAccount?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Pool>;
    readonly elements: __.ElementsOf<Pool>;
    readonly actions: globalThis.Record<never, never>;
};
export class Pool extends _PoolAspect(__.Entity) {
}
export class Pools extends Array<Pool> {
  $count?: number
}

// entity 'Drep'
export declare function _DrepAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    drepId?: __.Key<_.Bech32>
    hex?: string | null
    amount?: _.Lovelace | null
    hasScript?: boolean | null
    lastActiveEpoch?: number | null
    retired?: boolean | null
    expired?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Drep>;
    readonly elements: __.ElementsOf<Drep>;
    readonly actions: globalThis.Record<never, never>;
};
export class Drep extends _DrepAspect(__.Entity) {
}
export class Dreps extends Array<Drep> {
  $count?: number
}

// entity 'Asset'
export declare function _AssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    unit?: __.Key<_.AssetUnit>
    policyId?: _.Blake2b224 | null
    assetNameHex?: string | null
    assetName?: string | null
    fingerprint?: string | null
    totalSupply?: string | null
    mintOrBurnCount?: number | null
    initialMintTxHash?: _.Blake2b256 | null
    initialMintTime?: number | null
    onchainMetadata?: string | null
    registryName?: string | null
    registryTicker?: string | null
    registryDecimals?: number | null
    registryDescription?: string | null
    registryUrl?: string | null
    registryLogo?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Asset>;
    readonly elements: __.ElementsOf<Asset>;
    readonly actions: globalThis.Record<never, never>;
};
export class Asset extends _AssetAspect(__.Entity) {
}
export class Assets extends Array<Asset> {
  $count?: number
}

// entity 'AssetHistory'
export declare function _AssetHistoryAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    unit?: __.Key<_.AssetUnit>
    txHash?: __.Key<_.Blake2b256>
    action?: string | null
    quantity?: string | null
    blockTime?: number | null
    blockHeight?: number | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AssetHistory>;
    readonly elements: __.ElementsOf<AssetHistory>;
    readonly actions: globalThis.Record<never, never>;
};
export class AssetHistory extends _AssetHistoryAspect(__.Entity) {
}
export class AssetHistory_ extends Array<AssetHistory> {
  $count?: number
}

// entity 'Transaction'
export declare function _TransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    hash?: __.Key<_.Blake2b256>
    blockHash?: _.Blake2b256 | null
    blockHeight?: number | null
    blockTime?: number | null
    slot?: number | null
    txIndex?: number | null
    fee?: _.Lovelace | null
    deposit?: _.Lovelace | null
    size?: number | null
    metadata?: __.Composition.of.many<TransactionMetadata_>
    inputs?: __.Composition.of.many<TransactionInputs>
    outputs?: __.Composition.of.many<TransactionOutputs>
    hasMetadata?: boolean | null
    hasInputs?: boolean | null
    hasOutputs?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Transaction>;
    readonly elements: __.ElementsOf<Transaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class Transaction extends _TransactionAspect(__.Entity) {
}
export class Transactions extends Array<Transaction> {
  $count?: number
}

// entity 'TransactionInput'
export declare function _TransactionInputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    inputIndex?: __.Key<number>
    address?: __.Association.to<Address> | null
    address_address?: _.Bech32 | null
    utxoData_dataHash?: _.Blake2b256 | null
    utxoData_inlineDatum?: string | null
    utxoData_referenceScriptHash?: _.Blake2b256 | null
    isCollateral?: boolean | null
    isReference?: boolean | null
    assets?: __.Composition.of.many<TransactionInputAssets>
    hasAddresses?: boolean | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionInput>;
    readonly elements: __.ElementsOf<TransactionInput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionInput extends _TransactionInputAspect(__.Entity) {
}
export class TransactionInputs extends Array<TransactionInput> {
  $count?: number
}

// entity 'TransactionOutput'
export declare function _TransactionOutputAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    outputIndex?: __.Key<number>
    address?: __.Association.to<Address> | null
    address_address?: _.Bech32 | null
    utxo_dataHash?: _.Blake2b256 | null
    utxo_inlineDatum?: string | null
    utxo_referenceScriptHash?: _.Blake2b256 | null
    assets?: __.Composition.of.many<TransactionOutputAssets>
    hasAddresses?: boolean | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionOutput>;
    readonly elements: __.ElementsOf<TransactionOutput>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionOutput extends _TransactionOutputAspect(__.Entity) {
}
export class TransactionOutputs extends Array<TransactionOutput> {
  $count?: number
}

// entity 'TransactionInputAsset'
export declare function _TransactionInputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    input?: __.Key<__.Association.to<TransactionInput>>
    input_inputIndex?: __.Key<number>
    input_tx_hash?: __.Key<_.Blake2b256>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionInputAsset>;
    readonly elements: __.ElementsOf<TransactionInputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionInputAsset extends _TransactionInputAssetAspect(__.Entity) {
}
export class TransactionInputAssets extends Array<TransactionInputAsset> {
  $count?: number
}

// entity 'TransactionOutputAsset'
export declare function _TransactionOutputAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    output?: __.Key<__.Association.to<TransactionOutput>>
    output_outputIndex?: __.Key<number>
    output_tx_hash?: __.Key<_.Blake2b256>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionOutputAsset>;
    readonly elements: __.ElementsOf<TransactionOutputAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionOutputAsset extends _TransactionOutputAssetAspect(__.Entity) {
}
export class TransactionOutputAssets extends Array<TransactionOutputAsset> {
  $count?: number
}

// entity 'Account'
export declare function _AccountAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    stakeAddress?: __.Key<_.Bech32>
    active?: boolean | null
    activeEpoch?: number | null
    controlledAmount?: _.Lovelace | null
    rewardsSum?: _.Lovelace | null
    withdrawalsSum?: _.Lovelace | null
    reservesSum?: _.Lovelace | null
    treasurySum?: _.Lovelace | null
    withdrawableAmount?: _.Lovelace | null
    poolId?: __.Association.to<Pool> | null
    poolId_poolId?: _.Bech32 | null
    drepId?: __.Association.to<Drep> | null
    drepId_drepId?: _.Bech32 | null
    Address?: __.Composition.of.many<Addresses>
    hasAddresses?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Account>;
    readonly elements: __.ElementsOf<Account>;
    readonly actions: globalThis.Record<never, never>;
};
export class Account extends _AccountAspect(__.Entity) {
}
export class Accounts extends Array<Account> {
  $count?: number
}

// entity 'Address'
export declare function _AddressAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<_.Bech32>
    stakeAddress?: _.Bech32 | null
    type?: string | null
    isScript?: boolean | null
    totalLovelace?: _.Lovelace | null
    utxoCount?: number | null
    transactions?: __.Composition.of.many<AddressTransactions>
    assets?: __.Composition.of.many<AddressAssets>
    utxos?: __.Composition.of.many<AddressUTxOs>
    hasTransactions?: boolean | null
    hasAssets?: boolean | null
    hasUTxOs?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<Address>;
    readonly elements: __.ElementsOf<Address>;
    readonly actions: globalThis.Record<never, never>;
};
export class Address extends _AddressAspect(__.Entity) {
}
export class Addresses extends Array<Address> {
  $count?: number
}

// entity 'AddressAsset'
export declare function _AddressAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressAsset>;
    readonly elements: __.ElementsOf<AddressAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressAsset extends _AddressAssetAspect(__.Entity) {
}
export class AddressAssets extends Array<AddressAsset> {
  $count?: number
}

// entity 'AddressUTxO'
export declare function _AddressUTxOAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    hash?: __.Key<_.Blake2b256>
    index?: __.Key<number>
    blockHash?: _.Blake2b256 | null
    utxodata_dataHash?: _.Blake2b256 | null
    utxodata_inlineDatum?: string | null
    utxodata_referenceScriptHash?: _.Blake2b256 | null
    lovelace?: _.Lovelace | null
    assets?: __.Composition.of.many<UTxOAssets>
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressUTxO>;
    readonly elements: __.ElementsOf<AddressUTxO>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressUTxO extends _AddressUTxOAspect(__.Entity) {
}
export class AddressUTxOs extends Array<AddressUTxO> {
  $count?: number
}

// entity 'AddressTransaction'
export declare function _AddressTransactionAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    address?: __.Key<__.Association.to<Address>>
    address_address?: __.Key<_.Bech32>
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    netAmount?: (number | string) | null
    blockTime?: number | null
    netAssets?: string | null
    hasAssets?: boolean | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<AddressTransaction>;
    readonly elements: __.ElementsOf<AddressTransaction>;
    readonly actions: globalThis.Record<never, never>;
};
export class AddressTransaction extends _AddressTransactionAspect(__.Entity) {
}
export class AddressTransactions extends Array<AddressTransaction> {
  $count?: number
}

// entity 'UTxOAsset'
export declare function _UTxOAssetAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    validFrom?: __.CdsTimestamp | null
    validTo?: __.CdsTimestamp | null
    utxo?: __.Key<__.Association.to<AddressUTxO>>
    utxo_hash?: __.Key<_.Blake2b256>
    utxo_index?: __.Key<number>
    utxo_address_address?: __.Key<_.Bech32>
    unit?: __.Key<_.AssetUnit>
    asset_quantity?: _.Lovelace | null
    asset_policyId?: _.Blake2b224 | null
    asset_assetNameHex?: _.HexBytes | null
    asset_assetName?: string | null
    asset_fingerprint?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<UTxOAsset>;
    readonly elements: __.ElementsOf<UTxOAsset>;
    readonly actions: globalThis.Record<never, never>;
};
export class UTxOAsset extends _UTxOAssetAspect(__.Entity) {
}
export class UTxOAssets extends Array<UTxOAsset> {
  $count?: number
}

// entity 'TransactionMetadata'
export declare function _TransactionMetadataAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    id?: __.Key<number>
    tx?: __.Key<__.Association.to<Transaction>>
    tx_hash?: __.Key<_.Blake2b256>
    label?: _.MetadataLabel | null
    payload?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<TransactionMetadata>;
    readonly elements: __.ElementsOf<TransactionMetadata>;
    readonly actions: globalThis.Record<never, never>;
};
export class TransactionMetadata extends _TransactionMetadataAspect(__.Entity) {
}
export class TransactionMetadata_ extends Array<TransactionMetadata> {
  $count?: number
}

// entity 'LedgerProtocolParameter'
export declare function _LedgerProtocolParameterAspect<TBase extends new (...args: any[]) => object>(Base: TBase): {
  new (...args: any[]): {
    network?: __.Key<string>
    epoch?: __.Key<number>
    minFeeA?: number | null
    minFeeB?: number | null
    maxBlockSize?: number | null
    maxTxSize?: number | null
    maxBlockHeaderSize?: number | null
    keyDeposit?: string | null
    poolDeposit?: string | null
    eMax?: number | null
    nOpt?: number | null
    a0?: (number | string) | null
    rho?: (number | string) | null
    tau?: (number | string) | null
    minPoolCost?: string | null
    decentralisationParam?: (number | string) | null
    extraEntropy?: string | null
    protocolMajorVer?: number | null
    protocolMinorVer?: number | null
    minUtxo?: string | null
    nonce?: string | null
    costModels?: string | null
    priceMem?: (number | string) | null
    priceStep?: (number | string) | null
    maxTxExMem?: string | null
    maxTxExSteps?: string | null
    maxBlockExMem?: string | null
    maxBlockExSteps?: string | null
    maxValSize?: string | null
    collateralPercent?: number | null
    maxCollateralInputs?: number | null
    coinsPerUtxoSize?: string | null
    coinsPerUtxoWord?: string | null
    fetchedAt?: __.CdsTimestamp | null
    source?: string | null
  } & InstanceType<TBase>
    readonly kind: 'entity';
    readonly keys: __.KeysOf<LedgerProtocolParameter>;
    readonly elements: __.ElementsOf<LedgerProtocolParameter>;
    readonly actions: globalThis.Record<never, never>;
};
export class LedgerProtocolParameter extends _LedgerProtocolParameterAspect(__.Entity) {
}
export class LedgerProtocolParameters extends Array<LedgerProtocolParameter> {
  $count?: number
}


export declare const GetNetworkInformation:  {
  // positional
  (): globalThis.Promise<NetworkInformation | null> | NetworkInformation | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<NetworkInformation | null> | NetworkInformation | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<NetworkInformation | null> | NetworkInformation | null, __self: never
  kind: 'action'
}

export declare const GetBlockByHash:  {
  // positional
  (hash: _.Blake2b256 | null): globalThis.Promise<Block | null> | Block | null
  // named
  ({hash}: {hash?: _.Blake2b256 | null}): globalThis.Promise<Block | null> | Block | null
  // metadata (do not use)
  __parameters: {hash?: _.Blake2b256 | null}, __returns: globalThis.Promise<Block | null> | Block | null, __self: never
  kind: 'action'
}

export declare const GetEpochByNumber:  {
  // positional
  (epochNumber: number | null): globalThis.Promise<Epoch | null> | Epoch | null
  // named
  ({epochNumber}: {epochNumber?: number | null}): globalThis.Promise<Epoch | null> | Epoch | null
  // metadata (do not use)
  __parameters: {epochNumber?: number | null}, __returns: globalThis.Promise<Epoch | null> | Epoch | null, __self: never
  kind: 'action'
}

export declare const GetPoolById:  {
  // positional
  (poolId: string | null): globalThis.Promise<Pool | null> | Pool | null
  // named
  ({poolId}: {poolId?: string | null}): globalThis.Promise<Pool | null> | Pool | null
  // metadata (do not use)
  __parameters: {poolId?: string | null}, __returns: globalThis.Promise<Pool | null> | Pool | null, __self: never
  kind: 'action'
}

export declare const GetDrepById:  {
  // positional
  (drepId: string | null): globalThis.Promise<Drep | null> | Drep | null
  // named
  ({drepId}: {drepId?: string | null}): globalThis.Promise<Drep | null> | Drep | null
  // metadata (do not use)
  __parameters: {drepId?: string | null}, __returns: globalThis.Promise<Drep | null> | Drep | null, __self: never
  kind: 'action'
}

export declare const GetAssetInfo:  {
  // positional
  (unit: _.AssetUnit | null): globalThis.Promise<Asset | null> | Asset | null
  // named
  ({unit}: {unit?: _.AssetUnit | null}): globalThis.Promise<Asset | null> | Asset | null
  // metadata (do not use)
  __parameters: {unit?: _.AssetUnit | null}, __returns: globalThis.Promise<Asset | null> | Asset | null, __self: never
  kind: 'action'
}

export declare const GetAssetHistory:  {
  // positional
  (unit: _.AssetUnit | null, limit: number | null): globalThis.Promise<Array<AssetHistory>> | Array<AssetHistory>
  // named
  ({unit, limit}: {unit?: _.AssetUnit | null, limit?: number | null}): globalThis.Promise<Array<AssetHistory>> | Array<AssetHistory>
  // metadata (do not use)
  __parameters: {unit?: _.AssetUnit | null, limit?: number | null}, __returns: globalThis.Promise<Array<AssetHistory>> | Array<AssetHistory>, __self: never
  kind: 'action'
}

export declare const GetAccountByStakeAddress:  {
  // positional
  (stakeAddress: _.Bech32 | null): globalThis.Promise<Account | null> | Account | null
  // named
  ({stakeAddress}: {stakeAddress?: _.Bech32 | null}): globalThis.Promise<Account | null> | Account | null
  // metadata (do not use)
  __parameters: {stakeAddress?: _.Bech32 | null}, __returns: globalThis.Promise<Account | null> | Account | null, __self: never
  kind: 'action'
}

export declare const GetTransactionByHash:  {
  // positional
  (hash: _.Blake2b256 | null): globalThis.Promise<Transaction | null> | Transaction | null
  // named
  ({hash}: {hash?: _.Blake2b256 | null}): globalThis.Promise<Transaction | null> | Transaction | null
  // metadata (do not use)
  __parameters: {hash?: _.Blake2b256 | null}, __returns: globalThis.Promise<Transaction | null> | Transaction | null, __self: never
  kind: 'action'
}

export declare const GetMetadataByTxHash:  {
  // positional
  (txHash: _.Blake2b256 | null): globalThis.Promise<Array<TransactionMetadata>> | Array<TransactionMetadata>
  // named
  ({txHash}: {txHash?: _.Blake2b256 | null}): globalThis.Promise<Array<TransactionMetadata>> | Array<TransactionMetadata>
  // metadata (do not use)
  __parameters: {txHash?: _.Blake2b256 | null}, __returns: globalThis.Promise<Array<TransactionMetadata>> | Array<TransactionMetadata>, __self: never
  kind: 'action'
}

export declare const GetAddressByBech32:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<Address | null> | Address | null
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<Address | null> | Address | null
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<Address | null> | Address | null, __self: never
  kind: 'action'
}

export declare const GetUTxOsByAddress:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<Array<AddressUTxO>> | Array<AddressUTxO>
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<Array<AddressUTxO>> | Array<AddressUTxO>
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<Array<AddressUTxO>> | Array<AddressUTxO>, __self: never
  kind: 'action'
}

export declare const GetUTxOsByCredential:  {
  // positional
  (credential: string | null): globalThis.Promise<Array<AddressUTxO>> | Array<AddressUTxO>
  // named
  ({credential}: {credential?: string | null}): globalThis.Promise<Array<AddressUTxO>> | Array<AddressUTxO>
  // metadata (do not use)
  __parameters: {credential?: string | null}, __returns: globalThis.Promise<Array<AddressUTxO>> | Array<AddressUTxO>, __self: never
  kind: 'action'
}

export declare const GetAssetsByAddress:  {
  // positional
  (address: _.Bech32 | null): globalThis.Promise<Array<AddressAsset>> | Array<AddressAsset>
  // named
  ({address}: {address?: _.Bech32 | null}): globalThis.Promise<Array<AddressAsset>> | Array<AddressAsset>
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null}, __returns: globalThis.Promise<Array<AddressAsset>> | Array<AddressAsset>, __self: never
  kind: 'action'
}

export declare const GetLatestTransactionsByAddress:  {
  // positional
  (address: _.Bech32 | null, limit: number | null): globalThis.Promise<Array<AddressTransaction>> | Array<AddressTransaction>
  // named
  ({address, limit}: {address?: _.Bech32 | null, limit?: number | null}): globalThis.Promise<Array<AddressTransaction>> | Array<AddressTransaction>
  // metadata (do not use)
  __parameters: {address?: _.Bech32 | null, limit?: number | null}, __returns: globalThis.Promise<Array<AddressTransaction>> | Array<AddressTransaction>, __self: never
  kind: 'action'
}

export declare const GetLatestBlock:  {
  // positional
  (): globalThis.Promise<Block | null> | Block | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<Block | null> | Block | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<Block | null> | Block | null, __self: never
  kind: 'action'
}

export declare const GetLatestEpoch:  {
  // positional
  (): globalThis.Promise<Epoch | null> | Epoch | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<Epoch | null> | Epoch | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<Epoch | null> | Epoch | null, __self: never
  kind: 'action'
}

export declare const GetLedgerProtocolParameters:  {
  // positional
  (): globalThis.Promise<LedgerProtocolParameter | null> | LedgerProtocolParameter | null
  // named
  ({}: globalThis.Record<never, never>): globalThis.Promise<LedgerProtocolParameter | null> | LedgerProtocolParameter | null
  // metadata (do not use)
  __parameters: globalThis.Record<never, never>, __returns: globalThis.Promise<LedgerProtocolParameter | null> | LedgerProtocolParameter | null, __self: never
  kind: 'action'
}

export declare const ParseTransactionCbor:  {
  // positional
  (cbor: string | null): globalThis.Promise<_.ParsedTransaction | null> | _.ParsedTransaction | null
  // named
  ({cbor}: {cbor?: string | null}): globalThis.Promise<_.ParsedTransaction | null> | _.ParsedTransaction | null
  // metadata (do not use)
  __parameters: {cbor?: string | null}, __returns: globalThis.Promise<_.ParsedTransaction | null> | _.ParsedTransaction | null, __self: never
  kind: 'action'
}