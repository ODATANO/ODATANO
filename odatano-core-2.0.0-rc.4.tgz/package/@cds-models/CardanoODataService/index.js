// This is an automatically generated file. Please do not change its contents manually!
const { createEntityProxy } = require('./../_')
// service
const CardanoODataService = { name: 'CardanoODataService' }
module.exports = CardanoODataService
module.exports.CardanoODataService = CardanoODataService
// NetworkInformation
module.exports.NetworkInformation = createEntityProxy(['CardanoODataService', 'NetworkInformation'], { target: { is_singular: true } })
module.exports.NetworkInformation_ = createEntityProxy(['CardanoODataService', 'NetworkInformation'], { target: { is_singular: false }})
// Blocks
module.exports.Block = createEntityProxy(['CardanoODataService', 'Blocks'], { target: { is_singular: true } })
module.exports.Blocks = createEntityProxy(['CardanoODataService', 'Blocks'], { target: { is_singular: false }})
// Epochs
module.exports.Epoch = createEntityProxy(['CardanoODataService', 'Epochs'], { target: { is_singular: true } })
module.exports.Epochs = createEntityProxy(['CardanoODataService', 'Epochs'], { target: { is_singular: false }})
// Pools
module.exports.Pool = createEntityProxy(['CardanoODataService', 'Pools'], { target: { is_singular: true } })
module.exports.Pools = createEntityProxy(['CardanoODataService', 'Pools'], { target: { is_singular: false }})
// Dreps
module.exports.Drep = createEntityProxy(['CardanoODataService', 'Dreps'], { target: { is_singular: true } })
module.exports.Dreps = createEntityProxy(['CardanoODataService', 'Dreps'], { target: { is_singular: false }})
// Assets
module.exports.Asset = createEntityProxy(['CardanoODataService', 'Assets'], { target: { is_singular: true } })
module.exports.Assets = createEntityProxy(['CardanoODataService', 'Assets'], { target: { is_singular: false }})
// AssetHistory
module.exports.AssetHistory = createEntityProxy(['CardanoODataService', 'AssetHistory'], { target: { is_singular: true } })
module.exports.AssetHistory_ = createEntityProxy(['CardanoODataService', 'AssetHistory'], { target: { is_singular: false }})
// Transactions
module.exports.Transaction = createEntityProxy(['CardanoODataService', 'Transactions'], { target: { is_singular: true } })
module.exports.Transactions = createEntityProxy(['CardanoODataService', 'Transactions'], { target: { is_singular: false }})
// TransactionInputs
module.exports.TransactionInput = createEntityProxy(['CardanoODataService', 'TransactionInputs'], { target: { is_singular: true } })
module.exports.TransactionInputs = createEntityProxy(['CardanoODataService', 'TransactionInputs'], { target: { is_singular: false }})
// TransactionOutputs
module.exports.TransactionOutput = createEntityProxy(['CardanoODataService', 'TransactionOutputs'], { target: { is_singular: true } })
module.exports.TransactionOutputs = createEntityProxy(['CardanoODataService', 'TransactionOutputs'], { target: { is_singular: false }})
// TransactionInputAssets
module.exports.TransactionInputAsset = createEntityProxy(['CardanoODataService', 'TransactionInputAssets'], { target: { is_singular: true } })
module.exports.TransactionInputAssets = createEntityProxy(['CardanoODataService', 'TransactionInputAssets'], { target: { is_singular: false }})
// TransactionOutputAssets
module.exports.TransactionOutputAsset = createEntityProxy(['CardanoODataService', 'TransactionOutputAssets'], { target: { is_singular: true } })
module.exports.TransactionOutputAssets = createEntityProxy(['CardanoODataService', 'TransactionOutputAssets'], { target: { is_singular: false }})
// Accounts
module.exports.Account = createEntityProxy(['CardanoODataService', 'Accounts'], { target: { is_singular: true } })
module.exports.Accounts = createEntityProxy(['CardanoODataService', 'Accounts'], { target: { is_singular: false }})
// Addresses
module.exports.Address = createEntityProxy(['CardanoODataService', 'Addresses'], { target: { is_singular: true } })
module.exports.Addresses = createEntityProxy(['CardanoODataService', 'Addresses'], { target: { is_singular: false }})
// AddressAssets
module.exports.AddressAsset = createEntityProxy(['CardanoODataService', 'AddressAssets'], { target: { is_singular: true } })
module.exports.AddressAssets = createEntityProxy(['CardanoODataService', 'AddressAssets'], { target: { is_singular: false }})
// AddressUTxOs
module.exports.AddressUTxO = createEntityProxy(['CardanoODataService', 'AddressUTxOs'], { target: { is_singular: true } })
module.exports.AddressUTxOs = createEntityProxy(['CardanoODataService', 'AddressUTxOs'], { target: { is_singular: false }})
// AddressTransactions
module.exports.AddressTransaction = createEntityProxy(['CardanoODataService', 'AddressTransactions'], { target: { is_singular: true } })
module.exports.AddressTransactions = createEntityProxy(['CardanoODataService', 'AddressTransactions'], { target: { is_singular: false }})
// UTxOAssets
module.exports.UTxOAsset = createEntityProxy(['CardanoODataService', 'UTxOAssets'], { target: { is_singular: true } })
module.exports.UTxOAssets = createEntityProxy(['CardanoODataService', 'UTxOAssets'], { target: { is_singular: false }})
// TransactionMetadata
module.exports.TransactionMetadata = createEntityProxy(['CardanoODataService', 'TransactionMetadata'], { target: { is_singular: true } })
module.exports.TransactionMetadata_ = createEntityProxy(['CardanoODataService', 'TransactionMetadata'], { target: { is_singular: false }})
// LedgerProtocolParameters
module.exports.LedgerProtocolParameter = createEntityProxy(['CardanoODataService', 'LedgerProtocolParameters'], { target: { is_singular: true } })
module.exports.LedgerProtocolParameters = createEntityProxy(['CardanoODataService', 'LedgerProtocolParameters'], { target: { is_singular: false }})
// events
// actions
module.exports.GetNetworkInformation = 'GetNetworkInformation'
module.exports.GetBlockByHash = 'GetBlockByHash'
module.exports.GetEpochByNumber = 'GetEpochByNumber'
module.exports.GetPoolById = 'GetPoolById'
module.exports.GetDrepById = 'GetDrepById'
module.exports.GetAssetInfo = 'GetAssetInfo'
module.exports.GetAssetHistory = 'GetAssetHistory'
module.exports.GetAccountByStakeAddress = 'GetAccountByStakeAddress'
module.exports.GetTransactionByHash = 'GetTransactionByHash'
module.exports.GetMetadataByTxHash = 'GetMetadataByTxHash'
module.exports.GetAddressByBech32 = 'GetAddressByBech32'
module.exports.GetUTxOsByAddress = 'GetUTxOsByAddress'
module.exports.GetUTxOsByCredential = 'GetUTxOsByCredential'
module.exports.GetAssetsByAddress = 'GetAssetsByAddress'
module.exports.GetLatestTransactionsByAddress = 'GetLatestTransactionsByAddress'
module.exports.GetLatestBlock = 'GetLatestBlock'
module.exports.GetLatestEpoch = 'GetLatestEpoch'
module.exports.GetLedgerProtocolParameters = 'GetLedgerProtocolParameters'
module.exports.ParseTransactionCbor = 'ParseTransactionCbor'
// enums
